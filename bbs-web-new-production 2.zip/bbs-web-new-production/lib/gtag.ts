export const trackConversion = ({
  send_to,
  value = 1,
  currency = "INR",
}: {
  send_to: string;
  value?: number;
  currency?: string;
}) => {
  if (typeof window === "undefined" || !window.gtag) return;

  window.gtag("event", "conversion", {
    send_to,
    value,
    currency,
  });
};