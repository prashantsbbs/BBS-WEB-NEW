'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../common/button';
import { international_sec, stateOfArt } from '../constant/constant';
import { whyBBSSubHead } from '../constant/whyBBS';
import { useEffect, useState } from 'react';

const WhyBBS = () => {
  const defaultState = {
    mobileBanner: false,
  };

  const [state, setState] = useState(defaultState);

  const getBodyWidth = (evt: any) => {
    if (evt.target.innerWidth < 768) {
      setState((prev: any) => ({ mobileBanner: true }));
    } else setState((prev: any) => ({ mobileBanner: false }));
  };

  useEffect(() => {
    if (window) {
      window.addEventListener('resize', getBodyWidth);
      const screenWidth = window.screen.width;

      if (screenWidth < 768) {
        setState((prev: any) => ({ mobileBanner: true }));
      } else setState((prev: any) => ({ mobileBanner: false }));
    }
    return () => window && window.removeEventListener('resize', getBodyWidth);
  }, []);

  return (
    <>
      <div className="bg-gray ">
        {/* why BBS */}
        <div className="m-auto  animate__animated animate__slideInLeft">
          {state.mobileBanner ? (
            <Image
              unoptimized={true}
              src={'/banner/bannerAboutM.webp'}
              width={1000}
              height={1000}
              alt={'Banner About'}
              className=" bgImage_aboutM   "
            />
          ) : (
            <Image
              unoptimized={true}
              src={'/banner/bannerAbout.webp'}
              width={1400}
              height={1000}
              alt={'Banner About'}
              className=" bgImage_aboutD   "
            />
          )}
        </div>

        <div className="w-[80vw] p-4  m-auto ">
          <h1 className="m-0">Why BBS</h1>
          <h3 className="text-justify m-0">
            &emsp;&emsp;As a top ranking institute in India, BBS Group of
            Institution provides the perfect infrastructure to deliver an
            educational experience that rivals international standards.
          </h3>
        </div>
      </div>
      <div className="bg-gray">
        <div className="w-[80vw] p-4  m-auto ">
          <h2 className="font-semibold mb-4">
            BBS Group of Institution&apos;s Learning Facilities Offer:
          </h2>
          <div className="grid md:grid-cols-2 grid-cols-1 gap-4">
            {whyBBSSubHead.map((subHead: any, index: number) => (
              <div
                key={index}
                className="sm:flex block gap-4 p-4 h-full	shadow-md bg-whiteCol rounded-lg m-auto"
              >
                <Image
                  src={subHead.image}
                  unoptimized={true}
                  width={700}
                  height={150}
                  alt={'whyBBS Sub Head'}
                  className=" customWidth-30   rounded-lg min-h-52"
                />
                <div className="m-auto">
                  <h2 className="font-semibold  mb-0">{subHead.title}</h2>
                  <h4 className="text-justify mt-1">{subHead.content}</h4>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default WhyBBS;
