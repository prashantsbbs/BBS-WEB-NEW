import ApplyOnlinePage from "../apply-online/ApplyOnlinePage";


export default function Page() {
  return <ApplyOnlinePage source="google"/>;
}