'use client';
import Image from 'next/image';
import 'animate.css';
import Arrow from '../common/arrow';
import ScrollTrigger from 'react-scroll-trigger';
import { Suspense, useEffect, useState } from 'react';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import MasterCourse from '../eligibility-criteria/masterCourse';
import SwiperComponent from '../home/congracts-section/swiper';
import CourseSlider from '../common/courseSlider';
import FutureReadyEng from '../common/futureReadyEng';
// import Aos from "aos";
import { useSearchParams } from 'next/navigation';
import AppService from '../services';
import Head from 'next/head';
import SeoWrapper from '../common/SeoWrapper';

const programHighlights = [
  {
    highlight:
      'Pharmaceutical Sciences: Our B.Pharm program offers comprehensive training in pharmaceutical sciences, covering subjects such as pharmaceutics, pharmacology, medicinal chemistry, and pharmacognosy, providing students with a strong foundation in the field of pharmacy.',
  },
  {
    highlight:
      'Practical Experience: Students gain practical experience through laboratory work, internships, and industrial training, where they learn to compound medications, analyze drugs, and develop pharmaceutical formulations, preparing them for careers in pharmacy practice, research, and industry.',
  },
  {
    highlight:
      'Patient Care: Our program emphasizes the importance of patient care and pharmaceutical counseling, teaching students how to effectively communicate with patients, educate them about their medications, and ensure safe and effective use of drugs.',
  },
  {
    highlight:
      'Regulatory Compliance: Students learn about pharmaceutical regulations and quality control standards, ensuring that they are well-versed in the laws and regulations governing the pharmaceutical industry and are equipped to maintain high standards of quality and safety in pharmaceutical practice.',
  },
  {
    highlight:
      'Professional Ethics: We place a strong emphasis on professional ethics and social responsibility, instilling in our students a commitment to ethical conduct, integrity, and respect for the rights and dignity of patients, and preparing them to uphold the highest standards of professional practice in the field of pharmacy.',
  },
];

const employmentRules = [
  'Hospital Pharmacist',
  'Community Pharmacist',
  'Production Chemist',
  'Production Technician',
  'Medical Representative',
  'Pharmaceutical Wholesaler',
];

const placementOpportunies = [
  { point: 'Govt. Hospitals: AIIMS, PGI, ESIC, Etc.' },
  { point: 'Private Hospitals: Max, Fortis, Apollo, Etc.' },
  {
    point:
      'Pharmaceutical Industries: Alkem, Cipla, Abbott, Dr.Reddy’s, Mankind, Unichem, Etc',
  },
  { point: 'Private Clinics & Nursing Homes' },
  { point: 'Wholesale Drug Distribution' },
];

const faculty = [
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
];

const defaultState = {
  facultyList: [],
  isLoading: false,
};

const departmentId = 9;

const BPharm = () => {
  const defaultAnimation = {
    courseOverview: false,
    highlights: false,
  };

  const [animationStart, setAnimationStart] = useState(defaultAnimation);
  const [state, setState] = useState(defaultState);
  const fetchFacultyList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getFacultyList();
    if (!error) {
      // Rehan Code for Category Filtering
      const facultyList = data.filter(
        (item: any) => item?.attributes?.department?.data?.id === departmentId
      );
      setState((prevState) => ({
        ...prevState,
        facultyList,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchFacultyList();
  }, []);

  return (
    <>
      <SeoWrapper
        title="Best Private Pharmacy College in UP for B. Pharm Courses"
        description="Join the best private pharmacy college in UP for B. Pharm. Get quality teaching, modern labs, experienced faculty, and strong career support in pharmacy."
        keywords="Best Private Pharmacy College in UP"
      >
        {/* Hero Sectino */}
        <section>
          <div className="handleoverlflow w-[80%] m-auto grid md:grid-cols-2 grid-cols-1 justify-center items-center md:px-6 px-3 py-12">
            <div>
              <Image
                unoptimized={true}
                src={'/courses/b-pharma-icon.webp'}
                width={90}
                height={20}
                alt="B Pharma"
                className="animate__animated animate__fadeInLeftBig my-4 rotateAnimate"
              />
              <div>
                <h2 className="">UG Degree</h2>
                <div className="bg-secondary h-2 w-full"></div>
              </div>
              <h1 className="m-0">
                B.Pharm. <br /> Bachelor of Pharmacy{' '}
              </h1>
            </div>

            <div className="md:p-8 p-4">
              <Image
                unoptimized={true}
                src={'/courses/b-pharma.webp'}
                width={600}
                height={20}
                alt="B Pharma"
                className="animate__animated animate__fadeInRight rounded-lg"
              />
            </div>
          </div>
        </section>

        {/* Course Overveiw */}

        <section className="bg-gray handleoverlflow">
          <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-24 px-6">
            <div data-aos="fade-right" className={`p-6 `}>
              <div>
                <h2>COURSE OVERVIEW</h2>
                <h4 className="text-justify">
                  The Bachelor in Pharmacy (B. Pharm) is a professional degree
                  for students who want to make a career in pharmacy. The
                  program builds a strong base in subjects like medicine,
                  chemistry, and healthcare. After B. Pharm, students can also
                  go for higher studies like M. Pharm. Our institute is known as
                  one of the best pharmacy colleges in UP and is trusted for
                  quality teaching and practical training. Being a private
                  college, we provide modern labs, experienced faculty, and
                  career support to help students grow in the pharmaceutical
                  field.
                </h4>
              </div>

              <div className="">
                <h2 className="uppercase">Placement Opportunities</h2>
                <div className="grid  grid-cols-1">
                  {placementOpportunies.map((item, index) => (
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h3 className="m-2">{item.point}</h3>
                    </div>
                  ))}
                </div>
              </div>
              <div className="">
                <h2 className="uppercase">Advanced Options of Study</h2>
                <div className="grid md:grid-cols-2 grid-cols-1">
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">M.Pharm</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">Pharm.D</h3>
                  </div>
                </div>
              </div>
            </div>

            <div className={`m-auto `} data-aos="fade-left">
              <div className="bg-secondary p-4 m-4 md:mr-12">
                <div className="p-4">
                  <h3 className="m-0">Duration</h3>
                  <h2 className="m-0">4 Years</h2>
                </div>
                <div className="p-4">
                  <h3 className="m-0">Programme Name</h3>
                  <h2 className="m-0">B.Pharm.</h2>
                </div>
              </div>
              <div className="bg-primary text-whiteCol p-4 m-4 md:ml-12">
                <div className="p-4">
                  <h2 className="m-0">Eligibility</h2>

                  <h5 className="text-justify mt-0">
                    Passed 10+2 examination with PCB / PCM with at least 50%
                    marks. (Candidate must have attained the age of 17 years on
                    31.12.2025).
                  </h5>
                  <h5 className="text-justify mt-0">
                    Five percent relaxation in the minimum eligibility is
                    provided to SC/ST Category Students
                  </h5>
                </div>
                <div className="p-4">
                  <Link href={'apply-online'} target="blank">
                    <ButtonCustom
                      btnColor={'secondary'}
                      btnText={'Apply Online'}
                      textCol={'primary'}
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Program Highliths */}

        <section className="md:p-12 py-6 " data-aos="zoom-in-up">
          <div className="w-[80%] m-auto bg-primary p-6 text-whiteCol">
            <div>
              <h2 className="text-secondary">Programme Highlights</h2>
              <div
                className={`md:columns-2 columns-1 
                            ${
                              animationStart.highlights
                                ? 'animate__animated animate__fadeInRight animate__slower'
                                : ''
                            }`}
              >
                {programHighlights.map((list: any, index) => (
                  <>
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h4 className="m-2">{list.highlight}</h4>
                    </div>
                  </>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Future Ready */}
        <FutureReadyEng
          department={
            <>
              Department of <br />
              Bachelor of Pharmacy
            </>
          }
          image={'/futureReady/bpharmCenter.webp'}
          format={'jpg'}
        />

        {/* Advanced Options of Study */}

        <section data-aos="fade-up-right" className="md:p-12 py-6  bg-gray">
          <div className="w-[80%] m-auto bg-secondary rounded-xl p-6 text-whiteCol">
            <div>
              <h2 className="text-primary  text-center">Employment Roles</h2>
              <div className=" grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3   m-auto ">
                {employmentRules.map((career: any, index) => (
                  <h3
                    key={index}
                    className="bg-whiteCol rounded-md drop-shadow-md px-6 py-2
                    text-primary m-0"
                  >
                    {career}
                  </h3>
                ))}
              </div>
            </div>
          </div>
        </section>
        {/* </ScrollTrigger> */}

        {/* Top Recruiters */}
        <div className="mt-12">
          <RecruitersComapnies />
        </div>

        {/* Eligibility  */}

        {/* Faculty  */}
        {!!state.facultyList.length && (
          <div className="  bg-primary flex">
            <div className="lg:w-[85%] w-[90%] m-auto md:p-16 p-4  ">
              <h2 className="m-auto text-secondary text-center p-4">
                Our Faculty
              </h2>
              <CourseSlider elements={state.facultyList} />
            </div>
          </div>
        )}
      </SeoWrapper>
    </>
  );
};

const BPharmSusense = () => {
  return (
    <Suspense>
      <BPharm />
    </Suspense>
  );
};

export default BPharmSusense;
