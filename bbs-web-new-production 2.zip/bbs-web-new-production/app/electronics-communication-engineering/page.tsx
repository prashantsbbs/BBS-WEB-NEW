'use client';
import Image from 'next/image';
import 'animate.css';
import Arrow from '../common/arrow';
import ScrollTrigger from 'react-scroll-trigger';
import { useEffect, useState } from 'react';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import MasterCourse from '../eligibility-criteria/masterCourse';

import SwiperComponent from '../home/congracts-section/swiper';
import CourseSlider from '../common/courseSlider';
import FutureReadyEng from '../common/futureReadyEng';
import AppService from '../services';
import SeoWrapper from '../common/SeoWrapper';

const programHighlights = [
  {
    highlight: 'Electronics Fundamentals:',
    body: 'Analog & Digital Electronics, Microprocessors, Microcontrollers',
  },
  {
    highlight: 'Communication Technologies :',
    body: 'Wireless Communication, Optical Fiber Communication, Radar Systems',
  },
  {
    highlight: 'Signal Processing & Networks:',
    body: 'Digital Signal Processing, Network Analysis, IoT & 5G Technologies',
  },
  {
    highlight: 'Embedded & VLSI Systems:',
    body: 'VLSI Design, Embedded Systems, Robotics',
  },
  {
    highlight: 'Artificial Intelligence & IoT:',
    body: 'Machine Learning, AI Applications in ECE, IoT Security',
  },
];

const careerProspectus = [
  {
    head: 'Telecommunication & Networking',
    body: 'Mobile Networks, Satellite Communications, IoT Solutions',
  },
  {
    head: 'Electronics & Chip Design',
    body: 'VLSI, Semiconductor Industry, Embedded Systems',
  },
  {
    head: 'Automation & Robotics',
    body: 'AI-driven Automation, Industrial Robotics',
  },
  {
    head: 'IT & Software',
    body: 'AI & ML Engineer, Cybersecurity, Data Science',
  },
  {
    head: 'Research & Development',
    body: 'Academic Research, Government R&D Labs',
  },
];

const majorTrack = [
  {
    head: 'Industry-Oriented Curriculum:',
    body: 'Designed to keep pace with the latest advancements in electronics, telecommunications, and embedded systems.',
  },
  {
    head: 'State-of-the-Art Labs:',
    body: 'Well-equipped laboratories for VLSI, Embedded Systems, Digital Signal Processing, Microwave Engineering, and more.',
  },
  {
    head: 'Expert Faculty:',
    body: 'Learn from highly qualified professors and industry experts.',
  },
  {
    head: 'Internships & Placements',
    body: 'Strong industry tie-ups for training, internships, and placement opportunities in top companies.',
  },
  {
    head: 'Research & Innovation',
    body: 'Encouragement for student research, project funding, and participation in national & international competitions.',
  },
];

const faculty = [
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
];

const defaultState = {
  isLoading: false,
  facultyList: [],
};

const departmentId = 6;

const ECE = () => {
  const defaultAnimation = {
    courseOverview: false,
    highlights: false,
  };

  const [animationStart, setAnimationStart] = useState(defaultAnimation);
  const [state, setState] = useState(defaultState);
  const fetchFacultyList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getFacultyList();
    if (!error) {
      // Rehan Code for Category Filtering
      const facultyList = data.filter(
        (item: any) => item?.attributes?.department?.data?.id === departmentId
      );

      setState((prevState) => ({
        ...prevState,
        facultyList,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchFacultyList();
  }, []);

  return (
    <>
      <SeoWrapper
        title="Top Electronics and Communication Engineering College in UP"
        description="BBS College of Engineering offers B.Tech ECE at a leading electronics and communication engineering college in UP with practical labs and industry-ready training."
      >
        {/* Hero Sectino */}
        <section>
          <div className="handleoverlflow w-[80%] m-auto grid md:grid-cols-2 grid-cols-1 justify-center items-center md:px-6 px-3 py-12">
            <div>
              <Image
                unoptimized={true}
                src={'/courses/bca-icon.webp'}
                width={90}
                height={20}
                alt="BCA Icon"
                className="animate__animated animate__fadeInLeftBig my-4 rotateAnimate"
              />
              <div>
                <h2 className="">UG Degree</h2>
                <div className="bg-secondary h-2 w-full"></div>
              </div>
              <h1 className="m-0">
                B.Tech ECE <br /> Electronics and Communication Engineering{' '}
              </h1>
              <h4 className="m-0">Affiliated to AKTU Lucknow </h4>
            </div>

            <div className="md:p-8 py-4">
              <Image
                unoptimized={true}
                src={'/courses/ece.webp'}
                width={600}
                height={20}
                alt="ECE"
                className="animate__animated animate__fadeInRight rounded-lg"
              />
            </div>
          </div>
        </section>

        {/* Course Overveiw */}

        <section className="bg-gray handleoverlflow">
          <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-24 px-6">
            <div data-aos="fade-right" className={`p-6 `}>
              <div>
                <h2>COURSE OVERVIEW</h2>
                <h4 className="text-justify">
                  &emsp;&emsp;The B.Tech in Electronics and Communication
                  Engineering (ECE) program at BBS College of Engineering &
                  Technology in UP is designed to equip students with
                  cutting-edge knowledge in electronics, communication systems,
                  embedded technologies, and signal processing.
                  <br />
                  <br />
                  &emsp;&emsp;This four-year undergraduate course integrates
                  theoretical foundations with hands-on practical experience,
                  ensuring that graduates are industry-ready and capable of
                  driving technological innovations.
                </h4>
              </div>

              <div className="">
                <h2 className="uppercase">Why Choose This Program?</h2>
                <div className="">
                  {majorTrack.map((item, index) => (
                    <div key={index}>
                      <div className="flex gap-3">
                        <h3 className="m-0 font-semibold uppercase text-pink">
                          {item.head}
                        </h3>
                      </div>
                      <h4 className="m-2">{item.body}</h4>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className={`m-auto `} data-aos="fade-left">
              <div className="bg-secondary p-4 m-4 md:mr-12">
                <div className="p-4">
                  <h3 className="m-0">Duration</h3>
                  <h2 className="m-0">4 Years</h2>
                </div>
                <div className="p-4">
                  <h3 className="m-0">Programme Name</h3>
                  <h2 className="m-0">
                    B.Tech ECE (Electronics and Communication Engineering)
                  </h2>
                </div>
              </div>
              <div className="bg-primary text-whiteCol p-4 m-4 md:ml-12">
                <div className="p-4">
                  <h2 className="m-0">Eligibility</h2>

                  <h5 className="text-justify mt-0">
                    Passed 10+2 examination with at least 50% marks in any
                    stream with maths as subject of study
                  </h5>
                </div>
                <div className="p-4">
                  <Link href={'apply-online'} target="blank">
                    <ButtonCustom
                      btnColor={'secondary'}
                      btnText={'Apply Online'}
                      textCol={'primary'}
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Program Highliths */}

        <section className="md:p-12 py-6 " data-aos="zoom-in-up">
          <div className="w-[80%] m-auto bg-primary p-6 text-whiteCol">
            <div>
              <h2 className="text-secondary">Course Structure</h2>
              <h4 className="text-white">
                The curriculum covers essential topics like:
              </h4>
              <div
                className={`md:columns-2 columns-1 
                            ${
                              animationStart.highlights
                                ? 'animate__animated animate__fadeInRight animate__slower'
                                : ''
                            }`}
              >
                {programHighlights.map((list: any, index) => (
                  <>
                    <div key={index}>
                      <div className="flex gap-3">
                        <Arrow />
                        <h4 className="m-2 uppercase text-secondary">
                          {list.highlight}
                        </h4>
                      </div>
                      <h4 className="m-2">{list.body}</h4>
                    </div>
                  </>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* <AIMLFacilities/> */}

        {/* Future Ready */}
        <FutureReadyEng
          department={
            <>
              Department of <br />
              B.Tech ECE - Electronics and Communication Engineering
            </>
          }
          image={'/futureReady/ece.webp'}
          format="jpg"
        />

        {/* Advanced Options of Study */}
        {/* <ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}> */}
        <section data-aos="fade-up-right" className="md:p-12 py-6  bg-gray">
          <div className="w-[80%] m-auto bg-secondary rounded-xl p-6 text-whiteCol">
            <div>
              <h2 className="text-primary  text-center">
                Career Opportunities
              </h2>
              <h4 className="text-center text-bg-black">
                Graduates of ECE have diverse career paths in industries like:
              </h4>
              <div className=" grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3   m-auto ">
                {careerProspectus.map((career: any, index) => (
                  <div
                    key={index}
                    className="bg-whiteCol rounded-md drop-shadow-md px-6 py-2 text-center text-bg-black"
                  >
                    <h3
                      className="
                    text-primary m-0 font-semibold"
                    >
                      {career.head}
                    </h3>
                    <h4>{career.body}</h4>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
        {/* </ScrollTrigger> */}

        {/* Top Recruiters */}
        <div className="mt-12">
          <RecruitersComapnies />
        </div>
        {/* Eligibility  */}
        {/* <div className="md:p-12 p-8 ">
        <Eligibility EligibilityTable={EligibilityTable} />
      </div> */}

        {/* Faculty  */}
        {!!state.facultyList.length && (
          <div className="  bg-primary flex">
            <div className="lg:w-[85%] w-[90%] m-auto md:p-16 p-4  ">
              <h2 className="m-auto text-secondary text-center p-4">
                Our Faculty
              </h2>
              <CourseSlider elements={state.facultyList} />
            </div>
          </div>
        )}
      </SeoWrapper>
    </>
  );
};
export default ECE;
