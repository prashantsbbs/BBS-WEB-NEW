'use client'

import React, { useRef } from 'react';

const CollegeVideo = ({
  videoUrl = ""
}: any) =>{

    const videoRef = useRef<HTMLVideoElement>(null);

    const replayVideo = () => {
        videoRef.current?.play();
      };


    return (
        <>
        <h1 className="sr-only">Apply Online</h1>
        <div className="  flex md:p-8 bg-primary">
      {videoUrl && (
         <video autoPlay onEnded={replayVideo} ref={videoRef} muted 
         className="md:w-[90%]  m-auto rounded-xl"  >
               <source src={videoUrl} type="video/mp4" />
               Your browser does not support HTML5 video.
             </video>
      )}
        </div>
        </>
    )
}

export default CollegeVideo