'use client';

import BreadcrumbCommon from '../common/breadcrumbCommon';

const PlacementPolicy = () => {
  return (
    <>
      <BreadcrumbCommon
        componentName={'Placement Policy'}
        image={'/home/lifeBBS.webp'}
      />
      <div className=" lg:px-32 md:px-16 px-12 py-16">
        <div>
          <h1 className="text-pink">
            Overall Placement Policy & Rules at BBS Group of Institutions{' '}
          </h1>
        </div>

        <div>
          <div className="text-justify">
            <h4>
              1. Students who are placed in a company, having a package below 3
              Lakhs will be permitted to participate in placement drives only
              for those companies that are providing an annual package of 4
              Lakhs and above.
            </h4>
            <h4>
              2. Students who are placed in a company, having a package between
              3 Lakhs and 4 Lakhs will be permitted to participate in placement
              drives only for those companies that are providing an annual
              package of 5 Lakhs and above.
            </h4>
            <h4>
              3. Students who are placed in a company, having a package above 4
              Lakhs will be permitted to participate in placement drives for
              companies that are providing an annual package of 5.5 Lakhs and
              above.
            </h4>
            <h4>
              4. Placed students will be permitted to attend placement drives in
              other companies regardless of amount of package and domain of the
              company, only when 70% students in their respective branches are
              placed.
            </h4>
            <h4>
              5. Attendance is a mandatory factor in order to get participation
              in the placement drives.
            </h4>
            <h4>6. Students in the final year must not carry any backlog.</h4>
            <h4>
              7. It is not mandatory for a candidate who willingly decides not
              to participate in any placement drive to attend the drive;
              however, the T&P Cell will not take any responsibility for it.
            </h4>
          </div>
        </div>
      </div>

      {/* -------------------------Combine div-------------------------- */}
      <div className="grid lg:grid-cols-2 grid-cols-1">
        <div className=" lg:px-32 md:px-16 px-12 py-16 bg-gray">
          <div>
            <h2 className="text-pink">Note </h2>
          </div>

          <div>
            <div className="text-justify mb-6">
              <h4>
                <b className="text-pink text-3xl">•</b> &emsp;&emsp;I any
                company offers a package of 7 LPA or higher, then all
                candidates- whether placed or unplaced will be permitted to
                participate in the campus recruitment drive.
              </h4>
              <h4>
                <b className="text-pink text-3xl">•</b> &emsp;&emsp;2. Black
                dotted students will be allowed to participate in P.S.U.
                recruitments and other recruitments only upon special permission
                by the Faculty in-charge-T&P.
              </h4>
              <h4>
                <b className="text-pink text-3xl">•</b>&emsp;&emsp;It is
                mandatory for all eligible students (including those who have
                already secured placements) to participate in
                &#x27;on-campus&#x27; recruitment drives (Core/P.S.U./I.T.)
              </h4>
            </div>

            <div className="text-justify ">
              <h4>
                <b className="text-pink text-md">1.</b>&emsp;&emsp; The fore
                mentioned criterion are not applicable for any P.S.U. All
                eligible students may participate.
              </h4>
              <h4>
                <b className="text-pink text-md">2.</b>&emsp;&emsp; It is
                mandatory for all eligible students (including those who have
                already secured placements) to participate in
                &#x27;on-campus&#x27; recruitment drive.
              </h4>
              <h4>
                <b className="text-pink text-md">3.</b>&emsp;&emsp;If any
                candidate submits his/her willingness to participate in any
                on-campus or off-campus placement recruitment drive and thereby
                fails to present himself/herself on the day of the pre-placement
                talk (PPT), then he/she is likely to be blacklisted** from the
                training & Placement.
              </h4>
              <h4>
                <b className="text-pink text-md">4.</b>&emsp;&emsp;4. If any
                candidate is blacklisted from the Training & Placement Cell,
                then he/she will not be allowed to participate in any of the
                placement drives throughout the academic year.
              </h4>
            </div>
          </div>
        </div>

        {/* -------------------------Reimbursment & General Rules-------------------------- */}
        <div className="bg-primary text-whiteCol">
          {/* -------------------------Reimbursment -------------------------- */}
          <div className=" lg:px-32 md:px-16 px-12 py-8">
            <div>
              <h2 className="text-pink">
                Relating to reimbursement of expenses in the campus placement
                drive:{' '}
              </h2>
            </div>

            <div>
              <div className="text-justify ">
                <h4>
                  <b className="text-pink text-md">1.</b>&emsp;&emsp; One
                  student who remains unselected can avail only 3 reimbursements
                  throughout the entire academic year.
                </h4>
                <h4>
                  <b className="text-pink text-md">2.</b>&emsp;&emsp; If a
                  student is selected in any of the on-campus interviews (phase
                  I/Phase-II), then he/she can avail a single reimbursement.
                </h4>
                <h4>
                  <b className="text-pink text-md">3.</b>&emsp;&emsp;Once a
                  student is selected in any of the off-campus interviews (phase
                  I/Phase-II), the reimbursement is the forfeited for that
                  student.
                </h4>
              </div>
            </div>
          </div>

          {/* -------------------------General Rules -------------------------- */}
          <div className=" lg:px-32 md:px-16 px-12 py-8">
            <div>
              <h2 className="text-pink">Relating to General Rules: </h2>
            </div>

            <div>
              <div className="text-justify ">
                <h4>
                  <b className="text-pink text-md">1.</b>&emsp;&emsp;All
                  students are responsible to stay in constant touch with
                  Training & Placement Coordinators for details and updates
                  regarding Placement Matters.
                </h4>
                <h4>
                  <b className="text-pink text-md">2.</b>&emsp;&emsp; It is
                  mandatory for all black dotted students to participate in all
                  the on-campus placement drives (Core/I.T./P.S.U.).
                </h4>
                <h4>
                  <b className="text-pink text-md">3.</b>&emsp;&emsp; Any Black
                  Dotted student if fails to participate in any on-campus
                  placement recruitment drive (Core/I.T./P.S.U.) will be
                  blacklisted** from the Training & Placement Cell.
                </h4>
              </div>
            </div>
          </div>
        </div>

        {/* -------------------------Note-------------------------- */}
      </div>

      <div className=" lg:px-32 md:px-16 px-12 py-16">
        <div>
          <h2 className="text-pink">Relating to Code of Conduct: </h2>
        </div>

        <div>
          <div className="text-justify ">
            <h4>
              <b className="text-pink text-md">1.</b>&emsp;&emsp; Training &
              Placement Student coordinators only hold the sole right to deal
              with Training & Placement matters (Internal or External)
            </h4>
            <h4>
              <b className="text-pink text-md">2.</b>&emsp;&emsp;Only with the
              special permission of the Training & Placement officer any other
              student may deal with Training & Placement matters.
            </h4>
            <h4>
              <b className="text-pink text-md">3.</b>&emsp;&emsp;All post
              job-offer communication between student and company should be
              channelized through the placement cell.
            </h4>
            <h4>
              <b className="text-pink text-md">4.</b>&emsp;&emsp;Direct
              communications with the company officials is not allowed.
            </h4>
            <h4>
              <b className="text-pink text-md">5.</b>&emsp;&emsp;It is mandatory
              for the students to register in the company to participate in the
              placement process of the company.
            </h4>
            <h4>
              <b className="text-pink text-md">6.</b>&emsp;&emsp;Attendance in
              PPT is mandatory after registration, to be eligible for further
              placement process.
            </h4>
            <h4>
              <b className="text-pink text-md">7.</b>&emsp;&emsp;Students
              proceeding after the PPT for the next step in the selection
              process of the company cannot quit in between. If a student quits
              in between, then he/she will be debarred and will not be allowed
              to appear in any other further placement event.
            </h4>
            <h4>
              <b className="text-pink text-md">8.</b>&emsp;&emsp;Any kind of
              misbehavior/complaints reported by the company officials will be
              taken seriously and if proven, the student will be debarred from
              future campus placements/Blacklisted**.
            </h4>
          </div>
        </div>
      </div>

      {/* -------------------------Placement Guidelines-------------------------- */}

      <div className=" bg-secondary lg:px-32 md:px-16 px-12 py-16">
        <div className="bg-whiteCol p-4 rounded-lg">
          <div>
            <h2 className="text-pink">Relating to Placement Guidelines: </h2>
          </div>

          <div>
            <div className="text-justify ">
              <h4>
                <b className="text-pink text-md">1.</b>&emsp;&emsp;The role of
                T&P (Training & Placement) Cell is a facilitator for placement
                related activities. T&P does not guarantee a job.
              </h4>
              <h4>
                <b className="text-pink text-md">2.</b>&emsp;&emsp;The Placement
                facility is available to all the students registered with T&P
                Cell through the policy ONE JOB TO ONE STUDENT AT THE FIRST
                INSTANCE. This will ensure that every student will get equal job
                opportunities and only few students do not consume up all the
                jobs.
              </h4>
              <h4>
                <b className="text-pink text-md">3.</b>&emsp;&emsp;Any student
                against whom show cause notice/warning letter have been issued;
                will not be allowed to appear in campus Recruitment. The
                students are required to submit a certificate showing their
                academic performance as well as satisfactory conduct in the
                institute/hostel signed by all concerned department faculties &
                wardens to the faculty In-Charge Training & Placement for
                further consideration.
              </h4>
              <h4>
                <b className="text-pink text-md">4.</b>&emsp;&emsp;Any negative
                remark in this regard made by any faculty or warden against any
                student will make him/her ineligible for the entire campus
                placement process. Besides, any student against whom more than
                one warning letter is issued will not be allowed to appear in
                campus interview.
              </h4>
              <h4>
                <b className="text-pink text-md">5.</b>&emsp;&emsp;If a student
                is placed in any of the P.S.U&#x27;s, then the placement is over
                for him/her.
              </h4>
              <h4>
                <b className="text-pink text-md">6.</b>&emsp;&emsp;All students
                must keep their identity card with them at the time of
                PPT/Written Test/GD/PI and produce the same when demanded by the
                visiting team or T&P Cell Staff.
              </h4>
            </div>
          </div>
        </div>
      </div>

      <div className=" lg:px-32 md:px-16 px-12 py-8">
        <div>
          <h2 className="text-pink">*Black Dotted: </h2>
        </div>

        <div>
          <div className="text-justify ">
            <h4>
              &emsp;&emsp;A candidate is Black-Dotted if he/she remains
              unselected and willingly decides not to participate in any
              off-campus Placement rive (Core/I.T./P.S.U.)
            </h4>
          </div>
        </div>
      </div>

      <div className=" lg:px-32 md:px-16 px-12 py-8">
        <div>
          <h2 className="text-pink">*Blacklisted: </h2>
        </div>

        <div>
          <div className="text-justify ">
            <h4>&emsp;&emsp;A candidate is blacklisted if:</h4>
            <h4>
              <b className="text-pink text-3xl">•</b> &emsp;&emsp;The candidate
              submits his/her willingness to participate in any on-campus or
              off-campus placement recruitment drive and thereby fails to
              present himself/herself on the day of the placement talk (PPT)
            </h4>
            <h4>
              <b className="text-pink text-3xl">•</b> &emsp;&emsp;Any kind of
              misbehaviour/complaints are reported by the company officials/T&P
              Cell Staff regarding the candidate.
            </h4>
            <h4>
              <b className="text-pink text-3xl">•</b> &emsp;&emsp;The candidate
              is already Black dotted in any he/she fails to participate in any
              on-campus placement recruitment drive (Core/I.T./P.S.U.)
            </h4>
          </div>
        </div>
      </div>

      <div className=" lg:px-32 md:px-16 px-12 py-8">
        <div>
          <h2 className="text-pink">Remark </h2>
        </div>

        <div>
          <div className="text-justify ">
            <h4>
              <b className="text-pink text-3xl">•</b> &emsp;&emsp;The policy is
              subjected to stage at a later stage at the discretion of the
              Training & Placement Cell. The Changes made, if any, at a later
              stage will be notified to all concerned.
            </h4>
          </div>
        </div>
      </div>
    </>
  );
};

export default PlacementPolicy;
