'use client';
import Image from 'next/image';
import 'animate.css';
import CampusHiglight from '../common/campusHiglight';
import NewsEventsSection from '../home/news&events';
import { useEffect, useState } from 'react';

const academicOffer = [
  {
    title: 'Interactive Workshops',
    description:
      'Dive deep into your field of study with hands-on workshops led by industry experts and faculty members. From coding boot camps to business plan competitions, our workshops cover a wide range of topics designed to enhance your skills and knowledge.',
  },
  {
    title: 'Guest Lectures',
    description:
      'Gain insights from thought leaders and industry professionals through our series of guest lectures. These sessions provide valuable real-world perspectives and networking opportunities for students interested in various industries and career paths.',
  },
  {
    title: 'Debates and Discussions',
    description:
      'Engage in lively debates and discussions on current events, academic topics, and societal issues. Our club provides a platform for students to voice their opinions, exchange ideas, and sharpen their critical thinking skills in a supportive and inclusive environment.',
  },
  {
    title: 'Research Opportunities',
    description:
      "Explore your academic interests and contribute to cutting-edge research projects through our research initiatives. Whether you're interested in conducting independent research or collaborating with faculty members on interdisciplinary projects, our club supports students at every stage of the research process.",
  },
];

const recreationClub = [
  {
    title: 'Sports Tournaments',
    description:
      'Get ready to unleash your competitive spirit and showcase your athletic prowess in our sports tournaments. From basketball and volleyball to cricket and football, our club organizes a variety of tournaments and matches throughout the academic year, giving students the chance to represent their college and win exciting prizes.',
  },
  {
    title: 'Outdoor Adventures',
    description:
      "Embark on thrilling outdoor adventures and explore the natural beauty of our surroundings with our outdoor adventure trips. Whether you're hiking through scenic trails, camping under the stars, or rafting down roaring rivers, our club offers plenty of opportunities for adrenaline-pumping fun and unforgettable experiences.",
  },
  {
    title: 'Cultural Events',
    description:
      'Immerse yourself in the rich cultural tapestry of our college community with our cultural events and festivals. From traditional dance performances and music concerts to food festivals and art exhibitions, our club celebrates diversity and promotes cultural exchange, fostering a sense of unity and appreciation for different cultures.',
  },
  {
    title: 'Creative Workshops',
    description:
      "Unleash your creativity and express yourself through our creative workshops and activities. Whether you're interested in painting, photography, cooking, or dance, our club provides a platform for students to explore their artistic talents, learn new skills, and unleash their imagination in a supportive and encouraging environment.",
  },
];

const communityClub = [
  {
    title: 'Volunteer Opportunities',
    description:
      "Get involved in hands-on volunteer work and make a tangible difference in the lives of others. Whether it's organizing a food drive, participating in community clean-up efforts, or volunteering at local shelters and orphanages, our club provides numerous opportunities for students to give back and support those in need.",
  },
  {
    title: 'Social Impact Projects',
    description:
      'Take part in impactful projects and initiatives aimed at addressing social issues and promoting positive change in our community. From raising awareness about environmental conservation and sustainable living to advocating for social justice and equality, our club tackles a wide range of issues through collaborative action and advocacy.',
  },
  {
    title: 'Educational Outreach',
    description:
      "Engage in educational outreach programs and initiatives designed to empower and uplift underserved communities. Whether it's tutoring and mentoring students from disadvantaged backgrounds, organizing educational workshops and seminars, or providing resources and support to local schools and youth centers, our club is committed to promoting access to quality education for all.",
  },
  {
    title: 'Fundraising Events',
    description:
      'Support charitable causes and organizations through our fundraising events and campaigns. From charity walks and marathons to bake sales and talent shows, our club raises funds for important causes and organizations that make a positive impact in our community and beyond.',
  },
];

const literaryClub = [
  {
    title: 'Book Clubs',
    description:
      'Dive into the world of literature with our book clubs, where students come together to discuss and dissect their favorite books and authors. From classic literature to contemporary bestsellers, our club explores a wide range of genres and themes, providing an enriching and immersive reading experience for all.',
  },
  {
    title: 'Writing Workshops',
    description:
      "Hone your writing skills and unleash your creativity with our writing workshops led by experienced authors and writing professionals. Whether you're interested in fiction, poetry, non-fiction, or journalism, our club offers workshops and writing prompts to help you develop your craft and express yourself through words.",
  },
  {
    title: 'Poetry Readings',
    description:
      "Immerse yourself in the beauty of poetry with our poetry readings and open mic nights. Whether you're a seasoned poet or a newcomer to the world of verse, our club provides a supportive and welcoming environment for students to share their poetry, explore different poetic forms and styles, and connect with fellow poetry enthusiasts.",
  },
  {
    title: 'Storytelling Sessions',
    description:
      "Let your imagination soar with our storytelling sessions, where students come together to share their stories, anecdotes, and personal experiences. Whether it's through spoken word, prose, or multimedia presentations, our club celebrates the art of storytelling and encourages students to find their unique voice and narrative style.",
  },
];

const skillDevelopment = [
  {
    title: 'Technical Workshops',
    description:
      'Gain hands-on experience and technical expertise in areas such as programming, web development, graphic design, and more through our series of technical workshops and training sessions. Led by industry experts and experienced professionals, these workshops provide valuable practical skills and insights that are directly applicable to the workplace.',
  },
  {
    title: 'Soft Skills Training',
    description:
      'Enhance your communication, leadership, teamwork, and problem-solving skills with our soft skills training programs. From public speaking and presentation skills to time management and emotional intelligence, our club offers workshops and seminars designed to help students develop the interpersonal skills and qualities needed to succeed in any professional environment.',
  },
  {
    title: 'Entrepreneurship Development',
    description:
      "Explore your entrepreneurial aspirations and learn how to turn your ideas into reality with our entrepreneurship development programs. Whether you're interested in starting your own business or joining a startup, our club provides resources, mentorship, and networking opportunities to help you navigate the entrepreneurial journey and build a successful venture.",
  },
  {
    title: 'Career Guidance and Mentorship',
    description:
      "Receive personalized career guidance and mentorship from industry professionals and alumni through our mentorship programs. Whether you're exploring different career paths, seeking internship opportunities, or preparing for job interviews, our club connects students with experienced mentors who can provide valuable insights, advice, and support.",
  },
];

const healthClub = [
  {
    title: 'Fitness Workshops and Classes',
    description:
      'Get moving and stay active with our fitness workshops and classes, which cover a variety of activities such as yoga, zumba, aerobics, and strength training. Led by certified instructors, these classes are designed to help students improve their physical fitness, flexibility, and overall health in a fun and supportive environment.',
  },
  {
    title: 'Nutritional Guidance',
    description:
      "Learn how to make healthy food choices and maintain a balanced diet with our nutritional guidance sessions and workshops. Whether you're looking to lose weight, gain muscle, or simply adopt healthier eating habits, our club offers resources and support to help you make sustainable changes to your diet and lifestyle.",
  },
  {
    title: 'Mental Health Support',
    description:
      'Take care of your mental and emotional well-being with our mental health support services and resources. From stress management techniques and mindfulness exercises to counseling and therapy referrals, our club provides a range of options for students seeking support and guidance in managing their mental health.',
  },
  {
    title: 'Health Awareness Campaigns',
    description:
      "Stay informed about important health issues and participate in health awareness campaigns and events organized by our club. Whether it's raising awareness about common illnesses and diseases, promoting preventive health screenings, or advocating for healthy lifestyle choices, our club strives to educate and empower students to take control of their health.",
  },
];

const Club = () => {
  const defaultState = {
    mobileBanner: false,
  };

  const [state, setState] = useState(defaultState);

  const getBodyWidth = (evt: any) => {
    if (evt.target.innerWidth < 768) {
      setState((prev: any) => ({ mobileBanner: true }));
    } else setState((prev: any) => ({ mobileBanner: false }));
  };

  useEffect(() => {
    if (window) {
      window.addEventListener('resize', getBodyWidth);
      const screenWidth = window.screen.width;

      if (screenWidth < 768) {
        setState((prev: any) => ({ mobileBanner: true }));
      } else setState((prev: any) => ({ mobileBanner: false }));
    }
    return () => window && window.removeEventListener('resize', getBodyWidth);
  }, []);

  return (
    <>
      <div className="bg-gray pb-6 mb-3">
        {/* why BBS */}
        <div className="m-auto   animate__animated animate__slideInLeft">
          {state.mobileBanner ? (
            <Image
              src={'/banner/bannerAboutM.webp'}
              width={1000}
              height={1000}
              alt={'Banner About'}
              unoptimized={true}
              className=" bgImage_aboutM   "
            />
          ) : (
            <Image
              src={'/banner/bannerAbout.webp'}
              width={1400}
              height={1000}
              alt={'Banner About'}
              unoptimized={true}
              className=" bgImage_aboutD   "
            />
          )}
        </div>

        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <h1 className="text-3xl">
            Clubs at BBS: Explore a Vibrant Campus Community
          </h1>
          <h4 className="text-justify">
            &emsp;&emsp;Welcome to BBS Group of Institutions, where academic
            excellence meets a vibrant campus life. At BBS Group of
            Institutions, we believe in fostering holistic development by
            providing students with opportunities to explore their passions,
            interests, and talents outside the classroom. One of the key avenues
            for student engagement and enrichment is through our diverse range
            of clubs.
            <br />
          </h4>
          <h4 className="text-justify">
            &emsp;&emsp;We are proud to offer an extensive array of clubs
            catering to a wide spectrum of interests, ensuring that every
            student can find a community where they belong. Whether you&apos;re
            passionate about arts and culture, sports and fitness, community
            service, academic pursuits, or social activism, there&apos;s a club
            for you at BBS Group of Institutions.
            <br />
          </h4>
        </div>
      </div>

      <h2 className="m-0 uppercase text-center bg-pink text-whiteCol">
        Here&apos;s a glimpse into the dynamic club scene at BBS Group of
        Institutions:
      </h2>

      <div></div>

      {/* Academic Club---------------------------------------------- */}
      <div className="bg-primary  p-6 ">
        <div className="md:w-[80%] w-[90%] m-auto rounded-xl bg-whiteCol p-6 grid gap-10 lg:grid-cols-2 grid-cols-1 ">
          <div className="text-justify">
            <Image
              src={'/graduateClub.webp'}
              width={400}
              height={100}
              alt={'Graduate Club'}
              unoptimized={true}
              className=" w-[150px] m-auto   "
            />
            <h2 className="text-center  uppercase">Academic Club</h2>
            <h4>
              At BBS Group of Institutions, we understand that education extends
              far beyond the confines of the classroom. That&apos;s why we are
              proud to introduce our Academic Club, a vibrant platform where
              students can delve deeper into their areas of interest, engage in
              intellectually stimulating discussions, and foster a community of
              lifelong learners. The Academic Club at BBS Group of Institutions
              is a student-driven initiative aimed at promoting academic
              excellence and intellectual curiosity among our student body.
              Whether you&apos;re passionate about engineering, management,
              pharmacy, science, or legal studies, our club offers something for
              everyone.
            </h4>
            <h4>
              Our mission is simple: to provide students with opportunities for
              academic enrichment, personal growth, and professional development
              outside of the traditional academic setting. Through a diverse
              range of activities, workshops, seminars, and guest lectures, we
              strive to ignite a passion for learning and encourage students to
              explore new ideas and perspectives.
            </h4>
          </div>
          <div className=" ">
            <h3 className="bg-pink rounded-r-lg font-semibold text-whiteCol uppercase px-4 py-1 w-fit">
              What We Offer
            </h3>
            {academicOffer.map((list: any, index) => (
              <>
                <div className="m-2">
                  <h3 className="font-semibold text-pink m-0">{list.title}</h3>
                  <h4 className="text-justify  m-0">{list.description}</h4>
                </div>
              </>
            ))}
          </div>
        </div>
      </div>

      {/* Recreation Club---------------------------------------------- */}
      <div className="bg-seaGreen  p-6 ">
        <div className="md:w-[80%] w-[90%] m-auto rounded-xl bg-whiteCol p-6 grid gap-10 lg:grid-cols-2 grid-cols-1 ">
          <div className="text-justify">
            <Image
              src={'/recreationClub.webp'}
              width={400}
              height={100}
              alt={'Recreation Club'}
              unoptimized={true}
              className=" w-[150px] m-auto   "
            />
            <h2 className="text-center  uppercase">Recreation Club</h2>
            <h4>
              Welcome to the Recreation Club, where students come together to
              unwind, explore their passions, and create unforgettable memories
              outside of the classroom. At BBS Group of Institutions, we believe
              in fostering a holistic learning environment that promotes not
              only academic excellence but also personal growth, well-being, and
              community engagement. The Recreation Club at BBS Group of
              Institutions is a dynamic hub of activity, offering a wide range
              of recreational and leisure opportunities for students to enjoy.
              From sports and outdoor adventures to cultural events and creative
              workshops, our club aims to provide something for everyone,
              regardless of interests or backgrounds.
            </h4>
            <h4>
              Our mission is to promote a healthy and balanced lifestyle among
              our student body by providing access to diverse recreational
              activities and fostering a sense of camaraderie and community
              spirit. Through our events and initiatives, we aim to encourage
              students to de-stress, recharge, and form lasting friendships
              while pursuing their passions and interests.
            </h4>
          </div>
          <div className=" ">
            <h3 className="bg-pink rounded-r-lg font-semibold text-whiteCol uppercase px-4 py-1 w-fit">
              What We Offer
            </h3>
            {recreationClub.map((list: any, index) => (
              <>
                <div className="m-2">
                  <h3 className="font-semibold text-pink m-0">{list.title}</h3>
                  <h4 className="text-justify  m-0">{list.description}</h4>
                </div>
              </>
            ))}
          </div>
        </div>
      </div>

      {/* Community Service Club---------------------------------------------- */}
      <div className="bg-secondary  p-6 ">
        <div className="md:w-[80%] w-[90%] m-auto rounded-xl bg-whiteCol p-6 grid gap-10 lg:grid-cols-2 grid-cols-1 ">
          <div className="text-justify">
            <Image
              src={'/communityClub.webp'}
              width={400}
              height={100}
              alt={'Community Club'}
              unoptimized={true}
              className=" w-[150px] m-auto   "
            />
            <h2 className="text-center  uppercase">Community Service Club</h2>
            <h4>
              Welcome to the Community Service Club, where students unite to
              make a positive impact on society and contribute to the welfare of
              our local community. At BBS Group of Institutions, we believe in
              the power of service and giving back, and our club provides a
              platform for students to engage in meaningful volunteer work,
              social initiatives, and community outreach projects. The Community
              Service Club at BBS Group of Institutions is dedicated to
              promoting social responsibility, compassion, and empathy among our
              student body. Through a variety of service-oriented activities and
              initiatives, our club aims to address pressing social issues,
              support marginalized communities, and inspire positive change in
              the world around us.
            </h4>
            <h4>
              Our mission is to empower students to become active agents of
              change and leaders in their communities through service and
              volunteerism. By fostering a culture of kindness, empathy, and
              social awareness, we strive to create a more inclusive, equitable,
              and compassionate society where everyone has the opportunity to
              thrive.
            </h4>
          </div>
          <div className=" ">
            <h3 className="bg-pink rounded-r-lg font-semibold text-whiteCol uppercase px-4 py-1 w-fit">
              What We Offer
            </h3>
            {communityClub.map((list: any, index) => (
              <>
                <div className="m-2">
                  <h3 className="font-semibold text-pink m-0">{list.title}</h3>
                  <h4 className="text-justify  m-0">{list.description}</h4>
                </div>
              </>
            ))}
          </div>
        </div>
      </div>

      {/* Literary Club---------------------------------------------- */}
      <div className="bg-primary  p-6 ">
        <div className="md:w-[80%] w-[90%] m-auto rounded-xl bg-whiteCol p-6 grid gap-10 lg:grid-cols-2 grid-cols-1 ">
          <div className="text-justify">
            <Image
              src={'/literaryClub.webp'}
              width={400}
              height={100}
              alt={'Literary Club'}
              unoptimized={true}
              className=" w-[150px] m-auto   "
            />
            <h2 className="text-center  uppercase">Literary Club</h2>
            <h4>
              Welcome to the Literary Club, where students gather to celebrate
              the beauty of language, literature, and creative expression. At
              BBS Group of Institutions, we believe in the power of words to
              inspire, educate, and transform, and our club provides a platform
              for students to explore their love for literature, writing, and
              storytelling. The Literary Club at BBS Group of Institutions is a
              vibrant community of book lovers, writers, poets, and storytellers
              who come together to share their passion for words and creativity.
              From literary discussions and poetry readings to writing workshops
              and storytelling sessions, our club offers a wide range of
              activities and events for students to engage in and enjoy.
            </h4>
            <h4>
              Our mission is to foster a love for literature and language among
              our student body, promote creative expression and critical
              thinking skills, and provide a supportive and inclusive space for
              students to explore their interests and talents in writing and
              storytelling. Through our activities and initiatives, we aim to
              inspire a lifelong appreciation for the written word and empower
              students to find their voice and share their stories with the
              world.
            </h4>
          </div>
          <div className=" ">
            <h3 className="bg-pink rounded-r-lg font-semibold text-whiteCol uppercase px-4 py-1 w-fit">
              What We Offer
            </h3>
            {literaryClub.map((list: any, index) => (
              <>
                <div className="m-2">
                  <h3 className="font-semibold text-pink m-0">{list.title}</h3>
                  <h4 className="text-justify  m-0">{list.description}</h4>
                </div>
              </>
            ))}
          </div>
        </div>
      </div>

      {/* Skill Development Club---------------------------------------------- */}
      <div className="bg-pink  p-6 ">
        <div className="md:w-[80%] w-[90%] m-auto rounded-xl bg-whiteCol p-6 grid gap-10 lg:grid-cols-2 grid-cols-1 ">
          <div className="text-justify">
            <Image
              src={'/skillDevelopmentClub.webp'}
              width={400}
              height={100}
              alt={'Skill Development Club'}
              unoptimized={true}
              className=" w-[150px] m-auto   "
            />
            <h2 className="text-center  uppercase">Skill Development Club</h2>
            <h4>
              Welcome to the Skill Development Club, where students are
              empowered to acquire new skills, hone their talents, and unleash
              their full potential. At BBS Group of Institutions, we understand
              the importance of equipping students with practical skills and
              competencies that will serve them well beyond the classroom.
              That&apos;s why our club offers a wide range of opportunities for
              personal and professional growth through hands-on workshops,
              training sessions, and skill-building activities. The Skill
              Development Club at BBS Group of Institutions is dedicated to
              helping students develop the practical skills and competencies
              needed to succeed in today&apos;s dynamic and competitive world.
              Whether you&apos;re interested in honing your technical skills,
              enhancing your communication abilities, or mastering new tools and
              technologies, our club provides the resources, support, and
              guidance you need to thrive.
            </h4>
            <h4>
              Our mission is to empower students to become lifelong learners and
              adaptable problem-solvers by providing them with opportunities for
              skill development, personal growth, and professional advancement.
              Through our activities and initiatives, we aim to bridge the gap
              between academic knowledge and real-world application, equipping
              students with the tools and confidence they need to excel in their
              chosen fields.
            </h4>
          </div>
          <div className=" ">
            <h3 className="bg-pink rounded-r-lg font-semibold text-whiteCol uppercase px-4 py-1 w-fit">
              What We Offer
            </h3>
            {skillDevelopment.map((list: any, index) => (
              <>
                <div className="m-2">
                  <h3 className="font-semibold text-pink m-0">{list.title}</h3>
                  <h4 className="text-justify  m-0">{list.description}</h4>
                </div>
              </>
            ))}
          </div>
        </div>
      </div>

      {/* Health Club---------------------------------------------- */}
      <div className="bg-seaGreen  p-6 ">
        <div className="md:w-[80%] w-[90%] m-auto rounded-xl bg-whiteCol p-6 grid gap-10 lg:grid-cols-2 grid-cols-1 ">
          <div className="text-justify">
            <Image
              src={'/healthClub.webp'}
              width={400}
              height={100}
              alt={'Health Club'}
              unoptimized={true}
              className=" w-[150px] m-auto   "
            />
            <h2 className="text-center  uppercase">Health Club</h2>
            <h4>
              Welcome to the Health Club, where students come together to
              prioritize their physical, mental, and emotional well-being in a
              supportive and empowering environment. At BBS Group of
              Institutions, we understand the importance of maintaining a
              healthy lifestyle and fostering a culture of wellness among our
              student body. That&apos;s why our club offers a variety of
              activities, resources, and support services to help students lead
              happier, healthier lives. The Health Club at BBS Group of
              Institutions is dedicated to promoting holistic wellness and
              empowering students to make informed choices about their health
              and well-being. Whether you&apos;re looking to improve your
              fitness, manage stress, or enhance your overall quality of life,
              our club provides the tools, resources, and community support you
              need to thrive.
            </h4>
            <h4>
              Our mission is to inspire and empower students to prioritize their
              health and well-being by providing access to educational
              resources, fitness activities, and support services. Through our
              initiatives and events, we aim to create a campus culture that
              values and prioritizes wellness, fostering a community of students
              who are physically, mentally, and emotionally resilient.
            </h4>
          </div>
          <div className=" ">
            <h3 className="bg-pink rounded-r-lg font-semibold text-whiteCol uppercase px-4 py-1 w-fit">
              What We Offer
            </h3>
            {healthClub.map((list: any, index) => (
              <>
                <div className="m-2">
                  <h3 className="font-semibold text-pink m-0">{list.title}</h3>
                  <h4 className="text-justify  m-0">{list.description}</h4>
                </div>
              </>
            ))}
          </div>
        </div>
      </div>

      <div className="w-[80vw] p-5  relative z-10  m-auto   bg-whiteCol ">
        <h4 className="text-justify">
          &emsp;&emsp;With a number of clubs to choose from, BBS Group of
          Institutions offers a dynamic and inclusive campus environment where
          students can pursue their interests, develop leadership skills, and
          forge lifelong friendships. Whether you&apos;re seeking personal
          growth, professional development, or simply a sense of belonging,
          you&apos;ll find endless opportunities to thrive at BBS Group of
          Institutions.
          <br />
        </h4>
        <h4 className="text-justify">
          &emsp;&emsp;Join us at BBS Group of Institutions and embark on a
          journey of discovery, exploration, and growth both inside and outside
          the classroom. We look forward to welcoming you into our vibrant
          community of learners and leaders.
          <br />
        </h4>
      </div>

      {/* <CampusHiglight />
      <NewsEventsSection /> */}
    </>
  );
};

export default Club;
