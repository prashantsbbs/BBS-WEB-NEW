'use client';
import { useEffect, useMemo, useState } from 'react';
import AppService from '../services';

const cardData = [
  {
    img: '/press-section/press.webp',
    title: 'Title 1',
    date: 'Tue Aug 19 2020 22:18:29 GMT+0530 (India Standard Time)',
  },
  {
    img: '/press-section/press2.webp',
    title: 'Title 2',
    date: 'Tue Sep 19 2021 22:18:29 GMT+0530 (India Standard Time)',
  },
  {
    img: '/imagePlaceholder.webp',
    title: 'Title 3',
    date: 'Web Feb 19 2021 22:18:29 GMT+0530 (India Standard Time)',
  },
  {
    img: '/press-section/press3.webp',
    title: 'Title 4',
    date: 'Tue May 19 2020 22:18:29 GMT+0530 (India Standard Time)',
  },
  {
    img: '/press-section/press4.webp', // Random image link
    title: 'Title 5',
    date: 'Tue Apr 19 2023 22:18:29 GMT+0530 (India Standard Time)',
  },
  {
    img: '/press-section/press5.webp', // Random image link
    title: 'Title 6',
    date: 'Tue July 19 2021 22:18:29 GMT+0530 (India Standard Time)',
  },
];

const currentYear = new Date().getFullYear();
const years = ['Select Year', , currentYear];

const formatDate = (dateString: any) => {
  const date = new Date(dateString);
  const year = date.getFullYear();
  let month = (date.getMonth() + 1).toString().padStart(2, '0');
  let day = date.getDate().toString().padStart(2, '0');
  return `${year}-${month}-${day}`;
};

cardData.forEach((item) => {
  item.date = formatDate(item.date);
});

for (let i = 1; i <= 5; i++) {
  let previousYear = currentYear - i;
  years.push(previousYear);
}

const currentMonth = [
  'Select Month',
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

const VideoGallery = () => {
  const [state, setState] = useState({
    selectedYear: '',
    selectedMonth: '',
    data: cardData,
    videoGalleryList: [],
    isLoading: false,
  });

  const handleYear = (e: any) => {
    const selectedYear = parseInt(e.target.value);
    setState((prevState: any) => ({
      ...prevState,
      selectedYear,
    }));
    setState((prevState) => ({ ...prevState, selectedMonth: '' }));
  };

  const handleMonth = (e: any) => {
    const selectedMonth = e.target.value;
    setState((prevState) => ({ ...prevState, selectedMonth }));
  };

  const filteredCardData = state.data.filter((card) => {
    const [year, month] = card.date.split('-');
    return state.selectedMonth.length === 0 || state.selectedMonth == '0'
      ? year == state.selectedYear
      : year == state.selectedYear && +month === +state.selectedMonth;
  });

  const fetchVideoGalleryList = async () => {
    setState((prev) => ({ ...prev, isLoading: false }));
    const { data, error } = await AppService.getVideoGalleryList();
    if (error) {
    } else {
      setState((prev) => ({ ...prev, videoGalleryList: data }));
    }
    setState((prev) => ({ ...prev, isLoading: true }));
  };

  useEffect(() => {
    fetchVideoGalleryList();
  }, []);

  const videoGalleryList = useMemo(() => {
    return state.videoGalleryList.filter((item: any) => {
      if (state.selectedYear && state.selectedMonth) {
        const date = new Date(item?.attributes?.date);
        return (
          date.getFullYear() === +state.selectedYear &&
          date.getMonth() === +state.selectedMonth - 1
        );
      } else {
        return true;
      }
    });
  }, [state.videoGalleryList, state.selectedYear, state.selectedMonth]);

  return (
    <>
      <div className="relative">
        <video
          autoPlay
          muted
          loop
          className="breadCrumb animate__animated animate__slideInLeft object-cover"
        >
          <source src="/video.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        <div className="bg-[#14144277] absolute top-0 left-0 h-full w-full z-10"></div>
        <div className="absolute inset-0 text-whiteCol flex items-center justify-center z-20">
          <h1 className=" text-center">Video Gallery</h1>
        </div>
      </div>
      <div className="flex w-fit mx-auto mt-10 px-2">
        <select
          name="year"
          onChange={handleYear}
          value={state.selectedYear}
          className="mr-4 px-4 py-2 text-base border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
        >
          {years.map((year, index) => (
            <option key={index} value={year}>
              {year}
            </option>
          ))}
        </select>
        <select
          name="month"
          onChange={handleMonth}
          value={state.selectedMonth}
          className="px-4 py-2 text-base border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
          disabled={!state.selectedYear}
        >
          {state.selectedYear ? (
            currentMonth.map((month, index) => (
              <option key={index} value={index}>
                {month}
              </option>
            ))
          ) : (
            <option>Select Month</option>
          )}
        </select>
      </div>
      {videoGalleryList.length ? (
        <div className="md:py-20 py-10 md:px-32 px-10 grid grid-cols-3 lg:gap-20 gap-8 justify-center items-center  mx-auto my-auto image-grid-container ">
          {videoGalleryList.map((item: any, id) => (
            <div key={id}>
              <iframe
                width="100%"
                height="230"
                src={item?.attributes?.video_link}
                title="YouTube video player"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                style={{
                  borderRadius: '1rem',
                  objectFit: 'contain',
                  boxShadow:
                    'inset 0 -3em 3em rgba(74, 48, 48, 0.1), 0 0 0 2px rgb(190, 190, 190), 0.3em 0.3em 1em rgba(0, 0, 0, 0.3)',
                }}
              />
              <p>
                Date :{' '}
                {item?.attributes?.date
                  ? new Date(item?.attributes?.date).toLocaleDateString()
                  : '-'}
              </p>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-center text-xl py-14">NotFound</p>
      )}
    </>
  );
};

export default VideoGallery;
