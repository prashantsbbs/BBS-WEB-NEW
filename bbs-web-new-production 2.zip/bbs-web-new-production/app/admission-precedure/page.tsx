"use client";

import Image from "next/image";


const AdmissionProcedure = () => {
    const webTable = [
        {
          examName: "Joint Entrance ExaminationJEE (Main) 2025",
          website: "https://jeemain.nta.nic.in",
          examType: "Engineering",
        },
        {
          examName: "CUET (UG) - 2026",
          website: "https://cuet.samarth.ac.in/",
          examType:
            "B.Tech. (Lateral Entry), B.Pharm. (First year and Lateral Entry)",
        },
        {
          examName:
            "Entrance Examination Prof. Rajendra Singh (Rajju Bhaiya University)",
          website: "https://prsuniv.ac.in/",
          examType: "BBA, BCA, BA. LL.B.",
        },
        {
          examName: "BBS Entrance  Examination",
          website: "https://bbs.ac.in/",
          examType: "MBA, MCA",
        },
        {
          examName: "Joint Entrance Examination Council (Polytechnic), Uttar Pradesh",
          website: "https://jeecup.admissions.nic.in/",
          examType: "D. Pharm.",
        },
      ];
      
  return (
    <>

      {/* Admission Procedure */}
      <div className="sm:w-[80vw] w-95vw p-5   relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol my-8">
        <div>
          <h1 className="text-3xl text-center">ADMISSION PROCEDURE</h1>
          <h4 className="text-justify">
            &emsp;&emsp; Our admission process is designed to identify and
            welcome the brightest minds and most promising individuals who can
            contribute to our diverse and thriving community. We aim to ensure
            fairness, transparency, and equal opportunities for all applicants
            throughout the admission process. Application forms for admission
            can be obtained through both online and offline modes.
            <br />
            <br />
            &emsp;&emsp; The admission process in BBS group of Institutions
            takes place both through University counseling and admission in
            management quota seats. It varies depending on the institution, the
            program, and the level of study.
            <br />
            <br />
            &emsp;&emsp; In order to take your interest for admission forward,
            we encourage you to make an appointment with our Admission
            Counsellors and visit our campus. Our Admission Counsellors look
            forward to welcoming you to our campus for a tour and providing
            details, curricular and extracurricular activities and answer all
            your queries.
          </h4>
        </div>

        <div className="md:w-[80%] w-[100%] m-auto">
          <div className="overflow-x-auto ">
            <table className="table-auto   rounded-xl ">
              <thead>
                <tr className="bg-primary text-whiteCol p-4">
                  <th className="p-4">EXAM NAME</th>
                  <th className="p-4">WEBSITE</th>
                  <th className="p-4">EXAM TYPE</th>
                </tr>
              </thead>
              <tbody>
                {webTable.map((data: any, index: any) => (
                  <tr
                    key={index}
                    className="p-2 border border-gray-dark odd:bg-gray"
                  >
                    <td className="p-2 border-2 border-gray-dark">
                      {data.examName}
                    </td>
                    <td className="p-2 border-2 border-gray-dark">
                     <a className="text-primary font-bold" 
                     href={data.website} target="blank">
                      {data.website.split("//")[1].replace('/','')}
                     </a>
                    </td>
                    <td className="p-2 border-2 border-gray-dark">
                      {data.examType}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* ADMISSION TO B.TECH - FIRST YEAR */}
      <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
        <div>
          <h2 className="text-center">ADMISSION TO B.TECH - FIRST YEAR</h2>
          <div>
            <h4 className="bg-primary text-whiteCol px-6 py-2 rounded-r-full text-center w-max">Through Counseling</h4>
            <h4 className="text-justify">
              &emsp;&emsp; 85% seats of total approved intake will be filled
              through Counseling based on the JEE- 2025 Mains Rank as per the
              eligibility notified by AICTE/AKTU for the session 2026-27.
            </h4>
          </div>
          <div>
            <h4 className="bg-primary text-whiteCol px-6 py-2 rounded-r-full text-center w-max">Procedure</h4>
            <h4 className="text-justify">
              &emsp;&emsp; For participating in the counseling, the candidates are required to visit official website of the university www.aktu.ac.in regularly for detailed information which will be announced shortly.
              <br/>
              &emsp;&emsp;After the Counseling the candidate will get an Allotment Letter.
              <br/>
              &emsp;&emsp;Thereafter, the candidate is required to visit the allotted college on the dates as mentioned in the Allotment letter for the final reporting along with the required fees and documents.
              <br/>
              &emsp;&emsp;Before coming for the reporting to the college, kindly visits the college website www.bbs.ac.in to know the detailed information.

            </h4>
          </div>
          <div>
            <h4 className="bg-primary text-whiteCol px-6 py-2 rounded-r-full text-center w-max">Direct Admission</h4>
            <h4 className="text-justify">
              &emsp;&emsp; 15% seats will be offered to eligible candidate through direct admissions based on the guidelines of AICTE / AKTU and as per the College policy for the session 2026-27.
            </h4>
          </div>
          <div>
            <h4 className="bg-primary text-whiteCol px-6 py-2 rounded-r-full text-center w-max">Procedure </h4>
            <h4 className="text-justify">
              &emsp;&emsp; Candidate has to apply online through the college website <a className="text-primary font-bold" href="https://bbs.ac.in/">https://bbs.ac.in/</a> 
              <br/>
              &emsp;&emsp;  Institute will shortlist the candidate on the basis of their PCM % at 10+2 Level and JEE Main Score / Rank.
              <br/>
              &emsp;&emsp;On the basis of marks scored, the candidate will be offered seat for the admission.
            </h4>
          </div>
        </div>
      </div>
      
      {/* ADMISSION TO BBA, BCA, BA. LL.B. */}
      <div className="w-[80vw] p-5 mt-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
        <div>
          <h2 className="text-center">ADMISSION TO BBA, BCA, BA. LL.B. (Hons)</h2>
          <h3>&emsp;&emsp;Seats will be offered to eligible candidate through direct admissions based on the guidelines of Prof. Rajendra Singh (Rajju Bhaiya University)  and as per the College policy for the session 2026-27.</h3>
        </div>
      </div>
     
      {/* ADMISSION TO MBA */}
      <div className="w-[80vw] p-5 mt-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
        <div>
          <h2 className="text-center">ADMISSION TO MBA & MCA</h2>
          <h3>&emsp;&emsp;Seats will be offered to eligible candidate through direct admissions based on the guidelines of AKTU  and as per the College policy for the session 2026-27.</h3>
        </div>
      </div>
      
      
                
    </>
  );
};

export default AdmissionProcedure;
