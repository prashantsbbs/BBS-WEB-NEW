export function stripMarkdown(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, "$1") // bold remove
    .replace(/\*(.*?)\*/g, "$1") // italic remove
    .replace(/\[(.*?)\]\((.*?)\)/g, "$1") // links remove
    .replace(/`(.*?)`/g, "$1") // inline code remove
    .replace(/\n+/g, " ") // new lines remove
    .trim();
}