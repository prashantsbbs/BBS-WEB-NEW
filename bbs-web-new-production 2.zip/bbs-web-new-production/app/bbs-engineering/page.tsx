'use client';
import Image from 'next/image';
import 'animate.css';
import { bbsLabs } from '../constant/bbsLabs';
import Arrow from '../../app/common/arrow';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import CampusHiglight from '../common/campusHiglight';
import NewsEventsSection from '../home/news&events';
import { useEffect, useState } from 'react';
import AppService from '../services';
import Head from 'next/head';
import SeoWrapper from '../common/SeoWrapper';

const highlights = [
  {
    title: 'Quality Education',
    description:
      'Our programs are designed to meet global standards and are taught by experienced faculty members who are experts in their respective fields.',
  },
  {
    title: 'State-of-the-Art Facilities',
    description:
      'Our campus boasts modern infrastructure, well-equipped laboratories, and advanced technology to facilitate effective teaching, learning, and research.',
  },
  {
    title: 'Industry-Relevant Curriculum',
    description:
      'We continuously update our curriculum to align with industry trends, ensuring that our students are well-prepared to meet the demands of the ever-evolving job market.',
  },
  {
    title: 'Hands-On Learning',
    description:
      'Practical training, industry internships, and project-based learning opportunities enable students to gain real-world experience and develop practical skills.',
  },
  {
    title: 'Placement Assistance',
    description:
      'We have a dedicated placement cell that works tirelessly to provide placement assistance and career guidance to our students, helping them secure lucrative job opportunities in top companies.',
  },
  {
    title: 'Holistic Development',
    description:
      'In addition to academic excellence, we focus on the holistic development of our students, nurturing their leadership abilities, communication skills, and ethical values.',
  },
];

const programOffered = [
  {
    title: 'B.Tech',
  },
  {
    title: 'B.Tech (LE)',
  },
  {
    title: 'M.Tech',
  },
  {
    title: 'MBA',
  },
];

const departmentOffered = [
  {
    title: 'ECE',
    link: '/electronics-communication-engineering',
    intake: '60',
  },
  {
    title: 'AI & ML',
    link: '/btech-aiml',
    intake: '120',
  },
  {
    title: 'M.Tech CSE',
    link: '/m-tech-cse',
    intake: '18',
  },
  {
    title: 'CSE',
    link: '/computer-science-engineering',
    intake: '180',
  },
  {
    title: 'CIVIL',
    link: '/civil-engineering',
    intake: '60',
  },
  {
    title: 'ME',
    link: '/mechanical-engineering',
    intake: '60',
  },
  {
    title: 'EN',
    link: '/electrical-electronics-engineering',
    intake: '60',
  },
  {
    title: 'CAD/CAM',
    link: '/m-tech-cad-cam',
    intake: '18',
  },
  {
    title: 'MBA-Marketing',
    link: 'mba',
    intake: '',
  },
  {
    title: 'MBA-Human Resource Management',
    link: 'mba',
  },
  {
    title: 'MBA-Information Technology',
    link: 'mba',
  },
  {
    title: 'MBA-International Business',
    link: 'mba',
  },
  {
    title: 'MBA-Finance',
    link: 'mba',
  },
];

const mission = [
  {
    goal: 'Empowering Students: To provide a transformative learning experience through a blend of theoretical knowledge and practical skills, preparing students for the challenges of the evolving global landscape.',
  },
  {
    goal: 'Fostering Innovation: To cultivate an environment of research, creativity, and technological advancement, enabling students and faculty to develop solutions for real-world problems.',
  },
  {
    goal: 'Building Values: To instill ethical values, social responsibility, and professional integrity, ensuring holistic development and societal contribution.',
  },
  {
    goal: 'Strengthening Industry-Academia Collaboration: To forge strong partnerships with industry leaders, bridging the gap between academia and the professional world.',
  },
  {
    goal: 'Promoting Lifelong Learning: To encourage continuous learning and adaptability in students and faculty to meet the demands of an ever-changing world.',
  },
];

const defaultState = {
  isLoading: false,
  newsList: [],
  eventList: [],
};
const BBSEngineering = () => {
  const [state, setState] = useState(defaultState);

  const fetchNewsList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getNewsList();
    if (!error) {
      setState((prev: any) => ({ ...prev, newsList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  const fetchEventList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getEventList();
    if (!error) {
      setState((prev: any) => ({ ...prev, eventList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  useEffect(() => {
    fetchNewsList();
    fetchEventList();
  }, []);

  return (
    <>
      <SeoWrapper
        title="Top Engineering Colleges in UP for B.Tech Courses"
        description="Join one of the top engineering colleges in UP at BBSCET. Get hands-on B.Tech learning, modern labs, expert faculty, and strong career and placement support."
        keywords="top engineering colleges in up"
      >
        <div className="bg-gray pb-6 mb-3">
          {/* why BBS */}
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              src={'/bbsEngineering.webp'}
              width={1600}
              height={1000}
              unoptimized={true}
              alt={'BBS Engineering'}
              className=" bgImage_about   "
            />
          </div>

          <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
            <h2 className="text-5xl">
              BBS College of Engineering & Technology
            </h2>
            <h4 className="text-justify">
              &emsp;&emsp;Welcome to BBS College of Engineering and Technology
              (BBSCET). We are one of the top engineering colleges in UP. Our
              college began in 2002 under Beni Madhav Shiksha Samiti.
              <br />
              <br />
              &emsp;&emsp;BBSCET is affiliated with Dr. A.P.J. Abdul Kalam
              Technical University, Lucknow, and is approved by AICTE and MHRD,
              Govt. of India. These approvals show that our college is trusted.
              <br />
              <br />
              &emsp;&emsp;BBSCET is a private college, and we offer B.Tech and
              M.Tech courses in computer science, mechanical engineering, and
              other branches. Our campus is large and has modern labs,
              workshops, and tools for hands-on learning. Our teachers are well
              qualified, and lab instructors bring experience. They explain
              things clearly and guide students step by step.
              <br />
              <br />
              &emsp;&emsp; In our classes, we mix theory with projects. Students
              build things, test them, and learn to solve real problems. This
              training helps students gain skills employers want. Many students
              get strong placement offers after completing B.Tech. We focus on
              career readiness and industry ties so students leave job-ready.
              <br />
              <br />
              &emsp;&emsp; If you make a list of local colleges, we often rank
              in the top 10 in regional reports. Our rank is usually high.
              Students choose BBSCET to make wise education choices. Our college
              gives useful learning, steady support, and good career chances.
              Join us to learn, build skills, and start a solid engineering
              career. Check our course pages to find the best B.Tech branch for
              you.
            </h4>
          </div>
          <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
            <h3 className="bg-pink font-semibold px-8 py-2 rounded-r-full text-whiteCol w-max ">
              About BBSCET:
            </h3>
            <h4 className="text-justify">
              &emsp;&emsp; At BBS College of Engineering and Technology
              (BBSCET), we guide students to succeed in both their studies and
              careers. With a long history of innovation and achievements, our
              college is one of the top engineering universities in UP. We give
              students a friendly and creative learning environment to help them
              grow and become confident professionals.
              <br />
              <br />
              &emsp;&emsp;We offer many undergraduate and postgraduate programs
              in engineering, computer science, and management. These courses
              are designed to match what industries need today and in the
              future. Students can explore modern, practical courses at one of
              the best private engineering colleges in UP and get ready for a
              strong career in their field.
            </h4>
            <br />
            <div className="grid lg:grid-cols-2 ">
              <div className="">
                <h3 className="font-bold">Undergraduate Programs (B.Tech):</h3>
                <ul className="">
                  <li>Computer Science &amp; Engineering (CSE)</li>
                  <li>
                    Artificial Intelligence &amp; Machine Learning (AI &amp; ML)
                  </li>
                  <li>Electrical &amp; Electronics Engineering (EN)</li>
                  <li>Electronics &amp; Communication Engineering (ECE)</li>
                  <li>Mechanical Engineering (ME)</li>
                  <li>Civil Engineering (CE)</li>
                </ul>
              </div>
              <div>
                <h3 className="font-bold">Postgraduate Programs:</h3>
                <ul>
                  <li>M.Tech in Computer Science &amp; Engineering (CSE)</li>
                  <li>M.Tech in CAD/CAM</li>
                  <li>Master of Computer Applications (MCA)</li>
                  <li>Master of Business Administration (MBA)</li>
                </ul>
              </div>
            </div>

            <br />
            <h4>
              &emsp;&emsp; At BBSCET, we blend rigorous academics with
              real-world applications, equipping our students to thrive in
              today’s fast-evolving industries. Whether you&#39;re aspiring to
              innovate in technology, transform businesses, or engineer the
              future, BBSCET is your launchpad to success.
            </h4>
          </div>
        </div>

        <div className="bg-gray pb-6 ">
          <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
            <h3 className="bg-pink font-semibold px-8  mb-6  py-2 rounded-full m-auto text-whiteCol w-max ">
              Programs
            </h3>
            <div className="grid lg:grid-cols-4 grid-cols-2">
              {programOffered.map((list: any, index) => (
                <>
                  <div className="">
                    <Image
                      src={'/icon/graduateLogo.webp'}
                      width={100}
                      height={50}
                      alt="Graduate"
                      className="m-auto"
                      unoptimized={true}
                    />
                    <h3 className=" font-semibold text-center hover:text-pink">
                      {list.title}
                    </h3>
                  </div>
                </>
              ))}
            </div>

            <div>
              <h4>
                Our flagship programs, the B.Tech (4 years) and MBA , are
                meticulously designed to nurture future-ready engineers with a
                solid foundation in technical knowledge, problem-solving
                abilities, and practical skills. Guided by a distinguished
                faculty of experienced academicians, industry professionals, and
                research experts, our programs offer an ideal balance of
                theoretical understanding and real-world application. Through
                cutting-edge laboratories, industry collaborations, and hands-on
                projects, we ensure our students are equipped to meet the
                evolving demands of the global engineering landscape.
              </h4>
            </div>
          </div>
        </div>

        {/* Mission Vision */}
        <div className="grid md:grid-cols-2 grid-cols-1  ">
          <div className="bg-secondary p-8">
            <div className="p-5 lg:p-20 sm:p-10 m-auto animate__animated animate__zoomIn">
              <div
                className={`p-4 animate__animated animate__zoomIn flex m-auto bg-primary rounded-full w-[100px] h-[100px]`}
              >
                <Image
                  src="/about/vision.svg"
                  alt="Vision"
                  className="m-auto"
                  unoptimized={true}
                  width={200}
                  height={150}
                />
              </div>
              <h2 className="text-5xl">Vision</h2>

              <h3 className="text-justify">
                To emerge as a center of excellence in technical and managerial
                education, fostering innovation, creativity, and leadership to
                produce globally competent professionals who contribute
                meaningfully to society and drive sustainable development.
              </h3>
            </div>
          </div>
          <div className="bg-whiteCol p-8">
            <div className="p-5 lg:p-20 sm:p-10 m-auto animate__animated animate__zoomIn">
              <div
                className={`p-4 animate__animated animate__zoomIn flex m-auto bg-primary rounded-full w-[100px] h-[100px]`}
              >
                <Image
                  src="/about/mission.svg"
                  alt="Mission"
                  unoptimized={true}
                  className="m-auto"
                  width={200}
                  height={150}
                />
              </div>
              <h2 className="text-5xl">Mission</h2>
              <div className="text-left flex gap-5">
                <div className="">
                  {mission.map((list: any, index) => (
                    <>
                      <div key={index} className="flex gap-6">
                        <Arrow />
                        <h3 className="m-0">{list.goal}</h3>
                      </div>
                    </>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gray pb-6 ">
          <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
            <h3 className="bg-pink font-semibold px-8  mb-6  py-2 rounded-full m-auto text-whiteCol w-max ">
              Departments
            </h3>
            <div className="grid md:grid-cols-5 grid-cols-2">
              {departmentOffered.map((list: any, index) => (
                <>
                  <div className="">
                    <Link href={list?.link}>
                      <Image
                        src={'/icon/graduateLogo.webp'}
                        width={100}
                        unoptimized={true}
                        height={50}
                        alt="Graduate"
                        className="m-auto"
                      />
                      <h3 className=" font-semibold mb-0 text-center hover:text-pink">
                        {list.title}
                      </h3>
                      <h4 className="m-0 mb-2 font-semibold text-center hover:text-pink">
                        {list?.intake && `Intake : ${list?.intake}`}
                      </h4>
                    </Link>
                  </div>
                </>
              ))}
            </div>

            <div>
              <h4>
                Our flagship programs, the BALLB (5 years) and LLB (3 years),
                are meticulously crafted to equip students with a strong
                foundation in legal principles, critical thinking skills, and
                practical expertise. Taught by a distinguished faculty
                comprising experienced legal scholars, practitioners, and
                industry experts, our courses offer a blend of theoretical
                knowledge and hands-on learning opportunities.
              </h4>
            </div>
          </div>
        </div>

        <div className="bg-gray">
          <div className="w-[80vw] p-8  m-auto  ">
            <h1 className="font-semibold">Labs at BBSCET</h1>
            <h4 className="text-justify">
              <div className="md:columns-2 columns-1">
                {bbsLabs.map((list: any, index: number) => (
                  <div key={index} className="flex gap-4 ">
                    <Arrow />
                    {list.label}
                  </div>
                ))}
              </div>
            </h4>
          </div>
        </div>

        <div className="bg-primary flex p-6 ">
          <div className="md:w-[80%] w-[90%] m-auto rounded-xl bg-whiteCol p-6">
            <h2 className="text-center">
              Why Choose BBS College of Engineering & Technology?
            </h2>
            <div className="lg:columns-2 columns-1 ">
              {highlights.map((list: any, index) => (
                <>
                  <div className="m-2">
                    <h3 className="font-semibold text-pink">{list.title}</h3>
                    <h4 className="text-justify pb-6">{list.description}</h4>
                  </div>
                </>
              ))}
            </div>
          </div>
        </div>

        <div></div>

        <div className=" p-5  relative z-10 rounded-xl m-auto  shadow-md bg-whiteCol ">
          <div className=" m-auto md:px-16 px-4">
            <div className="p-6">
              <h3 className="bg-pink text-center font-semibold  px-8 py-2 rounded-full text-whiteCol w-max ">
                Join Us:
              </h3>
              <h4 className="text-justify py-6">
                &emsp;&emsp;Whether you aspire to pursue a career in
                engineering, technology, or management, BBS College of
                Engineering and Technology is the perfect destination to realize
                your dreams. Explore our website to learn more about our
                programs, faculty, admission process, and campus life. Join us
                on this exciting journey towards academic excellence and
                professional success.
                <br />
              </h4>
              <Link href={'/contact-us'}>
                <ButtonCustom
                  btnColor="primary"
                  btnText="Contact Us"
                  textCol="whiteCol"
                />
              </Link>
            </div>
          </div>
        </div>

        <CampusHiglight />
        <NewsEventsSection
          newsList={state.newsList}
          eventList={state.eventList}
        />
      </SeoWrapper>
    </>
  );
};

export default BBSEngineering;
