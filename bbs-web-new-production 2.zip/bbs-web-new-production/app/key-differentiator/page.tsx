import Image from 'next/image';

const KeyDiffrentiator = () => {
  return (
    <>
      <div className="bg-gray p-8 relative">
        <div className="text-center mb-6">
          <h1>Key Differentiators</h1>
          <h3>
            BBS excels in placements with personalized support, industry ties,
            hands-on learning, placement infrastructure, alumni engagement, and
            curriculum updates.
          </h3>
        </div>
        {/* center Image---------------------- */}

        <Image
          unoptimized={true}
          src={'/placement/key-display.webp'}
          width={500}
          height={60}
          alt="Key Display"
          loading="lazy"
          className="absolute top-[58%] left-[50%] tranformKeyImage lg:block hidden "
        />

        {/* blocks--------------------------------- */}
        <div className="grid lg:grid-cols-4 gap-4 lg:w-[80%] w-[95%] m-auto  ">
          {/* 1st------------------ */}
          <div className="bg-secondary px-6 md:py-8 py-4 m-auto">
            <Image
              unoptimized={true}
              src={'/placement/icon/key-icon1.webp'}
              width={60}
              height={60}
              alt="Key Differentiator"
              loading="lazy"
              className=""
            />
            <h3 className="font-semibold text-xl">
              Dynamic Industry Connections
            </h3>
            <h5 className="text-justify">
              Forge dynamic connections with industry leaders through our
              extensive network of partnerships, ensuring prime placement
              opportunities for our students.
            </h5>
          </div>
          {/* 2nd------------------------ */}
          <div className="bg-gray-dark md:col-start-4 px-6 md:py-8 py-4 m-auto">
            <Image
              unoptimized={true}
              src={'/placement/icon/key-icon2.webp'}
              width={60}
              height={60}
              alt="Key Differentiator"
              loading="lazy"
              className=""
            />
            <h3 className="font-semibold text-xl">
              Comprehensive Career Services
            </h3>
            <h5 className="text-justify">
              Our Career Services Division provides holistic support, offering
              tailored interview preparation, skill-building workshops, and
              professional training sessions to enhance student employability.
            </h5>
          </div>
          {/* 3rd---------------------------- */}
          <div className="bg-gray-dark px-6 md:py-8 py-4 m-auto">
            <Image
              unoptimized={true}
              src={'/placement/icon/key-icon3.webp'}
              width={60}
              height={60}
              alt="Key Differentiator"
              loading="lazy"
              className=""
            />
            <h3 className="font-semibold text-xl">
              Immersive Professional Experiences
            </h3>
            <h5 className="text-justify">
              Embark on immersive professional journeys with BBS as our students
              engage in a myriad of national and international internships,
              gaining invaluable hands-on experience in diverse work
              environments.
            </h5>
          </div>
          {/* 4th--------------------------- */}
          <div className="bg-secondary md:col-start-4 px-6 md:py-8 py-4 m-auto">
            <Image
              unoptimized={true}
              src={'/placement/icon/key-icon4.webp'}
              width={60}
              height={60}
              alt="Key Differentiator"
              loading="lazy"
              className=""
            />
            <h3 className="font-semibold text-xl">
              Empowering Training Initiatives
            </h3>
            <h5 className="text-justify">
              Empower yourself with our training initiatives led by the Training
              & Placement Cell, dedicated to equipping students with essential
              skills and knowledge through tailored interview preparations and
              comprehensive training programs.
            </h5>
          </div>
        </div>
      </div>
    </>
  );
};

export default KeyDiffrentiator;
