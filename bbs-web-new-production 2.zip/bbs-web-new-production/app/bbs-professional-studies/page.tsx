'use client';
import Image from 'next/image';
import 'animate.css';
import { bbsLabs } from '../constant/bbsLabs';
import Arrow from '../../app/common/arrow';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import CampusHiglight from '../common/campusHiglight';
import NewsEventsSection from '../home/news&events';
import { useEffect, useState } from 'react';
import AppService from '../services';

const institutionFeatures = [
  {
    title: 'Industry-Relevant Curriculum',
    description:
      'Our courses are meticulously crafted in consultation with industry experts to ensure that students acquire the latest knowledge and skills demanded by employers.',
  },
  {
    title: 'Experienced Faculty',
    description:
      'Our faculty members are seasoned professionals and scholars with extensive industry experience, providing students with invaluable insights and mentorship.',
  },
  {
    title: 'Hands-On Learning',
    description:
      'Through internships, projects, case studies, and workshops, students gain practical experience and develop critical thinking, problem-solving, and decision-making skills.',
  },
  {
    title: 'State-of-the-Art Facilities',
    description:
      'Our campus features modern facilities, well-equipped laboratories, and cutting-edge technology, creating an optimal environment for learning and research.',
  },
  {
    title: 'Career Support',
    description:
      'We offer comprehensive career counselling, placement assistance, and networking opportunities to help students launch their careers and achieve their professional goals.',
  },
  {
    title: 'Holistic Development',
    description:
      'In addition to academic excellence, we emphasize the holistic development of our students, fostering leadership, teamwork, communication, and ethical values.',
  },
];

const coursesOffered = [
  {
    title: 'Bachelor of Business Administration (BBA)',
    link: 'bba',
    intake: '120',
  },
  {
    title: 'Bachelor of Computer Applications (BCA)',
    link: 'bca',
    intake: '120',
  },
];

const mission = [
  {
    goal: 'To offer affordable education accessible to individuals from all backgrounds within professional studies.',
  },
  {
    goal: 'To provide cutting-edge technical, legal, and other professional courses, emphasizing the cultivation of ethical career values.',
  },
  {
    goal: 'To cultivate skilled and competent professionals dedicated to addressing societal needs within professional studies.',
  },
  {
    goal: 'To enhance the employability and entrepreneurial spirit of stakeholders within professional studies.',
  },
  {
    goal: 'To promote a culture of innovation and lifelong learning among students and faculty within professional studies.',
  },
];

const defaultState = {
  isLoading: false,
  newsList: [],
  eventList: [],
};

const BBSProfessionalStudies = () => {
  const [state, setState] = useState(defaultState);

  const fetchNewsList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getNewsList();
    if (!error) {
      setState((prev: any) => ({ ...prev, newsList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  const fetchEventList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getEventList();
    if (!error) {
      setState((prev: any) => ({ ...prev, eventList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  useEffect(() => {
    fetchNewsList();
    fetchEventList();
  }, []);

  return (
    <>
      <div className="bg-gray pb-6 mb-3">
        {/* why BBS */}
        <div className="m-auto   animate__animated animate__slideInLeft">
          <Image
            src={'/bbsProfessionalBanner.webp'}
            width={1600}
            height={1000}
            unoptimized={true}
            alt={'BBS Professional Banner'}
            className=" bgImage_about   "
            style={{ backgroundPositionY: 'top' }}
          />
        </div>

        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <h2 className="">Welcome to BBS Institute of Professional Studies</h2>
          <h4 className="text-justify">
            &emsp;&emsp;At BBS Institute of Professional Studies, we are
            committed to fostering the next generation of business and
            technology leaders through our comprehensive undergraduate programs.
            With a focus on excellence, innovation, and practical learning, we
            prepare students to thrive in today&apos;s dynamic professional
            landscape. BBS Institute of Professional Studies has its affiliation
            from Prof. Rajendra Singh (Rajju Bhaiya) University, Prayagraj.
            <br />
          </h4>
        </div>

        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <h3 className="bg-pink font-semibold px-8 py-2 rounded-r-full text-whiteCol w-max ">
            About BBSIPS :
          </h3>
          <h4 className="text-justify">
            &emsp;&emsp;Established with a vision to bridge the gap between
            academia and industry, BBS Institute of Professional Studies offers
            a range of undergraduate programs designed to equip students with
            the knowledge, skills, and mindset required to succeed in the
            competitive world of business and technology.
            <br />
          </h4>
        </div>
      </div>

      <div className="bg-gray pb-6 ">
        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <h3 className="bg-pink font-semibold px-8  mb-6  py-2 rounded-full m-auto text-whiteCol w-max ">
            Courses Offered:
          </h3>
          <div className="grid lg:grid-cols-2 grid-cols-1">
            {coursesOffered.map((list: any, index) => (
              <Link key={index} href={list.link}>
                <Image
                  src={'/icon/graduateLogo.webp'}
                  width={100}
                  unoptimized={true}
                  height={50}
                  alt="courses Offered"
                  className="m-auto"
                />
                <h3 className=" font-semibold text-center hover:text-pink">
                  {list.title}
                </h3>
                <h3 className=" font-semibold text-center hover:text-pink">
                  Intake : {list.intake}
                </h3>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Mission Vision */}
      <div className="grid md:grid-cols-2 grid-cols-1  ">
        <div className="bg-secondary p-8">
          <div className="p-5 lg:p-20 sm:p-10 m-auto animate__animated animate__zoomIn">
            <div
              className={`p-4 animate__animated animate__zoomIn flex m-auto bg-primary rounded-full w-[100px] h-[100px]`}
            >
              <Image
                src="/about/vision.svg"
                alt="Vision"
                unoptimized={true}
                className="m-auto"
                width={200}
                height={150}
              />
            </div>
            <h1 className="">Vision</h1>

            <h3 className="text-justify">
              At BBS Professional Studies, our vision is to foster the growth
              and refinement of our students&apos; talents during their
              formative years, molding them into exemplary professionals of
              tomorrow. With a steadfast commitment to holistic development, our
              aim is to empower students with the technical and management
              acumen required to excel in the dynamic landscape of their chosen
              fields. We aspire to nurture the leaders of tomorrow!
            </h3>
          </div>
        </div>
        <div className="bg-whiteCol p-8">
          <div className="p-5 lg:p-20 sm:p-10 m-auto animate__animated animate__zoomIn">
            <div
              className={`p-4 animate__animated animate__zoomIn flex m-auto bg-primary rounded-full w-[100px] h-[100px]`}
            >
              <Image
                src="/about/mission.svg"
                alt="Mission"
                className="m-auto"
                unoptimized={true}
                width={200}
                height={150}
              />
            </div>
            <h2 className="text-5xl">Mission</h2>
            <div className="text-left flex gap-5">
              <div className="">
                {mission.map((list: any, index) => (
                  <>
                    <div key={index} className="flex gap-6">
                      <Arrow />
                      <h3 className="m-0">{list.goal}</h3>
                    </div>
                  </>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-primary flex p-6 ">
        <div className="md:w-[80%] w-[90%] m-auto rounded-xl bg-whiteCol p-6">
          <h2 className="text-center">
            Why Choose BBS Institute of Professional Studies?
          </h2>
          <div className="lg:columns-2 columns-1 ">
            {institutionFeatures.map((list: any, index) => (
              <>
                <div key={index} className="m-2">
                  <h3 className="font-semibold text-pink">{list.title}</h3>
                  <h4 className="text-justify pb-6">{list.description}</h4>
                </div>
              </>
            ))}
          </div>
        </div>
      </div>

      <div></div>

      <div className=" p-5  relative z-10 rounded-xl m-auto  shadow-md bg-whiteCol ">
        <div className=" m-auto md:px-16 px-4">
          <div className="p-6">
            <h3 className="bg-pink text-center font-semibold  px-8 py-2 rounded-full text-whiteCol w-max ">
              Join Us:
            </h3>
            <h4 className="text-justify py-6">
              &emsp;&emsp;Whether you aspire to pursue a career in business
              management, entrepreneurship, information technology, or software
              development, BBS Institute of Professional Studies is your gateway
              to success. Explore our website to learn more about our programs,
              faculty, admission process, and campus life. Join us on this
              exciting journey towards realizing your potential and achieving
              your dreams.
              <br />
            </h4>
            <Link href={'/contact-us'}>
              <ButtonCustom
                btnColor="primary"
                btnText="Contact Us"
                textCol="whiteCol"
              />
            </Link>
          </div>
        </div>
      </div>

      <CampusHiglight />
      <NewsEventsSection
        newsList={state.newsList}
        eventList={state.eventList}
      />
    </>
  );
};

export default BBSProfessionalStudies;
