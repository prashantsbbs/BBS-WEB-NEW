'use client';
import Image from 'next/image';
import 'animate.css';
import Arrow from '../common/arrow';
import ScrollTrigger from 'react-scroll-trigger';
import { useEffect, useState } from 'react';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import MasterCourse from '../eligibility-criteria/masterCourse';
import SwiperComponent from '../home/congracts-section/swiper';
import CourseSlider from '../common/courseSlider';
import FutureReadyEng from '../common/futureReadyEng';
import AppService from '../services';
import Head from 'next/head';
import SeoWrapper from '../common/SeoWrapper';

const programHighlights = [
  { description: 'Case-based Learning Approach' },
  { description: 'State-of-the-art Lab Facilities' },
  { description: 'National and International Immersion Programs' },
  {
    description:
      'Industry-Academia Partnerships for Internship and Placement Assistance',
  },
  {
    description:
      'Skill Enhancement Courses such as business communication, effective presentation and more',
  },
  {
    description:
      'MoUs with 23+ Corporates for Training, Research, and Development',
  },
  {
    description:
      'Encouraging Entrepreneurship in Students through Funding, Mentoring, and Network Connection',
  },
  {
    description:
      'Industry Visits, Guest Lectures, Seminars, and Workshops by Eminent Researchers and Industry Practitioners',
  },
  {
    description:
      'Hands-on Training in Technologies and Tools like iOS Training using Swift, mobile application development (using Kotlin), full stack development, internet technologies, internet of things, data science, cyber security, etc.',
  },
];

const careerProspectus = [
  {
    role: 'CAD/CAM Software Developer',
    description:
      'Designing and developing software solutions tailored for computer-aided design and manufacturing processes.',
  },
  {
    role: 'Testing Engineer',
    description:
      'Ensuring the reliability and functionality of CAD/CAM software through rigorous testing and quality assurance procedures.',
  },
  {
    role: 'System Analyst',
    description:
      'Analyzing user requirements and system specifications to design efficient CAD/CAM solutions that meet industry needs.',
  },
  {
    role: 'Technical Support Engineer',
    description:
      'Providing technical assistance and troubleshooting support to users encountering issues with CAD/CAM software or systems.',
  },
  {
    role: 'IT Technical Content Developer',
    description:
      'Creating technical documentation, tutorials, and training materials for CAD/CAM software users and developers.',
  },
  {
    role: 'System Database Administrator',
    description:
      'Managing databases and data repositories integral to CAD/CAM systems, ensuring data integrity, security, and accessibility.',
  },
];

const faculty = [
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
];

const EligibilityTable = [
  {
    name: 'B. Tech.',
    duration: '4 yrs.',
    specialization: 'Computer Science & Engineering',
    eligibility:
      'Passed 10+2 examination with Physics and Mathematics as compulsory subjects along with Chemistry / Computer Science. With at least 50% marks in the above subjects, taken together and 50% marks overall',
    relaxation:
      'Five percent relaxation in the minimum eligibility is provided to SC/ST Category Students',
  },
  {
    name: 'B. Tech.(Lateral Entry).',
    duration: '3 yrs.',
    specialization: 'Computer Science & Engineering',
    eligibility:
      'With at least 50% in 3 years Diploma recognized by Board of Technical Education / University or B Sc (PCM)',
    relaxation:
      'Five percent relaxation in the minimum eligibility is provided to SC/ST Category Students',
  },
];

const defaultState = {
  isLoading: false,
  facultyList: [],
};

const departmentId = 12;
const MtechCadCam = () => {
  const defaultAnimation = {
    courseOverview: false,
    highlights: false,
  };

  const [animationStart, setAnimationStart] = useState(defaultAnimation);

  const onEnterViewport = () => {
    setAnimationStart((prev) => ({
      ...prev,
      courseOverview: true,
      highlights: true,
    }));
  };

  const onExitViewport = () => {
    setAnimationStart((prev) => ({
      ...prev,
      courseOverview: true,
      highlights: true,
    }));
  };

  const [state, setState] = useState(defaultState);
  const fetchFacultyList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getFacultyList();
    if (!error) {
      // Rehan Code for Category Filtering
      const facultyList = data.filter(
        (item: any) => item?.attributes?.department?.data?.id === departmentId
      );

      setState((prevState) => ({
        ...prevState,
        facultyList,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchFacultyList();
  }, []);
  return (
    <>
      <SeoWrapper
        title="Leading Private M.Tech CAD CAM College in UP"
        description="Advance your M.Tech CAD CAM skills at BBS, a reputed private college in UP. Learn modern design, simulation, and manufacturing techniques."
        keywords="M.Tech College in UP"
      >
        {/* Hero Sectino */}
        <section className="">
          <div className="handleoverlflow w-[80%] m-auto grid md:grid-cols-2 grid-cols-1 justify-center items-center md:px-6 px-3 py-12">
            <div>
              <Image
                unoptimized={true}
                src={'/courses/mtech-icon.webp'}
                width={90}
                height={20}
                alt="M Tech Course Icon"
                className="animate__animated animate__fadeInLeftBig my-4 rotateAnimate"
              />
              <div>
                <h2 className="">PG Degree</h2>
                <div className="bg-secondary h-2 w-full"></div>
              </div>
              <h1 className="m-0">
                Master of Technology in Computer-Aided Design (CAD) and
                Computer-Aided Manufacturing (CAM)
              </h1>
            </div>

            <div className="md:p-8 p-4">
              <Image
                unoptimized={true}
                src={'/courses/mtech.webp'}
                width={600}
                height={20}
                alt="M Tech Courses"
                className="animate__animated animate__fadeInRight rounded-lg"
              />
            </div>
          </div>
        </section>

        {/* Course Overveiw */}

        <section className="bg-gray handleoverlflow">
          <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-24 px-6">
            <div data-aos="fade-right" className={`p-6 `}>
              <div>
                <h2>COURSE OVERVIEW</h2>
                <h4 className="text-justify">
                  M.Tech in Computer-Aided Design and Computer-Aided
                  Manufacturing (CAD/CAM) is an advanced postgraduate program
                  that integrates computational technologies with engineering
                  principles. Through theoretical coursework and hands-on
                  training, students gain proficiency in CAD and CAM tools,
                  geometric modeling, CNC programming, and additive
                  manufacturing. They also explore emerging technologies like
                  Artificial Intelligence, Machine Learning, and Cloud
                  Computing. Graduates are well-prepared for careers as CAD/CAM
                  engineers, design analysts, and manufacturing specialists
                  across various industries.
                </h4>
              </div>

              <div className="">
                <h2 className="uppercase">Major Tracks</h2>
                <div className="grid md:grid-cols-2 grid-cols-1">
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">CAD Technologies</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">CAM Technologies</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">Advanced Manufacturing Processes</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">
                      Emerging Technologies in Engineering
                    </h3>
                  </div>
                </div>
              </div>
            </div>

            <div className={`m-auto `} data-aos="fade-left">
              <div className="bg-secondary p-4 m-4 md:mr-12">
                <div className="p-4">
                  <h3 className="m-0">Duration</h3>
                  <h2 className="m-0">2 Years</h2>
                </div>
                <div className="p-4">
                  <h3 className="m-0">Programme Name</h3>
                  <h2 className="m-0">
                    Master of Technology in Computer-Aided Design (CAD) and
                    Computer-Aided Manufacturing (CAM)
                  </h2>
                </div>
              </div>
              <div className="bg-primary text-whiteCol p-4 m-4 md:ml-12">
                <div className="p-4">
                  <h2 className="m-0">Eligibility</h2>
                  <h5 className="text-justify m-0">
                    M.Tech (CAD/CAM) eligibility typically requires a
                    bachelor&apos;s degree in Engineering, a valid entrance exam
                    score like GATE, and a minimum aggregate around 55%-60%. A
                    background in Mechanical or Manufacturing Engineering is
                    preferred.
                  </h5>
                </div>
                <div className="p-4">
                  <Link href={'apply-online'} target="blank">
                    <ButtonCustom
                      btnColor={'secondary'}
                      btnText={'Apply Online'}
                      textCol={'primary'}
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Program Highliths */}

        <section className="md:p-12 py-6 " data-aos="zoom-in-up">
          <div className="w-[80%] m-auto bg-primary p-6 text-whiteCol">
            <div>
              <h2 className="text-secondary">Programme Highlights</h2>
              <div
                className={`md:columns-2 columns-1 
                            ${
                              animationStart.highlights
                                ? 'animate__animated animate__fadeInRight animate__slower'
                                : ''
                            }`}
              >
                {programHighlights.map((list: any, index) => (
                  <>
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h4 className="m-2">{list.description}</h4>
                    </div>
                  </>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Future Ready */}
        <FutureReadyEng
          department={
            <>
              Department of Computer Science <br />& Engineering
            </>
          }
        />

        {/* Advanced Options of Study */}
        {/* <ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}> */}
        <section data-aos="fade-up-right" className="md:p-12 py-6  bg-gray">
          <div className="w-[80%] m-auto bg-secondary rounded-xl p-6 text-whiteCol">
            <div>
              <h2 className="text-primary  text-center">Career Prospects</h2>
              <div className=" grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3   m-auto ">
                {careerProspectus.map((career: any, index) => (
                  <h3
                    key={index}
                    className="bg-whiteCol rounded-md drop-shadow-md px-6 py-2
                    text-primary m-0"
                  >
                    {career.role}
                  </h3>
                ))}
              </div>
            </div>
          </div>
        </section>
        {/* </ScrollTrigger> */}

        {/* Top Recruiters */}
        <div className="mt-12">
          <RecruitersComapnies />
        </div>

        {/* Eligibility  */}
        {/* <div className="md:p-12 p-8 ">
        <Eligibility EligibilityTable={EligibilityTable} />
      </div> */}

        {/* Faculty  */}
        {!!state.facultyList.length && (
          <div className="  bg-primary flex">
            <div className="lg:w-[85%] w-[90%] m-auto md:p-16 p-4  ">
              <h2 className="m-auto text-secondary text-center p-4">
                Our Faculty
              </h2>
              <CourseSlider elements={state.facultyList} />
            </div>
          </div>
        )}
      </SeoWrapper>
    </>
  );
};
export default MtechCadCam;
