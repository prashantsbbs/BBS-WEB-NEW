'use client';

import Image from 'next/image';
import SocialIcons from './socialIcons';
import Arrow from './arrow';
import { useContext, useEffect, useState } from 'react';
import { megaMenuList } from '../constant/constant';
import MobileHeader from './mobileHeader';
import Link from 'next/link';
import OutsideClickHandler from 'react-outside-click-handler';
import 'animate.css';
import EnquiryForm from './formMdal';
import { topBar, topBarRight } from '../constant/topBar';
import 'animate.css';
import CampusContext from '../context/campusContext';
import CoursesH from '../home/coursesH';
import AdmissionMobileFooter from './admissionMobFooter';
import ContactMobileFooter from './contactMobileFooter';
import CoursesMobileFooter from './coursesMobFooter';
import RegistrationForm from './apply-online-form';
import { usePathname } from 'next/navigation';

import Modal from '../apply-online/modal/index';
import AdmissionEnquiryForm from './admission-enquiry';

const Header = ({ courseList = [] }) => {
  const defaultState: any = {
    activeMenu: {},
    activeMenuName: '',
    megaMenueOpen: false,
    openMobileMenu: false,
    coursesMobile: false,
    ativeMobSidBar: 0,
    isSolidVariant: false,
    screenSizeLessThanDesktop: true,
  };

  const renderPanel = (step: number) => {
    let panel = <></>;
    switch (step) {
      case 1:
        panel = <CoursesMobileFooter setState={setState} />;
        break;
      case 2:
        panel = <AdmissionMobileFooter setState={setState} />;
        break;
      case 3:
        panel = <ContactMobileFooter />;
        break;
    }
    return panel;
  };

  const handleMobSidebar = (activeMenu: any) => {
    if (state.ativeMobSidBar === activeMenu) {
      setState((prev: any) => ({ ...prev, ativeMobSidBar: 0 }));
    } else {
      setState((prev: any) => ({ ...prev, ativeMobSidBar: activeMenu }));
    }
  };

  const modalclose = () => {
    if (state.megaMenueOpen === true) {
      setState((prevSatte: any) => ({
        ...prevSatte,
        megaMenueOpen: false,
      }));
    }
  };

  const delayFun = () => {
    setState((prev: any) => ({ ...prev, ativeMobSidBar: 0 }));
    if (state.openMobileMenu === false) {
      setState((prev: any) => ({ ...prev, openMobileMenu: true }));
    } else if (state.openMobileMenu) {
      setTimeout(() => {
        setState((prev: any) => ({ ...prev, openMobileMenu: false }));
      }, 1);
    }
  };

  const [state, setState] = useState<any>(defaultState);

  const handleActiveMenu = (activeMenu: any) => {
    if (state.megaMenueOpen) {
      setState((prevSatte: any) => ({
        ...prevSatte,
        megaMenueOpen: false,
      }));
    }
    setTimeout(() => {
      setState((prevSatte: any) => ({
        ...prevSatte,
        activeMenu,
        activeMenuName: activeMenu.title,
        megaMenueOpen: true,
      }));
    }, 1);
  };

  const handleSubmenu = (activesubMenu: any) => {};

  const [open, setOpen] = useState<boolean>(false);
  const handleEnquiryForm = () => {
    setOpen(true);
  };

  const urlPath = usePathname();

  const handleMegaMenuDisapper = () => {
    if (state.megaMenueOpen) {
      setState((prevSatte: any) => ({
        ...prevSatte,
        megaMenueOpen: false,
      }));
    }
  };
  const handleMegaMenunotDisapper = (arg: any) => {
    if (state.megaMenueOpen && arg) {
      setState((prevSatte: any) => ({
        ...prevSatte,
        megaMenueOpen: true,
      }));
    } else if (arg === false) {
      setState((prevSatte: any) => ({
        ...prevSatte,
        megaMenueOpen: false,
      }));
    }
  };

  const handleScroll = () => {
    console.log('handleScroll');
    const scrollPosition = window.scrollY || document.documentElement.scrollTop;

    setState((prev: any) => ({
      ...prev,
      isSolidVariant: scrollPosition > 100,
    }));
  };

  useEffect(() => {
    handleScroll();
  }, [urlPath]);

  const [isModalOpen, setIsModalOpen] = useState(false);

  const closeModal = () => {
    setIsModalOpen((prevState) => !prevState);
  };

  const getBodyWidth = (evt: any) => {
    if (evt.target.innerWidth < 768) {
      setState((prev: any) => ({ ...prev, screenSizeLessThanDesktop: false }));
    } else
      setState((prev: any) => ({ ...prev, screenSizeLessThanDesktop: true }));
  };

  useEffect(() => {
    if (window) {
      window.addEventListener('resize', getBodyWidth);
      const screenWidth = window.screen.width;

      if (screenWidth < 768) {
        setState((prev: any) => ({
          ...prev,
          screenSizeLessThanDesktop: false,
        }));
      } else
        setState((prev: any) => ({ ...prev, screenSizeLessThanDesktop: true }));
    }
    return () => window && window.removeEventListener('resize', getBodyWidth);
  }, []);

  return (
    <>
      <div></div>

      {/* Admission Enquir Form  */}
      <div
        onMouseEnter={handleEnquiryForm}
        className=" h-10 cursor-pointer bg-danger1 text-primary py-2 text-sm px-4 rounded-b-xl drop-shadow-md  right-4 origin-right z-50 top-[40%] fixed   rotate-90"
      >
        Admission Enquiry
      </div>
      <div className="h-10 cursor-pointer bg-danger1 text-whiteCol py-2 text-sm px-4 rounded-b-xl drop-shadow-md right-4 origin-right z-50 top-[80%] fixed  rotate-90">
        <div className="">
          <SocialIcons
         
            btnColor={'danger1'}
            //  btnInvert='invert'
            size={11}
            rotate="-rotate-90"
          ></SocialIcons>
        </div>
      </div>
      <AdmissionEnquiryForm isOpen={open} onClose={() => setOpen(false)} />
      <Modal isOpen={isModalOpen} onClose={closeModal} />

      <Link target="_blank" href={'https://erp.bbs.ac.in/pay/index.php'}>
        <h4 className=" cursor-pointer 	 bg-danger1 text-primary py-2 text-sm px-2 rounded-t-xl drop-shadow-md  -left-11 z-50 top-[25%] fixed   rotate-90">
          Pay Fee Online
        </h4>
      </Link>
      <Link href={'/alumini-form'}>
        <div className=" cursor-pointer 	 bg-danger1 text-primary py-2 text-sm px-4 rounded-t-xl drop-shadow-md  -left-11 z-50 top-[50%] fixed   rotate-90">
          Alumini Form
        </div>
      </Link>

      {/* --------------------------------Desktop Menu-------------------------------- */}
      {/* <div
        className={`  flex justify-between drop-shadow-xl items-center  relative z-40 sticky top-0  lg:flex w-full px-5 lg:px-8 xl:px-20 
  ${
    state.isSolidVariant || urlPath === '/'
      ? 'md:bg-[#00000099] bg-whiteCol   '
      : 'bg-whiteCol'
  }   
  ${
    state.isSolidVariant || urlPath === '/' ? 'text-whiteCol' : 'text-primary'
  }`}
      > */}
        <div
        className={`  flex justify-between drop-shadow-xl items-center  relative z-40 sticky top-0  lg:flex w-full px-5 lg:px-8 xl:px-20 
  ${
    state.isSolidVariant || urlPath === '/'
      ? 'md:bg-[#00000099] bg-whiteCol   '
      : 'bg-whiteCol'
  }   
  ${
    state.isSolidVariant || urlPath === '/' ? 'text-whiteCol' : 'text-primary'
  }`}
      >
        {/* --------------------------------Logo -------------------------------- */}
        {state.screenSizeLessThanDesktop ? (
          <div className="m-auto lg:m-0">
            <Link href={'/'}>
              {state.isSolidVariant || urlPath === '/' ? (
                <Image
                  unoptimized={true}
                  src={'/logo/logoReverseNew.webp'}
                  width={600}
                  height={50}
                  alt="Logo BBS Reverse"
                  className={`animate__animated siteLogo py-4 ${
                    state.megaMenueOpen === true ? 'animate__backInDown' : ''
                  }animate__backInDown`}
                />
              ) : (
                <Image
                  unoptimized={true}
                  src={'/logo/logoBBSNew.webp'}
                  width={300}
                  height={50}
                  alt="Logo BBS"
                  className={`animate__animated siteLogo py-4 ${
                    state.megaMenueOpen === true ? 'animate__backInDown' : ''
                  }animate__backInDown`}
                />
              )}
            </Link>
          </div>
        ) : (
          <div className="m-auto lg:m-0">
            <Link href={'/'}>
              <Image
                unoptimized={true}
                src={'/logo/logoBBSNew.webp'}
                width={300}
                height={50}
                alt="Logo BBS"
                className={`animate__animated siteLogo py-4 ${
                  state.megaMenueOpen === true ? 'animate__backInDown' : ''
                }animate__backInDown`}
              />
            </Link>
          </div>
        )}

        <div>
          {/* --------------------------------Top Bar-------------------------------- */}
          <div
            className={`text-whiteCol  py-2 m-0  hideTopbar flex justify-between gap-4 items-center `}
          >
            {topBar.map((item: any, index) => (
              // <>
                <div className="flex gap-3 items-center" key={index}>
                  {item.image && (
                    <Image
                      unoptimized={true}
                      src={item.image}
                      width={20}
                      height={20}
                      alt="Top Bar"
                    />
                  )}
                  {item.link !== '' ? (
                    <Link href={item.link}>
                      <h5
                        className={`m-0 font-semibold ${
                          state.isSolidVariant || urlPath === '/'
                            ? ''
                            : 'text-primary'
                        } `}
                      >
                        {item.title}
                      </h5>
                    </Link>
                  ) : (
                    <h5
                      className={`m-0 font-semibold ${
                        state.isSolidVariant || urlPath === '/'
                          ? ''
                          : 'text-primary'
                      } `}
                    >
                      {item.title}
                    </h5>
                  )}
                </div>
              // </>
            ))}

            <Link href={'/apply-online'} target="_blank">
              <h4
                className="px-3 p-1 rounded-lg"
                style={{
                  backgroundColor: '#EA436E',
                  animationName: 'color-change-animation',
                  animationDuration: '1s',
                  animationIterationCount: 'infinite',
                }}
              >
                Admissions Open 2026-27
              </h4>
            </Link>

            <div className="flex  h-14 items-center">
              {topBarRight.map((item: any, index) => (
                // <>
                  <div
                    className={`flex gap-3 items-center  h-full px-4 py-2 ${
                      item.number ? 'bg-whiteCol' : 'bg-danger1'
                    } `}
                    key={index}
                  >
                    {item.image && (
                      <Image
                        unoptimized={true}
                        src={item.image}
                        width={20}
                        height={20}
                        alt="Top Bar"
                      />
                    )}
                    {item.link !== '' ? (
                      <Link
                        href={item.link}
                        className="flex items-center w-full h-full"
                      >
                        {/* <h5
                          className={`m-0 flex items-center font-semibold text-whiteCol h-full w-full`}
                        > */}
                         <h5
                          className={`m-0 flex items-center font-semibold text-primary h-full w-full`}
                        >
                          {item.title}
                        </h5>
                      </Link>
                    ) : (
                      <div className="">
                        <h5 className={`m-0 text-primary `}>{item.title}</h5>
                        <h5 className={`m-0 font-semibold text-primary`}>
                          {item.number}
                        </h5>
                      </div>
                    )}
                  </div>
                // </>
              ))}
            </div>
          </div>

          {/* --------------------------------Menu-------------------------------- */}
          <div>
            <div className="flex items-center border-t-2 border-secondary m-auto  py-2  justify-between text-right ">
              <div className="hidden lg:block ">
                {megaMenuList.map((menu: any, index: number) => (
                  <Link
                    key={index}
                    href={`${menu?.link !== '' ? menu?.link : []}`}
                  >
                    <h5
                      onMouseEnter={() =>
                        menu.subMenu && handleActiveMenu(menu)
                      }
                      onMouseOut={() =>
                        menu.subMenu && handleMegaMenuDisapper()
                      }
                      className=" uppercase p-2 m-auto font-semibold  inline "
                    >
                      {menu.title}
                    </h5>
                  </Link>
                ))}
              </div>
            </div>

            {/* mega Menu  */}
            {state.megaMenueOpen && (
              <div
                onMouseEnter={() => handleMegaMenunotDisapper(true)}
                onMouseLeave={() => handleMegaMenunotDisapper(false)}
                className="  top-[98px] left-0 right-0  m-auto w-[70%] z-50 absolute text-primary "
                data-aos="fade-up"
                data-aos-duration="300"
              >
                <div className="hidden md:flex justify-between min-h-64	m-auto bg-whiteCol mt-2 drop-shadow-md rounded-lg">
                  <div className="w-full menuImage">
                    <OutsideClickHandler
                      onOutsideClick={() => {
                        if (state.megaMenueOpen === true) {
                          setState((prevSatte: any) => ({
                            ...prevSatte,
                            megaMenueOpen: false,
                          }));
                        }
                      }}
                    >
                      <div
                        onClick={modalclose}
                        className={`w-10/12  p-4  flex  ${
                          state.activeMenu?.title !== 'Campus Gallery'
                            ? 'divideColumn flex-col m-auto '
                            : 'flex-row'
                        }`}
                      >
                        {(state.activeMenu?.subMenu || []).map(
                          (item: any, index: number) => (
                            <div key={index} className="flex gap-2">
                              <div className="mt-2"></div>
                              <Link
                                href={`${item?.link || '#'}`}
                                className={item?.link ? '' : 'cursor-default'}
                              >
                                <h4 className="m-0 text-sm font-medium">
                                  {item?.label === 'Apply Online' ? (
                                    <h5 className="bg-pink rounded-lg p-2 m-0 text-whiteCol">
                                      {item?.label}
                                    </h5>
                                  ) : (
                                    <>
                                      {state.activeMenu?.title ===
                                      'Campus Gallery' ? (
                                        <>
                                          <div className="p-8 m-">
                                            <div className=" ">
                                              <Image
                                                unoptimized={true}
                                                src={item.icon}
                                                width={60}
                                                height={20}
                                                alt="Campus Gallery"
                                                className="m-auto mb-3 rotateAnimate"
                                              />
                                              <h5 className="hover:text-pink m-auto m-0 font-bold ">
                                                {item?.label}
                                              </h5>
                                            </div>
                                          </div>
                                        </>
                                      ) : (
                                        <>
                                          <div className="flex gap-2">
                                            <Arrow />
                                            <h5
                                              className={
                                                item?.link
                                                  ? 'hover:text-pink m-0 font'
                                                  : 'm-0 font'
                                              }
                                            >
                                              {item?.label}
                                            </h5>
                                          </div>
                                        </>
                                      )}
                                    </>
                                  )}
                                  <div>
                                    <h4 className="text-sm">
                                      {item?.subMenu && (
                                        <div>
                                          {item?.subMenu.map(
                                            (list: any, index: number) => (
                                              <Link
                                                key={index}
                                                href={`${list?.link}`}
                                              >
                                                <div
                                                  className="flex gap-3 ml-3"
                                                  onClick={() =>
                                                    handleSubmenu(list?.section)
                                                  }
                                                >
                                                  <>
                                                    <Arrow />
                                                    <h5 className="hover:text-pink m-0">
                                                      {list.label}
                                                    </h5>
                                                  </>
                                                </div>
                                              </Link>
                                            )
                                          )}
                                        </div>
                                      )}
                                    </h4>
                                  </div>
                                </h4>
                              </Link>
                            </div>
                          )
                        )}
                      </div>
                    </OutsideClickHandler>
                  </div>

                  <div
                    style={{
                      backgroundImage: `url(${state.activeMenu?.image})`,
                    }}
                    className="bg-cover bg-no-repeat  relative bg-center w-1/3  flex justify-center align-middle text-secondary rounded-r-lg"
                  >
                    <div className="bg-[#211b3286] rounded-r-lg top-0 left-0 w-full h-full absolute "></div>
                    <h2 className=" drop-shadow-8xl   m-auto text-center z-10 relative ">
                      {state.activeMenuName}
                    </h2>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* --------------------------------Open Mobile Side Bar-------------------------------- */}
      {state.openMobileMenu && (
        <div className="animate__animated animate__fadeInLeftBig overflow-y-scroll h-screen w-10/12 bg-gradient-to-l from-gradientL to-gradientR z-40 fixed left-0 top-30 drop-shadow-2xl">
          <OutsideClickHandler
            onOutsideClick={() => {
              if (state.openMobileMenu) {
                delayFun();
              }
            }}
          >
            {state.openMobileMenu && <MobileHeader delayFun={delayFun} />}
          </OutsideClickHandler>
        </div>
      )}

      {/* --------------------------------Mobile Menu-------------------------------- */}

      <div className="lg:hidden block  fixed h-[67px] z-50 bottom-0 left-0    w-screen px-5 md:px-8 lg:px-20 bg-whiteCol m-auto  drop-shadow-xl items-center flex items-center justify-around">
        <div onClick={() => handleMobSidebar(1)} className="  cursor-pointer ">
          <Image
            unoptimized={true}
            className="z-40 relative min-w-5 m-auto	"
            src={'/svg/courses.svg'}
            width={15}
            height={15}
            alt="Courses"
          />
          <h5 className="m-0 font-semibold"> Courses</h5>
        </div>

        <div onClick={() => handleMobSidebar(2)} className=" cursor-pointer ">
          <Image
            unoptimized={true}
            className="z-40 relative min-w-5 m-auto	"
            src={'/svg/admission.svg'}
            width={15}
            height={15}
            alt="Admission"
          />
          <h5 className="m-0 font-semibold"> Admission</h5>
        </div>

        <div onClick={() => handleMobSidebar(3)} className="  cursor-pointer ">
          <Image
            unoptimized={true}
            className="z-40 relative min-w-5 m-auto	"
            src={'/svg/contact.svg'}
            width={15}
            height={15}
            alt="Contact"
          />
          <h5 className="m-0 font-semibold "> Contact</h5>
          {/* <div
        onClick={handleContactForm}
        className=" cursor-pointer 	 bg-secondary py-2 text-sm px-4 "
      >
        Contact,,,,
      </div> */}
        </div>

        <div className=" cursor-pointer " onClick={delayFun}>
          {state.openMobileMenu == false ? (
            <Image
              unoptimized={true}
              className="z-40 relative min-w-5 m-auto	"
              src={'/svg/hamburger.svg'}
              width={15}
              height={15}
              alt="Hamburger"
            />
          ) : (
            <Image
              unoptimized={true}
              className="z-40 relative min-w-5 m-auto  	"
              src={'/svg/crossHamburger.svg'}
              width={15}
              height={15}
              alt="Cross Hamburger"
            />
          )}
          <h5 className="m-0 font-semibold"> Menu</h5>
        </div>
      </div>

      {state.ativeMobSidBar !== 0 && (
        <div className="animate__animated animate__fadeInLeftBig overflow-y-scroll h-screen w-10/12  z-40 fixed left-0 top-30 drop-shadow-2xl">
          <OutsideClickHandler onOutsideClick={() => {}}>
            {renderPanel(state.ativeMobSidBar)}
          </OutsideClickHandler>
        </div>
      )}
    </>
  );
};
export default Header;
