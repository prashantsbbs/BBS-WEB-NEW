'use client'


import Image from "next/image";


const BreadcrumbCommon = ({
    componentName = 'STRING',
    image ='/home/lifeBBS.webp'
}) =>{
    return(
        <>
        <div className="  relative breadCrumb bg-[url('/bbs-building.webp')] animate__animated animate__slideInLeft"
        style={{backgroundImage: `url(${image})`,
    }}
        >
          <div className="bg-[#13184e99] absolute top-0 left-0 h-full w-full z-10"></div>
            <div className="  flex h-full text-whiteCol relative z-20  ">
                
                <div className="m-auto text-center">
                    <h2 className="text-5xl w-2/3  text-center m-auto ">{componentName } </h2>
                    </div>
            </div>

        </div>
        </>
    )
}

export default BreadcrumbCommon