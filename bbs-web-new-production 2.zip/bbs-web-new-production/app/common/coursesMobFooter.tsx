'use client';
import Image from 'next/image';
import { homeCourses } from '../constant/constant';
import 'animate.css';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import AppService from '../services';

const CoursesMobileFooter = ({ setState }: any) => {
  const [courseList, setCourseList] = useState<any>([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchCourseList = async () => {
    setIsLoading(true);
    const { data, error } = await AppService.getCourseList();
    if (!error) {
      setCourseList(data);
    }
    setIsLoading(false);
  };

  function closeSidebar() {
    setState((prev: any) => ({ ...prev, ativeMobSidBar: 0 }));
  }

  useEffect(() => {
    fetchCourseList();
  }, []);

  return (
    <>
      <div className=" bg-gray">
        <div className="z-10 relative pt-10 pb-20">
          <div className="text-center pb-10 p-4">
            <h2 className="  "> COURSES @ BBS</h2>
            <h4 className="">
              Preparing students to make meaningful contributions to
              <br /> society as engaged citizens and leaders in a complex world
            </h4>
          </div>

          <div className="grid  grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12  justify-center md:px-24 px-4">
            {courseList.map((course: any, index: number) => (
              <div key={index} className="flex drop-shadow-2xl">
                <div
                  className="bg-secondary flex  rounded-l-xl w-1/4  left-0 top-0 
                 "
                >
                  <Image
                    src={'/svg/graduate.svg'}
                    width={50}
                    height={0}
                    unoptimized={true}
                    alt="Graduate"
                    loading="lazy"
                    className="  m-auto graduateAnimation animate__animated animate__shakeY  animate__infinite"
                  />
                </div>
                <div className="rounded-r-xl bg-whiteCol w-3/4 p-4 ">
                  <Link
                    href={course?.attributes?.detailed_view_link || ''}
                    onClick={closeSidebar}
                  >
                    <h3 className=" m-0 font-semibold ">
                      {course?.attributes?.name}
                    </h3>
                    <h5 className=" m-0 ">
                      {course?.attributes?.department?.data?.attributes?.name}
                    </h5>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default CoursesMobileFooter;
