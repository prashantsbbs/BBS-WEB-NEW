import type { ReactNode } from "react";

interface SeoWrapperProps {
  title: string;
  description: string;
  keywords?: string;
  canonical?: string;
  children: ReactNode;
}

export default function SeoWrapper({
  title,
  description,
  keywords,
  canonical,
  children,
}: SeoWrapperProps) {
  return (
    <>
      <head>
        <title>{title}</title>
        <meta name="description" content={description} />
        {keywords && <meta name="keywords" content={keywords} />}
        {canonical && <link rel="canonical" href={canonical} />}
      </head>
      {children}
    </>
  );
}
