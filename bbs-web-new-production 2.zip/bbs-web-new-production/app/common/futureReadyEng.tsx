'use client';

import Image from 'next/image';

const futureReadyList = [
  {
    Icon: '/futureReady/new-gen.webp',
    heading: 'Fun Learning',
    subHead: ' Achieved through luss green environment',
  },
  {
    Icon: '/futureReady/industrialLabour.webp',
    heading: 'Industrial Labs',
    subHead: ' with state of art facilities',
  },
  {
    Icon: '/futureReady/highlyExp.webp',
    heading: 'Highly Experienced Faculty',
    subHead: 'drawn from IITs & NITs',
  },
  {
    Icon: '/futureReady/project-based.webp',
    heading: 'Hi-tech Infrastructure',
    subHead: 'all learning resources and communication channels.',
  },
  {
    Icon: '/futureReady/guest-lecture.webp',
    heading: 'Guest Lectures',
    subHead: 'by eminent thought leaders from the industry',
  },
  {
    Icon: '/futureReady/top-notch.webp',
    heading: 'Top-Notch Placements',
    subHead: 'up to Rs. 44.00 LPA',
  },
];

const FutureReadyEng = ({ department = <></>, image = '', format = '' }) => {
  return (
    <>
      <div className="bg-gray flex md:py-20 py-10 overlflow-hidden">
        <div className="w-[80vw] m-auto">
          <div className="grid  md:grid-cols-2 grid-cols-1">
            <div>
              <h2 className="text-center text-4xl uppercase">
                Crafted to cultivate engineers prepared for the challenges of
                tomorrow.
              </h2>
              <h4 className="text-center m-0 mb-4">
                At BBS GROUP OF INSTITUTIONS, we prioritize experiential
                learning through projects, ensuring our students acquire
                industry-relevant skills beyond traditional classroom education.
              </h4>
              <div
                className="lg:columns-2  columns-1 m-auto lg:col-span-2 col-span-1  "
                data-aos="fade-up-right"
              >
                {futureReadyList.map((list: any, index) => (
                  <div key={index} className="flex gap-4 my-8">
                    <Image
                      src={list.Icon}
                      unoptimized={true}
                      width={50}
                      height={50}
                      alt="Future Ready"
                      style={{ backgroundSize: 'cover', objectFit: 'contain' }}
                    />

                    <div>
                      <h3 className="m-0 font-bold">{list.heading}</h3>
                      <h4 className="m-0">{list.subHead}</h4>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <h2 className="md:hidden block outlineFont text-3xl">
              {department}
            </h2>
            {/* Image */}
            <div
              className={`md:block hidden  ${
                format === 'jpg' && 'w-[80%] m-auto '
              }`}
              data-aos="fade-up-left"
            >
              <Image
                src={image || '/futureReady/center.webp'}
                width={700}
                unoptimized={true}
                height={0}
                alt="Future Ready Center"
                className="rounded-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default FutureReadyEng;
