'use client'

import Image from "next/image";

const Arrow =() =>{
return(
    <>
    <Image
                src={"/svg/pinkArrow.svg"}
                width={20}
                height={0}
                alt="Pink Arrow"
                className="rotateAnimate"
                unoptimized={true}
              />
    </>
)
} 
export default Arrow