'use client'

import Image from "next/image"
import Link from "next/link"

const campus = [
    {
        image:'/home/lifeBBS.webp',
        title:'Events',
        link:'events'
    },
    {
        image:'/home/internationalization/1.webp',
        title:'News',
        link:'news'
    },
    {
        image:'/home/innovative/2.webp',
        title:'Apply Online',
        link:'apply-online'
    },
    {
        image:'/home/innovative/3.webp',
        title:'Life at Campus',
        link:'/campus-facilities/medical-facilities'
    },
    {
        image:'/admission/college-student.webp',
        title:'Placement',
        link:'placement-overview'
    },
    {
        image:'/home/lifeBBS.webp',
        title:'Contact',
        link:'contact-us'
    },
]

const CampusHiglight = () =>{
    return (
        <>

        <div className="md:py-16 py-8"
        style={{backgroundImage:'url(/backImageInstitutions.webp)', objectFit:'cover', 
        backgroundPosition:'center left'}}>
                <h2 className="text-5xl text-secondary uppercase text-center pb-6">
                    Campus Highlight
                </h2>
            <div className="grid md:grid-cols-6 sm:grid-cols-3 grid-cols-2 w-[90%] m-auto text-center  ">
            {campus.map((list:any, index)=>(
                <>
                <Link href={list.link}>
                <div className="m-auto  animate__animated animate__slideInLeft">
                <Image
                    src={list.image}
                    width={200}
                    height={200}
                    alt={"Campus"}
                    unoptimized={true}
                    className="  
                    xl:h-[140px] 
                    xl:w-[140px]
                    lg:h-[100px]
                    lg:w-[100px]
                    h-[90px] 
                    w-[90px]
                    
                    m-auto campusLifeImage rounded-full "
                    />
                </div>
                <h3 className="text-whiteCol md:text-lg sm:text-md text-sm">{list.title}</h3>
                </Link>
                
                </>
            ))}
            </div>
        


        </div>
        </>
    )
}
export default CampusHiglight