'use client';

import Link from 'next/link';
import ButtonCustom from './button';
import Image from 'next/image';

const contactNumbers = [
  '1800-1200-407',
  '7607000961',
  '7607000962',
  '7607000963',
];

const AdmissionMobileFooter = ({ setState }: any) => {
  function closeSidebar() {
    setState((prev: any) => ({ ...prev, ativeMobSidBar: 0 }));
  }
  return (
    <>
      <div className="text-center  h-screen bg-gray p-6">
        <h2>ADMISSION</h2>
        <div className="rounded-lg bg-whiteCol p-4">
          <Link href={'/admission-precedure'} onClick={closeSidebar}>
            <h4>Admission Prospectus</h4>
          </Link>
          <Link href={'/admission-process'} onClick={closeSidebar}>
            <h4>Admission-Process</h4>
          </Link>
          <Link href={'/eligibility-criteria'} onClick={closeSidebar}>
            <h4> Eligibility-Criteria</h4>
          </Link>
        </div>
        <div className="flex justify-center p-4">
          <Link href={'/apply-online'}>
            <ButtonCustom btnText="Apply Now" />
          </Link>
        </div>
        <div className="m-auto mt-4">
          <Image
            src={'/svg/phone.svg'}
            width={20}
            height={20}
            alt="Phone"
            className="m-auto"
            unoptimized={true}
          />
          <h4 className="m-0">Admission Helpline</h4>
          {contactNumbers.map((number) => (
            <a key={number} href={`tel:${number}`}>
              <h2 className="m-0">{number}</h2>
            </a>
          ))}
        </div>
      </div>
    </>
  );
};

export default AdmissionMobileFooter;
