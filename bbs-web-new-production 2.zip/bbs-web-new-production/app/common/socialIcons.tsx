import Image from 'next/image';
import Link from 'next/link';
import { socialMedia } from '../constant/socialMedia';

const SocialIcons = ({ btnColor = 'dark-blue', size = 20, rotate = '',btnInvert=""}) => {
  return (
    <>
      <div className="flex gap-3 ">
        {socialMedia.map((social: any, index: number) => (
          <Link key={index} href={social.link} target="_blank">
            <div
              className={`bg-${btnColor} p-2 rounded-full ${rotate}  cursor-pointer flex`}
            >
              <Image
                unoptimized={true}
                src={social.image}
                width={size}
                height={size}
                alt={'Social Media'}
                className={`m-auto ${btnInvert}`}
              />
            </div>
          </Link>
        ))}
      </div>
    </>
  );
};
export default SocialIcons;
