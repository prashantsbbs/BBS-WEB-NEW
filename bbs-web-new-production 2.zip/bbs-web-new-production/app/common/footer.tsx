import Link from 'next/link';
import SubscribeSection from '../home/SubscribeSection';
import FooterEnd from './footerEnd';
import SocialIcons from './socialIcons';
import Image from 'next/image';
import ButtonCustom from './button';

const coursLink = [
  {
    label: 'Computer Science & Engineering',
    link: '/computer-science-engineering',
  },
  {
    label: 'AI & ML',
    link: '/btech-aiml',
  },
  {
    label: 'Information Technology',
    link: '/btech-it',
  },
  {
    label: 'Electronics & Communication Engineering',
    link: '/electrical-electronics-engineering',
  },
  {
    label: 'Mechanical Engineering',
    link: '/mechanical-engineering',
  },
  {
    label: 'Electrical & Electronics Engineering',
    link: '/electrical-electronics-engineering',
  },
  { label: 'Civil Engineering', link: '/civil-engineering' },
  {
    label: 'M.Tech (CSE)',
    link: '/m-tech-cse',
  },
  {
    label: 'M.Tech.(CAD/CAM)',
    link: '/m-tech-cad-cam',
  },

  {
    label: 'BBA',
    link: '/bba',
  },
  {
    label: 'BCA',
    link: '/bca',
  },
  {
    label: 'MCA',
    link: '/mca',
  },
  {
    label: 'MBA',
    link: '/mba',
  },
  {
    label: 'LLB',
    link: '/llb',
  },
  {
    label: 'BA. LL.B. (Hons)',
    link: '/ba-llb',
  },
  { label: 'D.Pharm.', link: '/d-pharm' },
  {
    label: 'B.Pharm.',
    link: '/b-pharm',
  },
];
const facilities = [
  { label: 'Lecture Theaters', link: '/academic-facilities/lecture-theater' },
  { label: 'Conference Halls', link: '/academic-facilities/conference-hall' },
  { label: 'Laboratories', link: '/academic-facilities/laboratories' },
  { label: 'Libraries', link: '/academic-facilities/libraries' },
  {
    label: 'Medical Facilities',
    link: '/campus-facilities/medical-facilities',
  },
  { label: 'Hostel', link: '/campus-facilities/hostel' },
  { label: 'Sports Overview', link: '/sports-facility/sports-overview' },
  { label: 'In Door Games', link: '/sports-facility/in-door-games' },
  { label: 'Sports Ground', link: '/sports-facility/sports-ground' },
  { label: 'Annual Sports', link: '/sports-facility/annual-sports' },
];

const footerLinksData = [
  {
    h2: 'Services',
    links: [
      'Our Institutions',
      'Admission',
      'Facilities',
      'Academics',
      'Placements',
      'Circular',
    ],
  },
];

const Footer = () => {
  return (
    <>
      <SubscribeSection />
      <div className="grid grid-flow-row-dense md:grid-cols-5 sm:grid-cols-2 grid-cols-1    bg-gradient-to-b from-gradientL to-gradientR  text-whiteCol  lg:px-20 p-4 lg:pt-16 pt-10 lg:pb-6    ">
        <div className=" px-8 py-4 ">
          <Link href={'/'}>
            <Image
              width={300}
              height={50}
              unoptimized={true}
              loading="lazy"
              src="/logo/logoReverseNew.webp"
              alt="Logo Reverse"
              className="w-full sm:max-w-[20rem] mb-2 "
            />
          </Link>

          <div>
            <p className="text-[12px] text-justify">
              BBS Institute Was Established Under BENI MADHAV SHIKSHA SAMITI In
              2002, Affiliated To Dr. A.P.J Abdul Kalam Technical University And
              Approved By AICTE, MHRD Govt. Of India (New Delhi).
            </p>
            <p className="text-[12px] text-justify">
              The College Is Spread Over The Vast Area Of 27 Acres Of Land With
              Around 15000 Sq. Meters Of Build-Up Area. It Has A Well- Furnished
              & Maintained Hostel Facility For Boys And Girls Separately.
            </p>
          </div>

          <div>
            <h2 className="mb-3 text-xl  tracking-wider">Follow Us:</h2>
            <SocialIcons btnColor={'secondary'} />
          </div>
        </div>

        <div className=" p-4">
          <h2 className="mb-3 w-fit text-xl font-semibold tracking-wide">
            Facilities
            <hr className="border-b-[3px] border-secondary mt-1" />
          </h2>
          <div className="">
            {facilities.map((item, id) => (
              <div key={id}>
                <Link href={item.link}>
                  <h5 className="m-0 mb-1">{item.label}</h5>
                </Link>
              </div>
            ))}
          </div>
        </div>

        <div className="p-4 md:col-span-2">
          <h2 className="mb-3 w-fit text-xl font-semibold tracking-wide">
            Courses
            <hr className="border-b-[3px] border-secondary mt-1" />
          </h2>
          <div className="md:columns-2 columns-1">
            {coursLink.map((item, id) => (
              <div key={id} className="">
                <Link href={item.link}>
                  <h5 className="m-0 mb-1">{item.label}</h5>
                </Link>
              </div>
            ))}
          </div>
        </div>

        <div className="p-4">
          <div>
            <div>
              <h2 className="mb-3 w-fit text-xl font-semibold tracking-wide">
                Contact Us
                <hr className="border-b-[3px] border-secondary mt-1" />
              </h2>
            </div>
            <div className="flex flex-col sm:gap-6 gap-4 mt-2 sm:text-medium text-sm">
              <div className="flex items-center gap-2">
                <div>
                  <p>Toll Free : </p>
                  <p className="	">1800-1200-407</p>
                </div>
              </div>
              <div className="flex items-center ">
                <div>
                  <p>Phone No. : </p>
                  <p className="	">7607000961, 7607000962, 7607000963 </p>
                </div>
              </div>
              <div className="flex items-center ">
                <div>
                  <p>Email : </p>
                  <p>mail@bbs.ac.in</p>
                </div>
              </div>
              <div className="flex items-center ">
                <div>
                  <p>Location : </p>
                  <p>
                    BBS GROUP OF INSTITUTIONS.
                    <br />
                    Phaphamau, Prayagraj-211013
                  </p>
                </div>
              </div>
            </div>
          </div>
          <Link href={'/privacy-policy'}>
            <h5>• Privacy Policy</h5>
          </Link>
          <Link href={'/terms-conditions'}>
            <h5>• Terms & Conditions</h5>
          </Link>
          <Link href={'#'}>
            <h5>• Feedback</h5>
          </Link>
        </div>
      </div>
      <FooterEnd />
    </>
  );
};

export default Footer;
