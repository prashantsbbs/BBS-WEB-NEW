'use client';
import { megaMenuList } from '../constant/constant';

import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import SocialIcons from './socialIcons';
import CoursesH from '../home/coursesH';

const MobileHeader = ({ delayFun = () => {} }) => {
  const defaultState: any = {
    activeMenu: {},
    iconSwitch: false,
  };

  const [state, setState] = useState<any>(defaultState);

  const openSubMenu = (actMenu: any) => {
    setState((prevState: any) => ({
      ...prevState,
      activeMenu: actMenu,
      iconSwitch: true,
    }));
  };

  const handlesubMenueIcon = (e: any) => {
    if (state.iconSwitch) {
      e.stopPropagation();
      e.preventDefault();
      setState((prevState: any) => ({
        ...prevState,
        activeMenu: {},
        iconSwitch: false,
      }));
    }
  };

  return (
    <>
      <div className="relative z-30    p-4 text-whiteCol">
        {megaMenuList.map((menu: any, index: number) => (
          <>
            <div key={index} className="bg-transparent h-px  w-full">
              {' '}
            </div>
            <Link href={`${menu?.link !== '' ? menu?.link : []}`}>
              <div
                className="flex justify-between  px-4 py-2"
                onClick={() => openSubMenu(menu)}
              >
                <div
                  className="text-sm"
                  onClick={!menu.subMenu ? delayFun : () => {}}
                >
                  {menu.title}
                </div>
                {menu.subMenu &&
                  (menu.title === state.activeMenu.title ? (
                    <Image
                      unoptimized={true}
                      src={'/svg/crossIcon.svg'}
                      onClick={handlesubMenueIcon}
                      width={15}
                      height={50}
                      alt="Cross Icon"
                    />
                  ) : (
                    <Image
                      unoptimized={true}
                      src={'/svg/plusIcon.svg'}
                      onClick={handlesubMenueIcon}
                      width={15}
                      height={50}
                      alt="Plus Icon"
                    />
                  ))}
              </div>
            </Link>

            <div>
              {menu.title === state.activeMenu.title &&
                state.activeMenu?.subMenu?.map((list: any, index: number) => (
                  <>
                    <Link key={index} href={`${list?.link} `}>
                      <div
                        className="ml-6 text-xs p-2  text-secondary"
                        onClick={delayFun}
                      >
                        <div>{list.label}</div>
                      </div>
                      <div>
                        {list?.subMenu && (
                          <div className="ml-10 text-xs   text-whiteCol">
                            {list?.subMenu.map(
                              (subList: any, index: number) => (
                                <Link key={index} href={`${subList?.link}`}>
                                  <div
                                    className="flex gap-3 m-2 "
                                    onClick={delayFun}
                                  >
                                    {subList.label}
                                  </div>
                                </Link>
                              )
                            )}
                          </div>
                        )}
                      </div>
                    </Link>
                  </>
                ))}
            </div>
          </>
        ))}

        <div className="bg-transparent h-px  mb-6 w-full"> </div>

        <div className="my-2">
          <SocialIcons btnColor={'secondary'} />
        </div>

        <div className="mt-4">
          <div className="flex gap-4 cursor-pointer items-center">
            <Image
              unoptimized={true}
              src={'/svg/download.svg'}
              width={20}
              height={20}
              alt="Download"
            />
            <h6 className="m-0  font-semibold text-whiteCol">
              Admission Registrations
              <br />
              Open-2026-27
            </h6>
          </div>

          <div className="flex gap-4 cursor-pointer items-center ">
            <Image
              unoptimized={true}
              src={'/svg/registration.svg'}
              width={20}
              height={20}
              alt="Registration"
            />
            <Link href={'/news-letters'}>
              <h6 className=" font-semibold text-whiteCol" onClick={delayFun}>
                News
                <br />
                Letter
              </h6>
            </Link>
          </div>
          <div className="flex gap-4 cursor-pointer items-center">
            <Image
              unoptimized={true}
              src={'/svg/graduate.svg'}
              width={20}
              height={20}
              alt="Registration"
              className="invert"
            />
            <Link href={'https://erp.bbs.ac.in/'}>
              {/* <h6 className=" font-semibold text-whiteCol" onClick={delayFun}>
               */}
               <h6 className=" font-semibold text-whiteCol" onClick={delayFun}>
                Student Portal
              </h6>
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default MobileHeader;
