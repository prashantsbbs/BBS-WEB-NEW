import ButtonCustom from "./button"
import Image from "next/image"

const contactNumbers = ["1800-1200-407", "7607000961", "7607000962", "7607000963"];

const ContactMobileFooter = () => {
    return (
        <>

            <div className="text-center   h-screen bg-gray p-6 flex " >
                <div className="">

                    <h2>CONTACT</h2>

                    <div className="rounded-lg bg-whiteCol p-4">
                        <div className="py-2">
                            <h4 className="m-0 font-bold uppercase">Email </h4>
                            <a href="mailto::admission@bbs.ac.in"> <h3 className="m-0">admission@bbs.ac.in</h3></a>
                        </div>
                        <div className="py-2">

                            <h4 className="m-0 font-bold uppercase">College :</h4>
                            <h4 className="m-0">BBS GROUP OF INSTITUTIONS.
                                Phaphamau, Prayagraj-211013</h4>
                        </div>
                    </div>
                    <div className="m-auto mt-4">
                        <Image
                            src={'/svg/phone.svg'}
                            unoptimized={true}
                            width={40}
                            height={20}
                            alt="Phone"
                            className="m-auto my-4"
                        />
                        <h4 className="m-0">Call Us</h4>
                        {contactNumbers.map(number => (
                            <a key={number} href={`tel:${number}`}>
                                <h2 className="m-0">{number}</h2>
                            </a>
                        ))}
                    </div>
                </div>
            </div>
        </>
    )
}

export default ContactMobileFooter