import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { Autoplay, Navigation } from 'swiper/modules';
import Image from 'next/image';

const CourseSlider = ({ elements = [{}] }) => {
  return (
    <>
      <Swiper
        slidesPerView={1}
        spaceBetween={30}
        loop={true}
        autoplay={{
          delay: 2500,
          disableOnInteraction: false,
        }}
        breakpoints={{
          300: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
          540: {
            slidesPerView: 2,
            spaceBetween: 20,
          },
          640: {
            slidesPerView: 2,
            spaceBetween: 20,
          },
          768: {
            slidesPerView: 3,
            spaceBetween: 40,
          },
          1024: {
            slidesPerView: 4,
            spaceBetween: 50,
          },
        }}
        modules={[Autoplay, Navigation]}
        className="mySwiper"
      >
        {elements.map((data: any, id) => (
          <SwiperSlide key={id} className="rounded-lg">
            <div
              key={data?.length}
              className="flex items-center justify-center flex-col font-semibold "
            >
              {data?.attributes?.media?.data?.attributes?.url && (
             <Image
  width={400}
  height={400}
  unoptimized={true}
  loading="lazy"
  src={data?.attributes?.media?.data?.attributes?.url}
  alt="BBS Faculty"
  className="w-full h-[360px] sm:h-[260px] object-cover object-top"
/>
              )}
              {data?.attributes?.name && (
                <>
                  <div className="p-2 text-whiteCol">
                    <h3 className="m-0">{data?.attributes?.name}</h3>
                    <h5 className="m-0 ">
                      {data?.attributes?.position?.data?.attributes?.name}
                    </h5>
                    <h6 className="m-0">
                      {data?.attributes?.department?.data?.attributes?.name}
                    </h6>
                    <h6 className="m-0">{data?.attributes?.qualification}</h6>
                    {data?.attributes?.experience && (
                      <h6 className="m-0">
                        {data?.attributes?.experience} Years
                      </h6>
                    )}
                  </div>
                </>
              )}
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </>
  );
};

export default CourseSlider;
