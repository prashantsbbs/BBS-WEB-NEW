const FooterEnd = () => {
    return (
      <div className="bg-bg-black">
        <hr className="border-b-[1px] border-yellow-500" />
        <div className="text-secondary text-center py-6 text-xs tracking-widest">Copyright © BBS 2025 | All Rights Reserved</div>
      </div>
    );
  };
  
  export default FooterEnd;