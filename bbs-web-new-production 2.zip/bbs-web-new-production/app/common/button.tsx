'use client';

import Image from 'next/image';

const ButtonCustom = ({
  btnColor = 'primary',
  btnText = 'Read More',
  textCol = 'whiteCol',
  btnHeight="10",
  btnWidth="44"
}) => {
  return (
    <>
      <div
        className={`h-9  md:h-${btnHeight} w-36 md:w-${btnWidth}  bg-${btnColor} cursor-pointer rounded-full flex hover:shadow-[0_0_20px_rgba(16,185,129,0.8)] transition duration-300 hover:scale-105 justify-between align-middle pl-3	`}
      >
        <h4 className={`m-auto text-sm font-medium text-${textCol}`}>
          {btnText}
        </h4>
        <div className="md:p-2.5 p-1.5 m-auto bg-whiteCol rounded-full">
          <Image
            src={'/svg/btnArrow_1.svg'}
            width={10}
            height={10}
            alt="Button Arrow"
            loading="lazy"
            className="  m-auto   "
            unoptimized={true}
          />
        </div>
      </div>
    </>
  );
};
export default ButtonCustom;
