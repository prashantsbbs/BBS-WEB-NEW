'use client'


import Image from "next/image";


const AcademicBreadcrumb = ({
    componentName = 'STRING',
}) =>{
    return(
        <>
        <div className=  {`relative h-[400px] bg-top bg-[url('/campusLife/academicBreadcrumb.webp')] animate__animated animate__slideInLeft `}>
          <div className="bg-[#13184e99] absolute top-0 left-0 h-full w-full z-10"></div>
            <div className="  flex h-full text-whiteCol relative z-20  ">
                
                <div className="m-auto text-center">
                    <h2 className="text-5xl w-2/3  text-center m-auto ">{componentName } </h2>
                    </div>
            </div>

        </div>
        </>
    )
}

export default AcademicBreadcrumb