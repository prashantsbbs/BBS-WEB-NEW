import { Fragment, useEffect, useMemo, useRef, useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import Image from 'next/image';
import ButtonCustom from './button';
import Link from 'next/link';

export default function FlyerModal({
  open = false,
  imageUrl = '',
  redirectLink = '',
  redirectCTALabel = 'Visit',
  setOpen = (isOpen: any) => {},
}) {
  const cancelButtonRef = useRef(null);

  const flyerContent = {
    image: '/flyerModal/flyerModal.webp',
    buttonText: 'Contact Us',
    link: '/contact-us',
  };

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog
        as="div"
        className="relative z-50 bg-whiteCol"
        initialFocus={cancelButtonRef}
        onClose={() => setOpen(false)}
      >
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className=" " />
        </Transition.Child>

        <div className="flyerModal p-4">
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            enterTo="opacity-100 translate-y-0 sm:scale-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100 translate-y-0 sm:scale-100"
            leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
          >
            <Dialog.Panel className="relative bg-whiteCol transform overflow-hidden rounded-lg bg-white text-left border-2 border-[#565555] border-opacity-30 transition-all ">
              <img
                src="/cross.webp"
                alt="Cross Image"
                className=" cursor-pointer absolute w-[30px] h-[30px] z-50"
                onClick={() => setOpen(false)}
              />

              {imageUrl && (
                <Image
                  src={imageUrl}
                  unoptimized={true}
                  width={1000}
                  height={1000}
                  alt={'Flyer'}
                />
              )}

              <div className="absolute z-50 bottom-0  m-auto left-0 right-0 flex justify-center ">
                {redirectLink && (
                  <Link href={redirectLink}>
                    <ButtonCustom
                      btnText={redirectCTALabel}
                      btnColor="secondary"
                      textCol="primary"
                    />
                  </Link>
                )}
              </div>
            </Dialog.Panel>
          </Transition.Child>
        </div>
      </Dialog>
    </Transition.Root>
  );
}
