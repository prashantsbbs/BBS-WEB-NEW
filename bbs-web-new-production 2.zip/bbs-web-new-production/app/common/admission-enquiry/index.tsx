'use client'
import Modal from '@/app/apply-online/modal';
import { ERROR_MESSAGES, REGEX } from '@/app/constant/constant';
import { STATE_CITY_LIST } from '@/app/constant/state-city';
import AppService from '@/app/services';
import { Dialog, Transition } from '@headlessui/react';
import axios from 'axios';
import Image from 'next/image';
import React, { Fragment, useEffect, useMemo, useState } from 'react';
import { Controller, useForm, useWatch } from 'react-hook-form';
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import {
  GoogleReCaptchaProvider,
  GoogleReCaptcha
} from 'react-google-recaptcha-v3';


const COURSE_LIST: any = [
  {
    id: 1,
    name: "MBA",
    branch: [
      { id: 1, name: "Marketing" },
      { id: 2, name: "Human Resource Management" },
      { id: 3, name: "Information Technology" },
      { id: 4, name: "International Business" }
    ]
  },
  {
    id: 2,
    name: "BBA",
    branch: []
  },
  {
    id: 3,
    name: "B. Tech",
    branch: [
      { id: 1, name: "Computer Science" },
      { id: 2, name: "Civil Engineering" },
      { id: 3, name: "Mechanical Engineering" },
      { id: 4, name: "Electrical Engineering" },
      { id: 5, name: "Electronics and Communication" },
    ]
  },
  {
    id: 4,
    name: "M. Tech",
    branch: [
      { id: 1, name: "Computer Science" },
      { id: 2, name: "Civil Engineering" },
      { id: 3, name: "Mechanical Engineering" },
      { id: 4, name: "Electrical Engineering" },
      { id: 5, name: "Electronics and Communication" },
    ]
  },
];

type FormData = {
  name: string;
  email: string;
  phone: string;
  course: string;
  branch: string;
  state: string;
  city: string;
};

const AdmissionEnquiryForm: React.FC<{ isOpen: boolean; onClose:any }> = ({
  isOpen,
  onClose = () => {
   }
}) => {
  const [courseList, setCourseList] = useState([]);
  const [alertMessage, setAlertMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const fetchCourseList = async () => {
    setIsLoading(true);
    const { data, error } = await AppService.getCourseList();
    if (!error) {
      setCourseList(data)
    }
    setIsLoading(false);
  };

  const {
    register,
    handleSubmit,
    getValues,
    control,
    watch,
    resetField,
    reset,
    formState: { errors },
  } = useForm<FormData>();
  const [moIsOpen, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const handleClose = () => setShow(false);

  const sendEmail = async (data: any) => {
    const response = await fetch("/api/email", {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    });
    const res = await response.json();
    console.log(res);
  };

  const onSubmit = async (formData: FormData) => {


    setIsLoading(true);
    const payload = {
      data: {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        state: formData.state,
        city: formData.city || "NA",
        course_name: formData.course,
        branch: formData.branch,
      }
    };

    const { error } = await AppService.createAdmissionEnquiry(payload);
    
    if (error) {
      setAlertMessage(error?.message);
    } else {
      setAlertMessage("Submitted Successfully.");
      sendEmail({
        from: process.env.NEXT_PUBLIC_ADMIN_EMAIL,
        to: formData.email,
        dynamicTemplateData: payload.data,
        templateId: process.env.NEXT_PUBLIC_ADMISSION_ENQUIRY_USER_TEMPLATE
      }); 
      reset();
    }
    setIsLoading(false);
  };

  const [selectedCourse, selectedState] = useWatch({
    control,
    name: ["course", "state"],
  });

  useEffect(() => {
    fetchCourseList();
  }, []);

  const courseAndBranchList = useMemo(() => {
    return courseList.reduce((acc: any, course: any) => {
      const courseIndex = acc.findIndex((item: any) => item.name === course?.attributes?.name);
      if (courseIndex > -1) {
        acc[courseIndex].branch.push(course?.attributes?.department?.data?.attributes?.name)
      } else {
        acc.push({
          name: course?.attributes?.name,
          branch: [course?.attributes?.department?.data?.attributes?.name]
        });
      }
      return acc;
    }, [])
  }, [courseList]);

  const branchList = courseAndBranchList.find(({ name }: any) => name === selectedCourse)?.branch|| [];
  const cityList = STATE_CITY_LIST[selectedState] || [];


// google Recaptcha-------------------------------
const [recaptchaToken, setRecaptchaToken] = useState<string>('');

const handleRecaptchaChange = (token: string | null) => {
  if (token) {
    setRecaptchaToken(token);
  }
};

  return (
    <Transition.Root show={isOpen} as={Fragment}>
      <Dialog
        as="div"
        className="relative z-50 bg-whiteCol"
        onClose={onClose}
      >
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 " />
        </Transition.Child>

        <div className="fixed top-20  sm:right-0   mx-auto z-50 animate__animated animate__slideInRight">
          <div className="flex min-h-full  items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <Dialog.Panel className="relative bg-whiteCol transform overflow-hidden rounded-lg bg-white text-left border-2 border-[#565555] border-opacity-30 transition-all sm:my-8 sm:w-full sm:max-w-lg">
                <Image
                unoptimized={true}
                  src="/cross.webp"
                  alt="Cross"
                  className="fixed top-3 h-7 left-2 cursor-pointer z-50 invert"
                  onClick={onClose}
                  width={29}
                  height={50}
                />
                <form
                  onSubmit={handleSubmit(onSubmit)}
                  className="relative flex flex-col px-8 pb-8 md:px-6 md:pb-6 md:pt-6 pt-2 gap-1 text-center bg-primary-new-light"
                >
                  
                  <p className="text-2xl drop-shadow-lg text-whiteCol font-bold	">
                    Admission Enquiry{" "}
                  </p>
                  <div className="form-container">
                    <div className='mb-2'>
                      <input
                        {...register("name", { required: true, maxLength: 55 })}
                        type="text"
                        className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${errors.name ? 'border-red-500' : ''}`}
                        placeholder="Name *"
                      />
                      {errors.name && (
                        <div className="text-left text-sm text-danger">
                          {ERROR_MESSAGES[errors.name.type] || errors.name.message}
                        </div>
                      )}
                    </div>
                    <div className='mb-2'>
                      <input
                        {...register("email", {
                          required: true,
                          pattern: {
                            value: REGEX.EMAIL,
                            message: "Email is not valid",
                          }
                        })}
                        className="mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Email *"
                      />
                      {errors.email && (
                        <div className="text-left text-sm text-danger">
                          {ERROR_MESSAGES[errors.email.type] || errors.email.message}
                        </div>
                      )}
                    </div>
                    <div className='mb-2'>
                      <Controller
                        name="phone"
                        control={control}
                        rules={{
                          required: true,
                          pattern: {
                            value: REGEX.PHONE,
                            message: "Invalid phone number"
                          }
                        }}
                        render={({ field: { value, onChange } }) => (
                          <PhoneInput
                            defaultCountry="IN"
                            countries={['IN']}
                            placeholder="Enter Phone Number *"
                            value={value}
                            onChange={onChange}
                            className='[&>input]:outline-none p-2.5 flex justify-stretch bg-whiteCol border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-1.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500'
                          />
                        )}
                      />
                      {errors.phone && (
                        <div className="text-left text-sm text-danger">
                          {ERROR_MESSAGES[errors.phone.type] || errors.phone.message}
                        </div>
                      )}
                    </div>
                    <div className='mb-2'>
                      <Controller
                        name="course"
                        control={control}
                        rules={{
                          required: true
                        }}
                        render={({ field: { value, onChange } }) => (
                          <select
                            name="course"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            onChange={onChange}
                          >
                            <option key={'index'} disabled selected>
                              Select Course *
                            </option>
                            {courseAndBranchList.map((course: any, index: any) => (
                              <option key={index}>
                                {course.name}
                              </option>
                            ))}
                          </select>
                        )}
                      />
                      {errors.course && (
                        <div className="text-left text-sm text-danger">
                          {ERROR_MESSAGES[errors.course.type] || errors.course.message}
                        </div>
                      )}
                    </div>
                    <div className='mb-2'>
                      <Controller
                        name="branch"
                        control={control}
                        rules={{
                          required: branchList.length > 1
                        }}
                        render={({ field: { value, onChange } }) => (
                          <select
                            disabled={branchList.length < 2}
                            name="course"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            onChange={onChange}
                          >
                            <option key={'index'} disabled selected>
                              Select Branch {(branchList.length > 1) ? "*" : ""}
                            </option>
                            {branchList.map((branch: any, index: any) => (
                              <option key={index}>{branch}</option>
                            ))}
                          </select>
                        )}
                      />
                      {errors.branch && (
                        <div className="text-left text-sm text-danger">
                          {ERROR_MESSAGES[errors.branch.type] || errors.branch.message}
                        </div>
                      )}
                    </div>
                    <div className='mb-2'>
                      <Controller
                        name="state"
                        control={control}
                        rules={{
                          required: true
                        }}
                        render={({ field: { value, onChange } }) => (
                          <select
                            name="state"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            onChange={onChange}
                          >
                            <option disabled selected className='text-gray'>
                              Select State *
                            </option>
                            {Object.entries(STATE_CITY_LIST).map(([key]) => (
                              <option key={key}>{key}</option>
                            ))}
                          </select>
                        )}
                      />
                      {errors.state && (
                        <div className="text-left text-sm text-danger">
                          {ERROR_MESSAGES[errors.state.type] || errors.state.message}
                        </div>
                      )}
                    </div>
                    <div className='mb-2'>
                      <Controller
                        name="city"
                        control={control}
                        rules={{
                          required: !!cityList.length
                        }}
                        render={({ field: { value, onChange } }) => (
                          <select
                            name="course"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            onChange={onChange}
                          >
                            <option disabled selected>
                              Select City {cityList.length ? "*" : ""}
                            </option>
                            {cityList.map((item: any) => (
                              <option key={item.id}>{item.city}</option>
                            ))}
                          </select>
                        )}
                      />
                      {errors.city && (
                        <div className="text-left text-sm text-danger">
                          {ERROR_MESSAGES[errors.city.type] || errors.city.message}
                        </div>
                      )}
                    </div>
                  </div>

                 <div className="flex items-start gap-2 pb-2">
  <input type="checkbox" className="mt-1 cursor-pointer" />

  <div className="text-[10px] text-whiteCol sm:w-44 text-start ">
    <p className='text-nowrap'>I would like to receive communication from </p>
    <p className='text-nowrap'>BBS Group of Institutions via and
    SMS, Email, RCS </p>
    <p className='text-nowrap'>WhatsApp for services, offers, and updates.</p>
  </div>
</div>

                  <button
                    type="submit"
                    className={`sign-btn bg-danger1 text-primary border rounded-3xl	py-2 font-semibold cursor-pointer hover:bg-blue-800`}
                  >
                    Submit
                  </button>
                  <GoogleReCaptchaProvider reCaptchaKey="6LeUDMcpAAAAAMLebnVfJ3q1kKeOYyjOUUDOPUcA">
    <GoogleReCaptcha onVerify={handleRecaptchaChange} />
  </GoogleReCaptchaProvider>
                  <Modal
                    message={alertMessage}
                    isOpen={!!alertMessage}
                    onClose={() => setAlertMessage("")}
                  />

                </form>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
};

export default AdmissionEnquiryForm;