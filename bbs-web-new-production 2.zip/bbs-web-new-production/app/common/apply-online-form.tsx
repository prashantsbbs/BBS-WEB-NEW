import { Fragment, useRef, useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { ExclamationTriangleIcon } from '@heroicons/react/24/outline';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';
import 'react-country-state-city/dist/react-country-state-city.css';
import { useForm, SubmitHandler } from 'react-hook-form';
import Image from 'next/image';
const stateList = [
  {
    name: 'Maharashtra',
    cities: ['Los Angeles', 'San Francisco', 'San Diego'],
  },
  { name: 'Delhi', cities: ['Houston', 'Dallas', 'Austin'] },
];

export default function RegistrationForm({
  openform = true,
  setopenform = (isOpen: boolean) => {},
  courseList = [],
}) {
  const cancelButtonRef = useRef(null);
  // Text Editor
  const editor = useRef(null);
  const [value, setValue] = useState('');
  type Inputs = {
    name: string;
    email: string;
    courseName: string;
    state: string;
    city: string;
    mobile: number;
    exampleRequired: string;
  };
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<Inputs>();
  const onSubmit: SubmitHandler<Inputs> = (data) => console.log();
  const getOtp = (evt: any) => {};
  const [selectedState, setSelectedState] = useState('');
  const [selectedCity, setSelectedCity] = useState('');

  const handleStateChange = (event: any) => {
    setSelectedState(event.target.value);
    setSelectedCity('');
  };

  const handleCityChange = (event: any) => {
    setSelectedCity(event.target.value);
  };

  return (
    <Transition.Root show={openform} as={Fragment}>
      <Dialog
        as="div"
        className="relative z-50 bg-whiteCol"
        initialFocus={cancelButtonRef}
        onClose={() => setopenform(false)}
      >
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 " />
        </Transition.Child>

        <div className="fixed inset-0 z-50  w-screen overflow-y-auto">
          <div className="flex min-h-full  items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <Dialog.Panel className="relative bg-whiteCol transform overflow-hidden rounded-lg bg-white text-left border-2 border-[#565555] border-opacity-30 transition-all sm:my-8 sm:w-full sm:max-w-lg">
                <Image
                  src="/cross.webp"
                  alt="Cross"
                  className="fixed top-3 h-7 right-2 cursor-pointer"
                  onClick={() => setopenform(false)}
                  width={29}
                  unoptimized={true}
                  height={50}
                />
                <div className="flex min-h-full flex-1 flex-col justify-center  py-5  ">
                  <p className=" text-center text-2xl   tracking-tight text-gray-900">
                    Apply Now
                  </p>

                  {/* RegistrationForm */}
                  <div className="mt-10 p-6  ">
                    <form
                      onSubmit={handleSubmit(onSubmit)}
                      className="container max-w-sm mx-auto"
                    >
                      <label
                        htmlFor="condidateName"
                        className="block text-lg font-large leading-6 text-gray-900 pb-2"
                      >
                        {' '}
                        Condidate Name
                      </label>
                      <input
                        type="text"
                        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Condidate Name"
                        defaultValue=""
                        {...register('exampleRequired', { required: true })}
                      />
                      {errors.exampleRequired && (
                        <span>This field is required</span>
                      )}

                      <label htmlFor="email" className="">
                        {' '}
                        Condidate Email
                      </label>
                      <input
                        defaultValue=""
                        {...register('exampleRequired', { required: true })}
                        type="text"
                        name="condidateEmail"
                        aria-describedby="helper-text-explanation"
                        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Email Address"
                      />
                      {errors.exampleRequired && (
                        <span>This field is required</span>
                      )}

                      <label
                        htmlFor="countries"
                        className="block mb-2 text-lg font-medium text-gray-900 dark:text-white pt-2"
                      >
                        Select your country
                      </label>
                      <span className=" flex justify-stretch bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-1.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                        <PhoneInput
                          country={'in'}
                          value={value}
                          onChange={setValue}
                        />
                        <button onClick={getOtp} className="font-bold">
                          Send{' '}
                        </button>
                      </span>

                      <label
                        htmlFor="email"
                        className="pb-2 block text-lg font-medium leading-6 text-gray-900 pt-2"
                      >
                        {' '}
                        Enter OTP
                      </label>
                      <input
                        type="text"
                        aria-describedby="helper-text-explanation"
                        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Inter OTP"
                      />

                      <label
                        htmlFor="program"
                        className="block mb-2 text-lg font-medium text-gray-900 dark:text-white pt-2"
                      >
                        Select your Programme
                      </label>
                      <select
                        defaultValue=""
                        {...register('courseName')}
                        name="program"
                        className="  mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      >
                        <option>+MBA</option>
                        <option>+BBA</option>
                        <option>B.Tecg</option>
                        <option>M.Tech</option>
                      </select>

                      <label
                        htmlFor="countries"
                        className="block mb-2 text-lg font-medium text-gray-900 dark:text-white pt-2"
                      >
                        Select your location
                      </label>
                      <span className="flex gap-3">
                        <select
                          defaultValue=""
                          {...register('state')}
                          name="state"
                          onChange={handleStateChange}
                          id="state"
                          className="  mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        >
                          <option disabled selected={selectedState === ''}>
                            {' '}
                            -- select state --{' '}
                          </option>
                          {stateList.map((state, index) => (
                            <option
                              selected={state.name === selectedState}
                              key={index}
                              value={state.name}
                            >
                              {state.name}
                            </option>
                          ))}
                        </select>
                        <select
                          defaultValue=""
                          {...register('city')}
                          name="city"
                          onChange={handleCityChange}
                          id="city"
                          className=" mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        >
                          <option disabled selected={selectedCity === ''}>
                            {' '}
                            -- select city --{' '}
                          </option>
                          {(
                            stateList.find(
                              (item) => item.name === selectedState
                            )?.cities || []
                          ).map((item, index) => (
                            <option
                              key={index}
                              value={item}
                              selected={item === selectedCity}
                            >
                              {item}
                            </option>
                          ))}
                        </select>
                      </span>
                      <button
                        type="submit"
                        className=" mt-4 bg-[#d3c7f5] flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                      >
                        Submit
                      </button>
                    </form>
                  </div>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
}
