import { Fragment, useEffect, useMemo, useRef, useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { useForm } from 'react-hook-form';
import 'react-phone-input-2/lib/style.css';
import 'react-country-state-city/dist/react-country-state-city.css';
import { Result } from 'postcss';
import Image from 'next/image';

const stateList = [
  {
    name: 'Maharashtra',
    cities: ['Los Angeles', 'San Francisco', 'San Diego'],
  },
  { name: 'Delhi', cities: ['Houston', 'Dallas', 'Austin'] },
];

export default function EnquiryForm({
  open = true,
  setOpen = (isOpen: any) => {},
}) {
  const cancelButtonRef = useRef(null);

  type Inputs = {
    name: string;
    email: string;
    mobile: number;
    courseName: string;
    branch: string;
    state: string;
    city: string;
    exampleRequired: string;
  };
  const {
    register,
    handleSubmit,
    reset,
    watch,
    formState: { errors },
  } = useForm<Inputs>();

  const [captcha, setCaptcha] = useState('');
  const [btnStatus, setBtnStatus] = useState('none');
  const [captchaStatus, setCaptchaStatus] = useState('');
  const [inputClr, setInputClr] = useState('');

  const characters = 'abc123';

  const generateCaptcha = () => {
    let result = '';
    const charactersLength = characters.length;
    for (let i = 0; i < 4; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    setCaptcha(result);
  };

  useEffect(() => {
    generateCaptcha();
  }, []);

  const handleRefresh = () => {
    generateCaptcha();
    setInputClr('');
  };

  const handleChange = (e: any) => {
    const input = e.target.value;
    if (input === captcha) {
      setCaptchaStatus('Correct');
      setBtnStatus('auto');
    } else if (input !== captcha && input !== '') {
      setCaptchaStatus('CAPTCHA* error !');
      setBtnStatus('none');
    } else if (input === '') {
      setCaptchaStatus('');
      setBtnStatus('none');
    }
    setInputClr(input);
  };

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog
        as="div"
        className="relative z-50 bg-whiteCol"
        initialFocus={cancelButtonRef}
        onClose={() => setOpen(false)}
      >
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 " />
        </Transition.Child>

        <div className="fixed top-20  sm:right-0 right-[15%]  mx-auto z-50 animate__animated animate__slideInRight">
          <div className="flex min-h-full  items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <Dialog.Panel className="relative bg-whiteCol transform overflow-hidden rounded-lg bg-white text-left border-2 border-[#565555] border-opacity-30 transition-all sm:my-8 sm:w-full sm:max-w-lg">
                <Image
                  src="/cross.webp"
                  alt="Cross"
                  unoptimized={true}
                  className="fixed top-3 h-7 left-2 cursor-pointer z-50"
                  onClick={() => setOpen(false)}
                  width={29}
                  height={50}
                />
                <form
                  onSubmit={handleSubmit((data) => {
                    reset();
                    setCaptchaStatus('');
                    setInputClr('');
                    generateCaptcha();
                    setTimeout(() => {
                      setOpen(false);
                    }, 1000);
                  })}
                  className="relative flex flex-col px-8 pb-8 md:px-6 md:pb-6 md:pt-6 pt-2 gap-1 text-center bg-secondary"
                >
                  <p className="text-2xl drop-shadow-lg text-whiteCol font-bold	">
                    Admission Enquiry{' '}
                  </p>
                  <div className="form-container">
                    <input
                      type="text"
                      {...register('name')}
                      required
                      className="  mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      placeholder="Name"
                    />
                    <input
                      type="email"
                      {...register('email')}
                      required
                      className="  mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      placeholder="Email"
                    />
                    <input
                      type="number"
                      {...register('mobile')}
                      required
                      className="  mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      placeholder="Mobile"
                    />
                    <select
                      defaultValue="-- Course --"
                      {...register('courseName')}
                      required
                      name="courseName"
                      id="courseName"
                      className="  mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    >
                      <option disabled selected>
                        -- Select Course --
                      </option>
                      <option>+MBA</option>
                      <option>+BBA</option>
                      <option>B.Tech</option>
                      <option>M.Tech</option>
                    </select>
                    <select
                      defaultValue="-- Select Branch --"
                      {...register('branch')}
                      required
                      name="branch"
                      id="branch"
                      className="  mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    >
                      <option disabled selected>
                        -- Select Branch --
                      </option>
                      <option>ECE</option>
                      <option>CS</option>
                      <option>EEE</option>
                    </select>
                    <select
                      defaultValue="-- Select State --"
                      {...register('state')}
                      required
                      name="state"
                      id="state"
                      className="  mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    >
                      <option disabled selected>
                        -- Select State --
                      </option>
                      <option>Uttar Pradesh</option>
                      <option>Delhi</option>
                      <option>Bihar</option>
                    </select>
                    <select
                      defaultValue="-- Select City --"
                      {...register('city')}
                      required
                      name="city"
                      id="city"
                      className="  mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    >
                      <option disabled selected>
                        -- Select City --
                      </option>
                      {stateList.map((state, index) => (
                        <option key={index}>{state.name}</option>
                      ))}
                    </select>
                    <div className="flex items-center justify-center sm:flex-row flex-col">
                      <div className="flex items-center gap-1">
                        <h2 className="bg-whiteCol px-10 h-fit rounded-md select-none">
                          {captcha}
                        </h2>
                        <Image
                          src="reload.webp"
                          alt="Reload"
                          className=" h-9 cursor-pointer"
                          onClick={handleRefresh}
                          unoptimized={true}
                          width={29}
                          height={50}
                        />
                      </div>
                      <input
                        type="text"
                        onChange={handleChange}
                        value={inputClr}
                        required
                        className="flex-1 sm:ml-4 ml-0 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Enter Captcha"
                      />
                    </div>
                  </div>
                  <p style={{ color: 'red', fontWeight: '800' }}>
                    {captchaStatus}
                  </p>
                </form>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
}
