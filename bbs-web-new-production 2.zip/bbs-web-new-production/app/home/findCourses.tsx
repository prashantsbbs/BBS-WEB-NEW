'use client';
import Image from 'next/image';
import 'animate.css';
import { Swiper, SwiperSlide } from 'swiper/react';

import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

import {
  Navigation,
  Pagination,
  Mousewheel,
  Keyboard,
  Autoplay,
} from 'swiper/modules';
import Link from 'next/link';
import { useEffect, useState } from 'react';

const FindCourses = ({ courseList = [] }: any) => {
  const [selectedCategory, setSelectedCategory] = useState(null);

  const defaultState = {
    renderList: 'Bachelor Courses',
    isHover: false,
  };

  const [state, setState] = useState(defaultState);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  const handleSlider = (value: any) => {
    setState((prev: any) => ({ ...prev, renderList: value }));
  };
  const filteredCourseList = courseList.filter((course: any) => {
    return course?.attributes?.course_category?.data?.id === selectedCategory;
  });

  return (
    <>
      {/* <div className={`bg-[url('/home/futureReadyBg.webp')]  md:bg-cover  relative px-6 md:px-16 py-8   bg-no-repeat  bg-center flex justify-center  items-center`}></div> */}
      {/* <div className={`h-3/4 bg-[url('/home/FutureReadyProgrammesBg.webp')]  md:bg-cover  relative px-6 md:px-16 py-8   bg-no-repeat  bg-center flex justify-center  items-center`}> */}
      <div
        className={` md:bg-cover  relative px-6 md:px-16 py-8   bg-no-repeat  bg-center flex justify-center  items-center`}
      >
        <div className="z-10 relative py-16">
          <div className="text-center pb-10 p-4">
            <h2 className="text-5xl text-primary"> Future Ready Programmes</h2>
            <h4 className="text-primary text-lg">
              Discover diverse new age programmes designed to shape future
              leaders
            </h4>
          </div>
          <div className="max-w-7xl grid grid-1 gap-8 justify-center mx-auto">
            {/* <div className="grid grid-1"><h2 className=" md:text-4xl text-2xl  text-dark-blue mb-2 mt-2">
           Future-proof your career with our courses
          </h2>
           <h4 className="mb-4  text-justify">
             Find the perfect courses to boost your knowledge and achieve your career ambitions.
            </h4></div> */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-8">
              {courseList?.length > 0 &&
                courseList.map((course: any, index: number) => (
                  <div
                    key={index}
                    data-aos="fade-right"
                    className=" "
                    onMouseEnter={() => setHoverIndex(index)}
                    onMouseLeave={() => setHoverIndex(null)}
                  >
                    <Link href={course?.attributes?.detailed_view_link}>
                      <div className="flex justify-center items-center group h-[120px] w-[120px] md:h-[140px] md:w-[140px] xl:h-[160px] xl:w-[160px] p-2 rounded-md border border-seaGreen group-hover:border-primary  group-hover:bg-primary-new-light  cursor-pointer bg-whiteCol flex flex-col items-center  text-center  transform transition-transform duration-300 ease-in-out hover:scale-110">
                        <div
                          className="bg-primary-new-light group-hover:bg-danger transition-all duration-1000 absolute h-full w-[0%] group-hover:w-full top-0 left-0 rounded-md"
                        ></div>
 <Image
                          unoptimized={true}
                          src={course?.attributes?.media?.data?.attributes?.url}
                          width={40}
                          alt="Best University"
                          height={40}
                          className={`transition-all duration-500 group-hover:scale-120 group-hover:-translate-y-1 group-hover:rotate-6
                               ${
                                 hoverIndex === index
                                   ? 'invert'
                                   : '[filter:invert(29%)_sepia(93%)_saturate(2037%)_hue-rotate(342deg)_brightness(93%)_contrast(95%)]'
                               }
                               `}
                        />
                        {/* <Image
                          unoptimized={true}
                          src="/home/chooseExcellence/online-learning.png"
                          width={40}
                          alt="Best University"
                          height={40}
                          className={`transition-all duration-500 group-hover:scale-120 group-hover:-translate-y-1 group-hover:rotate-6
                               ${
                                 hoverIndex === index
                                   ? 'invert'
                                   : '[filter:invert(29%)_sepia(93%)_saturate(2037%)_hue-rotate(342deg)_brightness(93%)_contrast(95%)]'
                               }`}
                        /> */}
                        
                        <div className="flex flex-col items-center gap-0.5 leading-tight">
                          <h2 className="text-primary text-lg text-center leading-tight m-2 group-hover:text-whiteCol z-20">
                            {course?.attributes?.name}
                          </h2>

                          <h5 className="hidden sm:block text-gradientR text-[10px] text-center leading-tight m-0 group-hover:text-whiteCol z-20">
                            {
                              course?.attributes?.department?.data?.attributes
                                ?.name
                            }
                          </h5>
                        </div>
                      </div>
                    </Link>
                  </div>
                ))}
            </div>
          </div>
          {/* <div className="grid grid-cols-1 md:grid-cols-3 sm:grid-cols-2 w-[80%] m-auto mb-4">
            {courseCategoryList.map((head: any, index: any) => (
              <h2
                key={index}
                onClick={() => setSelectedCategory(head?.id)}
                className="m-0 md:mb-6 text-pink cursor-pointer"
              >
                <div
                  className={
                    head?.id === selectedCategory
                      ? 'border-b-4  border-primary animate__animated animate__fadeInLeft m-0 px-2 py-1 w-max'
                      : 'm-0 px-2 py-1 w-max text-primary'
                  }
                >
                  {head?.attributes?.name}
                </div>
              </h2>
            ))}
          </div>

          <div className="bg-transparent h-px  mb-6 w-[80%] m-auto"> </div>
          <div className="swiperCourse ">
            <Swiper
              slidesPerView={1}
              loop={filteredCourseList.length > 4}
              cssMode={true}
              navigation={true}
              autoplay={{
                delay: 2500,
                disableOnInteraction: false,
              }}
              breakpoints={{
                300: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                },
                540: {
                  slidesPerView: 2,
                  spaceBetween: 20,
                },
                640: {
                  slidesPerView: 2,
                  spaceBetween: 20,
                },
                768: {
                  slidesPerView: 3,
                  spaceBetween: 40,
                },
                1024: {
                  slidesPerView: 4,
                  spaceBetween: 50,
                },
                1100: {
                  slidesPerView: 4,
                  spaceBetween: 50,
                },
              }}
              pagination={{
                clickable: true,
              }}
              mousewheel={true}
              keyboard={true}
              modules={[Navigation, Pagination, Mousewheel, Autoplay, Keyboard]}
              className="mySwiper "
            >
              <div>
                {filteredCourseList.map((slide: any, index: number) => (
                  <SwiperSlide className="" key={index}>
                    <div
                      key={index}
                      style={{
                        backgroundImage: `url(${
                          slide?.attributes?.media?.data?.attributes?.url || '#'
                        })`,
                      }}
                      className="bg-cover bg-no-repeat  relative bg-center justify-center align-middle text-secondary rounded-lg py-24 "
                    >
                      <div className="bg-[#211b3286] rounded-r-lg top-0 left-0 w-full h-full absolute "></div>
                      <div className=" m-auto h-full relative z-20">
                        <h2 className="  text-whiteCol   text-center  ">
                          {slide?.attributes?.name}
                        </h2>
                        <h5 className="  text-whiteCol   text-center  ">
                          {
                            slide?.attributes?.department?.data?.attributes
                              ?.name
                          }
                        </h5>
                        <Link
                          href={`${
                            slide?.attributes?.detailed_view_link
                              ? `${slide?.attributes?.detailed_view_link}?department=${slide?.attributes?.department?.data?.id}`
                              : '#'
                          }`}
                        >
                          <h4 className="bg-secondary text-primary w-1/2 m-auto  px-2 py-1  text-center rounded-full">
                            View More
                          </h4>{' '}
                        </Link>
                      </div>
                    </div>
                  </SwiperSlide>
                ))}
              </div>
            </Swiper>
          </div> */}
        </div>
      </div>
    </>
  );
};

export default FindCourses;
