'use client';
import Image from 'next/image';
import { international_sec } from '../constant/constant';
import ButtonCustom from '../common/button';
import { stateOfArt } from '../constant/constant';
import { useEffect, useMemo, useState } from 'react';
import CountUp from 'react-countup';
import ScrollTrigger from 'react-scroll-trigger';

const InternationalExposure = () => {
  const [counterStart, setCounterStart] = useState(false);

  const onEnterViewport = () => {
    console.log('onEnterViewport');
    setCounterStart(true);
  };

  const onExitViewport = () => {
    console.log('onExitViewport');
    setCounterStart(false);
  };

  return (
    <>
      {/* @ts-ignore */}
      <ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}>
        {stateOfArt.map((section: any, index: number) => (
          <div
            key={index}
            className="bg-whiteCol grid lg:grid-cols-2 grid-cols-1 relative "
          >
            <Image
              unoptimized={true}
              src={section.image}
              width={1200}
              alt="State Of Art"
              height={1000}
              className="bgImage h-full "
            />
            <div className="bg-gradient-to-b from-gradientL to-gradientR relative h-[80vh] lg:h-screen text-center items-center grid grid-cols-2 gap-6 p-6 text-whiteCol w-full     ">
              <Image
                unoptimized={true}
                src={'/home/internationalization/lines.svg'}
                width={500}
                alt="Lines"
                height={0}
                className="bgImage absolute top-0 left-0 w-full"
              />

              <>
                <div className=" text-center  ">
                  <h2 className="text-secondary m-0 md:text-5xl text-4xl ">
                    {counterStart && <CountUp start={0} end={24}></CountUp>}+
                  </h2>
                  <h4 className="md:text-xl text-md m-0">
                    Years of Academic Excellence
                  </h4>
                </div>

                <div className=" text-center  ">
                  <h2 className="text-secondary m-0 md:text-5xl text-4xl">
                    {counterStart && <CountUp start={0} end={15000}></CountUp>}+
                  </h2>
                  <h4 className="md:text-xl text-md m-0">Placements Record</h4>
                </div>

                <div className=" text-center  ">
                  <h2 className="text-secondary m-0 md:text-5xl text-4xl ">
                    Dedicated
                  </h2>
                  <h4 className="md:text-xl text-md m-0">
                    to Innovative Education
                  </h4>
                </div>

                <div className=" text-center  ">
                  <h2 className="text-secondary m-0 md:text-5xl text-4xl">
                    Excellent
                  </h2>
                  <h4 className="md:text-xl text-md m-0">
                    Linkage with Industry
                  </h4>
                </div>

                <div className=" text-center  ">
                  <h2 className="text-secondary m-0 md:text-5xl text-4xl ">
                    State of Art
                  </h2>
                  <h4 className="md:text-xl text-md m-0">Infrastructure</h4>
                </div>

                <div className=" text-center  ">
                  <h2 className="text-secondary m-0 md:text-5xl text-4xl ">
                    {counterStart && <CountUp start={0} end={20000}></CountUp>}+{' '}
                  </h2>
                  <h4 className="md:text-xl text-md m-0">PAN India Students</h4>
                </div>
              </>
            </div>
          </div>
        ))}
      </ScrollTrigger>

      {/* second Div */}
      {international_sec.map((section_2: any, index: number) => (
        <div
          key={index}
          className="  hidden bg-whiteCol grid lg:grid-cols-2 grid-cols-1      "
        >
          {/* @ts-ignore */}
          {/* <ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}> */}
          <div
            className={`bg-gradient-to-b from-gradientL to-gradientR order-2   lg:order-1 items-center p-6 text-whiteCol w-full md:p-32 p-16 ${
              counterStart
                ? 'animate__animated animate__fadeInLeft animate__slower'
                : ''
            }`}
          >
            <h2 className="lg:text-3xl text-secondary  text-2xl  pb-6">
              {section_2.title}
            </h2>
            <h4 className="pb-6  text-justify">{section_2.paragraph}</h4>
          </div>
          {/* </ScrollTrigger> */}

          <div className="order-1  lg:order-2">
            <Image
              unoptimized={true}
              src={section_2.image}
              width={500}
              alt="International Section"
              height={500}
              className="bgImage  "
            />
          </div>
        </div>
      ))}
    </>
  );
};

export default InternationalExposure;
