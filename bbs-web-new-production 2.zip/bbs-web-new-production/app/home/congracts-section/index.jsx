'use client';
import Image from 'next/image';
import SwiperComponent from './swiper/index.jsx';
import { keyRecruiters } from '@/app/constant/keyRecruiters';
export const data = {
  placementData: [
    {
      description: '12.5 Lakh Average CTC',
    },
    {
      description: '14.2 Lakh Average CTC',
    },
    {
      description: '11.8 Lakh Average CTC',
    },
    {
      description: '13.7 Lakh Average CTC',
    },
    {
      description: '12.9 Lakh Average CTC',
    },
    {
      description: '14.5 Lakh Average CTC',
    },
    {
      description: '13.2 Lakh Average CTC',
    },
    {
      description: '11.5 Lakh Average CTC',
    },
  ],
};

const CongractsSection = ({ companySliderdisplay = true }) => {
  const RecruitersCompanies = keyRecruiters;

  return (
    <section className="md:pb-18 pb-10 md:pt-18 pt-10 md:px-24 px-10 md:h-[580px]  bg-cover bg-no-repeat congo-bg ">
      {/* Text Section */}

      {/* Slider Section */}
      <div className="flex items-end justify-between ">
        <div className="md:w-[35%] w-[100%]  rounded-3xl mr-10 xl:mb-[7.5%] ">
          {/* Students Slider */}
          <h2 className="text-5xl text-secondary drop-shadow-lg  mb-5 ">
            Best Placements
          </h2>
          <div className="ctc-box">
            <SwiperComponent elements={data.placementData} />
          </div>
          <p className="text-whiteCol drop-shadow-lg tracking-wide font-bold text-lg mt-4 m-0 ">
            92% STUDENTS RECEIVED JOB OFFERS{' '}
          </p>
        </div>
        <div className=" text-whiteCol drop-shadow  xl:text-left md:text-right text-center justify-end md:flex hidden items-end">
          <div className="xl:mb-[16%]">
            <h2>Outstanding Achievement:</h2>
            <h2 className="text-5xl text-secondary drop-shadow-lg ">
              Package: 50 LPA
            </h2>
            <h3 className="xl:text-3xl text-3xl drop-shadow-lg">
              Nikhil Kumar
            </h3>
            <p className="text-xl drop-shadow-lg font-bold tracking-wide">
              Valmet Flow Control
            </p>
          </div>
<div className='w-[360px]'></div>
          {/* <Image
            unoptimized={true}
            src="/home/bestUniversity/Photo 3 NEW_cut.webp"
            alt="Congracts Section"
            className="w-[55%] lg:block hidden "
            height={400}
            width={600}
          /> */}
        </div>
      </div>
      {/* Companies Slider */}
      {companySliderdisplay && (
        <div className="relative">
          <div className="absolute top-[-2rem] left-1/2 md:px-5 px-3  transform -translate-x-1/2 z-10 bg-pink text-whiteCol rounded-md shadow-lg w-fit m-0 ">
            <h3 className="">Top Recruiters</h3>
          </div>
          <div className="md:p-1 p-4  shadow-2xl  mt-10 mx-auto my-auto rounded-3xl border-2 border-[#565555] border-opacity-30 bg-whiteCol">
            <div className="mt-6">
              <SwiperComponent elements={RecruitersCompanies} />
            </div>
          </div>
        </div>
      )}
      {/* <div className="md:float-right float-none md:text-right text-center md:leading-normal text-whiteCol text-lg font-medium mt-3 montserrat cursor-pointer hover:text-white hover:border-b hover:border-white md:w-fit">
        AND MANY MORE
      </div> */}
    </section>
  );
};

export default CongractsSection;
