import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import { Autoplay, Navigation } from "swiper/modules";
import Image from "next/image";

const SwiperComponent = ({ elements = [] }) => {
  return (
    <>
      <Swiper
        slidesPerView={1}
        spaceBetween={30}
        loop={true}
        autoplay={{
          delay: 2500,
          disableOnInteraction: false,
        }}
        breakpoints={
          !elements[0].description && {
            300: {
              slidesPerView: 1,
              spaceBetween: 10,
            },
            540: {
              slidesPerView: 2,
              spaceBetween: 20,
            },
            640: {
              slidesPerView: 2,
              spaceBetween: 20,
            },
            768: {
              slidesPerView: 3,
              spaceBetween: 40,
            },
            1024: {
              slidesPerView: 4,
              spaceBetween: 50,
            },
            1100: {
              slidesPerView: 5,
              spaceBetween: 50,
            },
          }
        }
        modules={[Autoplay, Navigation]}
        className="mySwiper swipperCenter"
      >
        {elements.map((data, id) => (
          <SwiperSlide key={id}>
            <div
              key={data.length}
              className={`flex   ${
                !data.description && "justify-center items-center"
              } flex-col font-semibold`}
              
            >
              {!data.description && (
                <Image
                unoptimized={true}
                  width={500}
                  height={50}
                  loading="lazy"
                  src={data.avatar}
                  alt="BBS Student"
                  className="md:mb-4 min-w-[5rem] mb-3 md:max-w-[70%] max-w-[60%]"
                />
              )}
              {data.description && <h2 className="text-whiteCol text-left text-5xl xl:text-4xl drop-shadow-lg"> {data.description}</h2>}
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </>
  );
};

export default SwiperComponent;
