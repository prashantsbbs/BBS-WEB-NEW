'use client';

import Link from 'next/link';
import Image from 'next/image';

const chooseExcellences = [
  {
    title: 'RANKED NO. 1',
    subTitle: 'Educational Leader',
    image: '/home/chooseExcellence/ranking.webp',
  },
  {
    title: 'ANTI-RAGGING',
    subTitle: 'Campus',
    image: '/home/chooseExcellence/ragging.webp',
  },
  {
    title: 'TIE-UPS WITH',
    subTitle: 'Research Bodies',
    image: '/home/chooseExcellence/tiesUp.webp',
  },
  {
    title: 'Student-Centric',
    subTitle: 'Cultural Programs',
    image: '/home/chooseExcellence/student.webp',
  },
  {
    title: 'INDUSTRY',
    subTitle: 'Exposure',
    image: '/home/chooseExcellence/factory.webp',
  },
  {
    title: 'Career-Opportunities',
    subTitle: 'Career Opportunities',
    image: '/home/chooseExcellence/opportunities.webp',
  },
  {
    title: 'World-Class-Infrastructure',
    subTitle: 'Modern-Amenities-&-Resources',
    image: '/home/chooseExcellence/infrastructure.webp',
  },
  {
    title: '24X7',
    subTitle: 'Secured Campus',
    image: '/home/chooseExcellence/24x7Support.webp',
  },
];

const ChooseExcellence = () => {
  return (
    <>
      {/* <div className=" bg-cover chooseExcellence  bg-no-repeat flex relative bg-center justify-center align-middle py-20 overflow-hidden "> */}
             <div className="bg-gray bg-cover  bg-no-repeat flex relative bg-center justify-center align-middle py-20 overflow-hidden ">
        {/* <div className="bg-[#FFFFFF80] absolute inset-0"></div> */}
        <div className="bg-whiteCol absolute inset-0"></div>

        <div className="m-auto w-10/12 relative">
          <div className="text-center pb-10 p-4">
            <h2 className="text-5xl text-primary">
              {' '}
              25+ Years Legacy of Academic Excellence
            </h2>
            <h4 className="text-primary text-lg">
              Existing Website BBS Group of Institutions
            </h4>
          </div>
          <div className="grid md:grid-cols-4 gap-y-8  grid-cols-2 gap-x-2 text-center">
            {chooseExcellences.map((list: any, index) => (
  //             <div
  //               key={index}
  //               className="transform transition-transform duration-300 ease-in-out hover:scale-105"
  //             >
  //               <Image
  //          unoptimized={true}
  // src={list.image}
  // width={130}
  // height={130}
  // alt="Best University"
  // className="m-auto mb-3 transition-transform duration-700 hover:rotate-[360deg]"
  // data-aos="fade-right"
  //               />
  //               <h3 className="font-semibold m-0 text-primary-new-light">{list.title}</h3>
  //               <h5 className="m-0 text-seaGreen">{list.subTitle}</h5>
  //             </div>
  <div
  key={index}
  className="transform transition-transform duration-300 ease-in-out hover:scale-105"
>
  
  {/* <div
  key={index}
  className="transform transition-transform duration-300 ease-in-out hover:scale-105"
> */}
 <div
  key={index}
  className="transition-transform duration-2000 rotate-y-hover hover:scale-105"
>
   <Image
  unoptimized={true}
  src={list.image}
  width={130}
  alt="Best University"
  height={0}
  className="m-auto mb-3 transition-all duration-1000 ease-out hover:scale-125 hover:rotate-6 hover:drop-shadow-[0_20px_25px_rgba(0,0,0,0.3)] "
   
  data-aos="fade-right"
/>
  </div>

  <h3 className="font-semibold m-0 text-primary">{list.title}</h3>
  <h5 className="m-0 text-primary text-sm">{list.subTitle}</h5>

</div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default ChooseExcellence;
