'use client';
import Image from 'next/image';
import 'animate.css';
import { Swiper, SwiperSlide } from 'swiper/react';

import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

import {
  Navigation,
  Pagination,
  Mousewheel,
  Keyboard,
  Autoplay,
} from 'swiper/modules';
import Link from 'next/link';
import { useEffect, useState } from 'react';

const CoursesH = ({ courseList = [{}], courseCategoryList = [] }: any) => {
  const [selectedCategory, setSelectedCategory] = useState(
    courseCategoryList[0]?.id
  );

  const defaultState = {
    renderList: 'Bachelor Courses',
  };

  const sliderHead = [
    { id: 1, value: 'Bachelor Courses' },
    { id: 2, value: 'Master Courses' },
    { id: 3, value: 'Diploma Courses' },
  ];

  const [state, setState] = useState(defaultState);

  const handleSlider = (value: any) => {
    setState((prev: any) => ({ ...prev, renderList: value }));
  };
  const filteredCourseList = courseList.filter((course: any) => {
    return course?.attributes?.course_category?.data?.id === selectedCategory;
  });

  useEffect(() => {
    setSelectedCategory(courseCategoryList[0]?.id);
  }, [courseCategoryList]);

  return (
    <>
      <div className="h-3/4 bg-gray">
        <div className="z-10 relative py-16">
          <div className="text-center pb-10 p-4">
            <h2 className="text-5xl text-seaGreen"> Future Ready Programmes</h2>
            <h4 className="">
              Discover diverse new age programmes designed to shape future leaders 
               
            </h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 sm:grid-cols-2 w-[80%] m-auto mb-4">
            {courseCategoryList.map((head: any, index: any) => (
              <h2
                key={index}
                onClick={() => setSelectedCategory(head?.id)}
                className="m-0 md:mb-6 text-pink cursor-pointer"
              >
                <div
                  className={
                    head?.id === selectedCategory
                      ? 'border-b-4  border-primary animate__animated animate__fadeInLeft m-0 px-2 py-1 w-max'
                      : 'm-0 px-2 py-1 w-max text-primary'
                  }
                >
                  {head?.attributes?.name}
                </div>
              </h2>
            ))}
          </div>

          <div className="bg-transparent h-px  mb-6 w-[80%] m-auto"> </div>
          <div className="swiperCourse ">
            <Swiper
              slidesPerView={1}
              loop={filteredCourseList.length > 4}
              cssMode={true}
              navigation={true}
              autoplay={{
                delay: 2500,
                disableOnInteraction: false,
              }}
              breakpoints={{
                300: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                },
                540: {
                  slidesPerView: 2,
                  spaceBetween: 20,
                },
                640: {
                  slidesPerView: 2,
                  spaceBetween: 20,
                },
                768: {
                  slidesPerView: 3,
                  spaceBetween: 40,
                },
                1024: {
                  slidesPerView: 4,
                  spaceBetween: 50,
                },
                1100: {
                  slidesPerView: 4,
                  spaceBetween: 50,
                },
              }}
              pagination={{
                clickable: true,
              }}
              mousewheel={true}
              keyboard={true}
              modules={[Navigation, Pagination, Mousewheel, Autoplay, Keyboard]}
              className="mySwiper "
            >
              <div>
                {filteredCourseList.map((slide: any, index: number) => (
                  <SwiperSlide className="" key={index}>
                    <div
                      key={index}
                      style={{
                        backgroundImage: `url(${
                          slide?.attributes?.media?.data?.attributes?.url || '#'
                        })`,
                      }}
                      className="bg-cover bg-no-repeat  relative bg-center justify-center align-middle text-secondary rounded-lg py-24 "
                    >
                      <div className="bg-[#211b3286] rounded-r-lg top-0 left-0 w-full h-full absolute "></div>
                      <div className=" m-auto h-full relative z-20">
                        <h2 className="  text-whiteCol   text-center  ">
                          {slide?.attributes?.name}
                        </h2>
                        <h5 className="  text-whiteCol   text-center  ">
                          {
                            slide?.attributes?.department?.data?.attributes
                              ?.name
                          }
                        </h5>
                        <Link
                          href={`${
                            slide?.attributes?.detailed_view_link
                              ? `${slide?.attributes?.detailed_view_link}?department=${slide?.attributes?.department?.data?.id}`
                              : '#'
                          }`}
                        >
                          <h4 className="bg-secondary text-primary w-1/2 m-auto  px-2 py-1  text-center rounded-full">
                            View More
                          </h4>{' '}
                        </Link>
                      </div>
                    </div>
                  </SwiperSlide>
                ))}
              </div>
            </Swiper>
          </div>
        </div>
      </div>
    </>
  );
};

export default CoursesH;
