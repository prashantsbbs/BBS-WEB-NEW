
'use client';

import { Swiper, SwiperSlide } from 'swiper/react';
import Image from 'next/image';

import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

import {
  Navigation,
  Pagination,
  Mousewheel,
  Keyboard,
  Autoplay,
} from 'swiper/modules';

import { useEffect, useState } from 'react';
import AppService from '../services';

const HeroSection = ({}) => {
  const [bannerList, setBannerList] = useState<any[]>([]);

  // 👇 mobile detection first render me hi
  const [isMobile, setIsMobile] = useState(
    // typeof window !== 'undefined' ? window.innerWidth <= 768 : false
        typeof window !== 'undefined' ? window.innerWidth <= 480 : false
  );

  const defaultBanner: any = {
    id: 'default',
    type: 'video',
    video: '/bbsBannerVideo.mp4',
  };
   const defaultBannerMobile: any = {
    id: 'defaultMobile',
    type: 'video',
    video: '/bbsBannerVideoMobile.mp4',
  };

  const fetchBannerList = async () => {
    const { data, error } = await AppService.getBannerList();
    console.log(data,"dataaaaa");
    

    // if (!error) {
    //   if (isMobile) {
    //     setBannerList(data.reverse());
    //   } else {
    //     setBannerList([defaultBanner, ...data.reverse()]);
    //   }
    // }
     if (!error) {
    const sortedData = data.sort((a: any, b: any) => b.id - a.id);

    if (isMobile) {
      // setBannerList(sortedData);
      setBannerList([defaultBannerMobile, ...sortedData]);
    } else {
      setBannerList([defaultBanner, ...sortedData]);
    }
  }
  };

  const getBodyWidth = () => {
    // setIsMobile(window.innerWidth <= 768);
     setIsMobile(window.innerWidth <= 480);
  };

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.addEventListener('resize', getBodyWidth);
    }

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('resize', getBodyWidth);
      }
    };
  }, []);

  useEffect(() => {
    fetchBannerList();
  }, [isMobile]);

  return (
    <div className="md:-mt-[7rem]">
      <Swiper
        cssMode={true}
        navigation={true}
        autoplay={{
          delay: 5000,
          disableOnInteraction: false,
        }}
        pagination={{ clickable: true }}
        mousewheel={true}
        loop={true}
        keyboard={true}
        modules={[Navigation, Pagination, Mousewheel, Autoplay, Keyboard]}
        onSlideChange={(swiper) => {
  const activeSlide = swiper.slides[swiper.activeIndex];

  const video = activeSlide?.querySelector(
    'video'
  ) as HTMLVideoElement | null;

  if (video) {
    // har baar reset + play
    video.currentTime = 0;

    const playPromise = video.play();

    if (playPromise !== undefined) {
      playPromise.catch(() => {
        // mobile autoplay fallback
        video.muted = true;
        video.play();
      });
    }
    swiper.autoplay.stop();
  } else {
    swiper.autoplay.start();
  }
}}
        // onSlideChange={(swiper) => {
        //   if (isMobile) {
        //     swiper.autoplay.start();
        //     return;
        //   }

        //   const activeSlide = swiper.slides[swiper.activeIndex];
        //   const video = activeSlide?.querySelector(
        //     'video'
        //   ) as HTMLVideoElement | null;

        //   if (video) {
        //     video.currentTime = 0;
        //     video.play();
        //     swiper.autoplay.stop();
        //   } else {
        //     swiper.autoplay.start();
        //   }
        // }}
      >
        {bannerList.map((slide: any, index: number) => {
          // VIDEO SLIDE (sirf desktop)
          // if (slide.type === 'video' && !isMobile) {
          if (slide.type === 'video'){
            return (
              <SwiperSlide key={index}>
                <video
                  width={1600}
                  height={1000}
                  autoPlay
                  muted
                  playsInline
                  onPlay={(e) => {
                    const swiper = (
                      (e.target as HTMLVideoElement).closest('.swiper') as any
                    )?.swiper;
                    swiper?.autoplay?.stop();
                  }}
                  onEnded={(e) => {
                    const swiper = (
                      (e.target as HTMLVideoElement).closest('.swiper') as any
                    )?.swiper;
                    swiper?.slideNext();
                    swiper?.autoplay?.start();
                  }}
                  className="heroSlider sm:object-contain sm:h-[80vh]"
                  // style={{ objectFit: 'contain', height: '80vh' }}
                >
                  <source src={slide.video} type="video/mp4" />
                </video>
              </SwiperSlide>
            );
          }

          // IMAGE SLIDE
          return (
            <SwiperSlide key={index}>
              <Image
                src={
                  isMobile
                    ? slide?.attributes?.mobile_media?.data?.attributes?.url
                    : slide?.attributes?.desktop_media?.data?.attributes?.url
                }
                width={1600}
                height={1000}
                alt="Banner List"
                loading="lazy"
                unoptimized={true}
                className="heroSlider"
                style={{ objectFit: 'contain', height: '80vh' }}
              />
            </SwiperSlide>
          );
        })}
      </Swiper>
    </div>
  );
};

export default HeroSection;

// 'use client';

// import { Swiper, SwiperSlide } from 'swiper/react';
// import Image from 'next/image';

// import 'swiper/css';
// import 'swiper/css/navigation';
// import 'swiper/css/pagination';

// import {
//   Navigation,
//   Pagination,
//   Mousewheel,
//   Keyboard,
//   Autoplay,
// } from 'swiper/modules';
// import { sliderHomeDesktop } from '../constant/constant';
// import { sliderHomeMobile } from '../constant/constant';
// import { useEffect, useState } from 'react';
// import AppService from '../services';

// const HeroSection = ({}) => {
//   const [isLoading, setIsLoading] = useState(false);
//   const [bannerList, setBannerList] = useState<any[]>([]);
//   const [isMobile, setIsMobile] = useState(false);
// const defaultBanner :any= {
//   id: "default",
//   type: "video",
//   video: "/bbsBannerVideo.mp4",
// };
//   // const fetchBannerList = async () => {
//   //   setIsLoading(false);
//   //   const { data, error } = await AppService.getBannerList();
//   //   if (error) {
//   //   } else {
//   //     setBannerList(data.reverse());
//   //   }
//   //   setIsLoading(true);
//   // };
// const fetchBannerList = async () => {
//   const { data, error } = await AppService.getBannerList();

//   if (!error) {
//     setBannerList([defaultBanner, ...data.reverse()]);
//   }
// };
//   const getBodyWidth = (evt: any) => {
//     setIsMobile(!(evt.target.innerWidth > 768));
//   };

//   useEffect(() => {
//     fetchBannerList();
//     if (window) {
//       window.addEventListener('resize', getBodyWidth);
//       const screenWidth = window.screen.width;
//       setIsMobile(!(screenWidth > 768));
//     }
//     return () => window && window.removeEventListener('resize', getBodyWidth);
//   }, []);

//   return (
//     <>
//       <div className=" md:-mt-[7rem] ">
//       <div className="">
//         <div className=" ">
//              {/* <Swiper
//             cssMode={true}
//             navigation={true}
//             autoplay={{
//               delay: 5000,
//               disableOnInteraction: false,
//             }}
//             pagination={{
//               clickable: true,
//             }}
//             mousewheel={true}
//             loop={true}
//             keyboard={true}
//             modules={[Navigation, Pagination, Mousewheel, Autoplay, Keyboard]}
//             className=""
//           >
//             <div>
//               {bannerList.map((slide: any, index: number) => (
//                 <SwiperSlide className="" key={index}>
//                   <Image
//                     src={
//                       isMobile
//                         ? slide?.attributes?.mobile_media?.data?.attributes?.url
//                         : slide?.attributes?.desktop_media?.data?.attributes
//                             ?.url
//                     }
//                     width={1600}
//                     height={1000}
//                     alt="Banner List"
//                     loading="lazy"
//                     unoptimized={true}
//                     className="heroSlider"
//                     style={{ objectFit: 'contain', height: '80vh' }}
//                   />
//                 </SwiperSlide>
//               ))}
//             </div>
//           </Swiper> */}
//       <Swiper
//   cssMode={true}
//   navigation={true}
//   autoplay={{
//     delay: 5000,
//     disableOnInteraction: false,
//   }}
//   pagination={{ clickable: true }}
//   mousewheel={true}
//   loop={true}
//   keyboard={true}
//   modules={[Navigation, Pagination, Mousewheel, Autoplay, Keyboard]}
//   className=""
//   onSlideChange={(swiper) => {
//     const activeSlide = swiper.slides[swiper.activeIndex];
//     const video = activeSlide?.querySelector("video") as HTMLVideoElement | null;

//     if (video) {
//       video.currentTime = 0;
//       video.play();
//       swiper.autoplay.stop();
//     } else {
//       swiper.autoplay.start();
//     }
//   }}
// >

//   {bannerList.map((slide: any, index: number) => {

//     // VIDEO SLIDE
//     if (slide.type === "video") {
//       return (
//         <SwiperSlide key={index}>
//           <video
//              width={1600}
//           height={1000}
//             autoPlay
//             muted
//             playsInline
//             onPlay={(e) => {
//               const swiper = ((e.target as HTMLVideoElement)
//                 .closest(".swiper") as any)?.swiper;
//               swiper?.autoplay?.stop();
//             }}
//             onEnded={(e) => {
//               const swiper = ((e.target as HTMLVideoElement)
//                 .closest(".swiper") as any)?.swiper;
//               swiper?.slideNext();
//               swiper?.autoplay?.start();
//             }}
//                     className="heroSlider"
//                     style={{ objectFit: 'contain', height: '80vh' }}
//           >
//             <source src={slide.video} type="video/mp4" />
//           </video>
//         </SwiperSlide>
//       );
//     }

//     // IMAGE SLIDES
//     return (
//       <SwiperSlide key={index}>
//         <Image
//           src={
//             isMobile
//               ? slide?.attributes?.mobile_media?.data?.attributes?.url
//               : slide?.attributes?.desktop_media?.data?.attributes?.url
//           }
//          width={1600}
//                     height={1000}
//                     alt="Banner List"
//                     loading="lazy"
//                     unoptimized={true}
//                     className="heroSlider"
//                     style={{ objectFit: 'contain', height: '80vh' }}
//         />
//       </SwiperSlide>
//     );
//   })}

// </Swiper>
//         </div>
//       </div>
//        </div>
//     </>
//   );
// };
// export default HeroSection;
