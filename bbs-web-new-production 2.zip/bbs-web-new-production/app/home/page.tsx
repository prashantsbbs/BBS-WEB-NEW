'use client';
import ScrollToTop from 'react-scroll-to-top';
import ButtonCustom from '../common/button';
import Example from '../common/formMdal';
import Innovative from './Innovative';
import ApplyForH from './applyForH';
import BbsInstituionsH from './bbsInstitutionH';
import CoursesH from './coursesH';
import HeroSection from './heroSection';
import InternationalExposure from './internationalExposure';
import CongractsSection from './congracts-section/index.jsx';
import InfrastructureSection from './InfrastructureSection.jsx';
import TestimonialSection from './TestimonialSection.jsx';
import NewsEventsSection from '../../app/home/news&events/index';
import Header from '../common/header';
import BestUniversity from './bestUniversity';
import LifeAtBBS from './lifeAtBbs';
import SlideStripe from './slideStripe.jsx';
import CollegeVideo from '../college-video/page';
import KeyDiffrentiator from '../key-differentiator/page';
import FlyerModal from '../common/flyerModal';
import { useEffect, useState } from 'react';
import AppService from '../services';
import BbsGroupInstitutions from './bbsGroupInstitutions';
import ChooseExcellence from './chooseExcellence';
import FindCourses from './findCourses';

const defaultState: any = {
  open: false,
  isLoading: false,
  courseList: [],
  courseCategoryList: [],
  newsList: [],
  eventList: [],
  homePageData: {},
  flyerModal: {
    open: false,
    imageUrl: '',
    redirectLink: '',
    redirectCTALabel: '',
  },
  bulletNewsList: [],
};

const Home = ({}) => {
  const [state, setState] = useState(defaultState);

  const fetchHomepageData = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getHomePageData();
    if (!error) {
      setState((prev: any) => ({ ...prev, homePageData: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  const fetchCourseList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getCourseList();
    if (!error) {
      setState((prev: any) => ({ ...prev, courseList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  const fetchNewsList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getNewsList();
    if (!error) {
      setState((prev: any) => ({ ...prev, newsList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  const fetchEventList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getEventList();
    if (!error) {
      setState((prev: any) => ({ ...prev, eventList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  const fetchCourseCategoryList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getCourseCategoryList();
    if (!error) {
      setState((prev: any) => ({ ...prev, courseCategoryList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  const fetchFlyerList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getFlyerList();
    if (!error) {
      console.log(data, 'flyerData');

      if (data?.length) {
        setTimeout(() => {
          setState((prevState: any) => ({
            ...prevState,
            flyerModal: {
              open: true,
              imageUrl: data[0]?.attributes?.media?.data?.attributes?.url,
              redirectLink: data?.attributes?.redirect_link,
              redirectCTALabel: data?.attributes?.redirect_cta_label,
            },
          }));
        }, 2000);
      }
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  const fetchBulletNewsList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getBulletNewsList();
    if (!error) {
      setState((prev: any) => ({
        ...prev,
        bulletNewsList: data,
        newsList: data,
      }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  useEffect(() => {
    fetchCourseCategoryList();
    fetchCourseList();
    fetchEventList();
    fetchFlyerList();
    fetchHomepageData();
    fetchBulletNewsList();
  }, []);

  return (
    <>
      <div>
        <h1 className="sr-only">Home</h1>
        <FlyerModal
          open={state.flyerModal.open}
          imageUrl={state.flyerModal.imageUrl}
          redirectLink={state.flyerModal.redirectLink}
          redirectCTALabel={state.flyerModal.redirectCTALabel}
          setOpen={() =>
            setState((prev: any) => ({
              ...prev,
              flyerModal: defaultState.flyerModal,
            }))
          }
        />
        <HeroSection />
        <SlideStripe bulletNewsList={state.bulletNewsList} />
        {/* <BbsInstituionsH /> */}
        {/* <CoursesH
          courseList={state.courseList}
          courseCategoryList={state.courseCategoryList}
        /> */}
        <FindCourses  courseList={state.courseList}
          courseCategoryList={state.courseCategoryList} />
        <ApplyForH />
        {/* <KeyDiffrentiator/> */}
        {/* <BestUniversity/> */}
        <ChooseExcellence />
         <NewsEventsSection
          newsList={state.newsList}
          eventList={state.eventList}
        />
        <CongractsSection />
        {/* <CollegeVideo
          videoUrl={
            state.homePageData?.attributes?.banner_video?.data?.attributes?.url
          }
        /> */}
         <Innovative />
        <div>
          <LifeAtBBS />
        </div>
           <TestimonialSection />
        <InternationalExposure />
        <BbsGroupInstitutions />
        {/* <InfrastructureSection /> */}
       

    
      </div>
      {/* <SubscribeSection /> */}
    </>
  );
};

export default Home;
