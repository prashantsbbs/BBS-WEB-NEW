import Image from 'next/image';
import 'animate.css';
import { useState } from 'react';
import ScrollTrigger from 'react-scroll-trigger';

const Infrastructure = () => {
  const [animationStart, setAnimationStart] = useState(false);

  const onEnterViewport = () => {
    console.log('onEnterViewport');
    setAnimationStart(true);
  };

  const onExitViewport = () => {
    console.log('onExitViewport');
    setAnimationStart(false);
  };

  return (
    <section className="relative bg-class">
      {/* @ts-ignore */}
      <ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}>
        <div className="flex  justify-between lg:flex-row flex-col lg:items-stretch items-center lg:px-24  p-9  lg:py-16 ">
          <div className="flex  flex-col items-center lg:rotate-[-90deg] rotate-[0] xl:translate-x-[23%] lg:translate-x-[18%] lg:mb-0 mb-10 w-fit">
            <div className="xl:text-4xl sm:text-3xl text-2xl text-whiteCol  lg:mb-7 mb-1	tracking-widest	">
              OUR
            </div>
            <div className="xl:text-8xl sm:text-7xl text-5xl	text-goldColor  great-vibes-regular ">
              Infrastructure
            </div>
          </div>

          {/* Images Section */}
          <div className="flex flex-col  items-center ">
            <div className="flex lg:flex-row flex-col  flex-1">
              <div
                className={`flex flex-1 items-end justify-end ${
                  animationStart
                    ? 'animate__animated animate__fadeInLeft animate__slower'
                    : ''
                }`}
              >
                <Image
                  width={400}
                  height={50}
                  loading="lazy"
                  unoptimized={true}
                  src="/bbsEngineering.webp"
                  alt="BBS Engineering"
                  className="m-2 w-[70%] h-[78%] shadow-xl"
                />
              </div>
              <div
                className={`flex flex-1 items-end justify-start
            ${
              animationStart
                ? 'animate__animated animate__fadeInDown animate__slower'
                : ''
            }`}
              >
                <Image
                  width={400}
                  height={50}
                  unoptimized={true}
                  loading="lazy"
                  src="/bbsProfessionalBanner.webp"
                  alt="BBS Professional Banner"
                  className="m-2 max-w-[83%]"
                />
              </div>
            </div>
            <div
              className={`flex lg:flex-row flex-col flex-1 
          `}
            >
              <div
                className={`flex flex-1 items-start justify-end
            ${
              animationStart
                ? 'animate__animated animate__fadeInUp animate__slower'
                : ''
            }`}
              >
                <Image
                  width={400}
                  height={50}
                  unoptimized={true}
                  loading="lazy"
                  src="/bbsLaw.webp"
                  alt="BBS Law"
                  className="m-2 max-w-[83%]"
                />
              </div>
              <div
                className={`flex flex-1 items- justify-start
            ${
              animationStart
                ? 'animate__animated animate__fadeInRight animate__slower'
                : ''
            }`}
              >
                <Image
                  width={400}
                  unoptimized={true}
                  height={50}
                  loading="lazy"
                  src="/bbs-Pharmacy.webp"
                  alt="BBS Pharmacy"
                  className="m-2  w-[70%] h-[78%]"
                />
              </div>
            </div>
          </div>
        </div>
      </ScrollTrigger>
    </section>
  );
};

export default Infrastructure;
