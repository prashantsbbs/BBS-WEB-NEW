'use client';

import Link from 'next/link';
import Image from 'next/image';

const bestUniversity = [
  {
    title: 'RANKED NO. 1',
    subTitle: 'Educational Leader',
    image: '/home/bestUniversity/ranking.webp',
  },
  {
    title: 'ANTI-RAGGING',
    subTitle: 'Campus',
    image: '/home/bestUniversity/ragging.webp',
  },
  {
    title: 'TIE-UPS WITH',
    subTitle: 'Research Bodies',
    image: '/home/bestUniversity/ties-up.webp',
  },
  {
    title: 'INDUSTRY',
    subTitle: 'Exposure',
    image: '/home/bestUniversity/industry.webp',
  },
  {
    title: '24X7',
    subTitle: 'Secured Campus',
    image: '/home/bestUniversity/24x7-support.webp',
  },
  {
    title: 'MEDICAL',
    subTitle: 'Facilities in Campus',
    image: '/home/bestUniversity/medical.webp',
  },
];

const BestUniversity = () => {
  return (
    <>
      <div className=" bg-cover bestUniversity bg-no-repeat flex relative bg-center justify-center align-middle  bg-whiteCol py-20 ">
        <div className="m-auto md:w-1/2 w-10/12 relative md:left-[15%]">
          <h2 className="text-5xl text-center mb-6">
            Considering Best Institution in Prayagraj?
          </h2>
          <div className="grid md:grid-cols-3   grid-cols-2 gap-2 text-center">
            {bestUniversity.map((list: any, index) => (
              <div key={index}>
                <Image
                  unoptimized={true}
                  src={list.image}
                  width={130}
                  alt="Best University"
                  height={0}
                  className="m-auto mb-3"
                  data-aos="fade-right"
                />
                <h3 className="font-semibold m-0">{list.title}</h3>
                <h5 className="m-0">{list.subTitle}</h5>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default BestUniversity;
