import { useEffect, useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import { Autoplay } from 'swiper/modules';
import Image from 'next/image';
import AppService from '../services';

const hrTestimonials = [
  {
    name: 'Ravina Raghuwanshi',
    position: 'Asia Campus Recruiter - Phillips',
    comment:
      'Outstanding support during campus recruitment, seamlessly guiding candidates toward fulfilling career opportunities.',
    image: '/hrTestimonials/RavinaRaghuwanshi.webp',
  },
  {
    name: 'Arpith Shetty',
    position: 'Talent Acquisition - iOPEX Technologies',
    comment:
      "A vital partner in connecting talent with our organization's vision.",
    image: '/hrTestimonials/ArpithShetty.webp',
  },
  {
    name: 'Amrit Bhasin',
    position: 'Campus Recruiter - British Telecom',
    comment:
      'BBS is preparing top-tier talent to drive innovation and growth in our telecom industry.',
    image: '/hrTestimonials/AmritBhasin.webp',
  },
  {
    name: 'Samar Bhalla',
    position: 'Talent Acquisition - HCL Tech',
    comment: 'College is nurturing tech-savvy candidates.',
    image: '/hrTestimonials/SamarBhalla.webp',
  },
  {
    name: 'Serena Fernandes',
    position: 'Campus Recruiter - Hitachi Energy',
    comment: 'Cultivating future leaders and managers.',
    image: '/hrTestimonials/SerenaFernandes.webp',
  },
];
const StudentTestimonial = [
  {
    id: 1,
    name: 'Shivangi Rai',
    image: 'studentTestimonial/ShivangiRai.webp',
    program: 'B.Tech CSE 4th Year',
    comment:
      "BBS' Corporate Relations and Training Cell delivers industry-oriented guest lectures and training programs.",
  },
  {
    id: 2,
    name: 'Shambhavi Singh',
    image: 'studentTestimonial/ShambhaviSingh.webp',
    program: 'MBA 1st Year',
    comment:
      'Being an MBA student, I am learning a lot from various industrial visits and extracurricular activities.',
  },
  {
    id: 3,
    name: 'Rajan Yadav',
    image: 'studentTestimonial/RajanYadav.webp',
    program: 'B.Tech CSE 2nd Year',
    comment:
      'College provides an open environment to explore and pursue your interests.',
  },
  {
    id: 4,
    name: 'Ritesh Tiwari',
    image: 'studentTestimonial/RiteshTiwari.webp',
    program: 'D.Pharm 1st Year',
    comment:
      'Practical classroom program with educational excursions and healthcare trainings for Pharmacy.',
  },
  {
    id: 5,
    name: 'Aman Yadav',
    image: 'studentTestimonial/AmanYadav.webp',
    program: 'B.Tech ME 3rd Year',
    comment:
      'At BBS, illustrative labs sessions and workshops are defining my engineering skills.',
  },
  {
    id: 6,
    name: 'Riya Ojha',
    image: 'studentTestimonial/RiyaOjha.webp',
    program: 'MBA 2nd Year',
    comment:
      'The placement cell of BBS provides support and guidance throughout the placement process, ensuring maximum opportunities for employment.',
  },
];

const alumniTestimonial = [
  {
    name: 'Varun Kant',
    image: '/alumniTestimonial/VarunKant.webp',
    branch: 'CE',
    batch: '2009-2013',
    comment:
      'From this campus, I got a chance to present a technical model to former President of India, Dr. A. P. J. Abdul Kalam Sir.',
  },
  {
    name: 'Swati Gupta',
    image: '/alumniTestimonial/SwatiGupta.webp',
    branch: 'CSE',
    batch: '2006-2010',
    comment: 'BBS delivers value-based and ethical education.',
  },
  {
    name: 'Brijesh Tripathi',
    image: '/alumniTestimonial/BrijeshTripathi.webp',
    branch: 'ECE',
    batch: '2005-2009',
    comment:
      "Had a great learning experience through BBS' innovative and encouraging environment.",
  },
  {
    name: 'Vikas Pandey',
    image: '/alumniTestimonial/VikasPandey.webp',
    branch: 'EN',
    batch: '2012-2016',
    comment:
      'Supportive staff members in all departments. Especially the Training & Placement Dept.',
  },
  {
    name: 'Akhilesh Tripathi',
    image: '/alumniTestimonial/AkhileshTripathi.webp',
    branch: 'ECE',
    batch: '2003-2007',
    comment:
      'It is through BBS College and its vivid teaching methods, that I got selected as a scientist in Dept. of Atomic Energy - BARC.',
  },
];

const elements = [
  {
    avatar: '/home/congracts-section/student.webp',
    title: 'Kuldeep Gupta',
    placed: 'Present Company Infosys',
    description:
      'It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',
  },
  {
    avatar: '/home/congracts-section/hr.webp',
    title: 'Junaid Husain',
    placed: 'Present Company TCS',
    description:
      'It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',
  },
];


const defaultState = {
  isLoading: false,
  testimonialList: [],
  testimonialCategoryList: [],
  selectedTestimonial: "",
  selectedCategory:"Student Testimonial"
};


const TestimonialSection = () => {
  const [state, setState] = useState(defaultState);
  const [currentElementIndex, setCurrentElementIndex] = useState(0);

  const fetchTestimonialList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getTestimonialList();
    console.log(data, 'ttttttttttttt');

    if (!error) {
      setState((prevState) => ({
        ...prevState,
        testimonialList: data,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };
  const handleSelectedTestimonial = (id) => {
    setState((prevState) => ({ ...prevState, selectedTestimonial: id }));
  };
   const handleSelectedCategory = (category) => {
    setState((prevState) => ({ ...prevState,selectedTestimonial: "", selectedCategory: category }));
  };
  const fetchTestimonialCategoryList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getTestimonialCategoryList();
    if (!error) {
      setState((prevState) => ({
        ...prevState,
        testimonialCategoryList: data,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };
  useEffect(() => {
    
  }, [state.selectedTestimonial]);

  useEffect(() => {
    fetchTestimonialCategoryList();
    fetchTestimonialList();
    const intervalId = setInterval(() => {
      setCurrentElementIndex((prevState) => (prevState + 1) % elements.length);
    }, 2500);
    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className="flex flex-col justify-center gap-16 w-full bg-whiceCol justify-center relative px-16 pb-16">
      <div className="great-vibes-regular pb-20 transform translate-y-14 md:text-7xl text-5xl text-primary  text-center leading-6 relative z-20 tangerine-bold ">
        Testimonial
      </div>
      <div className="grid grid-cols-1 md:grid-cols-[25%_75%] gap-10">
        <div>
          <div className="grid grid-cols-3 gap-1 pb-2">
            {state.testimonialCategoryList.map((category, index) => {
              return (
                <div className='px-4 pb-2' key={index}>
                  {' '}
                  <h5 className={`flex  text-primary leading-tight text-base text-primary font-semibold cursor-pointer`}
                  onClick={() => handleSelectedCategory(category?.attributes?.Category)}>
                    {category?.attributes?.Category?.split(' ')[0]}
                  </h5>
                  {state.selectedCategory === category?.attributes?.Category &&
                  <hr className="border-b-[3px] -mt-1 border-danger  w-16" />}
                  
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-3 gap-3">
            {state.testimonialList.filter(
                (item) =>
                   item?.attributes?.testimonial_category?.data?.attributes
                    ?.Category ===
                  state.selectedCategory
         ).map((element, index) => {
           if (index === 0 && !state.selectedTestimonial) {
            setState((prev)=>({
              ...prev,selectedTestimonial:element?.id
            }))
           }
              return  (
                <div key={index} data-aos="fade-right">
                  <div
                    className={`${state.selectedTestimonial !== element?.id && 'opacity-50'} m-auto animate__animated animate__slideInLeft cursor-pointer`}
                    onClick={() => handleSelectedTestimonial(element.id)}
                  >
                    <Image
                      unoptimized={true}
                      src={element?.attributes?.media?.data?.attributes?.url}
                      width={100}
                      height={100}
                      alt={'testimonial'}
                      className={` rounded-full w-14 h-14`}
                      
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        <div className="grid grid-cols-1">
            {state.testimonialList.filter(
                (item) =>
                   item?.attributes?.testimonial_category?.data?.attributes
                    ?.Category ===
                  state.selectedCategory
         ).map((element, index) => {
            return (
              state.selectedTestimonial === element?.id && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8" key={index}>
                  <div className="flex flex-col gap-2">
                    <h5 className="text-base font-medium text-primary">
                     {element?.attributes?.description}
                    </h5>
                    <div>
                      <h2 className="m-0 text-primary ">{element?.attributes?.name}</h2>
                      <h5 className="mt-0 text-base font-medium text-primary leading-tight">
                       {element?.attributes?.programme}
                      </h5>
                    </div>
                    <div className='flex justify-center rounded-3xl bg-primary px-2 py-1 text-whiteCol font-medium w-full md:w-1/2'>{state.selectedCategory}</div>
                  </div>
                  <Image
                    unoptimized={true}
                    src={element.attributes?.media?.data?.attributes?.url}
                    width={1000}
                    height={1000}
                    alt={'testimonial'}
                    className={`rounded-lg w-80 h-80`}
                  />
                </div>
              )
            );
          })}
        </div>
      </div>
    </div>
    // <div className="relative">
    //   <div className="great-vibes-regular py-6 transform translate-y-14 md:text-7xl text-5xl text-danger  text-center leading-6 relative z-20 tangerine-bold ">
    //     Testimonial
    //   </div>

    //   <div className="flex p-14 gap-6 m-auto w-full">
    //     {/* 1st------------------------------------ */}
    //     <div className="hidden lg:block h-full w-[30%] m-auto">
    //       <h2 className="text-center">
    //         {state.testimonialCategoryList[0]?.attributes?.Category}
    //       </h2>
    //       <Swiper
    //         cssMode={true}
    //         autoplay={{
    //           delay: 2500,
    //           disableOnInteraction: false,
    //         }}
    //         loop={true}
    //         modules={[Autoplay]}
    //         className=" "
    //       >
    //         {state.testimonialList
    //           .filter(
    //             (item) =>
    //               item?.attributes?.testimonial_category?.data?.attributes
    //                 ?.Category ===
    //               state.testimonialCategoryList[0]?.attributes?.Category
    //           )
    //           .map((slide, index) => (
    //             <SwiperSlide className="" key={index}>
    //               <div
    //                 style={{
    //                   backgroundImage: `url(${slide?.attributes?.media?.data?.attributes?.url})`,
    //                 }}
    //                 className="bg-cover bg-no-repeat w-40 h-40 rounded-full relative bg-center m-auto
    //           border-4 drop-shadow-xl border-whiteCol z-30 -mb-5 "
    //               ></div>
    //               <div className="relative rounded-3xl bg-primary text-white h-min lg:min-h-[230px] md:min-h-[170px] md:px-10 px-8 py-8  mx-auto my-auto">
    //                 <h2 className="m-0 text-secondary">
    //                   {slide?.attributes?.name}
    //                 </h2>
    //                 <h5 className="m-0 mb-2 text-whiteCol">
    //                   {slide?.attributes?.programme}
    //                 </h5>
    //                 <h5 className="m-0 text-justify text-whiteCol">
    //                   {slide?.attributes?.description}
    //                 </h5>
    //               </div>
    //             </SwiperSlide>
    //           ))}
    //       </Swiper>
    //     </div>

    //     {/* 2nd------------------------------------ */}
    //     <div className="h-full lg:w-[30%] md:w-[45%] w-[90%] m-auto ">
    //       <h2 className="text-center">
    //         {state.testimonialCategoryList[1]?.attributes?.Category}
    //       </h2>
    //       <Swiper
    //         cssMode={true}
    //         autoplay={{
    //           delay: 2500,
    //           disableOnInteraction: false,
    //         }}
    //         loop={true}
    //         modules={[Autoplay]}
    //         className=" "
    //       >
    //         {state.testimonialList
    //           .filter(
    //             (item) =>
    //               item?.attributes?.testimonial_category?.data?.attributes
    //                 ?.Category ===
    //               state.testimonialCategoryList[1]?.attributes?.Category
    //           )
    //           .map((slide, index) => (
    //             <SwiperSlide className="" key={index}>
    //               <div
    //                 style={{
    //                   backgroundImage: `url(${slide?.attributes?.media?.data?.attributes?.url})`,
    //                 }}
    //                 className="bg-cover bg-no-repeat w-40 h-40 rounded-full relative bg-center m-auto
    //           border-4 drop-shadow-xl border-whiteCol z-30 -mb-5 "
    //               ></div>
    //               <div className="relative rounded-3xl bg-primary text-white  lg:min-h-[230px]  min-h-[170px] md:px-10 px-8 py-8  mx-auto my-auto">
    //                 <h2 className="m-0 text-secondary">
    //                   {slide?.attributes?.name}
    //                 </h2>
    //                 <h5 className="m-0 mb-2 text-whiteCol">
    //                   {slide?.attributes?.programme}
    //                 </h5>
    //                 <h5 className="m-0 text-justify text-whiteCol">
    //                   {slide?.attributes?.description}
    //                 </h5>
    //               </div>
    //             </SwiperSlide>
    //           ))}
    //       </Swiper>
    //     </div>

    //     {/* 3rd------------------------------------ */}
    //     <div className="hidden md:block   h-full lg:w-[30%] md:w-[45%] m-auto ">
    //       <h2 className="text-center">
    //         {state.testimonialCategoryList[2]?.attributes?.Category}
    //       </h2>

    //       <Swiper
    //         cssMode={true}
    //         autoplay={{
    //           delay: 2500,
    //           disableOnInteraction: false,
    //         }}
    //         loop={true}
    //         modules={[Autoplay]}
    //         className=" "
    //       >
    //         {state.testimonialList
    //           .filter(
    //             (item) =>
    //               item?.attributes?.testimonial_category?.data?.attributes
    //                 ?.Category ===
    //               state.testimonialCategoryList[2]?.attributes?.Category
    //           )
    //           .map((slide, index) => (
    //             <SwiperSlide className="" key={index}>
    //               <div
    //                 style={{
    //                   backgroundImage: `url(${slide?.attributes?.media?.data?.attributes?.url})`,
    //                 }}
    //                 className="bg-cover bg-no-repeat w-40 h-40 rounded-full relative bg-center m-auto
    //           border-4 drop-shadow-xl border-whiteCol z-30 -mb-5 "
    //               ></div>
    //               <div className="relative rounded-3xl bg-primary text-white h-min lg:min-h-[230px] md:min-h-[170px]  md:px-10 px-8 py-8  mx-auto my-auto">
    //                 <h2 className="m-0 text-secondary">
    //                   {slide?.attributes?.name}
    //                 </h2>
    //                 <h5 className="m-0 mb-2 text-whiteCol">
    //                   {slide?.attributes?.programme}
    //                 </h5>
    //                 <h5 className="m-0 mb-2 text-secondary ">
    //                   {slide?.attributes?.batch}
    //                 </h5>
    //                 <h5 className="m-0 text-justify text-whiteCol">
    //                   {slide?.attributes?.description}
    //                 </h5>
    //               </div>
    //             </SwiperSlide>
    //           ))}
    //       </Swiper>
    //     </div>
    //   </div>
    //   <div className="w-full h-48   absolute bottom-0 left-0  bg-danger"></div>
    // </div>
  );
};

export default TestimonialSection;
