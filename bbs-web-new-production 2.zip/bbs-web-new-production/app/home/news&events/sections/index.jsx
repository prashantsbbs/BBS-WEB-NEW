import Link from "next/link";
import { useRef } from "react";

const Sections = ({ Component, title, Tag = "div", width, height }) => {
  const marqueeRef = useRef(null);

  const handleMouseOver = () => {
    marqueeRef.current.stop();
  };
  const handleMouseOut = () => {
    marqueeRef.current.start();
  };
  return (
    <>
      {/* <div
        className={`w-full md:${width} sm:w-[70%]  sm:mx-auto flex flex-col rounded-lg`}
      > */}
      <div
        className={`w-full md:${width}  sm:mx-auto flex flex-col rounded-lg`}
      >
        {title ==="Events" ? <h2 className="text-start text-5xl text-primary"> Events</h2>:<p className="md:text-4xl text-3xl font-bold text-center mb-6">
          {title}
        </p>}
        
        <Tag
          className={`flex-grow rounded-lg p-6 ${height} bg-whiteCol`}
          style={{
            boxShadow: "0 0 7px rgba(0, 0, 0, 0.16)",
          }}
          {...(Tag === "marquee" && {
            direction: "down",
            loop: "",
            ref: marqueeRef,
          })}
          onMouseOver={Tag === "marquee" ? handleMouseOver : undefined}
          onMouseOut={Tag === "marquee" ? handleMouseOut : undefined}
        >
          <Component />
        </Tag>
        {/* {Tag === "marquee" && (
          <Link href={'/news'}>
          <p className="cursor-pointer mt-3 border-b hover:border-white md:w-fit  mx-auto">
            See All News
          </p>
          
          </Link>
        )} */}
      </div>
    </>
  );
};

export default Sections;
