import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/pagination';
import {
  Navigation,
  Autoplay,
  Pagination,
  Mousewheel,
  Keyboard,
} from 'swiper/modules';
import ButtonCustom from '../../../../common/button';
import Image from 'next/image';
import { eventData } from '@/app/constant/eventData';
import { useEffect, useRef } from 'react';
import { useState } from 'react';
import Link from 'next/link';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const Events = ({ eventList = [] }) => {
  const defaultState = {
    latestData: [{}],
    onlyDate: '',
  };

  const [state, setState] = useState(defaultState);
    const swiperRef = useRef(null);
    const prevRef = useRef(null);
    const nextRef = useRef(null);

  useEffect(() => {
    let updateData = eventData.map((data) => {
      const onlyDate = new Date(data.date);
      data.onlyDate = onlyDate.toDateString();
      return data;
    });

    setState((prev) => ({ ...prev, latestData: updateData }));
  }, []);

  return (
    <div className="grid grid-cols-1 gap-2 px-10 md:px-20">
      <div className="flex justify-between items-center">
        <h2 className="text-start text-3xl md:text-5xl  text-primary"> Events</h2>
        <div className="flex justify-center gap-4 mt-4">
          <button
            onClick={() => swiperRef.current?.slidePrev()}
            className="bg-primary text-white p-1 rounded-md"
          >
            <ChevronLeft className="w-8 h-8 text-whiteCol" />
          </button>

          <button
            onClick={() => swiperRef.current?.slideNext()}
            className="bg-primary text-white p-1 rounded-md"
          >
            <ChevronRight className="w-8 h-8 text-whiteCol" />
          </button>
        </div>
      </div>

      <Swiper
        loop={true}
        autoplay={{
          delay: 2500,
          disableOnInteraction: false,
        }}
        slidesPerView={1}
        spaceBetween={10}
        pagination={{
          clickable: true,
        }}
        breakpoints={{
          600: {
            slidesPerView: 1,
            spaceBetween: 20,
          },
          694: {
            slidesPerView: 1,
            spaceBetween: 20,
          },
          772: {
            slidesPerView: 1,
            spaceBetween: 20,
          },
          920: {
            slidesPerView: 2,
            spaceBetween: 40,
          },
          1024: {
            slidesPerView: 2,
            spaceBetween: 50,
          },
        }}
         navigation={{
            prevEl: prevRef.current,
            nextEl: nextRef.current,
          }}
          speed={3000}
          onBeforeInit={(swiper) => {
            if (typeof swiper.params.navigation !== 'boolean') {
              swiper.params.navigation = {
                ...(swiper.params.navigation || {}),
                prevEl: prevRef.current,
                nextEl: nextRef.current,
              };
            }
          }}
       modules={[Navigation, Pagination, Mousewheel, Autoplay, Keyboard]}
        className="mySwiper news-swiper"
         onSwiper={(swiper) => {
            swiperRef.current = swiper;
          }}
      >
        {eventList.map((elements, id) => (
          <SwiperSlide
            key={id}
            className="rounded-2xl border-2 border-[#a8a7a7] border-opacity-30"
          >
            <div
              key={id}
              className="grid grid-cols-1 md:grid-cols-3 md:grid-rows-2 grid-rows-4 bg-whiteCol rounded-xl md:h-36 shadow-md overflow-hidden w-full"
            >
              {/* Date Box */}
              <div className="-py-2 col-span-1 row-span-2 text-whiteCol flex flex-col items-center justify-center h-full  min-w-[120px] ">
                <Image
                  unoptimized={true}
                  width={300}
                  height={50}
                  loading="lazy"
                  src={elements?.attributes?.media?.data?.attributes?.url || ''}
                  alt="Events"
                  className="rounded-xl shadow-lg swiper-img"
                  style={{ height: '25vh', width: '100%' }}
                />
                {/* <div className="text-2xl font-bold text-nowrap">08</div>
                <div className="text-sm text-nowrap">Nov 2022</div> */}
              </div>

              {/* Content */}
              <div className="pb-2 px-4 col-span-2 row-span-2  flex flex-col justify-between">
                <h3 className="text-start text-xl font-semibold text-primary  line-clamp-1 leading-tight">
                  {elements?.attributes?.title}
                </h3>
                 <p className="text-sm -mt-3 leading-4 text-justify line-clamp-3 text-gradientR">
              {elements?.attributes?.description}
            </p>
                
                <div className="flex justify-between gap-2 items-center w-full">
                   <p className="text-xs  font-medium text-center sm:leading-6 leading-5 text-neutral-400 text-nowrap text-gradientR">
                {elements?.attributes?.date
                  ? new Date(elements?.attributes?.date).toDateString()
                  : '-'}
              </p>
                  <Link href={`/events/${elements.id}`}>
                    <ButtonCustom
                      target="_blank"
                      btnColor="primary"
                      textCol="whiteCol"
                      btnText="Know More"
                      btnHeight='9'
                      btnWidth='40'
                    />
                  </Link>
                </div>
              </div>

              {/* <div className="flex justify-between md:py-2 py-1">
              <p className="text-xs text-center sm:leading-6 leading-5 text-neutral-400">
                Category : {elements?.attributes?.category}
              </p>
              <p className="text-xs text-center sm:leading-6 leading-5 text-neutral-400">
                {elements?.attributes?.date
                  ? new Date(elements?.attributes?.date).toDateString()
                  : '-'}
              </p>
            </div>
            <div className="sm:text-xl text-lg text-center font-medium sm:py-1 py-4">
              {elements?.attributes?.title}
            </div>
            <p className="text-sm leading-4 text-justify">
              {elements?.attributes?.description}
            </p>
            <div className="mt-4">
              <Link href={`/events/${elements.id}`}>
                <ButtonCustom
                  btnColor="primary"
                  btnText="Read More"
                  textCol="whiteCol"
                />
              </Link>
            </div> */}
            </div>

            {/* <div key={id} className="p-5">
            <Image
              unoptimized={true}
              width={300}
              height={50}
              loading="lazy"
              src={elements?.attributes?.media?.data?.attributes?.url || ''}
              alt="Events"
              className="rounded-xl shadow-lg swiper-img"
              style={{ height: '17vh', width: '100%' }}
            />
            <div className="flex justify-between md:py-2 py-1">
              <p className="text-xs text-center sm:leading-6 leading-5 text-neutral-400">
                Category : {elements?.attributes?.category}
              </p>
              <p className="text-xs text-center sm:leading-6 leading-5 text-neutral-400">
                {elements?.attributes?.date
                  ? new Date(elements?.attributes?.date).toDateString()
                  : '-'}
              </p>
            </div>
            <div className="sm:text-xl text-lg text-center font-medium sm:py-1 py-4">
              {elements?.attributes?.title}
            </div>
            <p className="text-sm leading-4 text-justify">
              {elements?.attributes?.description}
            </p>
            <div className="mt-4">
              <Link href={`/events/${elements.id}`}>
                <ButtonCustom
                  btnColor="primary"
                  btnText="Read More"
                  textCol="whiteCol"
                />
              </Link>
            </div>
          </div> */}
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
};

export default Events;
