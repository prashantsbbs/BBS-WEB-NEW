'use client';
import Link from 'next/link';

import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/pagination';
import {
  Navigation,
  Autoplay,
  Pagination,
  Mousewheel,
  Keyboard,
} from 'swiper/modules';
import ButtonCustom from '../../../../common/button';
import Image from 'next/image';
import { eventData } from '@/app/constant/eventData';
import { useEffect, useRef } from 'react';
import { useState } from 'react';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';

const News = ({ handleMouseOver, handleMouseOut, newsList = [] }) => {
  const swiperRef = useRef(null);
  const prevRef = useRef(null);
  const nextRef = useRef(null);

  return (
    <>
     <div className={`bg-[url('/home/newsBg.webp')] px-10 md:px20  md:bg-cover  relative pt-16 pb-24   bg-no-repeat  bg-center flex justify-center  items-center`}>
      <div className="grid grid-cols-1 gap-2 md:h-72">
        <div className="flex justify-between items-center h-full">
          <h2 className="text-start text-3xl md:text-5xl text-whiteCol text-nowrap">
            {' '}
            Latest News
          </h2>
          <div className="flex justify-center gap-4 mt-4 ">
            <button
              onClick={() => swiperRef.current?.slidePrev()}
              className="bg-primary text-white p-1 rounded-md"
            >
              <ChevronLeft className="w-8 h-8 text-whiteCol" />
            </button>

            <button
              onClick={() => swiperRef.current?.slideNext()}
              className="bg-primary text-white p-1 rounded-md"
            >
              <ChevronRight className="w-8 h-8 text-whiteCol" />
            </button>
          </div>
        </div>

        <Swiper
          loop={true}
          autoplay={{
            delay: 2500,
            disableOnInteraction: false,
          }}
          slidesPerView={1}
          spaceBetween={10}
          pagination={{
            clickable: true,
          }}
          breakpoints={{
            600: {
              slidesPerView: 1,
              spaceBetween: 20,
            },
            694: {
              slidesPerView: 1,
              spaceBetween: 20,
            },
            772: {
              slidesPerView: 1,
              spaceBetween: 20,
            },
            920: {
              slidesPerView: 2,
              spaceBetween: 40,
            },
            1024: {
              slidesPerView: 2,
              spaceBetween: 50,
            },
          }}
          navigation={{
            prevEl: prevRef.current,
            nextEl: nextRef.current,
          }}
          speed={3000}
          onBeforeInit={(swiper) => {
            if (typeof swiper.params.navigation !== 'boolean') {
              swiper.params.navigation = {
                ...(swiper.params.navigation || {}),
                prevEl: prevRef.current,
                nextEl: nextRef.current,
              };
            }
          }}
          modules={[Navigation, Pagination, Mousewheel, Autoplay, Keyboard]}
          className="mySwiper news-swiper"
          onSwiper={(swiper) => {
            swiperRef.current = swiper;
          }}
        >
          {newsList.map((elements, index) => (
            <SwiperSlide
              key={index}
              className="rounded-2xl h-full border-2 border-[#a8a7a7] border-opacity-30"
            >
              <div
                key={index}
                className="flex bg-whiteCol rounded-xl shadow-md overflow-hidden w-full h-40 md:h-full"
              >
                {/* Date Box */}
                <div className="bg-danger text-whiteCol flex flex-col items-center justify-center px-4 py-2 min-w-[120px] ">
                  <p className="text-xs md:text-sm font-medium text-center sm:leading-6 leading-5 text-neutral-400 text-nowrap text-seaGreen"></p>
                  <Calendar className="w-4 h-4" />
                  <div className="text-2xl
                   font-bold text-nowrap">
                    {elements?.attributes?.publishedAt
                      ? new Date(
                          elements?.attributes?.publishedAt,
                        ).toLocaleDateString('en-GB', { day: '2-digit' })
                      : '-'}
                  </div>
                  <div className="text-sm text-nowrap">
                    {elements?.attributes?.publishedAt
                      ? new Date(
                          elements?.attributes?.publishedAt,
                        ).toLocaleDateString('en-GB', {
                          month: 'short',
                          year: 'numeric',
                        })
                      : '-'}
                  </div>
                </div>

                {/* Content */}
                <div className="py-3 px-4 flex flex-col justify-between">
                  <h3 className="text-lg md:text-xl font-semibold text-primary text-start  ">
                    {elements?.attributes?.Title}
                  </h3>
                  <Link
                    href={elements?.attributes?.File?.data[0]?.attributes?.url}
                  >
                    <ButtonCustom
                      target="_blank"
                      btnColor="primary"
                      textCol="whiteCol"
                      btnText="Know More"
                      btnHeight="9"
                      btnWidth="40"
                    />
                  </Link>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
      </div>
    </>
  );
};

export default News;

// const News = ({ handleMouseOver, handleMouseOut, newsList = [] }) => {
//   return (
//     <>
//       {newsList.map((elements, index) => (
//         <div className="rounded-xl text-center my-auto mx-auto " key={index}>
//           <div
//             className="text-lg border-b cursor-pointer"
//             onMouseOver={handleMouseOver}
//             onMouseOut={handleMouseOut}
//           >
//             <h3 className="font-semibold hover:text-pink">
//               <Link
//                 target="_blank"
//                 href={elements?.attributes?.File?.data[0]?.attributes?.url}
//               >
//                 {elements?.attributes?.Title}
//               </Link>
//             </h3>
//           </div>
//         </div>
//       ))}
//     </>
//   );
// };

// export default News;
