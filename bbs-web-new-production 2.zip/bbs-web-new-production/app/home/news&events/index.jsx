import Events from "./sections/events/index.jsx";
import News from "./sections/news/index.jsx";

import Sections from "./sections/index.jsx";

const NewsEventsSection = ({
  newsList = [],
  eventList = []
}) => {
  return (
    // <div className={`bg-[url('/home/futureReadyBg.webp')]  md:bg-cover  relative px-6  py-8   bg-no-repeat  bg-center flex justify-center  items-center`}>
       <div className={`relative  pb-8   bg-no-repeat  bg-center flex justify-center  items-center`}>
      <div className="grid grid-cols-1 sm:gap-14 gap-10  md:flex-row w-full  pb-8"> 
      <News newsList={newsList} />
      <Events eventList={eventList} />
        {/* <Sections
          Component={() => <Events eventList={eventList} />}
          title={"Events"}
          width={"w-full"}
          height={null}
        /> */}
          {/* <Sections
          Component={() => <News newsList={newsList} />}
          title={"News"}
          width={"w-full"}
          Tag={"marquee"}
          height={"h-[20vh]"}
        /> */}
      
      </div>
    </div>
  );
};

export default NewsEventsSection;
