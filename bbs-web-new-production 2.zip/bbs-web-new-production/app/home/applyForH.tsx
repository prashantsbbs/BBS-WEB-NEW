'use client';

import Image from 'next/image';
import { applyForHomePage } from '../constant/constant';
import ButtonCustom from '../common/button';
import 'animate.css';
import Link from 'next/link';
import { useState } from 'react';
import ScrollTrigger from 'react-scroll-trigger';

const ApplyForH = () => {
  const [animationStart, setAnimationStart] = useState(false);

  const onEnterViewport = () => {
    console.log('onEnterViewport');
    setAnimationStart(true);
  };

  const onExitViewport = () => {
    console.log('onExitViewport');
    setAnimationStart(false);
  };

  return (
    <>
      {/* @ts-ignore */}
<ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}>
  {/* <section className="py-20 px-6 md:px-16 bg-whiteCol"> */}
  <section className={`bg-[url('/home/applyFor/applyForBg.webp')] bg-content md:bg-cover  relative py-20 px-6 md:px-16 md:min-h-[460px] md:max-h-[460px]  bg-no-repeat  bg-center`}>

  {/* Heading */}
  <div className="text-center mb-12">
    <h2 className="text-4xl text-whiteCol font-bold mb-4 tracking-wide">
      Apply for Admission 2026
    </h2>
    <p className=" text-whiteCol text-lg">
      Discover the admission process and begin your journey with BBS.
    </p>
  </div>

  {/* Cards */}
  <div className="grid lg:grid-cols-4 px-4 sm:px-1 md:grid-cols-2 grid-cols-1 gap-10">

    {/* Admission */}
    <Link href="/admission-precedure" className="group w-full">
      <div className="relative w-full">

        <div className="absolute rounded-sm top-1 left-1 w-full h-full bg-seaGreen"></div>

        <div className="flex justify-center items-center relative w-full rounded-sm bg-whiteCol border border-gray-300 px-10 py-8 text-center font-semibold text-lg text-primary transition-transform duration-300 group-hover:-translate-y-1 text-nowrap">
          Admission Procedure
        </div>

      </div>
    </Link>


    {/* Eligibility */}
    <Link href="/eligibility-criteria" className="group w-full">
      <div className="relative w-full">

        <div className="absolute top-1 left-1 rounded-sm  w-full h-full bg-seaGreen"></div>

        <div className="flex justify-center items-center relative w-full rounded-sm bg-whiteCol border border-gray-300 px-10 py-8 text-center font-semibold text-lg text-primary transition-transform duration-300 group-hover:-translate-y-1 text-nowrap">
          Eligibility Criteria
        </div>

      </div>
    </Link>


    {/* Fee */}
    <Link href="https://erp.bbs.ac.in/pay/index.php" className="group w-full">
      <div className="relative w-full">

        <div className="absolute top-1 left-1 rounded-sm  w-full h-full bg-seaGreen"></div>

        <div className="flex justify-center items-center  relative w-full rounded-sm bg-whiteCol border border-gray-300 px-10 py-8 text-center font-semibold text-lg text-primary transition-transform duration-300 group-hover:-translate-y-1 text-nowrap">
          Fee Payment
        </div>

      </div>
    </Link>


    {/* Apply */}
    <Link href="/apply-online" className="group w-full">
      <div className="relative w-full">

        <div className="absolute top-1 left-1  w-full h-full bg-seaGreen"></div>

        <div className=" flex justify-center items-center relative w-full bg-whiteCol border border-gray-300 px-10 py-8 text-center font-semibold text-lg text-primary transition-transform duration-300 group-hover:-translate-y-1 text-nowrap">
          Apply Online
        </div>

      </div>
    </Link>

  </div>

</section>
</ScrollTrigger>
      {/* <ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}>
        {applyForHomePage.map((image: any, index: number) => (
          <div
            key={index}
            className={`bg-[url('/home/applyFor/apply.webp')] applyForImage relative`}
          >
            <div className=" absolute top-0 left-0   ">
              <Image
                unoptimized={true}
                src={'/home/applyFor/applySideImage.webp'}
                width={700}
                height={0}
                alt="Apply Side Image"
                loading="lazy"
                className="tlitImage h-fit	"
              />
            </div>
            <div
              className={`relative md:p-20 sm:p-10 p-8 lg:w-2/5 md:w-3/5 w-4/5
          ${
            animationStart
              ? 'animate__animated animate__fadeInLeft animate__slower'
              : ''
          }`}
            >
              <h2 className="text-2xl  text-whiteCol pb-6 ">
                Apply for admission 2026 at BBS Group of Institutions
              </h2>

              <div className="my-2">
                <Link
                  href={'/admission-precedure'}
                  className="my-2 text-whiteCol underline underline-offset-2 hover:text-secondary"
                >
                  Admission Procedure
                </Link>
              </div>

              <div className="my-2">
                <Link
                  href={'/eligibility-criteria'}
                  className="my-2 text-whiteCol underline underline-offset-2 hover:text-secondary"
                >
                  Eligibility Criteria
                </Link>
              </div>

              <div className="my-2">
                <Link
                  href={'https://erp.bbs.ac.in/pay/index.php'}
                  className="my-2 text-whiteCol underline underline-offset-2 hover:text-secondary"
                >
                  Fee Payment
                </Link>
              </div>

              <div className="my-6">
                <Link href={'apply-online'} className="my-2">
                  <ButtonCustom
                    btnColor={'secondary'}
                    textCol={'black'}
                    btnText={'Apply Online'}
                  />
                </Link>
              </div>
            </div>
          </div>
        ))}
      </ScrollTrigger> */}
    </>
  );
};

export default ApplyForH;
