'use client';
import Image from 'next/image';
import ButtonCustom from '../common/button';
import { innovative } from '../constant/constant';
import { useState } from 'react';
import ScrollTrigger from 'react-scroll-trigger';
import 'animate.css';
import Link from 'next/link';

const Innovative = () => {
  return (
    <div className='grid grid-cols-1 sm:grid-cols-3 gap-4 p-12 md:p-16 bg-whiteCol' >
    
    {innovative.map((section: any, index: number) => (
      <div className='grid grid-cols-1' data-aos="fade-right" key={index}>
   <div
      className={`relative ${
        section.id === 2 ? "md:order-2" : "md:order-1"
      }`}
      data-aos="fade-up"
    >
      <Image
        src={section.image}
        alt="Innovative"
        width={900}
        height={600}
        className="w-full h-[320px] object-cover shadow-xl"
        // data-aos="zoom-in"
      />
 
       {/* CONTENT */}
    <div
      className={`${
        section.id === 2 ? "md:order-1" : "md:order-2"
      }`}
    >
      <div
        
        className="bg-gradient-to-br from-yellow-400 to-yellow-500 p-4 rounded-b-2xl shadow-xl max-w-xl bg-danger1 md:h-[380px] overflow-y-auto"
      >
        <h2 className="text-2xl font-semibold mb-4 text-primary tracking-wide">
          {section.title}
        </h2>

        <p className="text-gray-800 leading-relaxed mb-6 text-justify text-primary">
          {section.subTitle}
        </p>

        <Link href={section.link}>
          <ButtonCustom />
        </Link>
      </div>
    </div>
      </div>   </div>
  // <div
  //   key={index}
  //   className="grid md:grid-cols-2 gap-10 items-center py-16 px-6 md:px-16 bg-whiteCol"
  // >
  //   {/* IMAGE */}
  //   <div
  //     className={`relative ${
  //       section.id === 2 ? "md:order-2" : "md:order-1"
  //     }`}
  //   >
  //     <Image
  //       src={section.image}
  //       alt="Innovative"
  //       width={900}
  //       height={600}
  //       className="w-full h-[420px] object-cover rounded-2xl shadow-xl"
  //       data-aos="zoom-in"
  //     />
  //   </div>

  //   {/* CONTENT */}
  //   <div
  //     className={`${
  //       section.id === 2 ? "md:order-1" : "md:order-2"
  //     }`}
  //   >
  //     <div
  //       data-aos="fade-up"
  //       className="bg-gradient-to-br from-yellow-400 to-yellow-500 p-10 rounded-2xl shadow-xl max-w-xl"
  //     >
  //       <h2 className="text-3xl font-bold mb-4 text-black">
  //         {section.title}
  //       </h2>

  //       <p className="text-gray-800 leading-relaxed mb-6 text-justify">
  //         {section.subTitle}
  //       </p>

  //       <Link href={section.link}>
  //         <ButtonCustom />
  //       </Link>
  //     </div>
  //   </div>
  // </div>
))}
      {/* {innovative.map((section: any, index: number) => (
        <div
          key={index}
          className=" h-3/4 bg-whiteCol grid md:grid-cols-2 grid-cols-1"
        >
          {section.id === 2 ? (
            <>
              <div
                className={`flex order-2 md:order-1 h-[500px] m-auto  items-center justify-end
            `}
              >
                <div
                  data-aos="fade-right"
                  className={`  bg-secondary h-3/4 sm:w-3/4 w-11/12 rounded-l-2xl p-6  flex items-center`}
                >
                  <div>
                    <h2 className="lg:text-3xl text-2xl  ">{section.title}</h2>
                    <h4 className=" text-justify">{section.subTitle}</h4>
                    <div>
                      <Link href={section.link}>
                        <ButtonCustom />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>

              <Image
                unoptimized={true}
                src={section.image}
                width={1000}
                alt="Innovative Image"
                height={0}
                data-aos="fade-up"
                data-aos-duration="3000"
                className="bgImage order-1 md:order-0"
              />
            </>
          ) : (
            <>
              <Image
                unoptimized={true}
                data-aos="fade-up"
                data-aos-duration="3000"
                src={section.image}
                width={1000}
                alt="Innovative"
                height={0}
                className="bgImage order-1 md:order-0 order-1 md:order-0"
              />
              <div className=" flex order-2 md:order-0 h-[500px] m-auto  items-center ">
                <div
                  data-aos="fade-right"
                  className={`    bg-secondary h-3/4 sm:w-3/4 w-11/12 rounded-r-2xl p-3 px-4  flex items-center`}
                >
                  <div className={``}>
                    <h2 className="lg:text-3xl text-2xl  ">{section.title}</h2>
                    <h4 className="  text-justify">{section.subTitle}</h4>
                    <div>
                      <Link href={section.link}>
                        <ButtonCustom />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      ))} */}
    </div>
  );
};

export default Innovative;
