'use client';

import Link from 'next/link';
import { newsData } from '../constant/newsData';

const SlideStrip = ({ bulletNewsList = [] }) => {
  return (
    <>
      <div className="bg-primary-new-light">
        <marquee direction="left">
          <div className="flex gap-16 ">
            {bulletNewsList
              .filter((list) => list.attributes.Active)
              .map((list) => (
                <Link
                  key={list.id}
                  href={
                    list.attributes?.File?.data?.[0]?.attributes?.url || '#'
                  }
                  target="_blank"
                >
                  <h3 className="font-bold text-whiteCol flex items-center">
                    {list.attributes.Title}
                  </h3>
                </Link>
              ))}
          </div>
        </marquee>
      </div>
    </>
  );
};
export default SlideStrip;
