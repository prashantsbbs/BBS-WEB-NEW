import ButtonCustom from '../common/button';
import ScrollTrigger from 'react-scroll-trigger';
import { useState } from 'react';
import Link from 'next/link';

const SubscribeSection = () => {
  const [counterStart, setCounterStart] = useState(false);

  const onEnterViewport = () => {
    console.log('onEnterViewport');
    setCounterStart(true);
  };

  const onExitViewport = () => {
    console.log('onExitViewport');
    setCounterStart(false);
  };

  return (
    <section className=" shadow-[0_35px_60px_-05px_rgba(0,0,0,0.8)] flex lg:h-[400px] md:h-[350px]  h-screen justify-center md:items-center  subscribeImg md:justify-between lg:pl-32  md:p-16 px-16 pt-16     ">
      {/* @ts-ignore */}
      <ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}>
        <div
          className={`md:w-1/3 sm:w-2/3  w-full md:text-left text-center
      ${
        counterStart
          ? 'animate__animated animate__fadeInLeft animate__slower'
          : ''
      }`}
        >
          <h2 className=" md:text-3xl text-2xl  text-dark-blue mb-2 mt-2">
            Blogs @ BBS Group of Institutions
          </h2>
          <div className={``}>
            <h4 className="mb-4 mt-4 text-justify">
              Our blog brings you valuable knowledge to inspire, inform, and
              empower you. Stay connected with fresh content designed to keep
              you ahead.
            </h4>
            <Link href={'/blogs'}>
              <ButtonCustom
                btnColor="primary"
                btnText="Blogs"
                textCol="whiteCol"
              />
            </Link>
          </div>
        </div>
      </ScrollTrigger>
    </section>
  );
};

export default SubscribeSection;
