'use client';
import Link from 'next/link';
import { CircleArrowRight, HeartPulse, Trophy, FlaskConical } from "lucide-react";
const LifeAtBBS = () => {

  const facilities=[
    [{id:1,
      name:"Academic Facilities",
      link:"/academic-facilities/lecture-theater"
    },
     {id:2,
      name:"Medical Facilities",
      link:"/campus-facilities/medical-facilities'"
    },
     {id:3,
      name:"Sport Facilities",
      link:"/sports-facility/sports-ground"
    }],
     [{id:4,
      name:"Other Facilities",
      link:"/academic-facilities/laboratories"
    },
     {id:5,
      name:"Transport Facility",
      link:"/campus-facilities/transport-facility"
    },
     {id:6,
      name:"Campus Facility",
      link:"/campus-facilities/hostel"
    }],
     [{id:7,
      name:"Cafeteria",
      link:"/campus-facilities/cafeteria"
    },
     {id:8,
      name:"Sports Ground",
      link:"/sports-facility/sports-ground"
    },
     {id:4,
      name:"Gym",
      link:"/campus-facilities/gym"}]

  ]
  return (
    <>
<div className=" bg-cover lifeBBS bg-no-repeat  relative bg-center justify-center  md:h-[520px] flex p-6 md:p-16">
  
  <div className="w-10/12 md:w-[80%]">

    <h2 className="text-5xl text-whiteCol  text-center font-bold mb-10">
      Life @ BBS
    </h2>

<div className="grid grid-rows-1 w-full gap-4 text-whiteCol">
<div className="grid md:grid-cols-3 w-full gap-4">
  {facilities.map((item: any, index: number) => {
    return (
      <div key={index} className="grid md:grid-cols-1 gap-2 p-3 bg-[#00000080] rounded-lg" data-aos="fade-right">
        {item.map((facility: any, index: number) => {
          return (
            <Link
              key={index}
              href={facility.link}
            >
              <div
                className="bg-primary  px-6 relative rounded-lg overflow-hidden shadow-lg transition-all duration-500 group flex items-center gap-3"
                
              >
                <div className="bg-[#00000060] group-hover:bg-danger transition-all duration-500 absolute h-full w-[0%] group-hover:w-full top-0 left-0"></div>

                <div className="flex items-center gap-3 relative z-20">
                  <CircleArrowRight
                    className="transition-all duration-500 group-hover:scale-125 group-hover:rotate-6"
                    size={24}
                  />

                  <h2 className="text-base md:text-lg text-nowrap text-start w-full font-medium tracking-wide">
                    {facility.name}
                  </h2>
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    );
  })}
</div> 

    

     

     

    </div>


    {/* <div className="grid md:grid-cols-2 grid-cols-1 gap-4 text-whiteCol">

      <Link href={'/academic-facilities/lecture-theater'}>
        <div className="bg-pink py-4 px-3 relative rounded-xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 group flex items-center gap-3"
          data-aos="fade-right">

          <div className="bg-[#00000060] group-hover:bg-primary transition-all duration-500 absolute h-full w-[15%] group-hover:w-full top-0 left-0"></div>

          <GraduationCap className="relative z-20 transition-all duration-500 group-hover:scale-125 group-hover:rotate-6" size={28} />

          <h2 className="text-xl md:text-3xl text-nowrap relative z-20 text-center w-full font-semibold">
            Academic Facilities
          </h2>

        </div>
      </Link>

      <Link href={'/campus-facilities/medical-facilities'}>
        <div className="bg-seaGreen py-4 px-3 relative rounded-xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 group flex items-center gap-3"
          data-aos="fade-right">

          <div className="bg-[#00000060] group-hover:bg-primary transition-all duration-500 absolute h-full w-[15%] group-hover:w-full top-0 left-0"></div>

          <HeartPulse className="relative z-20 transition-all duration-500 group-hover:scale-125 group-hover:rotate-6" size={28} />

          <h2 className="text-xl md:text-3xl text-nowrap relative z-20 text-center w-full font-semibold ">
            Medical Facilities
          </h2>

        </div>
      </Link>

      <Link href={'/sports-facility/sports-ground'}>
        <div className="bg-secondary py-4 px-3 relative rounded-xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 group flex items-center gap-3"
          data-aos="fade-left">

          <div className="bg-[#00000060] group-hover:bg-primary transition-all duration-500 absolute h-full w-[15%] group-hover:w-full top-0 left-0"></div>

          <Trophy className="relative z-20 transition-all duration-500 group-hover:scale-125 group-hover:rotate-6" size={28} />

          <h2 className="text-xl md:text-3xl text-nowrap relative z-20 text-center w-full font-semibold">
            Sport Facilities
          </h2>

        </div>
      </Link>

      <Link href={'/academic-facilities/laboratories'}>
        <div className="bg-primary py-4 px-3 relative rounded-xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 group flex items-center gap-3"
          data-aos="fade-left">

          <div className="bg-[#00000060] group-hover:bg-primary transition-all duration-500 absolute h-full w-[15%] group-hover:w-full top-0 left-0"></div>

          <FlaskConical className="relative z-20 transition-all duration-500 group-hover:scale-125 group-hover:rotate-6" size={28} />

          <h2 className="text-xl md:text-3xl text-nowrap relative z-20 text-center w-full font-semibold">
            Other Facilities
          </h2>

        </div>
      </Link>

    </div> */}

  </div>

</div>

    {/* <div className="bg-cover lifeBBS bg-no-repeat relative bg-center justify-center bg-whiteCol md:h-[80vh] flex p-16">

  <div className="w-10/12 md:w-1/2">
    
    <h2 className="text-5xl md:text-whiteCol text-primary text-center font-bold mb-10 tracking-wide">
      Life @ BBS
    </h2>

    <div className="grid md:grid-cols-2 grid-cols-1 gap-6 text-whiteCol">

      <Link href={'/academic-facilities/lecture-theater'}>
        <div className="bg-pink p-6 relative rounded-xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 cursor-pointer group"
          data-aos="fade-right">

          <div className="bg-[#00000060] group-hover:bg-primary transition-all duration-500 absolute h-full w-[10%] group-hover:w-full top-0 left-0"></div>

          <h2 className="relative z-20 text-center text-lg font-semibold tracking-wide">
            Academic Facilities
          </h2>

        </div>
      </Link>

      <Link href={'/campus-facilities/medical-facilities'}>
        <div className="bg-seaGreen p-6 relative rounded-xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 cursor-pointer group"
          data-aos="fade-right">

          <div className="bg-[#00000060] group-hover:bg-primary transition-all duration-500 absolute h-full w-[10%] group-hover:w-full top-0 left-0"></div>

          <h2 className="relative z-20 text-center text-lg font-semibold tracking-wide">
            Medical Facilities
          </h2>

        </div>
      </Link>

      <Link href={'/sports-facility/sports-ground'}>
        <div className="bg-secondary p-6 text-primary relative rounded-xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 cursor-pointer group"
          data-aos="fade-left">

          <div className="bg-[#00000060] group-hover:bg-primary transition-all duration-500 absolute h-full w-[10%] group-hover:w-full top-0 left-0"></div>

          <h2 className="relative z-20 text-center text-lg font-semibold tracking-wide">
            Sport Facilities
          </h2>

        </div>
      </Link>

      <Link href={'/academic-facilities/laboratories'}>
        <div className="bg-primary p-6 relative rounded-xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 cursor-pointer group"
          data-aos="fade-left">

          <div className="bg-[#00000060] group-hover:bg-primary transition-all duration-500 absolute h-full w-[10%] group-hover:w-full top-0 left-0"></div>

          <h2 className="relative z-20 text-center text-lg font-semibold tracking-wide">
            Other Facilities
          </h2>

        </div>
      </Link>

    </div>

  </div>

</div> */}
      {/* <div className=" bg-cover lifeBBS bg-no-repeat  relative bg-center justify-center      bg-whiteCol md:h-[80vh]    flex  p-16">
        <div className="w-10/12 md:w-1/2   ">
          <h2 className="text-5xl md:text-whiteCol rext-primary text-center">
            Life @ BBS
          </h2>
          <div className="grid md:grid-cols-2 grid-cols-1 gap-4 text-whiteCol ">
            <Link href={'/academic-facilities/lecture-theater'}>
              <div className="bg-pink p-4 relative" data-aos="fade-right">
                <div
                  className="bg-[#00000060] hover:bg-primary p-4 absolute h-full w-[10%] top-0 left-0"
                  data-aos="fade-right"
                ></div>
                <h2 className="relative z-20 text-center">
                  Academic Facilities
                </h2>
              </div>
            </Link>
            <Link href={'/campus-facilities/medical-facilities'}>
              <div className="bg-seaGreen p-4 relative" data-aos="fade-right">
                <div
                  className="bg-[#00000060] hover:bg-primary p-4 absolute h-full w-[10%] top-0 left-0"
                  data-aos="fade-right"
                ></div>
                <h2 className="relative z-20 text-center">
                  Medical Facilities
                </h2>
              </div>
            </Link>
            <Link href={'/sports-facility/sports-ground'}>
              <div
                className="bg-secondary p-4 text-primary relative"
                data-aos="fade-left"
              >
                <div
                  className="bg-[#00000060] hover:bg-primary p-4 absolute h-full w-[10%] top-0 left-0"
                  data-aos="fade-right"
                ></div>
                <h2 className="relative z-20 text-center">Sport Facilities</h2>
              </div>
            </Link>
            <Link href={'/academic-facilities/laboratories'}>
              <div className="bg-primary p-4 relative" data-aos="fade-left">
                <div
                  className="bg-[#00000060] hover:bg-primary p-4 absolute h-full w-[10%] top-0 left-0"
                  data-aos="fade-right"
                ></div>
                <h2 className="relative z-20 text-center">Other Facilities</h2>
              </div>
            </Link>
          </div>
        </div>
      </div> */}
    </>
  );
};

export default LifeAtBBS;
