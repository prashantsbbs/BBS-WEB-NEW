'use client';

import { animationTailwind } from '../constant/classConstant';
import { Bbsgroupinstitution, institution } from '../constant/constant';
import HeroSection from './heroSection';
import Image from 'next/image';
import 'animate.css';
import { useState } from 'react';
import ScrollTrigger from 'react-scroll-trigger';
import ButtonCustom from '../common/button';
import Link from 'next/link';

const BbsGroupInstitutions = () => {
  const [animationStart, setAnimationStart] = useState(false);

  const onEnterViewport = () => {
    console.log('onEnterViewport');
    setAnimationStart(true);
  };

  const onExitViewport = () => {
    console.log('onExitViewport');
    setAnimationStart(false);
  };

  return (
    <>
      {/* @ts-ignore */}
      <ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}>
        <div className="h-10/12 bg-whiteCol relative">
          <div className="z-10 relative ">
            <div className="text-center pb-10 p-4">
              <h2 className="text-5xl mt-10 text-primary">
                BBS Group of Institutions
              </h2>
            </div>
            <div className="grid  grid-cols-1 sm:grid-cols-2 lg:grid-cols-4  text-center justify-center  ">
              {Bbsgroupinstitution.map((institute: any, index: number) => (
                <div key={index} className="text-center m-auto relative h-full">
                  <div
                    className={`h-full flex flex-col justify-between items-center relative z-10 p-8 animate__animated ${
                      animationStart
                        ? 'animate__fadeInLeft animate__slower'
                        : ''
                    }`}
                  >
                    <Image
                      unoptimized={true}
                      src={institute.image}
                      width={260}
                      height={260}
                      alt="Institute"
                      loading="lazy"
                      className={`rounded-xl mb-3 m-auto bbs-building-apply `}
                    />
                    <h4 className="text-primary text-lg h-full font-semibold">
                      {institute.title}
                    </h4>
                    <h4 className="text-sm text-seaGreen">
                      Approved by {institute.approvedBy}
                    </h4>
                    {institute.collegeCode ? (
                      <h4 className="text-seaGreen  text-sm md:text-md  uppercase hover:text-sm ">
                        College Code: {institute.collegeCode}
                      </h4>
                    ) : (
                      <h4 className="text-seaGreen text-sm md:text-md uppercase opacity-0">
                        College Code:
                      </h4>
                    )}
                    <Link href={institute.link}>
                      <ButtonCustom
                        btnColor="primary"
                        textCol="whiteCol"
                        btnText="Know More"
                      />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </ScrollTrigger>
    </>
  );
};

export default BbsGroupInstitutions;
