'use client';

import { animationTailwind } from '../constant/classConstant';
import { institution } from '../constant/constant';
import HeroSection from './heroSection';
import Image from 'next/image';
import 'animate.css';
import { useState } from 'react';
import ScrollTrigger from 'react-scroll-trigger';

const BbsInstituionsH = () => {
  const [animationStart, setAnimationStart] = useState(false);

  const onEnterViewport = () => {
    console.log('onEnterViewport');
    setAnimationStart(true);
  };

  const onExitViewport = () => {
    console.log('onExitViewport');
    setAnimationStart(false);
  };

  return (
    <>
      {/* @ts-ignore */}
      <ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}>
        <div className="h-10/12 heroApplyRecruiters relative">
          <div className="z-10 relative ">
            <div className="text-center pb-10 text-whiteCol p-4">
              <h2 className="text-5xl mt-10 "> BBS INSTITUTIONS</h2>
              <h4 className="m-0 text-lg">
                Preparing students to make meaningful contributions to society
                as engaged citizens and leaders in a complex world
              </h4>
            </div>

            <div className="grid  grid-cols-1 sm:grid-cols-2 lg:grid-cols-4  text-center justify-center  ">
              {institution.map((institute: any, index: number) => (
                <div key={index} className="text-center m-auto relative">
                  {/* <div className="bg-gradient-to-b from-gradientL to-gradientR absolute bottom-0 rounded-t-2xl h-[40%] md:h-2/3 w-full z-0"></div> */}
                   <div className="bg-danger absolute bottom-0 rounded-t-2xl h-[40%] md:h-2/3 w-full z-0"></div>
                  <div
                    className={`relative z-10 p-8 animate__animated ${
                      animationStart
                        ? 'animate__fadeInLeft animate__slower'
                        : ''
                    }`}
                  >
                    <Image
                      unoptimized={true}
                      src={institute.image}
                      width={260}
                      height={260}
                      alt="Institute"
                      loading="lazy"
                      className={`rounded-xl mb-3 m-auto bbs-building-apply `}
                    />
                    <h2 className="text-whiteCol  text-sm md:text-md  uppercase hover:text-sm ">
                      {institute.title}
                    </h2>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </ScrollTrigger>
    </>
  );
};

export default BbsInstituionsH;
