// 'use client';

// import { useEffect, useState } from 'react';
// import AppService from '../services';

// export default function Page() {
//   const [role, setRole] = useState<null | 'admin' | 'others'>(null);
//   const [password, setPassword] = useState('');
//   const [data, setData] = useState([]);
//   const [filter, setFilter] = useState<'all' | 'meta' | 'google' | 'others'>(
//     'all'
//   );

//   // 🔐 LOGIN
//   const handleLogin = async () => {
//    let type: 'admin' | 'others' | null = null;

//     if (password === '1') type = 'admin';
//     if (password === '2') type = 'others';

//     if (!type) {
//       alert('Wrong Password');
//       return;
//     }

//     setRole(type);
//  const res= await AppService.getAdmissionApply(type);
   
//     setData(res);
//   };

//   // 🔎 FILTER (frontend filter)
//   const filteredData = data.filter((item: any) => {
//     if (filter === 'all') return true;
//     return item.attributes.source === filter;
//   });

//   return (
//     <div className="p-6 text-white flex justify-center min-h-screen">
//         <div className='w-[85%]'>

//       {/* 🔐 PASSWORD MODAL */}
//       {!role && (
//     <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">

//   {/* CARD */}
//   <div className="bg-whiteCol p-8 rounded-xl shadow-lg w-[90%] max-w-sm text-center">

//     {/* TITLE */}
//     <h2 className="text-xl font-semibold text-primary mb-5">
//       🔐 Enter Password
//     </h2>

//     {/* INPUT */}
//     <input
//       type="password"
//       placeholder="Enter your password"
//       className="w-full border border-gray-dark rounded-md p-3 mb-4 
//       focus:outline-none focus:ring-2 focus:ring-primary-new-light"
//       onChange={(e) => setPassword(e.target.value)}
//     />

//     {/* BUTTON */}
//     <button
//       onClick={handleLogin}
//       className="w-full py-3 rounded-md font-medium transition
//       bg-primary text-whiteCol hover:bg-primary-new-light"
//     >
//       Submit
//     </button>

//   </div>
// </div>
//       )}

//       {/* 📊 DATA */}
//       {role && (
//        <>
//   <h1 className="text-2xl mb-5 font-semibold text-primary">
//     Admission Data
//   </h1>

//   {/* 🔎 FILTER BUTTONS */}{role === "admin" &&  <div className="flex gap-3 mb-5 flex-wrap">
//     {['all', 'meta', 'google'].map((type) => (
//       <button
//         key={type}
//         onClick={() => setFilter(type as any)}
//         className={`px-4 py-2 rounded-md text-sm font-medium transition
//         ${
//           filter === type
//             ? 'bg-secondary text-primary'
//             : 'bg-primary text-whiteCol hover:bg-primary-new-light'
//         }`}
//       >
//         {type.toUpperCase()}
//       </button>
//     ))}
//   </div> }
 

//   {/* 📊 TABLE */}
//   <div className="overflow-auto border border-gray-dark rounded-lg">

//     <table className="w-full text-center border-collapse">

//       {/* 🔥 HEADER */}
//       <thead className="bg-primary text-whiteCol">
//         <tr>
//           <th className="p-4 font-semibold">Name</th>
//           <th className="p-4 font-semibold">Email</th>
//           <th className="p-4 font-semibold">Phone</th>
//           <th className="p-4 font-semibold">Date</th>
//           <th className="p-4 font-semibold">Source</th>
//         </tr>
//       </thead>

//       {/* BODY */}
//       <tbody>
//         {filteredData.map((item: any, index: number) => (
//           <tr
//             key={item.id}
//             className={`border-t border-gray-dark transition
//             ${
//               index % 2 === 0
//                 ? 'bg-gray'
//                 : 'bg-whiteCol'
//             }
//             hover:bg-secondary/20`}
//           >
//             <td className="p-3 font-medium text-primary">
//               {item.attributes.name}
//             </td>

//             <td className="p-3 text-primary-new-light">
//               {item.attributes.email}
//             </td>

//             <td className="p-3 text-primary">
//               {item.attributes.phone}
//             </td>

//             <td className="p-3 whitespace-nowrap text-primary-new-dark">
//               {new Date(item.attributes.createdAt).toLocaleString('en-IN', {
//                 dateStyle: 'medium',
//                 timeStyle: 'short',
//               })}
//             </td>

//             <td className="p-3">
//               <span className="px-3 py-1 rounded-full text-xs font-semibold bg-primary-new-light text-whiteCol">
//                 {item.attributes.source}
//               </span>
//             </td>
//           </tr>
//         ))}
//       </tbody>
//     </table>
//   </div>
// </>
//       )}
//     </div></div>
//   );
// }

'use client';

//////////

// import { useState } from 'react';
// import AppService from '../services';

// export default function Page() {
//   const [role, setRole] = useState<null | 'admin' | 'others'>(null);
//   const [password, setPassword] = useState('');
//   const [data, setData] = useState<any[]>([]);
//   const [filter, setFilter] = useState<'all' | 'meta' | 'google' | 'others'>(
//     'all'
//   );

//   // 🔥 PAGINATION STATE
//   const [page, setPage] = useState(1);
//   const [hasMore, setHasMore] = useState(true);

//   // 🔐 LOGIN
//   const handleLogin = async () => {
//     let type: 'admin' | 'others' | null = null;

//     if (password === '1') type = 'admin';
//     if (password === '2') type = 'others';

//     if (!type) {
//       alert('Wrong Password');
//       return;
//     }

//     setRole(type);
//     setPage(1);

//     const res = await AppService.getAdmissionApply(type, 1, 50);

//     setData(res);

//     // 🔥 last page detect
//     setHasMore(res.length === 50);
//   };

//   // 🔁 FETCH DATA
//   const fetchData = async (pageNo: number) => {
//     const res = await AppService.getAdmissionApply(role!, pageNo, 50);

//     setData(res);
//     setHasMore(res.length === 50);
//   };

//   // ▶ NEXT
//   const handleNext = () => {
//     const nextPage = page + 1;
//     setPage(nextPage);
//     fetchData(nextPage);
//   };

//   // ◀ PREV
//   const handlePrev = () => {
//     if (page === 1) return;

//     const prevPage = page - 1;
//     setPage(prevPage);
//     fetchData(prevPage);
//   };

//   // 🔎 FILTER
//   const filteredData = data.filter((item: any) => {
//     if (filter === 'all') return true;
//     return item.attributes.source === filter;
//   });

//   return (
//     <div className="p-6 text-white flex justify-center min-h-screen">
//       <div className="w-[85%]">

//         {/* 🔐 PASSWORD MODAL */}
//         {!role && (
//           <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
//             <div className="bg-whiteCol p-8 rounded-xl shadow-lg w-[90%] max-w-sm text-center">
//               <h2 className="text-xl font-semibold text-primary mb-5">
//                 🔐 Enter Password
//               </h2>

//               <input
//                 type="password"
//                 placeholder="Enter your password"
//                 className="w-full border border-gray-dark rounded-md p-3 mb-4 
//                 focus:outline-none focus:ring-2 focus:ring-primary-new-light"
//                 onChange={(e) => setPassword(e.target.value)}
//               />

//               <button
//                 onClick={handleLogin}
//                 className="w-full py-3 rounded-md font-medium transition
//                 bg-primary text-whiteCol hover:bg-primary-new-light"
//               >
//                 Submit
//               </button>
//             </div>
//           </div>
//         )}

//         {/* 📊 DATA */}
//         {role && (
//           <>
//             <h1 className="text-2xl mb-5 font-semibold text-primary">
//               Admission Data
//             </h1>

//             {/* 🔎 FILTER */}
//             {role === 'admin' && (
//               <div className="flex gap-3 mb-5 flex-wrap">
//                 {['all', 'meta', 'google'].map((type) => (
//                   <button
//                     key={type}
//                     onClick={() => setFilter(type as any)}
//                     className={`px-4 py-2 rounded-md text-sm font-medium transition
//                     ${
//                       filter === type
//                         ? 'bg-secondary text-primary'
//                         : 'bg-primary text-whiteCol hover:bg-primary-new-light'
//                     }`}
//                   >
//                     {type.toUpperCase()}
//                   </button>
//                 ))}
//               </div>
//             )}

//             {/* 📊 TABLE */}
//             <div className="overflow-auto border border-gray-dark rounded-lg">
//               <table className="w-full text-center border-collapse">
//                 {/* <thead className="bg-primary text-whiteCol"> */}
//                 <thead className="bg-primary text-whiteCol table w-full table-fixed">
//                   <tr>
//                     <th className="p-4">Name</th>
//                     <th className="p-4">Email</th>
//                     <th className="p-4">Phone</th>
//                     <th className="p-4">Date</th>
//                     <th className="p-4">Source</th>
//                   </tr>
//                 </thead>

//                 {/* <tbody>
//                   {filteredData.map((item: any, index: number) => (
//                     <tr
//                       key={item.id}
//                       className={`border-t border-gray-dark
//                       ${
//                         index % 2 === 0
//                           ? 'bg-gray'
//                           : 'bg-whiteCol'
//                       }
//                       hover:bg-secondary/20`}
//                     >
//                       <td className="p-3 text-primary">
//                         {item.attributes.name}
//                       </td>
//                       <td className="p-3 text-primary-new-light">
//                         {item.attributes.email}
//                       </td>
//                       <td className="p-3 text-primary">
//                         {item.attributes.phone}
//                       </td>
//                       <td className="p-3 text-primary-new-dark">
//                         {new Date(item.attributes.createdAt).toLocaleString(
//                           'en-IN',
//                           {
//                             dateStyle: 'medium',
//                             timeStyle: 'short',
//                           }
//                         )}
//                       </td>
//                       <td className="p-3">
//                         <span className="px-3 py-1 rounded-full text-xs font-semibold bg-primary-new-light text-whiteCol">
//                           {item.attributes.source}
//                         </span>
//                       </td>
//                     </tr>
//                   ))}
//                 </tbody> */}
//                 <tbody className="block max-h-[400px] overflow-y-auto w-full">
//   {filteredData.map((item: any, index: number) => (
//     <tr
//       key={item.id}
//       className={`border-t border-gray-dark w-full table table-fixed
//       ${
//         index % 2 === 0
//           ? 'bg-gray'
//           : 'bg-whiteCol'
//       }
//       hover:bg-secondary/20`}
//     >
//       <td className="p-3 text-primary">
//         {item.attributes.name}
//       </td>
//       <td className="p-3 text-primary-new-light">
//         {item.attributes.email}
//       </td>
//       <td className="p-3 text-primary">
//         {item.attributes.phone}
//       </td>
//       <td className="p-3 text-primary-new-dark whitespace-nowrap">
//         {new Date(item.attributes.createdAt).toLocaleString('en-IN', {
//           dateStyle: 'medium',
//           timeStyle: 'short',
//         })}
//       </td>
//       <td className="p-3">
//         <span className="px-3 py-1 rounded-full text-xs font-semibold bg-primary-new-light text-whiteCol">
//           {item.attributes.source}
//         </span>
//       </td>
//     </tr>
//   ))}
// </tbody>
//               </table>
//             </div>

//             {/* 🔥 PAGINATION */}
//             <div className="flex justify-center gap-4 mt-6">

//               <button
//                 onClick={handlePrev}
//                 disabled={page === 1}
//                 className="px-4 py-2 bg-primary text-whiteCol rounded disabled:opacity-50"
//               >
//                 Prev
//               </button>

//               <span className="px-4 py-2 bg-gray text-primary rounded">
//                 Page {page}
//               </span>

//               <button
//                 onClick={handleNext}
//                 disabled={!hasMore}
//                 className="px-4 py-2 bg-primary text-whiteCol rounded disabled:opacity-50"
//               >
//                 Next
//               </button>

//             </div>
//           </>
//         )}
//       </div>
//     </div>
//   );
// }
/////////

'use client';

import { useState } from 'react';
import AppService from '../services';

export default function Page() {
  const [role, setRole] = useState<null | 'admin' | 'others'>(null);
  const [password, setPassword] = useState('');
  const [data, setData] = useState<any[]>([]);
  const [filter, setFilter] = useState<'all' | 'meta' | 'google' | 'others'>(
    'all'
  );

  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  // 🔐 LOGIN
  const handleLogin = async () => {
    let type: 'admin' | 'others' | null = null;

    if (password === 'Admin123') type = 'admin';
    if (password === 'Adminothers123') type = 'others';

    if (!type) {
      alert('Wrong Password');
      return;
    }

    setRole(type);
    setPage(1);

    const res = await AppService.getAdmissionApply(type, 1, 50);

    setData(res);
    setHasMore(res.length === 50);
  };

  // 🔁 FETCH
  const fetchData = async (pageNo: number) => {
    const res = await AppService.getAdmissionApply(role!, pageNo, 50);
console.log(res,"dataaaa")
    setData(res);
    setHasMore(res.length === 50);
  };

  // ▶ NEXT
  const handleNext = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchData(nextPage);
  };

  // ◀ PREV
  const handlePrev = () => {
    if (page === 1) return;

    const prevPage = page - 1;
    setPage(prevPage);
    fetchData(prevPage);
  };

  // 🔎 FILTER
  const filteredData = data.filter((item: any) => {
    if (filter === 'all') return true;
    return item.attributes.source === filter;
  });

  return (
    <div className="p-2 text-white flex justify-center min-h-screen">
      <div className="w-[95%]">

        {/* 🔐 PASSWORD MODAL */}
        {!role && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
            <div className="bg-whiteCol p-8 rounded-xl shadow-lg w-[90%] max-w-sm text-center">
              <h2 className="text-xl font-semibold text-primary mb-5">
                🔐 Enter Password
              </h2>

              <input
                type="password"
                placeholder="Enter your password"
                className="w-full border border-gray-dark rounded-md p-3 mb-4 
                focus:outline-none focus:ring-2 focus:ring-primary-new-light"
                onChange={(e) => setPassword(e.target.value)}
              />

              <button
                onClick={handleLogin}
                className="w-full py-3 rounded-md font-medium transition
                bg-primary text-whiteCol hover:bg-primary-new-light"
              >
                Submit
              </button>
            </div>
          </div>
        )}

        {/* 📊 DATA */}
        {role && (
          <>
            <h1 className="text-2xl mb-5 font-semibold text-primary">
              Admission Data
            </h1>

            {/* 🔎 FILTER */}
            {role === 'admin' && (
              <div className="flex gap-3 mb-5 flex-wrap">
                {['all', 'meta', 'google'].map((type) => (
                  <button
                    key={type}
                    onClick={() => setFilter(type as any)}
                    className={`px-4 py-2 rounded-md text-sm font-medium transition
                    ${
                      filter === type
                        ? 'bg-secondary text-primary'
                        : 'bg-primary text-whiteCol hover:bg-primary-new-light'
                    }`}
                  >
                    {type.toUpperCase()}
                  </button>
                ))}
              </div>
            )}

            {/* 📊 TABLE */}
            <div className="border border-gray-dark rounded-lg overflow-hidden">

              {/* HEADER */}
              <table className="w-full text-center table-fixed">
                <thead className="bg-primary text-whiteCol">
                  <tr>
                    <th className="p-4">Name</th>
                    <th className="p-4">Email</th>
                    <th className="p-4">Phone</th>
                    <th className="p-4">Date</th>
                    <th className="p-4">Course</th>
                    <th className="p-4">Source</th>
                  </tr>
                </thead>
              </table>

              {/* SCROLLABLE BODY */}
              <div className="max-h-[400px] overflow-y-auto">
                <table className="w-full text-center table-fixed">
                 <div className="max-h-[400px] overflow-y-auto overflow-x-auto">
  <table className="min-w-[800px] w-full text-center table-fixed">
    <tbody>
      {filteredData.map((item: any, index: number) => (
        <tr
          key={item.id}
          className={`border-t border-gray-dark
          ${index % 2 === 0 ? 'bg-gray' : 'bg-whiteCol'}
          hover:bg-secondary/20`}
        >
          <td className="p-3 text-primary break-words">
            {item.attributes.name}
          </td>

          <td className="p-3 text-primary-new-light break-words">
            {item.attributes.email}
          </td>

          <td className="p-3 text-primary break-words">
            {item.attributes.phone}
          </td>

          <td className="p-3 text-primary-new-dark whitespace-nowrap">
            {new Date(item.attributes.createdAt).toLocaleString('en-IN', {
              dateStyle: 'medium',
              timeStyle: 'short',
            })}
          </td>
           <td className="p-3">
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-danger text-whiteCol">
              {item.attributes.course_name}
            </span>
          </td>

          <td className="p-3">
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-primary-new-light text-whiteCol">
              {item.attributes.source}
            </span>
          </td>
        </tr>
      ))}
    </tbody>
  </table>
</div>
                </table>
              </div>

            </div>

            {/* 🔥 PAGINATION */}
            <div className="flex justify-center gap-4 mt-6">
              <button
                onClick={handlePrev}
                disabled={page === 1}
                className="px-4 py-2 bg-primary text-whiteCol rounded disabled:opacity-50"
              >
                Prev
              </button>

              <span className="px-4 py-2 bg-gray text-primary rounded">
                Page {page}
              </span>

              <button
                onClick={handleNext}
                disabled={!hasMore}
                className="px-4 py-2 bg-primary text-whiteCol rounded disabled:opacity-50"
              >
                Next
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}