'use client';
import Image from 'next/image';
import 'animate.css';
import Arrow from '../common/arrow';
import ScrollTrigger from 'react-scroll-trigger';
import { Suspense, useEffect, useState } from 'react';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import MasterCourse from '../eligibility-criteria/masterCourse';
import SwiperComponent from '../home/congracts-section/swiper';
import CourseSlider from '../common/courseSlider';
import FutureReadyEng from '../common/futureReadyEng';
import { useSearchParams } from 'next/navigation';
import AppService from '../services';
import Head from 'next/head';
import SeoWrapper from '../common/SeoWrapper';
const careerProspectus = [
  'Lawyers',
  'Judges',
  'Academician',
  'Corporate Lawyers',
  'Public Prosecutors',
  'Legal Firms Executives',
  'Legal Advisors',
  'Legal Aids In NGO',
  'Officers In Ministry Of Law & Justice',
];

const programHighlights = [
  {
    point:
      'Advisory board made up of high court judges, senior advocates in the Supreme Court, and in-house counsels for business corporations Court, and In-house counsels of business corporations.',
  },
  {
    point:
      'A dedicated library of School of Law, in addition to the main university library.',
  },
  {
    point:
      'A dedicated Employability, Placement, and Career Advancement Cell to help students develop a high employability index (HEI).',
  },
  {
    point: 'The curriculum is contemporary and emphasizes hands-on experience.',
  },
  { point: 'Dedicated center for training in Corporate and Business Laws.' },
  {
    point:
      'Literary and Debate Committee to develop elocution and oratory skills.',
  },
  {
    point:
      'Moot court session, MUN, and Parliamentary debates for hands-on experience.',
  },
];

const faculty = [
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
];

const majorTracks = [
  { title: 'Legal Principles and Case Studies' },
  { title: 'Legal Research and Writing' },
  { title: 'Advocacy and Legal Procedure' },
  { title: 'Professional Ethics and Legal Practice' },
  { title: 'Elective Courses' },
];

const defaultState = {
  facultyList: [],
  isLoading: false,
};
const departmentId = 8;
const BaLlb = () => {
  const defaultAnimation = {
    courseOverview: false,
    highlights: false,
  };

  const [animationStart, setAnimationStart] = useState(defaultAnimation);

  const [state, setState] = useState(defaultState);
  const fetchFacultyList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getFacultyList();
    if (!error) {
      // Rehan Code for Category Filtering
      const facultyList = data.filter(
        (item: any) => item?.attributes?.department?.data?.id === departmentId
      );
      setState((prevState) => ({
        ...prevState,
        facultyList,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchFacultyList();
  }, []);

  return (
    <>
      <SeoWrapper
        title="Best LLB College in UP | B.A.-LLB"
        description="Study at the best LLB college in UP with BBS’s B.A.-LLB program. Excellent campus, top faculty and strong placement support."
        keywords="Best LLB College in UP"
      >
        {/* Hero Sectino */}
        <section>
          <div className="handleoverlflow w-[80%] m-auto grid md:grid-cols-2 grid-cols-1 justify-center items-center md:px-6 px-3 py-12">
            <div>
              <Image
                src={'/courses/llb-icon.webp'}
                unoptimized={true}
                width={90}
                height={20}
                alt="LLB"
                className="animate__animated animate__fadeInLeftBig my-4 rotateAnimate"
              />
              <div>
                <h2 className="">UG Degree</h2>
                <div className="bg-secondary h-2 w-full"></div>
              </div>
              <h1 className="m-0">
                B.A. LL.B. <br /> Bachelor of Arts and Bachelor of Legislative
                Law{' '}
              </h1>
            </div>

            <div className="md:p-8 p-4">
              <Image
                src={'/courses/llb.webp'}
                unoptimized={true}
                width={600}
                height={20}
                alt="LLB"
                className="animate__animated animate__fadeInRight rounded-lg"
              />
            </div>
          </div>
        </section>

        {/* Course Overveiw */}

        <section className="bg-gray handleoverlflow">
          <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-24 px-6">
            <div data-aos="fade-right" className={`p-6 `}>
              <div>
                <h2>COURSE OVERVIEW</h2>
                <h4 className="text-justify">
                  The BA LLB is a five-year program that combines the study of
                  humanities subjects such as sociology, history, political
                  science, economics and psychology with the study of law. The
                  program allows students to understand the larger social
                  context in which the legal system operates, and the curriculum
                  is designed to meet the needs of modern industry and prepare
                  students for competitive examinations. The Faculty of Law has
                  a dedicated Internship and Placement Office that helps
                  students find internships and other opportunities.
                </h4>
              </div>

              <div className="">
                <h2 className="uppercase">MAJOR TRACKS</h2>
                <div className="grid  grid-cols-1">
                  {majorTracks.map((item, index) => (
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h3 className="m-2">{item.title}</h3>
                    </div>
                  ))}
                </div>
              </div>
              
            </div>

            <div className={`m-auto `} data-aos="fade-left">
              <div className="bg-secondary p-4 m-4 md:mr-12">
                <div className="p-4">
                  <h3 className="m-0">Duration</h3>
                  <h2 className="m-0">5 Years</h2>
                </div>
                <div className="p-4">
                  <h3 className="m-0">Programme Name</h3>
                  <h2 className="m-0">BA LL.B.</h2>
                </div>
              </div>
              <div className="bg-primary text-whiteCol p-4 m-4 md:ml-12">
                <div className="p-4">
                  <h2 className="m-0">Eligibility</h2>
                  
                  <h5 className="text-justify mt-0">
                    Passed 10+2 examination with at least 50% marks in any
                    stream.
                  </h5>
                </div>
                <div className="p-4">
                  <Link href={'apply-online'} target="blank">
                    <ButtonCustom
                      btnColor={'secondary'}
                      btnText={'Apply Online'}
                      textCol={'primary'}
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Program Highliths */}

        <section className="md:p-12 py-6 " data-aos="zoom-in-up">
          <div className="w-[80%] m-auto bg-primary p-6 text-whiteCol">
            <div>
              <h2 className="text-secondary">Programme Highlights</h2>
              <div
                className={`md:columns-2 columns-1 
                            ${
                              animationStart.highlights
                                ? 'animate__animated animate__fadeInRight animate__slower'
                                : ''
                            }`}
              >
                {programHighlights.map((list: any, index) => (
                  <>
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h4 className="m-2">{list.point}</h4>
                    </div>
                  </>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Future Ready */}
        <FutureReadyEng
          department={
            <>
              Department of <br />
              B.A. LL.B.
            </>
          }
          image={'/futureReady/ballbCenter.webp'}
          format={'jpg'}
        />

        {/* Advanced Options of Study */}
       
        <section data-aos="fade-up-right" className="md:p-12 py-6  bg-gray">
          <div className="w-[80%] m-auto bg-secondary rounded-xl p-6 text-whiteCol">
            <div>
              <h2 className="text-primary  text-center">Career Prospects</h2>
              <div className=" grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3   m-auto ">
                {careerProspectus.map((career: any, index) => (
                  <h3
                    key={index}
                    className="bg-whiteCol rounded-md drop-shadow-md px-6 py-2
                    text-primary m-0"
                  >
                    {career}
                  </h3>
                ))}
              </div>
            </div>
          </div>
        </section>
        {/* </ScrollTrigger> */}

        {/* Top Recruiters */}
        <div className="mt-12">
          <RecruitersComapnies />
        </div>

        {/* Eligibility  */}
        {/* <div className="md:p-12 p-8 ">
        <Eligibility EligibilityTable={EligibilityTable} />
      </div> */}

        {/* Faculty  */}
        {!!state.facultyList.length && (
          <div className="  bg-primary flex">
            <div className="lg:w-[85%] w-[90%] m-auto md:p-16 p-4  ">
              <h2 className="m-auto text-secondary text-center p-4">
                Our Faculty
              </h2>
              <CourseSlider elements={state.facultyList} />
            </div>
          </div>
        )}
      </SeoWrapper>{' '}
    </>
  );
};

const BaLlbSusense = () => {
  return (
    <Suspense>
      <BaLlb />
    </Suspense>
  );
};

export default BaLlbSusense;
