'use client';

import Image from 'next/image';
import Arrow from '../common/arrow';
import { animationTailwind } from '../constant/classConstant';
import 'animate.css';

const VisionMission = () => {
  return (
    <>
      <div
        className={`grid md:grid-cols-2 grid-cols-1 mt-4 m-auto w-[80vw] text-center `}
      >
        {/* Vision */}
        <div className="p-5 lg:p-20 sm:p-10 m-auto animate__animated animate__zoomIn">
          <div
            className={`p-4 animate__animated animate__zoomIn flex m-auto bg-primary rounded-full w-[100px] h-[100px]`}
          >
            <Image
              unoptimized={true}
              src="/about/vision.svg"
              alt="Vision"
              className="m-auto"
              height={200}
              width={200}
            />
          </div>
          <h1 className="">Vision</h1>

          <h3>
            Our vision is to nurture and hone the talents of students in their
            developing stage, turning them into elite citizens of the future.
            With BBS we focus on their overall development so that they can
            sustain the rigorous industry requirements in terms of technical and
            management skills. We are making leaders of the future!
          </h3>
        </div>

        {/* Mission */}
        <div className="p-5 lg:p-20 sm:p-10 m-auto animate__animated animate__zoomIn">
          <div
            className={`p-4 animate__animated animate__zoomIn flex m-auto bg-primary rounded-full w-[100px] h-[100px]`}
          >
            <Image
              unoptimized={true}
              src="/about/mission.svg"
              alt="Mission"
              className="m-auto"
              height={200}
              width={200}
            />
          </div>
          <h2 className="text-5xl">Mission</h2>
          <div className="text-left">
            <div className="flex gap-5">
              <Arrow />
              <h3 className="m-0">
                To provide affordable education to the society in all walks of
                life.
              </h3>
            </div>
            <div className="flex gap-5">
              <Arrow />
              <h3 className="m-0">
                To provide modern technical, legal and other Professional
                courses with emphasis on developing value based ethical career
                orientation.
              </h3>
            </div>
            <div className="flex gap-5">
              <Arrow />
              <h3 className="m-0">
                To produce skilled and competent manpower with commitment to
                societal needs.
              </h3>
            </div>
            <div className="flex gap-5">
              <Arrow />
              <h3 className="m-0">
                To develop employability and entrepreneurship of stakeholders.
              </h3>
            </div>
          </div>
        </div>

        <div></div>
      </div>
    </>
  );
};
export default VisionMission;
