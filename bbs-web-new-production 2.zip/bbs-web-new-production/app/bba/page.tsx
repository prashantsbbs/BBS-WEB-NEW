'use client';
import Image from 'next/image';
import 'animate.css';
import Arrow from '../common/arrow';
import ScrollTrigger from 'react-scroll-trigger';
import { Suspense, useEffect, useState } from 'react';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import MasterCourse from '../eligibility-criteria/masterCourse';
import SwiperComponent from '../home/congracts-section/swiper';
import CourseSlider from '../common/courseSlider';
import FutureReadyEng from '../common/futureReadyEng';
import { useSearchParams } from 'next/navigation';
import AppService from '../services';
import Head from 'next/head';
import SeoWrapper from '../common/SeoWrapper';
const programHighlights = [
  {
    highlight:
      'Practical Learning: Our BBA program emphasizes practical learning and real-world application of business concepts through case studies, simulations, and experiential projects.',
  },
  {
    highlight:
      'Industry Engagement: We foster strong ties with leading businesses and organizations to offer internships, industry visits, and collaborative projects, providing students with valuable insights into business operations and challenges.',
  },
  {
    highlight:
      'Specialized Curriculum: Our curriculum covers a wide range of business disciplines including management, marketing, finance, and entrepreneurship, allowing students to gain a comprehensive understanding of the business landscape.',
  },
  {
    highlight:
      'Innovation and Entrepreneurship: We encourage innovation and entrepreneurship among our students through courses, workshops, and mentorship programs, empowering them to develop and launch their own business ventures.',
  },
  {
    highlight:
      'Global Perspective: Our program offers a global perspective by exposing students to international business practices, cultural diversity, and global trends through guest lectures, study abroad programs, and partnerships with international universities.',
  },
];

const careerProspectus = [
  'Financial Adviser, Marketer',
  'Commodities Trader',
  'Human Resources Executive',
  'Loan Officer',
  'Salesperson',
  'Real Estate Agent',
  'Customer Relationship',
];

const majorTrack = [
  { track: 'Strategic Management' },
  { track: 'Marketing and Branding' },
  { track: 'Financial Analysis' },
  { track: 'Organizational Behavior' },
  { track: 'Entrepreneurship and Innovation' },
];

const faculty = [
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
];

const defaultState = {
  facultyList: [],
  isLoading: false,
};

const departmentId = 7;
const Bba = () => {
  const defaultAnimation = {
    courseOverview: false,
    highlights: false,
  };

  const [animationStart, setAnimationStart] = useState(defaultAnimation);

  const [state, setState] = useState(defaultState);
  const fetchFacultyList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getFacultyList();
    if (!error) {
      // Rehan Code for Category Filtering
      const facultyList = data.filter(
        (item: any) => item?.attributes?.department?.data?.id === departmentId
      );
      setState((prevState) => ({
        ...prevState,
        facultyList,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchFacultyList();
  }, []);

  return (
    <>
      <SeoWrapper
        title="Best BBA Colleges in UP for Business and Management"
        description="Join one of the best BBA colleges in UP. BBS College offers industry visits, internships, live projects, and career support to shape future business leaders."
        keywords="best bba colleges in up"
      >
        {/* Hero Sectino */}
        <section>
          <div className="handleoverlflow w-[80%] m-auto grid md:grid-cols-2 grid-cols-1 justify-center items-center md:px-6 px-3 py-12">
            <div>
              <Image
                unoptimized={true}
                src={'/courses/bba-icon.webp'}
                width={90}
                height={20}
                alt="BBA"
                className="animate__animated animate__fadeInLeftBig my-4 rotateAnimate"
              />
              <div>
                <h2 className="">UG Degree</h2>
                <div className="bg-secondary h-2 w-full"></div>
              </div>
              <h1 className="m-0">
                BBA <br /> Bachelor of Business Administration{' '}
              </h1>
            </div>

            <div className="md:p-8 p-4">
              <Image
                unoptimized={true}
                src={'/courses/bba.webp'}
                width={600}
                height={20}
                alt="BBA"
                className="animate__animated animate__fadeInRight rounded-lg"
              />
            </div>
          </div>
        </section>

        {/* Course Overveiw */}

        <section className="bg-gray handleoverlflow">
          <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-24 px-6">
            <div data-aos="fade-right" className={`p-6 `}>
              <div>
                <h2>COURSE OVERVIEW</h2>
                <h4 className="text-justify">
                  At BBS College, we offer a BBA program that builds the skills
                  needed for success in business. We are proud to be listed
                  among the best BBA colleges in UP and ranked in the top 10. In
                  our classrooms, students learn leadership, entrepreneurship,
                  research, communication, and ethics. We give real exposure
                  through industry visits, internships, and live projects. Our
                  faculty and industry experts guide students with lectures,
                  seminars, and workshops. With our career services and training
                  support, we help students prepare for jobs and higher
                  education opportunities.
                </h4>
              </div>

              <div className="">
                <h2 className="uppercase">Major Tracks</h2>
                <div className="grid md:grid-cols-2 grid-cols-1">
                  {majorTrack.map((item, index) => (
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h3 className="m-2">{item.track}</h3>
                    </div>
                  ))}
                </div>
              </div>
              <div className="">
                <h2 className="uppercase">Advanced Options of Study</h2>
                <div className="grid md:grid-cols-2 grid-cols-1">
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">M.Tech.</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">MBA</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">Other PG Course</h3>
                  </div>
                </div>
              </div>
            </div>

            <div className={`m-auto `} data-aos="fade-left">
              <div className="bg-secondary p-4 m-4 md:mr-12">
                <div className="p-4">
                  <h3 className="m-0">Duration</h3>
                  <h2 className="m-0">3 Years</h2>
                </div>
                <div className="p-4">
                  <h3 className="m-0">Programme Name</h3>
                  <h2 className="m-0">BBA</h2>
                </div>
              </div>
              <div className="bg-primary text-whiteCol p-4 m-4 md:ml-12">
                <div className="p-4">
                  <h2 className="m-0">Eligibility</h2>
                  <h5 className="text-justify mt-0">
                    Passed 10+2 examination with at least 50% marks in any
                    stream.
                  </h5>
                </div>
                <div className="p-4">
                  <Link href={'apply-online'} target="blank">
                    <ButtonCustom
                      btnColor={'secondary'}
                      btnText={'Apply Online'}
                      textCol={'primary'}
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Program Highliths */}

        <section className="md:p-12 py-6 " data-aos="zoom-in-up">
          <div className="w-[80%] m-auto bg-primary p-6 text-whiteCol">
            <div>
              <h2 className="text-secondary">Programme Highlights</h2>
              <div
                className={`md:columns-2 columns-1 
                            ${
                              animationStart.highlights
                                ? 'animate__animated animate__fadeInRight animate__slower'
                                : ''
                            }`}
              >
                {programHighlights.map((list: any, index) => (
                  <>
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h4 className="m-2">{list.highlight}</h4>
                    </div>
                  </>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Future Ready */}
        <FutureReadyEng
          department={
            <>
              Department of <br />
              Bachelor of Business Administration
            </>
          }
          image={'/futureReady/bbaCenter.webp'}
          format={'jpg'}
        />

        {/* Advanced Options of Study */}

        <section data-aos="fade-up-right" className="md:p-12 py-6  bg-gray">
          <div className="w-[80%] m-auto bg-secondary rounded-xl p-6 text-whiteCol">
            <div>
              <h2 className="text-primary  text-center">Career Prospects</h2>
              <div className=" grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3   m-auto ">
                {careerProspectus.map((career: any, index) => (
                  <h3
                    key={index}
                    className="bg-whiteCol rounded-md drop-shadow-md px-6 py-2
                    text-primary m-0"
                  >
                    {career}
                  </h3>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Top Recruiters */}
        <div className="mt-12">
          <RecruitersComapnies />
        </div>

        {/* Eligibility  */}
        {/* <div className="md:p-12 p-8 ">
        <Eligibility EligibilityTable={EligibilityTable} />
      </div> */}

        {/* Faculty  */}
        {!!state.facultyList.length && (
          <div className="  bg-primary flex">
            <div className="lg:w-[85%] w-[90%] m-auto md:p-16 p-4  ">
              <h2 className="m-auto text-secondary text-center p-4">
                Our Faculty
              </h2>
              <CourseSlider elements={state.facultyList} />
            </div>
          </div>
        )}
      </SeoWrapper>
    </>
  );
};

const BbaSusense = () => {
  return (
    <Suspense>
      <Bba />
    </Suspense>
  );
};

export default BbaSusense;
