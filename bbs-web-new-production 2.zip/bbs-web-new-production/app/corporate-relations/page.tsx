'use client';
import Image from 'next/image';
import 'animate.css';
import CampusHiglight from '../common/campusHiglight';
import NewsEventsSection from '../home/news&events';
import { useEffect, useState } from 'react';

const keyInitiatives = [
  {
    title: 'Industry-Academia Collaborations',
    description:
      'CRTC acts as a liaison between BBS Group of Institutions and industry partners fostering collaborations for curriculum development, guest lectures, workshops, and industry visits. Associations and academic collaborations with Computer Society of India (CSI), Institute of Electrical and Electronics Engineers (IEEE), IIM Lucknow, IIT Madras; provide students with insights into real-world challenges, industry trends, and best practices, enhancing their learning experience.',
  },
  {
    title: 'Internship and Placement Assistance',
    description:
      'CRTC facilitates internship opportunities for students in reputed organizations across various sectors, enabling them to gain hands-on experience and practical exposure in their field of study. Additionally, the cell works closely with recruiters to organize campus placement drives, mock interviews, resume workshops, and career counseling sessions, ensuring students are well-prepared to transition into the workforce.',
  },
  {
    title: 'Skills Development Workshops',
    description:
      "Recognizing the importance of soft skills and professional competencies, CRTC conducts regular workshops and training programs focused on communication skills, leadership development, teamwork, problem-solving, and personal branding. These initiatives aim to enhance students' employability and career readiness, equipping them with the tools to thrive in a dynamic work environment.",
  },
  {
    title: 'Entrepreneurial Support',
    description:
      'CRTC fosters an entrepreneurial mindset among students, providing guidance, mentorship, and resources to aspiring entrepreneurs. Through workshops, seminars, and networking events, students have the opportunity to explore entrepreneurial ventures, develop business plans, and access incubation support to turn their ideas into reality.',
  },
];

const highlits = [
  {
    title: 'Industry Partnerships',
    description:
      'BBS Group of Institutions has forged strong partnerships with leading companies across diverse sectors, enabling us to offer a wide range of placement opportunities to our students. Our extensive network of recruiters includes multinational corporations, top-tier firms, SMEs, startups, and government organizations.',
  },
  {
    title: 'Placement Assistance',
    description:
      'The Placement Cell at BBS Group of Institutions provides comprehensive assistance to students throughout the placement process. From resume building and interview preparation to mock interviews and career counseling, our experienced placement officers are dedicated to guiding students at every step of their job search journey.',
  },
  {
    title: 'Campus Placement Drives',
    description:
      'We organize regular campus placement drives, inviting recruiters to our campus to conduct interviews and recruit students for various job roles. These placement drives provide students with direct access to potential employers and facilitate seamless interaction between students and recruiters.',
  },
  {
    title: 'Internship Opportunities',
    description:
      'In addition to full-time placements, we also facilitate internship opportunities for students to gain hands-on experience and industry exposure. Internships are offered in collaboration with reputed organizations, allowing students to apply their theoretical knowledge in real-world settings and develop practical skills.',
  },
  {
    title: 'Skill Enhancement Workshops',
    description:
      'We conduct skill enhancement workshops and training programs to equip students with the necessary skills and competencies demanded by employers. These workshops cover areas such as communication skills, problem-solving, teamwork, leadership, and industry-specific technical skills, ensuring that students are well-prepared for the demands of the job market.',
  },
];

const CorporateRelations = () => {
  const defaultState = {
    mobileBanner: false,
  };

  const [state, setState] = useState(defaultState);

  const getBodyWidth = (evt: any) => {
    if (evt.target.innerWidth < 768) {
      setState((prev: any) => ({ mobileBanner: true }));
    } else setState((prev: any) => ({ mobileBanner: false }));
  };

  useEffect(() => {
    if (window) {
      window.addEventListener('resize', getBodyWidth);
      const screenWidth = window.screen.width;

      if (screenWidth < 768) {
        setState((prev: any) => ({ mobileBanner: true }));
      } else setState((prev: any) => ({ mobileBanner: false }));
    }
    return () => window && window.removeEventListener('resize', getBodyWidth);
  }, []);

  return (
    <>
      <div className="bg-gray pb-6 mb-3">
        {/* why BBS */}
        <div className="m-auto   animate__animated animate__slideInLeft">
          {state.mobileBanner ? (
            <Image
              unoptimized={true}
              src={'/banner/bannerAboutM.webp'}
              width={1000}
              height={1000}
              alt={'Banner About'}
              className=" bgImage_aboutM   "
            />
          ) : (
            <Image
              unoptimized={true}
              src={'/banner/bannerAbout.webp'}
              width={1400}
              height={1000}
              alt={'Banner About'}
              className=" bgImage_aboutD   "
            />
          )}
        </div>

        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <h2 className="">
            Welcome to CORPORATE RELATIONS AND TRAINING CELL (CRTC)
          </h2>
          <h3 className="">
            The training & placement cell of BBS Group of Institutions
          </h3>
          <h4 className="text-justify">
            &emsp;&emsp;At BBS, we recognize the importance of bridging the gap
            between academia and industry, preparing our students to excel in
            the competitive corporate landscape. The Corporate Relations and
            Training Cell (CRTC) serves as a catalyst in this endeavor,
            facilitating meaningful collaborations with corporate partners and
            providing comprehensive training programs to enhance students&apos;
            employability skills.
            <br />
          </h4>
        </div>
      </div>

      {/* Mission Vision */}
      <div className="grid md:grid-cols-2 grid-cols-1  ">
        <div className="bg-secondary p-8">
          <div className="p-5 lg:p-20 sm:p-10 m-auto animate__animated animate__zoomIn">
            <div
              className={`p-4 animate__animated animate__zoomIn flex m-auto bg-primary rounded-full w-[100px] h-[100px]`}
            >
              <Image
                unoptimized={true}
                src="/about/vision.svg"
                alt="Vision"
                className="m-auto"
                width={200}
                height={150}
              />
            </div>
            <h1 className="">Vision</h1>

            <h3 className="text-justify">
              At BBS Professional Studies, the CORPORATE RELATIONS AND TRAINING
              CELL is dedicated to nurturing and refining the talents of our
              students during their formative years. Our vision is to shape them
              into exemplary professionals of tomorrow. With an unwavering
              commitment to holistic development, our aim is to equip students
              with the technical and managerial skills necessary to thrive in
              the ever-evolving corporate world. We aspire to cultivate the
              leaders of tomorrow!
            </h3>
          </div>
        </div>
        <div className="bg-whiteCol p-8">
          <div className="p-5 lg:p-20 sm:p-10 m-auto animate__animated animate__zoomIn">
            <div
              className={`p-4 animate__animated animate__zoomIn flex m-auto bg-primary rounded-full w-[100px] h-[100px]`}
            >
              <Image
                unoptimized={true}
                src="/about/mission.svg"
                alt="Mission"
                className="m-auto"
                width={200}
                height={150}
              />
            </div>
            <h2 className="text-5xl">Mission</h2>
            <div className="text-left flex gap-5">
              <div className="">
                <h3 className="text-justify">
                  The primary mission of the Corporate Relations and Training
                  Cell (CRTC) is to foster strong partnerships with leading
                  corporations, industry associations, and recruiters,
                  facilitating avenues for internships, placements, and
                  industry-relevant projects. We aim to equip our students with
                  the requisite knowledge, skills, and exposure to succeed in
                  their chosen careers and make meaningful contributions to the
                  corporate world.
                </h3>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-primary flex p-6 ">
        <div className="md:w-[80%] w-[90%] m-auto rounded-xl bg-whiteCol p-6">
          <h2 className="text-center">Key Initiatives</h2>
          <div className="lg:columns-2 columns-1 ">
            {keyInitiatives.map((list: any, index) => (
              <>
                <div className="m-2">
                  <h3 className="font-semibold text-pink">{list.title}</h3>
                  <h4 className="text-justify pb-6">{list.description}</h4>
                </div>
              </>
            ))}
          </div>
        </div>
      </div>

      <div></div>

      <div className=" p-5   z-10 rounded-xl m-auto  shadow-md bg-whiteCol ">
        <div className=" m-auto md:px-16 px-4">
          <div className="px-6">
            <h3 className="bg-pink text-center font-semibold  px-8 py-2 rounded-full text-whiteCol w-max ">
              Our Commitment :
            </h3>
            <h4 className="text-justify py-6">
              &emsp;&emsp;At BBS Group of Institutions, we are committed to
              empowering our students to become future-ready professionals,
              capable of navigating the complexities of the corporate world with
              confidence and competence. Through the Corporate Relations and
              Training Cell (CRTC), we strive to create a conducive environment
              for experiential learning, industry engagement, and personal
              growth, ensuring our students emerge as leaders and change-makers
              in their respective fields.
            </h4>
          </div>
        </div>
      </div>

      <div className=" p-5  relative z-10 rounded-xl m-auto  shadow-md bg-whiteCol ">
        <div className=" m-auto md:px-16 px-4">
          <div className="px-6">
            <h3 className="bg-pink text-center font-semibold  px-8 py-2 rounded-full text-whiteCol w-max ">
              Placements :
            </h3>
            <h4 className="text-justify py-6">
              &emsp;&emsp;At BBS Group of Institutions, where we are dedicated
              to fostering academic excellence and preparing students for
              successful careers in their chosen fields. Our commitment to
              providing quality education extends beyond the classroom, with a
              strong emphasis on facilitating placements and career
              opportunities for our students.
            </h4>
          </div>
        </div>
      </div>

      <div className="bg-primary flex p-6 ">
        <div className="md:w-[80%] w-[90%] m-auto rounded-xl bg-whiteCol p-6">
          <h2 className="text-center">Placement Highlights</h2>
          <div className="lg:columns-2 columns-1 ">
            {highlits.map((list: any, index) => (
              <>
                <div className="m-2">
                  <h3 className="font-semibold text-pink">{list.title}</h3>
                  <h4 className="text-justify pb-6">{list.description}</h4>
                </div>
              </>
            ))}
          </div>
        </div>
      </div>

      <CampusHiglight />
      <NewsEventsSection />
    </>
  );
};

export default CorporateRelations;
