'use client';
import Image from 'next/image';
import 'animate.css';
import { bbsLabs } from '../constant/bbsLabs';
import Arrow from '../../app/common/arrow';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import CampusHiglight from '../common/campusHiglight';
import NewsEventsSection from '../home/news&events';
import { useEffect, useState } from 'react';
import AppService from '../services';
import Head from 'next/head';
import SeoWrapper from '../common/SeoWrapper';

const pharmaceuticalInstitutionFeatures = [
  {
    title: 'Experienced Faculty',
    description:
      'Our faculty members are seasoned experts and scholars with extensive experience in academia, research, and industry, providing students with high-quality education and mentorship.',
  },
  {
    title: 'Cutting-Edge Curriculum',
    description:
      'Our courses are designed in accordance with the latest industry trends, regulatory standards, and scientific advancements, ensuring that students are well-prepared to meet the evolving demands of the pharmaceutical sector.',
  },
  {
    title: 'State-of-the-Art Facilities',
    description:
      'Our campus features modern laboratories, research facilities, and pharmaceutical technology, providing students with hands-on experience in drug formulation, analysis, and manufacturing.',
  },
  {
    title: 'Practical Learning',
    description:
      'Through internships, clinical rotations, hospital visits, guest lectures, and industry collaborations, students gain real-world experience and develop practical skills in patient care, drug dispensing, and pharmaceutical management.',
  },
  {
    title: 'Career Opportunities',
    description:
      'With a strong emphasis on career development, we provide comprehensive placement assistance, networking opportunities, and industry connections to help students launch successful careers in pharmaceutical companies, hospitals, research institutions, and regulatory agencies.',
  },
  {
    title: 'Ethical Values',
    description:
      'We instil in our students a strong sense of ethics, integrity, and social responsibility, emphasizing the importance of patient safety, healthcare ethics, and professional conduct.',
  },
];

const mission = [
  {
    goal: 'To provide affordable education to the society in all walks of life.',
  },
  {
    goal: 'To provide modern technical, legal, and other professional courses with emphasis on developing value-based ethical career orientation.',
  },
  {
    goal: 'To produce skilled and competent manpower with commitment to societal needs.',
  },
  {
    goal: 'To develop employability and entrepreneurship of stakeholders.',
  },
  {
    goal: 'To foster a culture of innovation and continuous learning among students and faculty.',
  },
];

const coursesOffered = [
  {
    title: 'Diploma in Pharmacy (D.Pharm)',
    link: 'd-pharm',
    intake: '60',
  },
  {
    title: 'Bachelor of Pharmacy (B.Pharm)',
    link: 'b-pharm',
    intake: '100',
  },
];

const defaultState = {
  isLoading: false,
  newsList: [],
  eventList: [],
};

const BBSPharmcy = () => {
  const [state, setState] = useState(defaultState);

  const fetchNewsList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getNewsList();
    if (!error) {
      setState((prev: any) => ({ ...prev, newsList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  const fetchEventList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getEventList();
    if (!error) {
      setState((prev: any) => ({ ...prev, eventList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  useEffect(() => {
    fetchNewsList();
    fetchEventList();
  }, []);

  return (
    <>
      <SeoWrapper
        title="Best Pharmacy College in UP for Practical Learning"
        description="Study at the best pharmacy college in UP. BBSCPP offers PCI-approved programs, modern labs, expert faculty, and practical training for strong career growth."
        keywords="best pharmacy college in up"
      >
        <div className="bg-gray pb-6 mb-3">
          {/* why BBS */}
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              src={'/bbs-Pharmacy.webp'}
              width={1600}
              height={1400}
              alt={'Pharmacy Building'}
              className=" bgImage_about    "
            />
          </div>

          <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
            <h2 className="">
              Welcome to BBS College of Pharmacy and Polytechnic
            </h2>
            <h4 className="text-justify">
              &emsp;&emsp;Welcome to BBS College of Pharmacy and Polytechnic
              (BBSCPP). We train students to become skilled pharmacy
              professionals. Some lists call us the best pharmacy college in UP.
              BBSCPP is a private institute that focuses on quality, ethics, and
              practical skills. The college is approved by PCI, New Delhi, and
              affiliated to AKTU and BTE, Lucknow. This shows our courses meet
              government standards.
              <br />
            </h4>
          </div>

          <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
            <h3 className="bg-pink font-semibold px-8 py-2 rounded-r-full text-whiteCol w-max ">
              About BBSCPP :
            </h3>
            <h4 className="text-justify">
              &emsp;&emsp;We offer a list of programs that mix theory with
              hands-on lab work. Students practice in modern labs and learn from
              teachers with real experience. Our classes include projects, case
              studies, and practical training to prepare students for jobs in
              hospitals, labs, and pharmaceutical companies. Many students get
              good career options after finishing their studies.
              <br />
              <br />
              &emsp;&emsp;Rank-wise we score well in regional lists. BBSCPP aims
              to be a top choice for students who want a clear path to a
              pharmacy career. Check our course pages to find the right program
              and see admission details.
              <br />
            </h4>
          </div>
        </div>

        <div className="bg-gray pb-6 ">
          <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
            <h3 className="bg-pink font-semibold px-8  mb-6  py-2 rounded-full m-auto text-whiteCol w-max ">
              Courses Offered:
            </h3>
            <div className="grid lg:grid-cols-2 grid-cols-1">
              {coursesOffered.map((list: any, index) => (
                <Link key={index} href={list.link}>
                  <Image
                    src={'/icon/graduateLogo.webp'}
                    width={100}
                    unoptimized={true}
                    height={50}
                    alt="courses Offered Logo"
                    className="m-auto"
                  />
                  <h3 className=" font-semibold text-center hover:text-pink">
                    {list.title}
                  </h3>
                  <h3 className=" font-semibold text-center hover:text-pink">
                    Intake :{list.intake}
                  </h3>
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Mission Vision */}
        <div className="grid md:grid-cols-2 grid-cols-1  ">
          <div className="bg-secondary p-8">
            <div className="p-5 lg:p-20 sm:p-10 m-auto animate__animated animate__zoomIn">
              <div
                className={`p-4 animate__animated animate__zoomIn flex m-auto bg-primary rounded-full w-[100px] h-[100px]`}
              >
                <Image
                  src="/about/vision.svg"
                  alt="Vision"
                  className="m-auto"
                  unoptimized={true}
                  width={200}
                  height={150}
                />
              </div>
              <h1 className="">Vision</h1>

              <h3 className="text-justify">
                At BBS College of Pharmacy, our vision is to nurture and refine
                the talents of our students during their formative years,
                shaping them into exemplary citizens of tomorrow. With a
                dedicated focus on comprehensive development, we aim to equip
                our students with the technical and management skills necessary
                to thrive in the demanding landscape of the pharmaceutical
                industry. Our goal is to cultivate the leaders of the future!
              </h3>
            </div>
          </div>
          <div className="bg-whiteCol p-8">
            <div className="p-5 lg:p-20 sm:p-10 m-auto animate__animated animate__zoomIn">
              <div
                className={`p-4 animate__animated animate__zoomIn flex m-auto bg-primary rounded-full w-[100px] h-[100px]`}
              >
                <Image
                  src="/about/mission.svg"
                  alt="Mission"
                  className="m-auto"
                  unoptimized={true}
                  width={200}
                  height={150}
                />
              </div>
              <h2 className="text-5xl">Mission</h2>
              <div className="text-left flex gap-5">
                <div className="">
                  {mission.map((list: any, index) => (
                    <>
                      <div key={index} className="flex gap-6">
                        <Arrow />
                        <h3 className="m-0">{list.goal}</h3>
                      </div>
                    </>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* why Choose */}
        <div className="bg-primary flex p-6 ">
          <div className="md:w-[80%] w-[90%] m-auto rounded-xl bg-whiteCol p-6">
            <h2 className="text-center">
              Why Choose BBS College of Pharmacy and Polytechnic?
            </h2>
            <div className="lg:columns-2 columns-1 ">
              {pharmaceuticalInstitutionFeatures.map((list: any, index) => (
                <>
                  <div key={index} className="m-2">
                    <h3 className="font-semibold text-pink">{list.title}</h3>
                    <h4 className="text-justify pb-6">{list.description}</h4>
                  </div>
                </>
              ))}
            </div>
          </div>
        </div>

        <div></div>

        <div className=" p-5  relative z-10 rounded-xl m-auto  shadow-md bg-whiteCol ">
          <div className=" m-auto md:px-16 px-4">
            <div className="p-6">
              <h3 className="bg-pink text-center font-semibold  px-8 py-2 rounded-full text-whiteCol w-max ">
                Join Us:
              </h3>
              <h4 className="text-justify py-6">
                &emsp;&emsp;Whether you aspire to become a pharmacist,
                pharmaceutical researcher, clinical pharmacist, or
                pharmaceutical entrepreneur, BBS College of Pharmacy and
                Polytechnic is your gateway to a rewarding career in the
                healthcare industry. Explore our website to learn more about our
                programs, faculty, admission process, and campus life. Join us
                on this transformative journey towards becoming a leader in
                pharmacy practice and research.
                <br />
              </h4>
              <Link href={'/contact-us'}>
                <ButtonCustom
                  btnColor="primary"
                  btnText="Contact Us"
                  textCol="whiteCol"
                />
              </Link>
            </div>
          </div>
        </div>

        <CampusHiglight />
        <NewsEventsSection
          newsList={state.newsList}
          eventList={state.eventList}
        />
      </SeoWrapper>
    </>
  );
};

export default BBSPharmcy;
