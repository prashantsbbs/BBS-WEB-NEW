"use client";

import BreadcrumbCommon from "../common/breadcrumbCommon";

const SkillEnhancement = () => {
  return (
    <>
    <BreadcrumbCommon componentName={'Skill Enhancement'} image={'/home/applyFor/applyFor.webp'} />
      <div className=" lg:px-32 md:px-16 px-12 py-8">
        <div>
          <h1 className="text-pink">
            Skill Enhancement at BBS Group of Institutions
          </h1>
          <div className="md:columns-2 columns-1 gap-16">
          <div className="text-justify">
            <h4>
              Introduction: In today&apos;s dynamic and competitive world, possessing
              the right skill set is paramount for success. Recognizing this,
              BBS Group of Institutions has embarked on a journey to empower its
              students with not only academic knowledge but also practical
              skills that are indispensable in the professional arena. Through
              innovative programs and initiatives, the institution aims to mold
              individuals who are not just job seekers but creators and leaders
              in their respective fields.
            </h4>
          </div>
        <div>
          <h3 className="font-semibold">
            Holistic Skill Development Approach: BBS Group of Institutions
            adopts a holistic approach to skill development, encompassing
            various facets essential for personal and professional growth. This
            approach includes:
          </h3>
          <div className="text-justify">
            <h4>
              <b className="text-pink">1. Academic Excellence:</b> The
              institution maintains high academic standards, providing students
              with a strong foundation in their chosen fields of study. Rigorous
              coursework, led by experienced faculty members, ensures that
              students grasp theoretical concepts effectively.
            </h4>
            <h4>
              <b className="text-pink">2. Practical Training:</b> Complementing
              theoretical learning, BBS Group of Institutions emphasizes
              practical training through workshops, seminars, and hands-on
              projects. Students are encouraged to apply their knowledge in
              real-world scenarios, thereby honing their problem-solving and
              critical thinking skills.
            </h4>
            <h4>
              <b className="text-pink">3. Industry Collaboration:</b>{" "}
              Recognizing the importance of industry exposure, the institution
              collaborates with leading companies and organizations. This
              partnership facilitates internships, industrial visits, and guest
              lectures, allowing students to gain insights into industry trends
              and practices.
            </h4>
            <h4>
              <b className="text-pink">4. Soft Skills Development:</b> In
              addition to technical expertise, BBS Group of Institutions places
              great emphasis on soft skills development. Workshops on
              communication, leadership, teamwork, and time management equip
              students with the interpersonal skills necessary for professional
              success.
            </h4>
          </div>
        </div>

          </div>
        </div>

      </div>

      <div className=" lg:px-32 md:px-16 px-12 py-8 bg-pink">
        <div className="bg-whiteCol p-4 rounded-lg">
        <div>
          <h2 className="text-5xl text-seaGreen">Innovative Programs and Initiatives:</h2>
          <div className="text-justify"></div>
        </div>

        <div>
          <h3 className="font-semibold">
            To foster skill enhancement and innovation, BBS Group of
            Institutions has introduced several pioneering programs and
            initiatives, including:
          </h3>
          <div className="text-justify">
            <h4>
              <b className="text-pink">1. Skill Development Workshops: </b>{" "}
              Regular workshops are conducted on topics such as coding, digital
              marketing, financial literacy, and entrepreneurship. These
              workshops provide students with practical skills that are highly
              sought after in the job market.
            </h4>
            <h4>
              <b className="text-pink">2. Entrepreneurship Cell:</b> The
              institution has established an Entrepreneurship Cell to nurture
              entrepreneurial talent among students. Through mentorship
              programs, startup competitions, and networking events, aspiring
              entrepreneurs are encouraged to pursue their business ideas and
              ventures.
            </h4>
            <h4>
              <b className="text-pink">3. Industry-Institute Partnerships:</b>{" "}
              BBS Group of Institutions has forged partnerships with industry
              leaders to offer specialized training programs and certification
              courses. These programs are designed in collaboration with
              industry experts, ensuring alignment with current market demands.
            </h4>
            <h4>
              <b className="text-pink">4. Research and Innovation:</b> The
              institution promotes a culture of research and innovation,
              encouraging students to undertake research projects and pursue
              innovative ideas. Funding support, laboratory facilities, and
              guidance from faculty mentors facilitate research endeavors.
            </h4>
          </div>
        </div>

        </div>
      </div>
      
      <div className=" lg:px-32 md:px-16 px-12 py-8">
        <div>
          <h2 className="text-5xl text-pink">Impact and Outcomes:</h2>
          <div className="text-justify"></div>
        </div>

        <div>
          <h3 className="font-semibold">
          The emphasis on skill enhancement at BBS Group of Institutions has yielded significant outcomes, including:
          </h3>
          <div className="text-justify">
            <h4>
              <b className="text-pink">1.	Enhanced Employability:  </b>{" "}
              Graduates of the institution are highly sought after by employers due to their strong academic background and practical skills. The industry-relevant training provided equips students with the necessary competencies to excel in their careers.
            </h4>
            <h4>
              <b className="text-pink">2.	Entrepreneurial Success: </b> Several alumni have successfully launched their own startups, leveraging the entrepreneurial skills and knowledge acquired during their time at BBS Group of Institutions.
            </h4>
            <h4>
              <b className="text-pink">3.	Industry Recognition: </b>{" "}
              The institution has earned accolades for its innovative programs and initiatives, earning recognition from industry bodies and stakeholders.
            </h4>
          </div>
        </div>
      </div>
    </>
  );
};

export default SkillEnhancement;
