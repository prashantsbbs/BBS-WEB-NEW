'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { newsData } from '../constant/newsData';
import AppService from '../services';

const Years = [2024, 2023, 2022, 2021];
const Months = [
  'Select Month',
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

const defaultState = {
  latestYear: 2024,
  latestMonth: '',
  latestData: [{}],
  onlyDate: '',

  eventList: [],
};

const monthMapping: any = {
  January: 1,
  February: 2,
  March: 3,
  April: 4,
  May: 5,
  June: 6,
  July: 7,
  August: 8,
  September: 9,
  October: 10,
  November: 11,
  December: 12,
};

const Events = () => {
  const [state, setState] = useState<any>(defaultState);

  const hanldeYear = (e: any) => {
    const currentYear = +e.target.value;

    setState((prev: any) => ({
      ...prev,

      latestMonth: 'Select Month',
      latestYear: currentYear,
    }));
  };

  const handleMonth = (e: any) => {
    const currentMonth = e.target.value;
    setState((prev: any) => ({ ...prev, latestMonth: currentMonth }));

    console.log(state.latestData, 'latestmonth');
  };

  useEffect(() => {
    const year = new Date();
    const currentYear = year.getFullYear();
    setState((prev: any) => ({ ...prev, latestYear: currentYear }));

    const month = new Date();
    const currentMonth = year.getMonth();
    setState((prev: any) => ({ ...prev, latestMonth: 'Select Month' }));

    let updateData = newsData.map((data: any) => {
      const month = new Date(data.date);
      data.month = month.toLocaleString('default', { month: 'long' });

      const year = new Date(data.date);
      data.year = year.getFullYear();

      const onlyDate = new Date(data.date);
      data.onlyDate = onlyDate.toDateString();

      return data;
    });
    updateData = updateData.sort((a, b) => b.year - a.year);

    console.log(updateData, 'update Data');
    setState((prev: any) => ({ ...prev, latestData: updateData }));
  }, []);

  const fetchEventList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getEventList();
    if (!error) {
      setState((prev: any) => ({ ...prev, eventList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  useEffect(() => {
    fetchEventList();
  }, []);

  return (
    <>
      <div className="md:w-[80%] m-auto">
        <div className="md:flex block justify-between items-end px-4">
          <h1 className="text-3xl uppercase text-pink">Event Section</h1>
          <div className="flex mb-4 gap-4 justify-end">
            <select
              className="px-4 py-2 border-2 border-primary rounded-lg"
              name="year"
              id="year"
              onChange={hanldeYear}
            >
              {Years.map((year: any, index) => (
                <option key={index} value={year}>
                  {year}
                </option>
              ))}
            </select>

            <select
              className="px-4 py-2 border-2 border-primary rounded-lg"
              name="month"
              id="month"
              onChange={handleMonth}
            >
              {Months.map((month: any, index) => (
                <option key={index} value={month}>
                  {month}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="mb-10">
          <div>
            <div className="m-auto  md:w-[80%]   animate__animated animate__slideInLeft ">
              <Image
                src={
                  state.eventList[0]?.attributes?.media?.data?.attributes?.url
                }
                width={1000}
                height={1000}
                alt={'Latest Year Event'}
                unoptimized={true}
                className=" bgImage_news  md:rounded-xl "
              />
            </div>
            <div className="bg-secondary lg:w-1/3 ml-auto -mt-20 relative z-10">
              <h4 className="p-4">
                {state.eventList[0]?.attributes?.description}
              </h4>
            </div>
          </div>
        </div>

        <div className="grid w-[80%] m-auto lg:grid-cols-4 md:grid-cols-2 grid-cols-1  gap-12">
          {state.eventList
            .filter((news: any) => {
              const selectedMonth = monthMapping[state.latestMonth];
              if (state.latestYear && selectedMonth) {
                const year = new Date(news?.attributes?.date).getFullYear();
                const month = new Date(news?.attributes?.date).getMonth() + 1;
                return year === state.latestYear && month === selectedMonth;
              } else {
                return true;
              }
            })
            .map((news: any) => (
              <div key={news.id}>
                <Image
                  src={news?.attributes?.media?.data?.attributes?.url}
                  width={400}
                  height={400}
                  alt={'Event News'}
                  unoptimized={true}
                  className=" bgImage_news-list  rounded-xl "
                />
                <Link href={`/news/${news.id}`}>
                  <h5 className="font-semibold">
                    {news?.attributes?.description}
                  </h5>
                  <h5 className="font-semibold text-gray-dark">
                    {news?.attributes?.date
                      ? new Date(news?.attributes?.date).toDateString()
                      : '-'}
                  </h5>
                </Link>
              </div>
            ))}
        </div>
      </div>
    </>
  );
};

export default Events;
