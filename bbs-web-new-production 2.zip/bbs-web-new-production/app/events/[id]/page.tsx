"use client";

import { newsData } from "@/app/constant/newsData";
import AppService from "@/app/services";
import { BlocksRenderer } from "@strapi/blocks-react-renderer";
import Image from "next/image";
import { useEffect, useState } from "react";

interface StateType {
  event: any,
  isLoading: boolean
}
const defaultState: StateType = {
  event: {},
  isLoading: false
};

const EventsSinglePage = ({ params }: { params: { id: String } }) => {
  const [state, setState] = useState(defaultState);

  const fetchEvent = async (id: any) => {
    setState(prevState => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getEvent(id);
    if (!error) {
      setState(prevState => ({ ...prevState, event: data }));
    }
    setState(prevState => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchEvent(params.id);
  }, [params.id]);

  return (
    <>
      <div>
              <div className="m-auto mt-5  w-[80%] m-auto animate__animated animate__slideInLeft ">
                <div>
                  <Image
                    src={state.event?.attributes?.media?.data?.attributes?.url || ""}
                    width={1000}
                    height={1000}
                    alt={"Event"}
                    unoptimized={true}
                    className=" bgImage_news  rounded-xl "
                  />
                <div className="bg-secondary md:w-1/3 ml-auto -mt-20 relative z-10">
                  <h1 className="text-xl p-4 mb-4 text-justify font-semibold">{state.event?.attributes?.description}</h1>
                </div>
                </div>

                <div>
                <BlocksRenderer
                  content={state.event?.attributes?.content || []}
                />
                </div>
              </div>
            </div>
    </>
  );
};

export default EventsSinglePage;
