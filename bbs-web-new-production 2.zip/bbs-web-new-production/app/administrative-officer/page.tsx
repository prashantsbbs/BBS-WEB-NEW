"use client";
import Image from "next/image";
import "animate.css";

const AdministrativeMessage = () => {
  return (
    <>
      <div
        className="grid md:grid-cols-2 grid-cols-1 gap-2 
             bgHalf "
      >
        <div className='m-auto  lg:p-16 md:p-10 p-5 animate__animated animate__slideInLeft'>
                <Image 
            src={'/placement/team/divyasen_1.webp'} 
            width={700}
            height={150}
            unoptimized={true}
            alt={'Administrative Message'}
            className=' bgImage  shadow-2xl '
            />
                

                </div>

        <div className="lg:p-10 sm:p-8 p-10 mt-10 text-whiteCol">
          <h1 className="mb-8  text-secondary">Chairperson&#39;s Message</h1>
          <h3 className="text-justify">
            &emsp;&emsp;It is with great pleasure that I welcome you to our website.
At BBS Group of Institutions wholesome participation is encouraged in the extensive range of extra-curricular activities and care is also taken to ensure the well-being and happiness of each and every student in the Institution. Under my leadership, and as a team working together, we strongly promote academic achievement among our students. The cultural, sporting and other successes of all of our students and staff are also proudly celebrated together.

            <br />
            <br />
            &emsp;&emsp; With more than 22 years of rewarding history of achievement in various courses of education behind us, our Institution community continues to move forward together with confidence, pride and enthusiasm.
            <br />
            <br />
            &emsp;&emsp; The institute has a proven record of its existence with Academic, Research, Corporate skills and innumerable Institute-society interaction. Our Excellent infrastructure, Competent and Qualified faculty; Industrial and Human Relations place us well above the rest of the institutes in different aspects. Our students are well placed in positions in different sectors of the national and global industries. We strive to deliver quality education among all fields.
            <br />
            &emsp;&emsp; I hope you enjoy your visit to the website and if you wish to contact us, please find details at the contact page.
            <br />
            &emsp;&emsp; Truly Yours,
          </h3>
          <h2 className="text-secondary m-0  ">
          Divyasen Singh 
          </h2>
          <h4 className="m-0">Administrative Officer, BBS Group of Institutions
</h4>
        </div>
      </div>
    </>
  );
};

export default AdministrativeMessage;
