import Image from 'next/image';
import 'animate.css';

const sportsCulture = [
  {
    title: 'Sports Culture',
    image: '/campusLife/hostel_3.webp',
  },
  {
    title: 'Sports Culture',
    image: '/campusLife/sport5.webp',
  },
  {
    title: 'Sports Culture',
    image: '/campusLife/Culture1.webp',
  },

  {
    title: 'Sports Culture',
    image: '/campusLife/Culture2.webp',
  },
  {
    title: 'Sports Culture',
    image: '/campusLife/Culture3.webp',
  },
  {
    title: 'Sports Culture',
    image: '/campusLife/Culture4.webp',
  },
  {
    title: 'Sports Culture',
    image: '/campusLife/Culture.webp',
  },
  {
    title: 'Sports Culture',
    image: '/campusLife/sportGround/hostel2.webp',
  },
];

const SportsCulture = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        <div className="w-[80vw] p-5   relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              src={'/campusLife/Culture4.webp'}
              width={1400}
              height={400}
              alt={'Culture'}
              unoptimized={true}
              className=" bgImage_about mb-4 "
            />
          </div>

          <h1 className="">Sports & Cultural Events</h1>
          <h4 className="text-justify">
            &emsp;&emsp; Cultural Festivals: Immerse yourself in the rich
            tapestry of culture with our annual cultural festivals. Experience
            vibrant performances, traditional dances, music concerts, art
            exhibitions, and delicious cuisine from around the world.
          </h4>
          <h4 className="text-justify">
            Theater Productions: Be a part of our theater productions and
            witness the magic of live performances. From classic plays to
            contemporary dramas, our talented actors bring stories to life on
            stage.{' '}
          </h4>
          <div className="grid lg:grid-cols-4 mb-6 sm:grid-cols-2 gap-12 h-bg-primary">
            {sportsCulture.map((game: any, index) => (
              <>
                <div key={index}>
                  <Image
                    src={game.image}
                    width={400}
                    height={400}
                    alt={'Sports Culture'}
                    unoptimized={true}
                    className="  bgImageIndoor rounded-lg "
                  />
                </div>
              </>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default SportsCulture;
