'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../../common/button';
import { international_sec, stateOfArt } from '../../constant/constant';
import { inDoorGames, sportGround } from '../../constant/campusLife';

const annualSportPic = [
  {
    title: 'Annual Sport',
    image: '/campusLife/gabaddi.webp',
  },

  {
    title: 'Annual Sport',
    image: '/campusLife/annual2.webp',
  },
  {
    title: 'Annual Sport',
    image: '/campusLife/annual3.webp',
  },
  {
    title: 'Annual Sport',
    image: '/campusLife/annual4.webp',
  },
  {
    title: 'Annual Sport',
    image: '/campusLife/annual5.webp',
  },
  {
    title: 'Annual Sport',
    image: '/campusLife/annualSport.webp',
  },
  {
    title: 'Annual Sport',
    image: '/campusLife/sport20.webp',
  },
  {
    title: 'Annual Sport',
    image: '/campusLife/sport15.webp',
  },
  {
    title: 'Annual Sport',
    image: '/campusLife/sport14.webp',
  },
  {
    title: 'Annual Sport',
    image: '/campusLife/sport21.webp',
  },
  {
    title: 'Annual Sport',
    image: '/campusLife/sport13.webp',
  },
  {
    title: 'Annual Sport',
    image: '/campusLife/sport12.webp',
  },
];

const AnnualSports = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        <div className="w-[80vw] p-5   relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              unoptimized={true}
              src={'/campusLife/sport3.webp'}
              width={1400}
              height={400}
              alt={'Sport'}
              className=" bgImage_about mb-4 "
            />
          </div>

          <h1 className="">Annual Sports</h1>
          <h4 className="text-justify">
            &emsp;&emsp; The sports department organizes events round the year
            be it national level, state level, inter-collegiate level,
            inter-departmental level, intra-departmental level as well as hall
            of residence level.
          </h4>

          <div className="grid lg:grid-cols-4 mb-6 sm:grid-cols-2 gap-12 h-bg-primary">
            {annualSportPic.map((game: any, index) => (
              <>
                <div key={index}>
                  <Image
                    unoptimized={true}
                    src={game.image}
                    width={400}
                    height={400}
                    alt={'Annual Sport'}
                    className="  bgImageIndoor rounded-lg "
                  />
                </div>
              </>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default AnnualSports;
