'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../../common/button';
import { international_sec, stateOfArt } from '../../constant/constant';
import { inDoorGames } from '../../constant/campusLife';

const sportOver = [
  {
    title: 'Annual Sport',
    image: '/campusLife/sport9.webp',
  },

  {
    title: 'Annual Sport',
    image: '/campusLife/sport7.webp',
  },
  {
    title: 'Annual Sport',
    image: '/campusLife/sport6.webp',
  },
  {
    title: 'Annual Sport',
    image: '/campusLife/sport5.webp',
  },
  {
    title: 'Badmiton',
    image: '/campusLife/award.webp',
  },
  {
    title: 'Chess',
    image: '/campusLife/award2.webp',
  },
  {
    title: 'Table Tennis',
    image: '/campusLife/tableTennis.webp',
  },
  {
    title: 'Carrom',
    image: '/campusLife/carrom.webp',
  },
];

const SportsOverview = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        {/* why BBS */}

        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              unoptimized={true}
              src={'/campusLife/sportsOverview.webp'}
              width={1000}
              height={1000}
              alt={'Sports Overview'}
              className=" bgImage_about "
            />
          </div>

          <h1 className="">Sports Overview</h1>
          <h4 className="text-justify">
            &emsp;&emsp; BBS Group of Institutions firmly believes in the
            saying, &#39;In a healthy body resides a healthy mind&#39;. Sports
            get their due in the university in such a way that faculty, staff
            members as well as students take active participation in the
            activities which are organized in the university round-the-year.
            National-level players serve as coaches for various sports. Each
            sport has got dedicated staff and amenities. The events which are
            earmarked for sports dot the academic calendar of the university be
            it national level, inter college, inter school or other inter and
            intra departmental activities. There is never a dull moment in the
            campus of the university thanks to the vibrant sports culture which
            is as much part of the student&#39;s life as is the academic
            pursuit. Students are encouraged to participate in activities so
            that they could hone their sportsmanship as well as develop the
            spirit with which game ought to be played. They participate in
            sports activities in various famed institutions across the length
            and breadth of the country. Overall, the sports department is
            committed for the physical well being of the student fraternity
            because we firmly believe that a student who possesses a sound
            physique is the one who would ace all the competitions in life!
          </h4>

          <div className="grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary">
            {sportOver.map((game: any, index) => (
              <>
                <div key={index}>
                  <Image
                    unoptimized={true}
                    src={game.image}
                    width={400}
                    height={400}
                    alt={'Sports Overview'}
                    className="  bgImageIndoor rounded-lg  "
                  />
                </div>
              </>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default SportsOverview;
