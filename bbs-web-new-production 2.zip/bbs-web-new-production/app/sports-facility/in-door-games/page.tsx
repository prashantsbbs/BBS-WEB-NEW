'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../../common/button';
import { international_sec, stateOfArt } from '../../constant/constant';
import { inDoorGames } from '../../constant/campusLife';

const indoor = [
  {
    title: 'indoorGames',
    image: '/campusLife/sport20.webp',
  },
  {
    title: 'indoorGames',
    image: '/campusLife/sport16.webp',
  },
  {
    title: 'indoorGames',
    image: '/campusLife/sport15.webp',
  },
  {
    title: 'indoorGames',
    image: '/campusLife/sport14.webp',
  },
  {
    title: 'indoorGames',
    image: '/campusLife/sport13.webp',
  },
  {
    title: 'indoorGames',
    image: '/campusLife/sport12.webp',
  },
  {
    title: 'indoorGames',
    image: '/campusLife/sport11.webp',
  },
  {
    title: 'indoorGames',
    image: '/campusLife/sport7.webp',
  },
];
const InDoorGames = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        {/* why BBS */}

        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <h1 className="">
            Indoor games facilities at BBS Group of Institutions are:
          </h1>

          <div className="grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary">
            {indoor.map((game: any, index) => (
              <>
                <div key={index}>
                  <Image
                    unoptimized={true}
                    src={game.image}
                    width={400}
                    height={400}
                    alt={'Indoor Game'}
                    className="  bgImageIndoor rounded-lg "
                  />
                </div>
              </>
            ))}
          </div>
          <div>
            <h4 className="text-justify">
              &emsp;&emsp; The sports department makes sure that all the latest
              and top-of-the-line equipment are made available to those having
              interest in the various sports-related activities as offered by
              the institutions. These equipments are all of top-notch quality
              and bear the same standards as those offered by the best of the
              best in the market. The students request, from time to time,
              additions in the repertoire of sports-related goods and they are
              fulfilled by the college.
            </h4>
          </div>
        </div>
      </div>
    </>
  );
};

export default InDoorGames;
