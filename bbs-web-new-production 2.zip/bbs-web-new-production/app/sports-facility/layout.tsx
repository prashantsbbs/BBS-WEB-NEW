'use client';
import Image from 'next/image';
import 'animate.css';
import Breadcrumb from '../common/breadcurb';
import { useContext, useEffect, useState } from 'react';

import SportsOverview from './sports-overview/page';
import InDoorGames from './in-door-games/page';
import SportsGround from './sports-ground/page';
import AnnualSports from './annual-sports/page';
import BreadcrumbSports from '../common/breadcrumbSports';
import { usePathname } from 'next/navigation';
import Link from 'next/link';

const SportsFailities = ({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) => {
  const defaultState: any = {
    activeHead: 0,
  };

  const [state, setState] = useState(defaultState);

  const heads = [
    {
      title: 'Sports Overview',
      active: 0,
      url: '/sports-facility/sports-overview',
    },
    { title: 'Indoor Games', active: 1, url: '/sports-facility/in-door-games' },
    {
      title: 'Sports Ground',
      active: 2,
      url: '/sports-facility/sports-ground',
    },
    {
      title: 'Annual Sports',
      active: 3,
      url: '/sports-facility/annual-sports',
    },
    {
      title: 'Sports & Cultural Events',
      active: 4,
      url: '/sports-facility/sports-cultural',
    },
  ];

  let pathname = usePathname();

  useEffect(() => {
    heads.map((page: any) => {
      if (pathname === page.url) {
        setState((prev: any) => ({ ...prev, activeHead: page.active }));
      }
    });
  }, [pathname]);

  const handleActiveMenu = (activeMenu: any, url: any) => {
    setState((prev: any) => ({ ...prev, activeHead: activeMenu }));
  };

  return (
    <>
      <div className="bg-gray ">
        <BreadcrumbSports componentName={'Sports Facility'} />

        <div className="bg-primary text-whiteCol py-5 ">
          <div className="flex md:flex-row flex-col text-center justify-between items-center	 w-3/4 m-auto   cursor-pointer ">
            {heads.map((head, index) => (
              <div key={index}>
                <Link href={head?.url}>
                  <h3
                    className="px-4 my-2"
                    onClick={() => handleActiveMenu(index, head.url)}
                  >
                    {head.active !== state.activeHead ? (
                      head.title
                    ) : (
                      <div className="bg-secondary animate__animated animate__fadeInLeft rounded-md m-0 px-2 py-1 m-auto w-max	 text-primary">
                        {head.title}
                      </div>
                    )}
                  </h3>
                </Link>
              </div>
            ))}
          </div>
        </div>
        {children}
      </div>
    </>
  );
};

export default SportsFailities;
