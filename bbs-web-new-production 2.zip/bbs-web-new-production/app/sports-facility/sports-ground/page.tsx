'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../../common/button';
import { international_sec, stateOfArt } from '../../constant/constant';
import { inDoorGames, sportGround } from '../../constant/campusLife';

const SportsGround = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        {/* why BBS */}
        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <h1 className="">Sports Ground</h1>

          <div className="grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary">
            {sportGround.map((game: any, index) => (
              <>
                <div key={index}>
                  <Image
                    unoptimized={true}
                    src={game.image}
                    width={400}
                    height={400}
                    alt={'Sport Ground'}
                    className="  bgImageIndoor rounded-lg h-full "
                  />
                </div>
              </>
            ))}
          </div>
          <div>
            <h4 className="text-justify">
              &emsp;&emsp; The playing fields for various outdoor sports deserve
              special mention as they are spread across the college campus.
              Verdant surroundings are the hallmark of the college and these
              playing grounds are no exception to the same. All the playing
              grounds are located strategically across the college thereby
              making sports part of one&#39;s life no matter where the person is
              in the university.
            </h4>
          </div>
        </div>
      </div>
    </>
  );
};

export default SportsGround;
