import Image from "next/image";
import { useEffect } from "react";

const Modal = ({
  isOpen,
  onClose,
  message = ""
}: any) => {
  const depend = isOpen === true;
  useEffect(() => {
    isOpen &&
      setTimeout(() => {
        onClose();
      }, 3000);
  }, [depend]);
  if (!isOpen) return null;
  return (
    <div className="h-20 md:min-w-[27%] min-w-full  fixed top-0 right-0 flex items-center justify-center rounded-lg text-whiteCol bg-primary z-50 animate__animated animate__slideInRight">
      <div className="flex justify-between items-center bg-white p-6 rounded-lg w-full">
        <div className="flex justify-between items-center">
          <Image
            src="/cnfrm-btn.gif"
            className="w-[1.7rem] h-[1.7rem] rounded-full relative top-[-5px] mr-5"
            alt="Confirm Button"
            width={29}
            height={50}
            unoptimized={true}
          />
          <h2 className="text-lg font-bold mb-4">{message}</h2>
        </div>
        <Image
          src="/cross.webp"
          className="w-[1.3rem] h-[1.3rem] rounded-full relative top-[-5px]  bg-whiteCol ml-10"
          alt="Cross"
          onClick={onClose}
          unoptimized={true}
          width={29}
          height={50}
        />
      </div>
    </div>
  );
};

export default Modal;
