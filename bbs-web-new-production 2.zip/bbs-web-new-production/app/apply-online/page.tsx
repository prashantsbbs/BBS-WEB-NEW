import ApplyOnlinePage from "./ApplyOnlinePage";

export default function Page() {
  return <ApplyOnlinePage source="others" />;
}
//////before///////
// import HeroApply from './heroApply';
// import ApplyOnlineClient from './ApplyOnlineClient';
// import ApplyOnlinePixel from './ApplyOnlinePixel';

// export default function Page() {
//   return (
//     <>
//     <ApplyOnlinePixel />
//       <HeroApply />   
//       <ApplyOnlineClient />
//     </>
//   );
// }