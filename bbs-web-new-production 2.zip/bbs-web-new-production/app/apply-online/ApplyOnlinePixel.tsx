'use client';

import Script from "next/script";
type SourceType = "google" | "meta" | "others";

type Props = {
  source: SourceType;
};
export default function ApplyOnlinePixel({ source }: Props) {
  return (
    <>
  
      {/* Meta Pixel Code */}
      {source === "meta" && (
        <>
          <Script
            id="meta-pixel"
            strategy="afterInteractive"
            dangerouslySetInnerHTML={{
              __html: `
                !function(f,b,e,v,n,t,s)
                {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
                n.callMethod.apply(n,arguments):n.queue.push(arguments)};
                if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
                n.queue=[];t=b.createElement(e);t.async=!0;
                t.src=v;s=b.getElementsByTagName(e)[0];
                s.parentNode.insertBefore(t,s)}(window, document,'script',
                'https://connect.facebook.net/en_US/fbevents.js');

                fbq('init', '2021738278751699');
                fbq('track', 'PageView');
              `,
            }}
          />

          <noscript>
            <img
              height="1"
              width="1"
              style={{ display: "none" }}
              src="https://www.facebook.com/tr?id=2021738278751699&ev=PageView&noscript=1"
              alt=""
            />
          </noscript>
        </>
      )}
     
     {/* Google Tag Script (gtag.js load) */}
      <Script
        src="https://www.googletagmanager.com/gtag/js?id=AW-18076117043"
        strategy="afterInteractive"
      />

      {/* Google Tag Config */}
      <Script
        id="google-gtag"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'AW-18076117043');
          `,
        }}
      />
    </>
  );
}