'use client'
import { useEffect, useMemo, useState } from "react";
import PhoneInput from 'react-phone-number-input';
import React from 'react';
import 'react-phone-number-input/style.css';
import "react-country-state-city/dist/react-country-state-city.css";
import { ERROR_MESSAGES, REGEX } from "@/app/constant/constant";
import { Controller, useForm, useWatch } from 'react-hook-form';
import { STATE_CITY_LIST } from "@/app/constant/state-city";
import Modal from "../modal";
import AppService from "@/app/services";
import { useRouter } from "next/navigation";
import {
  GoogleReCaptchaProvider,
  GoogleReCaptcha
} from 'react-google-recaptcha-v3';

const OTP_STATUS = {
  NOT_SENT: 'not-sent',
  SENT: 'sent',
  RESENT: 're-sent'
};
type SourceType = "google" | "meta" | "others";
type Props = {
  source: SourceType;
  setIsModalOpen?: any;
};

const stateList = [
  {
    name: "Maharashtra",
    cities: ["Los Angeles", "San Francisco", "San Diego"],
  },
  { name: "Delhi", cities: ["Houston", "Dallas", "Austin"] },
];
const ApplyForm = ({ setIsModalOpen, source }: Props) => {

  const [courseList, setCourseList] = useState([]);
  const [alertMessage, setAlertMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
   const [isSubmit, setIsSubmit] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);
  const [otpStatus, setOtpStatus] = useState(OTP_STATUS.NOT_SENT);
  const router = useRouter();

  const fetchCourseList = async () => {
    setIsLoading(true);
    const { data, error } = await AppService.getCourseList();
    if (!error) {
      setCourseList(data)
    }
    setIsLoading(false);
  };

  type FormData = {
    otp: Number;
    name: string;
    email: string;
    phone: string;
    course: string;
    state: string;
    city: string;
  };
  const {
    register,
    handleSubmit,
    getValues,
    control,
    watch,
    resetField,
    reset,
    formState: { errors },
  } = useForm<FormData>();

  const sendEmail = async (data: any) => {
    const response = await fetch("/api/email", {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    });
    const res = await response.json();
    console.log(res);
  };

  const sendOTP = async (data: any) => {
    const response = await fetch("/api/send-otp", {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    });
    const res = await response.json();
    if (res?.error) {
      setAlertMessage("OTP not sent. Please contact to administrator.");
    }
  };

  const verifyOTP = async (data: any) => {
    const response = await fetch("/api/verify-otp", {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    });
    return await response.json();
  };

  const onSubmit = async (formData: FormData) => {

    const otpRes = await verifyOTP({
      phone_number: (formData.phone || "").replace(/^\+\d{1,2}/, ''),
      otp: formData.otp
    });
    if (otpRes?.error) {
      setAlertMessage(otpRes?.error);
      return;
    }
     setIsSubmit(true);
  setIsLoading(true);
    // console.log(otpRes, formData.otp);
    const payload = {
      data: {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        state: formData.state,
        city: formData.city || "NA",
        course_name: formData.course,
        source:source,
      }
    };
    const { error } = await AppService.createAdmissionApply(payload);
    if (error) {
      setAlertMessage(error?.message);
       setIsLoading(false);
    setIsSubmit(false);
    } else {
      // setAlertMessage("Submitted Successfully.");
    await  sendEmail({
        from: process.env.NEXT_PUBLIC_ADMIN_EMAIL,
        to: formData.email,
        dynamicTemplateData: payload.data,
        templateId: process.env.NEXT_PUBLIC_ADMISSION_ENQUIRY_USER_TEMPLATE
      });
      // reset();
      router.push("/thank-you")
    }
    setIsLoading(false);
  };

  const [isOpen, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const handleClose = () => setShow(false);

  useEffect(() => {
    fetchCourseList();
  }, []);
  const [selectedCourse, selectedState] = useWatch({
    control,
    name: ["course", "state"],
  });

  const courseAndBranchList = useMemo(() => {
    return courseList.reduce((acc: any, course: any) => {
      const courseIndex = acc.findIndex((item: any) => item.name === course?.attributes?.name);
      if (courseIndex > -1) {
        acc[courseIndex].branch.push(course?.attributes?.department?.data?.attributes?.name)
      } else {
        acc.push({
          name: course?.attributes?.name,
          branch: [course?.attributes?.department?.data?.attributes?.name]
        });
      }
      return acc;
    }, [])
  }, [courseList]);
  const cityList = STATE_CITY_LIST[selectedState] || [];

  const [phoneNumberValue] = useWatch({
    control,
    name: ["phone"],
  });

  const handleSendOTP = (phoneNumber: any) => {
    setOtpStatus(otpStatus === OTP_STATUS.NOT_SENT ? OTP_STATUS.SENT : OTP_STATUS.RESENT);
    setOtpTimer(5);
    const timer = setInterval(() => {
      setOtpTimer(prevCount => prevCount - 1);
    }, 1000);

    setTimeout(() => {
      clearInterval(timer);
    }, 5000);

    sendOTP({ phone_number: phoneNumber.replace(/^\+\d{1,2}/, '')})
  };

  // google Recaptcha-------------------------------
const [recaptchaToken, setRecaptchaToken] = useState<string>('');

const handleRecaptchaChange = (token: string | null) => {
  if (token) {
    setRecaptchaToken(token);
  }
};

  return (
    <div
      className="lg:max-w-[100%] md:max-w-[60%] max-w-[90%]  lg:mt-0 mt-4 border-2 border-[#565555] border-opacity-30 overflow-hidden rounded-lg  m-auto lg:absolute static mb-10 lg:mb-0 right-[5%] top-[11.5%] z-10"
    >
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="relative flex flex-col px-8 pb-8 md:px-6 md:pb-6 md:pt-6 pt-2 gap-1 text-center bg-primary-new-light"
      >
        <p className="text-2xl drop-shadow-lg text-whiteCol font-bold	">
          Apply
        </p>
        <input
          {...register("name", { required: true, maxLength: 55 })}
          type="text"
          className="  mb-2 bg-gray-50 border border-gray-300 text-gray-1000  rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          placeholder="Candidate Name *"
        />
        {errors.name && (
          <div className="text-left  text-danger">
            {ERROR_MESSAGES[errors.name.type] || errors.name.message}
          </div>
        )}
        <input
          type="email"
          {...register("email", { required: true, maxLength: 55 })}
          required
          className="  mb-2 bg-gray-50 border border-gray-300 text-gray-900  rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          placeholder="Candidate Email"
        />
        {/* before */}
        <div className='mb-2'>
          <Controller
            name="phone"
            control={control}
            rules={{
              required: true,
              pattern: {
                value: REGEX.PHONE,
                message: "Invalid phone number"
              }
            }}
            render={({ field: { value, onChange } }) => (
              <div className="w-full sm:flex
              [&>input]:outline-none p-2.5 flex justify-stretch 
              bg-whiteCol border border-gray-300 text-gray-900  
              rounded-lg focus:ring-blue-500 focus:border-blue-500 
              block w-full p-1.5  dark:bg-gray-700 dark:border-gray-600 
              dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
               dark:focus:border-blue-500
               ">
              <PhoneInput
                defaultCountry="IN"
                countries={['IN']}
                placeholder="Enter Phone  *"
                value={value}
                onChange={onChange}
                className='[&>input]:outline-none max-w-[150px]'
              />
              {
                (phoneNumberValue?.length > 12 && phoneNumberValue?.length < 15)
                  ? otpTimer > 0 ? (
                    <span className="text-right">
                      {otpTimer} Secs
                    </span>
                  ) : (
                    <span
                      className="text-info block cursor-pointer text-right
                      ml-auto"
                      onClick={() => handleSendOTP(getValues('phone'))}
                    >
                      {otpStatus === OTP_STATUS.NOT_SENT ? 'Get OTP' : 'Resend OTP'}
                    </span>
                  )
                  : ''
              }  
              </div>
            )}
          />
          {errors.phone && (
            <div className="text-left  text-danger">
              {ERROR_MESSAGES[errors.phone.type] || errors.phone.message}
            </div>
          )}
        </div>
        <input
          {...register("otp", { required: true, maxLength: 55 })}
          type="text"
          className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900  rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${errors.name ? 'border-red-500' : ''}`}
          placeholder="Enter OTP *"
        />
        {/* after */}
        {/* <div className='mb-2'>
  <Controller
    name="phone"
    control={control}
    render={({ field: { value, onChange } }) => (
      <div
        className="w-full sm:flex
        [&>input]:outline-none p-2.5 flex justify-stretch 
        bg-whiteCol border border-gray-300 text-gray-900  
        rounded-lg focus:ring-blue-500 focus:border-blue-500 
        block w-full p-1.5 dark:bg-gray-700 dark:border-gray-600 
        dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
        dark:focus:border-blue-500"
      >
        <PhoneInput
          defaultCountry="IN"
          countries={['IN']}
          placeholder="Enter Phone"
          value={value}
          onChange={onChange}
          className='[&>input]:outline-none w-full'
        />
      </div>
    )}
  />
</div> */}
{/* \\\\\\ */}
        {errors.name && (
          <div className="text-left  text-danger">
            {ERROR_MESSAGES[errors.name.type] || errors.name.message}
          </div>
        )}
        <div className='mb-2'>
          <Controller
            name="course"
            control={control}
            rules={{
              required: true
            }}
            render={({ field: { value, onChange } }) => (
              <select
                name="course"
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                onChange={onChange}
              >
                <option key={'index'} disabled selected>
                  Select Course *
                </option>
                {courseAndBranchList.map((course: any, index: any) => (
                  <option key={index}>
                    {course.name}
                  </option>
                ))}
              </select>
            )}
          />
          {errors.course && (
            <div className="text-left  text-danger">
              {ERROR_MESSAGES[errors.course.type] || errors.course.message}
            </div>
          )}
        </div>
        <div className='mb-2'>
          <Controller
            name="state"
            control={control}
            rules={{
              required: true
            }}
            render={({ field: { value, onChange } }) => (
              <select
                name="state"
                className="bg-gray-50 border border-gray-300 text-gray-900  rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                onChange={onChange}
              >
                <option disabled selected className='text-gray'>
                  Select State *
                </option>
                {Object.entries(STATE_CITY_LIST).map(([key]) => (
                  <option key={key}>{key}</option>
                ))}
              </select>
            )}
          />
          {errors.state && (
            <div className="text-left  text-danger">
              {ERROR_MESSAGES[errors.state.type] || errors.state.message}
            </div>
          )}
        </div>
        <div className='mb-2'>
          <Controller
            name="city"
            control={control}
            rules={{
              required: !!cityList.length
            }}
            render={({ field: { value, onChange } }) => (
              <select
                name="city"
                className="bg-gray-50 border border-gray-300 text-gray-900  rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                onChange={onChange}
              >
                <option disabled selected>
                  Select City {cityList.length ? "*" : ""}
                </option>
                {cityList.map((item: any) => (
                  <option key={item.id}>{item.city}</option>
                ))}
              </select>
            )}
          />
          {errors.city && (
            <div className="text-left  text-danger">
              {ERROR_MESSAGES[errors.city.type] || errors.city.message}
            </div>
          )}
        </div>

                 <div className="flex items-start gap-2 pb-2">
  <input type="checkbox" className="mt-1 cursor-pointer" />

  <div className="text-[10px] text-whiteCol sm:w-44 text-start ">
    <p className='text-nowrap'>I would like to receive communication from </p>
    <p className='text-nowrap'>BBS Group of Institutions via and
    SMS, Email, RCS </p>
    <p className='text-nowrap'>WhatsApp for services, offers, and updates.</p>
  </div>
</div>
        {/* <button
          type="submit"
          className={` sign-btn bg-secondary text-primary border 	py-2 font-semibold cursor-pointer hover:bg-blue-600  w-full rounded-3xl`}
        >
          Submit
        </button> */}
          <button
  type="submit"
  disabled={isLoading}
  className={`sign-btn bg-secondary text-primary border py-2 font-semibold w-full rounded-3xl transition-all duration-200
    ${isLoading && isSubmit ? "opacity-70 cursor-not-allowed" : "hover:bg-blue-600 active:scale-95"}
  `}
>
  {isLoading && isSubmit ? (
    <span className="flex items-center justify-center gap-2">
      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
      Loading...
    </span>
  ) : (
    "Submit"
  )}
</button>
        {/* <GoogleReCaptchaProvider reCaptchaKey="6LeUDMcpAAAAAMLebnVfJ3q1kKeOYyjOUUDOPUcA">
    <GoogleReCaptcha onVerify={handleRecaptchaChange} />
  </GoogleReCaptchaProvider> */}
      </form>
      <Modal
        message={alertMessage}
        isOpen={!!alertMessage}
        onClose={() => setAlertMessage("")}
      />


    </div>
  );
};

export default ApplyForm;
