'use client';
import { useState } from 'react';
import ScrollTrigger from 'react-scroll-trigger';

import { keyRecruiters } from '../constant/keyRecruiters';
import Image from 'next/image';
import EligibilityCriteria from '../eligibility-criteria/page';
import 'animate.css';

const RecruitersComapnies = () => {
  return (
    <>
    {/* <div className='w-full heroApplyRecruiters m-auto -mt-6'> */}
    <div className='w-full pb-10  m-auto -mt-6'>
      <div className="w-[80%] m-auto bg-primary p-4 rounded-xl  drop-shadow-2xl -mt-6">
        <h3 className="text-center text-whiteCol  m-0">Placements & Recruiters</h3>
        <h2 className="text-5xl text-center text-secondary m-0 leading-normal">
          96% Placement in the Region
        </h2>
        <h2 className="text-center text-whiteCol m-0">Top Recruiters</h2>
        <div className=" grid md:grid-cols-6 sm:grid-cols-3 grid-cols-2 ">
          {keyRecruiters.map((company: any, index) => (
            
              <div
                key={index}
                data-aos="flip-left"
                data-aos-easing="ease-out-cubic"
                data-aos-duration="2000"
                className={`border-2 border-gray flex rounded-xl p-2 m-2 bg-whiteCol`}
              >
                <Image
                  src={company.avatar}
                  unoptimized={true}
                  width={200}
                  height={20}
                  alt="key Recruiters"
                  className="h-24 w-48 m-auto object-contain"
                />
              </div>
          
          ))}
        </div>
      </div>
      </div>
    </>
  );
};

export default RecruitersComapnies;
