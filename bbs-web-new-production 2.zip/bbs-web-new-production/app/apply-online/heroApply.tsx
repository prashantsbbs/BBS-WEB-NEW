import "animate.css";

const HeroApply = () => {
  return (
    <>
      <div className="heroApply flex relative">
        <div className="my-auto lg:w-[50%] w-full lg:ml-[10%]  text-whiteCol">
          <h1
            className=" m-auto text-center p-4 drop-shadow-2xl sm:text-7xl text-5xl 
            text-whiteCol uppercase animate__animated animate__fadeInLeftBig animate__slower"
          >
            Empowering India <br />
            to thrive in the modern era
          </h1>
          <h3 className="w-[70%] m-auto text-center animate__animated animate__fadeInUpBig animate__slower">
            BBS Group of Institutions offers seamless online application for
            prospective students, ensuring convenience and accessibility in the
            application process.
          </h3>
        </div>
      </div>
    </>
  );
};

export default HeroApply;
