import HeroApply from './heroApply';
import ApplyOnlineClient from './ApplyOnlineClient';
import ApplyOnlinePixel from './ApplyOnlinePixel';

type SourceType = "google" | "meta" | "others";

type Props = {
  source: SourceType;
};
export default function ApplyOnlinePage({ source }: Props) {
  return (
    <>
    <ApplyOnlinePixel source={source} />
      <HeroApply />   
      <ApplyOnlineClient source={source}/>
    </>
  );
}