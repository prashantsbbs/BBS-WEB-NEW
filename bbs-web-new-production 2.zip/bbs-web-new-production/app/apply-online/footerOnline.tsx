'use client'
import Image from "next/image"
import Link from "next/link"
import SocialIcons from "../common/socialIcons"

const FooterOnline = () =>{
    return (
        <>

        <div className="bg-whiteCol drop-shadow-[0_35px_35px_rgba(0,0,0,0.25)]  z-50 p-3 md:fixed bottom-0 flex md:flex-row flex-col justify-center items-center md:gap-20 gap-3 md:rounded-r-full">
        <Link
          href={'/'}>
          <Image
          width={200}
          height={50}
          loading="lazy"
          unoptimized={true}
          src="/logo/logoBBSNew.webp"
          alt="BBS Group Logo"
          />
          </Link>

<div className="md:w-auto w-screen text-center  flex justify-center gap-6 font-bold md:border-none border-y-[1px] solid border-gray-dark">
          <Link href={'/'}><h4 className="cursor-pointer" >Home</h4></Link>
          <Link href={'/'}><h4 className="cursor-pointer">Download Prospectus</h4></Link>
          <Link href={'contact-us'}><h4 className="cursor-pointer">Contact Us</h4></Link>
          
          
          
          

</div>
<SocialIcons btnColor={"secondary"} size={10}></SocialIcons>
        </div>
        </>
    )
}

export default FooterOnline