'use client';

import 'animate.css';
import Arrow from '../common/arrow';
import { useState } from 'react';
import ScrollTrigger from 'react-scroll-trigger';

const CourseOnline = () => {
  const [animationStart, setAnimationStart] = useState(false);

  const onEnterViewport = () => {
    console.log('onEnterViewport');
    setAnimationStart(true);
  };

  const onExitViewport = () => {
    console.log('onExitViewport');
    setAnimationStart(false);
  };

  return (
    <>
      <div className="courseOnline p-16  flex text-whiteCol ">
        <div className="m-auto md:w-[80%] w-[   ]">
          <h2
            className="text-5xl m-auto m-0 text-center drop-shadow-4xl  
            text-whiteCol  animate__animated animate__fadeInLeftBig"
          >
            BBS GROUP OF INSTITUTIONS PROGRAMS
          </h2>

          {/* @ts-ignore */}
          <ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}>
            <div
              className={`m-auto sm:columns-2 columns-1
            ${
              animationStart
                ? 'animate__animated animate__fadeInLeft animate__slower'
                : ''
            }`}
            >
              <div className="py-2">
                <div className="flex gap-2">
                  <Arrow />
                  <h2 className="m-0 text-secondary">B. Tech. - 4 yrs.</h2>
                </div>
                <h4 className="m-0">
                  Computer Science & Engineering, AI & ML, Information
                  Technology, Civil Engineering, Mechanical Engineering,
                  Electrical and Electronics Engineering, Electronics &
                  Communication Engineering
                </h4>
              </div>

              <div className="py-2">
                <div className="flex gap-2">
                  <Arrow />
                  <h2 className="m-0 text-secondary">
                    B. Tech.(Lateral Entry) - 3 yrs.
                  </h2>
                </div>
                <h4 className="m-0">
                  Computer Science & Engineering, AI & ML, Information
                  Technology, Civil Engineering, Mechanical Engineering,
                  Electrical and Electronics Engineering, Electronics &
                  Communication Engineering
                </h4>
              </div>

              <div className="py-2">
                <div className="flex gap-2">
                  <Arrow />
                  <h2 className="m-0 text-secondary">D. Pharm. - 2 Yrs.</h2>
                </div>
              </div>

              <div className="py-2">
                <div className="flex gap-2">
                  <Arrow />
                  <h2 className="m-0 text-secondary">B.Pharm - 4 Yrs.</h2>
                </div>
              </div>

              <div className="py-2">
                <div className="flex gap-2">
                  <Arrow />
                  <h2 className="m-0 text-secondary">BCA - 3 Yrs.</h2>
                </div>
              </div>

              <div className="py-2">
                <div className="flex gap-2">
                  <Arrow />
                  <h2 className="m-0 text-secondary">BBA - 3 Yrs.</h2>
                </div>
              </div>

              <div className="py-2">
                <div className="flex gap-2">
                  <Arrow />
                  <h2 className="m-0 text-secondary">LL.B. - 3 Yrs.</h2>
                </div>
              </div>

              <div className="py-2">
                <div className="flex gap-2">
                  <Arrow />
                  <h2 className="m-0 text-secondary">BA. LL.B. - 5 Yrs.</h2>
                </div>
              </div>

              <div className="py-2">
                <div className="flex gap-2">
                  <Arrow />
                  <h2 className="m-0 text-secondary">MBA - 2 yrs.</h2>
                </div>
              </div>

              <div className="py-2">
                <div className="flex gap-2">
                  <Arrow />
                  <h2 className="m-0 text-secondary">MCA - 2 yrs.</h2>
                </div>
              </div>

              <div className="py-2">
                <div className="flex gap-2">
                  <Arrow />
                  <h2 className="m-0 text-secondary">M.Tech - 2 yrs.</h2>
                </div>
                <h4 className="m-0">Computer Science & Engineering, CAD/CAM</h4>
              </div>
            </div>
          </ScrollTrigger>
        </div>
      </div>
    </>
  );
};

export default CourseOnline;
