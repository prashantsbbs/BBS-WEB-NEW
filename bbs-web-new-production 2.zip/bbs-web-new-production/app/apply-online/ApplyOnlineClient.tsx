'use client';

import { useEffect, useState } from 'react';
import RegistrationForm from '../common/apply-online-form';
import { sliderApplyOnline } from '../constant/constant';
import EligibilityCriteria from '../eligibility-criteria/page';
import Infrastructure from '../home/InfrastructureSection';
import ApplyForH from '../home/applyForH';
import BbsInstituionsH from '../home/bbsInstitutionH';
import CongractsSection from '../home/congracts-section';
import CoursesH from '../home/coursesH';
import HeroSection from '../home/heroSection';
import RecruitersComapnies from './RecruitersCompanies';
import CourseOnline from './courseOnline';
import { usePathname } from 'next/navigation';
import FutureReadyEng from '../common/futureReadyEng';
import FooterOnline from './footerOnline';
import StepToFollow from './stepToFollow';
import ApplyForm from './applyForm/index';
import Modal from './modal/index';

type SourceType = "google" | "meta" | "others";

type Props = {
  source: SourceType;
};

const customSlide = sliderApplyOnline;
const ApplyOnline = ({ source }: Props) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [open, setOpen] = useState<boolean>(false);

  const handleEnquiryForm = () => {
    setOpen(true);
  };

  const urlPath = usePathname();
  const [state, setState] = useState(false);

  useEffect(() => {
    const delay = setTimeout(() => {
      // if (urlPath === '/apply-online') {
  if (urlPath.startsWith('/apply-online')) {
        setState(true);
      }
    }, 3000);
    return () => clearTimeout(delay);
  }, [urlPath]);

  const closeModal = () => {
    setIsModalOpen((prevState) => !prevState);
  };

  return (
    <>
      <ApplyForm setIsModalOpen={setIsModalOpen} source={source} />
      <Modal isOpen={isModalOpen} onClose={closeModal} />
      <RecruitersComapnies />
      <BbsInstituionsH />
      <EligibilityCriteria />
      <CourseOnline />
      <FutureReadyEng />
      <CongractsSection companySliderdisplay={false} />
      <StepToFollow />
      <Infrastructure />
      <FooterOnline />
    </>
  );
};

export default ApplyOnline;
