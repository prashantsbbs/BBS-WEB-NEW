'use client'

import Image from "next/image"

const StepToFollow = () => {
    return (
        <>
        <div className="p-12 flex">
            
        <Image
          width={400}
          height={50}
          unoptimized={true}
          loading="lazy"
            src="/step.webp"
            alt="step-to-follow"
            className="m-auto md:hidden block"
          />
        <Image
          width={800}
          height={50}
          unoptimized={true}
          loading="lazy"
            src="/stepDesk.webp"
            alt="Step To Follow"
            className="m-auto md:block hidden w-1/2"
          />
        </div>
        </>
    )
}

export default StepToFollow