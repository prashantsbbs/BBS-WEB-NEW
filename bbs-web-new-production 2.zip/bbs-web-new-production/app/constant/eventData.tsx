export let eventData = [
  {
    date: 'Tue Apr 19 2022 22:18:29 GMT+0530 (India Standard Time)',
    id: 1,
    link: '',
    category: 'College Event',
    title: 'Annual Sport 2025',

    mainImage: '/news/annualSport.webp',

    heading:
      'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati',
    subTitle: [
      {
        p: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati culpa debitis non aspernatur? Distinctio magnam consequatur assumenda fuga earum error voluptatibus quasi sit rerum, sint, rem sequi tempore amet sunt',
      },
      {
        p: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati culpa debitis non aspernatur? Distinctio magnam consequatur assumenda fuga earum error voluptatibus quasi sit rerum, sint, rem sequi tempore amet sunt',
      },
      {
        p: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati culpa debitis non aspernatur? Distinctio magnam consequatur assumenda fuga earum error voluptatibus quasi sit rerum, sint, rem sequi tempore amet sunt',
      },
      {
        p: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati culpa debitis non aspernatur? Distinctio magnam consequatur assumenda fuga earum error voluptatibus quasi sit rerum, sint, rem sequi tempore amet sunt',
      },
    ],
    innerImage: [
      {
        image: '/imagePlaceholder.webp',
      },
      {
        image: '/imagePlaceholder.webp',
      },
      {
        image: '/imagePlaceholder.webp',
      },
    ],
  },
  {
    id: 2,

    mainImage: '/news/badminton.webp',
    category: 'VIP Visit',
    title: 'Placemnt of Students 2025',
    date: 'Tue Dec 19 2024 22:18:29 GMT+0530 (India Standard Time)',
    heading:
      ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati',
    subTitle: [
      {
        p: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati culpa debitis non aspernatur? Distinctio magnam consequatur assumenda fuga earum error voluptatibus quasi sit rerum, sint, rem sequi tempore amet sunt',
      },
      {
        p: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati culpa debitis non aspernatur? Distinctio magnam consequatur assumenda fuga earum error voluptatibus quasi sit rerum, sint, rem sequi tempore amet sunt',
      },
      {
        p: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati culpa debitis non aspernatur? Distinctio magnam consequatur assumenda fuga earum error voluptatibus quasi sit rerum, sint, rem sequi tempore amet sunt',
      },
      {
        p: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati culpa debitis non aspernatur? Distinctio magnam consequatur assumenda fuga earum error voluptatibus quasi sit rerum, sint, rem sequi tempore amet sunt',
      },
    ],
    innerImage: [
      {
        image: '/imagePlaceholder.webp',
      },
      {
        image: '/imagePlaceholder.webp',
      },
      {
        image: '/imagePlaceholder.webp',
      },
    ],
  },
  {
    title: 'Republic Day in BBS',
    category: 'National Events',
    id: 3,
    mainImage: '/news/breadcrumbSports.webp',
    date: 'Tue Feb 19 2024 22:18:29 GMT+0530 (India Standard Time)',
    heading:
      ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati',
    subTitle: [
      {
        p: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati culpa debitis non aspernatur? Distinctio magnam consequatur assumenda fuga earum error voluptatibus quasi sit rerum, sint, rem sequi tempore amet sunt',
      },
      {
        p: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati culpa debitis non aspernatur? Distinctio magnam consequatur assumenda fuga earum error voluptatibus quasi sit rerum, sint, rem sequi tempore amet sunt',
      },
    ],
    innerImage: [
      {
        image: '/imagePlaceholder.webp',
      },
      {
        image: '/imagePlaceholder.webp',
      },
      {
        image: '/imagePlaceholder.webp',
      },
    ],
  },
  {
    id: 4,
    title: 'Indian President visit BBS ',
    category: 'College Tour',
    mainImage: '/news/cafeteria.webp',
    date: 'Tue Jan 19 2021 22:18:29 GMT+0530 (India Standard Time)',
    heading:
      'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati',
    subTitle: [
      {
        p: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati culpa debitis non aspernatur? Distinctio magnam consequatur assumenda fuga earum error voluptatibus quasi sit rerum, sint, rem sequi tempore amet sunt',
      },
      {
        p: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis praesentium deserunt nostrum obcaecati culpa debitis non aspernatur? Distinctio magnam consequatur assumenda fuga earum error voluptatibus quasi sit rerum, sint, rem sequi tempore amet sunt',
      },
    ],
    innerImage: [
      {
        image: '/imagePlaceholder.webp',
      },
      {
        image: '/imagePlaceholder.webp',
      },
      {
        image: '/imagePlaceholder.webp',
      },
    ],
  },
];
