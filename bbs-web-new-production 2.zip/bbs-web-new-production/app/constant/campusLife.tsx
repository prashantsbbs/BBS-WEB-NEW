export const inDoorGames = [
    {
        title:'Badmiton',
        image:'/campusLife/badminton.webp'
    },
    {
        title:'Chess',
        image:'/campusLife/chess.webp'
    },
    {
        title:'Table Tennis',
        image:'/campusLife/tableTennis.webp'
    },
    {
        title:'Carrom',
        image:'/campusLife/carrom.webp'
    },
    {
        title:'Chess',
        image:'/campusLife/chess.webp'
    },
    {
        title:'Table Tennis',
        image:'/campusLife/tableTennis.webp'
    },
    {
        title:'Badmiton',
        image:'/campusLife/badminton.webp'
    },
    {
        title:'Table Tennis',
        image:'/campusLife/tableTennis.webp'
    },
]

export const sportGround = [
    {
        image:'/campusLife/sportGround/ground_1.webp'
    },
    {
        image:'/campusLife/sportGround/ground_2.webp'
    },
    {
        image:'/campusLife/sportGround/ground_3.webp'
    },
    {
        image:'/campusLife/sportGround/ground_4.webp'
    },
    {
        image:'/campusLife/sportGround/ground_2.webp'
    },
    {
        image:'/campusLife/sportGround/ground_3.webp'
    },
    {
        image:'/campusLife/sportGround/ground_4.webp'
    },
    {
        image:'/campusLife/sportGround/ground_1.webp'
    },
]