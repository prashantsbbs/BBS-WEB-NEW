export const whyBBSSubHead = [
    {
        title:'Fun Learning',
        content:'The zest to attain knowledge is achieved through a host of facilities like study halls, well-stocked libraries, auditoriums, research laboratories, creative zones, etc.',
        image:'/why-bbs/fun.webp'
    },
    {
        title:'Smart Classrooms',
        content:'Smart learning tools like projectors and smartboards enhance the learning experience and the beauty of the overall educational process. Classroom is equipped with the latest technology and has large windows to brighten up the classroom and provide fresh breeze and sunlight as a good working space.',
        image:'/why-bbs/smart.webp'
    },
    {
        title:'Laboratories',
        content:'With state-of-the-art laboratories across its institutions and departments, BBS Group of institutions is one of the best private college in Uttar Pradesh, which provides hands-on learning opportunities in all the programs that it offers.',
        image:'/why-bbs/lab.webp'
    },
    {
        title:'Green Campus',
        content:'A green campus has a positive impact on learning. It encourages the youth to undertake environment-friendly habits like walking or riding a bicycle, recycle products, consume organic foods, etc. The campus is a no-smoking zone and participates in rainwater harvesting and other green initiatives. The lush green lawns with beautiful flowers enhance the charm of the campus.',
        image:'/why-bbs/green.webp'
    },
    {
        title:'Sports',
        content:'An exceptional mind resides in a sound body. BBS group provides proper courts for basketball, volleyball, cricket, badminton, football, tennis, and a sports stadium to encourage students to take up a career in sports. Yoga rooms and gyms help improve the overall personality of the students.',
        image:'/why-bbs/sports.webp'
    },
    {
        title:'Home Away from Home',
        content:'Ergonomically designed hostel rooms are airy and comfortable, providing all the amenities that are required to help the students focus on academics and extracurricular activities. Separate hostels for boys and girls and one for international students are also provided.',
        image:'/why-bbs/homeAway.webp'
    },
    {
        title:'Hi-tech Infrastructure',
        content:'The entire campus including the hostels, cafeterias, lawns, departments, etc. is Wi-Fi enabled. The excellent IT infrastructure provides seamless access to all learning resources and communication channels.',
        image:'/why-bbs/hiTech.webp'
    },
    {
        title:'Complete Security',
        content:'A secure environment at all 4 campuses the campus allows the mind to focus entirely on academics. 24*7 security of its campus, hostels, departments, laboratories, etc. provides students, staff, and faculty the necessary peace of mind for focused academic pursuits. All campuses are CCTV-enabled and geared with all safety equipment.',
        image:'/why-bbs/security.webp'
    },
]






















