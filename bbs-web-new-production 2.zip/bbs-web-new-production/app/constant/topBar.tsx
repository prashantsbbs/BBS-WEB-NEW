export const topBar = [
  {
    title: 'News Letter',
    image: '/svg/download.svg',
    link: '/news-letters',
  },
];
export const topBarRight = [
  {
    title: 'Admission Helpline',
    number: '1800-1200-407',
    image: '/svg/phone.svg',
    link: '',
  },
  {
    title: 'STUDENT PORTAL',
    image: '',
    link: 'https://erp.bbs.ac.in',
  },
];
