export const keyRecruiters = [
    {
      avatar: "/keyRecruiters/1.webp",
    },
    {
      avatar: "/keyRecruiters/2.webp",
    },
    {
      avatar: "/keyRecruiters/3.webp",
    },
    {
      avatar: "/keyRecruiters/4.webp",
    },
    {
      avatar: "/keyRecruiters/5.webp",
    },
    {
      avatar: "/keyRecruiters/6.webp",
    },
    {
      avatar: "/keyRecruiters/7.webp",
    },
    {
      avatar: "/keyRecruiters/8.webp",
    },
    {
      avatar: "/keyRecruiters/9.webp",
    },
    {
      avatar: "/keyRecruiters/10.webp",
    },
    {
      avatar: "/keyRecruiters/11.webp",
    },
    {
      avatar: "/keyRecruiters/12.webp",
    },
    {
      avatar: "/keyRecruiters/13.webp",
    },
    {
      avatar: "/keyRecruiters/14.webp",
    },
    {
      avatar: "/keyRecruiters/15.webp",
    },
    {
      avatar: "/keyRecruiters/16.webp",
    },
    {
      avatar: "/keyRecruiters/17.webp",
    },
    {
      avatar: "/keyRecruiters/18.webp",
    },
    {
      avatar: "/keyRecruiters/19.webp",
    },
    {
      avatar: "/keyRecruiters/20.webp",
    },
    {
      avatar: "/keyRecruiters/21.webp",
    },
    {
      avatar: "/keyRecruiters/22.webp",
    },
    {
      avatar: "/keyRecruiters/24.webp",
    },
    {
      avatar: "/keyRecruiters/25.webp",
    },
    {
      avatar: "/keyRecruiters/26.webp",
    },
    {
      avatar: "/keyRecruiters/27.webp",
    },
    
  ]