import { link } from "fs";
import { title } from "process";

export const megaMenuList: any = [
  //  1.
  {
    title: "Home", link: "/",
  },

  // 2.
  {
    title: "About Us",
    link: "",
    image:'/megaMenu/newAboutimg.webp',
    subMenu: [
      { label: "The Institute", link: "/the-institute" },
      { label: "Mission & Vision", link: "/vision-mission" },
      { label: "Our Management", link:'' },
      // {
      //   label: "Message from :",
      //   subMenu: [
      //     { label: "Chairperson", link: "/chairperson-message" },
      //     { label: "Director", link: "/director-message" },
      //     { label: "Administrative", link: "/administrative-officer" },
      //   ],
      // },
      { label: "Board of Governors / Advisory Council" },
      { label: "Social Initiatives", link: '/social-initiatives' },
      { label: "Why BBS", link: '/why-bbs' },
      { label: "Mandatory Disclosure", link:'' },
      { label: "Beni Madhav Shiksha Samiti", link:'beni-madhav-shiksha-samiti' },
      
      {
        label: "Our Institutions :",
        subMenu: [
          {
            label: "BBS College of Engineering & Technology",
            link: '/bbs-engineering'
          },
          {
            label: "BBS College of Pharmacy & Polytechnic",
            link: '/bbs-pharmacy'
          },
          {
            label: "BBS Institute of Professional Studies",
            link: '/bbs-professional-studies'
          },
          {
            label: "BBS Institute of Law",
            link: '/bbs-law'
          }
        ],
      },
      { label: "News", link:'/news' },
      { label: "Events", link:'/events' },
    ],
  },
  // 3.
  {
    title: "Campus Life",
    link: "",
    image:'/megaMenu/campusgallery.webp',

    subMenu: [
           { label: "Ncc & Ano", link:'/ncc-ano' },
      {
        label: "Academic Facilities :",
        link: '',
        subMenu: [
          { label: "Lecture Theaters", link: "/academic-facilities/lecture-theater" },
          { label: "Conference Halls", link: "/academic-facilities/conference-hall" },
          { label: "Laboratories", link: "/academic-facilities/laboratories" },
          { label: "Libraries", link: "/academic-facilities/libraries" },
        ],
      },
      {
        label: "Campus Facilities :",
        link: '',
        subMenu: [
          { label: "Medical Facilities", link: "/campus-facilities/medical-facilities" },
          { label: "Hostel", link: "/campus-facilities/hostel" },
          { label: "Gym", link: "/campus-facilities/gym" },
          { label: "Cafeteria", link: "/campus-facilities/cafeteria" },
          { label: "Transport Facility", link: "/campus-facilities/transport-facility" },
        ],
      },
      {
        label: "Sports Facility :",
        link: '',
        subMenu: [
          { label: "Sports Overview", link: '/sports-facility/sports-overview' },
          { label: "In Door Games", link: '/sports-facility/in-door-games' },
          { label: "Sports Ground", link: '/sports-facility/sports-ground' },
          { label: "Annual Sports", link: '/sports-facility/annual-sports' },
          { label: "Sports & Cultural Events", link: '/sports-facility/sports-cultural' }
        ],
      },
      {
        label: "Clubs", link:'club',
      },
    
    ],
  },
  // 4.
  {
    title: "Admission",
    link: "",
    image:'/megaMenu/admissionNEW.webp',

    subMenu: [
      {
        label: "Admission Procedure",
        link: '/admission-precedure'
      },
      {
        label: "Admission Process",
        link: '/admission-process'
      },
      {
        label: "Eligibiity Criteria",
        link: '/eligibility-criteria'
      },
      {
        label: "Download Prospectus",
      },
      {
        label: "Apply Online",
        link: '/apply-online'
      },
    ],
    footer: [
      { label: '1800 120 0407', icon: '/svg/phone.svg' }
    ]
  },
  // 5.
  {
    title: "Courses",
    link: "",
    image:'/megaMenu/courseNew.webp',

    subMenu: [
      {
        label: "Diploma in Pharmacy (D.Pharm.)",
        link: '/d-pharm'
      },
      {
        label: "Bachelor of Technology (B.Tech.) :",
        link: '',
        subMenu: [

          {
            label: "Computer Science & Engineering",
            link: '/computer-science-engineering'
          },
          {
            label: "AI & ML",
            link: '/btech-aiml'
          },
          {
            label: "Information Technology",
            link: '/btech-it'
          },
          {
            label: "Civil Engineering",
            link: '/civil-engineering'
          },
          {
            label: "Mechanical Engineering",
            link: '/mechanical-engineering'
          },
          {
            label: "Electrical & Electronics Engineering",
            link: '/electrical-electronics-engineering'
          },
          {
            label: "Electronics & Communication Engineering",
            link: '/electronics-communication-engineering'
          },

        ],
      },
      {
        label: "Bachelor of Computer Application (BCA)",
        link: '/bca'
      },
      {
        label: "Bachelor of Business Administration (BBA)",
        link: '/bba'
      },
      {
        label: "Bachelor of Arts and Bachelor of Legislative Law (BA. LL.B. (Hons))",
        link: '/ba-llb'
      },
      {
        label: "Bachelor of Law (LL.B.)",
        link: '/llb'
      },
      {
        label: "Bachelor of Pharmacy (B.Pharm.)",
        link: '/b-pharm'
      },
      {
        label: "Master of Business Administration (MBA)",
        link: '/mba'
      },
      {
        label: "M.Tech.(CAD/CAM)",
        link: '/m-tech-cad-cam'
      },
      // {
      //   label: "BBA + MBA (IPM)",
      //   link: '/under-construction'
      // },
      {
        label: "M.Tech (Computer Science & Engineering)",
        link: '/m-tech-cse'
      },
      {
        label: "MCA",
        link: '/mca'
      },
      // {
      //   label: "B.COM (Hons)",
      //   link: '/under-construction'
      // },
    ],
  },
  // 6.
  {
    title: "Placement",
    image:'/megaMenu/placementNew.webp',
    link: "",
    subMenu: [
      {
        label: "Overview",
        link:'placement-overview'
      },
      {
        label: "Placement Team",
        link:'placement-team'
      },
      {
        label: "Placement Policy",
        link:'placement-policy'
      },
       {
        label: "Industrial Visits", link:'',
      },
      {
        label: "Corporate/Alumini Testimonials",
        link:'corporate-alumni-testimonial'
      },
      {
        label: "Corporate Relations and Training Cell",
        link:'corporate-relations'
      },
       {
        label: "Placement Process", link:'placement-process'
      },
      {
        label: "Skill Enhancement",
        link:'skill-enhancement'
      },
    ],
  },
  // 7.
  {
    title: "Campus Gallery",
    image:'/megaMenu/campusgallery.webp',
    link: "",
    subMenu: [
      {
        label: "Photo Gallery",
        icon:'/icon/gallery.webp',
        link : "photo-gallery"
      },
      {
        label: "Video Gallery",
        link : "video-gallery",
        icon:'/icon/news.webp',
      },
      {
        label: "Press Release",
        link : "press-release",
        icon:'/icon/video.webp',
      },
    ],
  },
  // 8.
  { title: "Contact", link: "/contact-us" },
];

//   export const menuList = [
//     { label: "Home" },
//     { label: "About us", megaMenu: "about" },
//     { label: "Campus Life", megaMenu: "campusLife" },
//     { label: "Admission", megaMenu: "Admission" },
//     { label: "Courses", megaMenu: "Courses" },
//     { label: "Placement", megaMenu: "Placement" },
//     { label: "Campus Gallery", megaMenu: "CampusGallery" },
// { label: "Contact", megaMenu: "Contact" },
//   ];

//   export const mobileMegaMenuList: any = [
//     {
//         title : 'about',
//     subMenu: [
//       { label: "The Institute" },
//       { label: "Mission & Vision" },
//       { label: "Our Management" },
//       { label: "Message from :",
//         subMenu: ["Chairman", "Director", "CAO"] },
//       { label: "Board of Governors / Advisory Council" },
//       { label: "Social Initiatives" },
//       { label: "Why BBS" },
//       { label: "Mandatory Disclosure" },
//       { label: "Beni Madhav Shiksha Samiti" },
//       {
//         label: "Our Institutions :",
//         subMenu: [
//           "BBS College of Engineering & Technology",
//           "BBS College of Pharmacy & Polytechnic",
//           "BBS Institute of Professional Studies",
//           "BBS Institute of Law",
//         ],
//       },
//     ]
// },
//     {
//         title : 'campusLife',
//     subMenu: [
//       {
//         label: "Academic Facilities :",
//         subMenu: [
//           "Lecture Theaters",
//           "Conference Halls",
//           "Laboratories",
//           "Libraries",
//         ],
//       },
//       {
//         label: "Campus Facilities :",
//         subMenu: [
//           "Medical Facilities",
//           "Hostel",
//           "Gym",
//           "Cafeteria",
//           "Transport Facility",
//         ],
//       },
//       {
//         label: "Sports Facility :",
//         subMenu: [
//           "Sports Overview",
//           "In Door Games",
//           "Sports Ground",
//           "Annual Sports",
//           "Sports & Cultural Events",
//         ],
//       },
//       {
//         label: "Clubs",
//       },
//     ],
//     },

//     {
//         title : 'Admission',
//         subMenu: [
//             {
//               label: "Admission Process",
//             },
//             {
//               label: "Admission Process (Lateral)",
//             },
//             {
//               label: "Payment Procedure",
//             },
//             {
//               label: "Download Prospectus",
//             },
//             {
//               label: "Helplines",
//             },
//           ],
//     },
// ];

export const sliderHomeDesktop: any = [
  {
    title: "Welcome to BBS College",
    link: "/banner/banner_1_D.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_2_D.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_3_D.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_4_D.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/placementD.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_5_D.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_6_D.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_7_D.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_8_D.webp",
  },
];

export const sliderHomeMobile: any = [
  {
    title: "Welcome to BBS College",
    link: "/banner/banner_1_M.webp",
  },
  {
    title: "Welcome to BBS College",
    link: "/banner/banner_11_M.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_2_M.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_3_M.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_4_M.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/placementM.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_5_M.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_6_M.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_7_M.webp",
  },
  {
    title: "We are here to help you",
    link: "/banner/banner_8_M.webp",
  },
];

export const sliderApplyOnline: any = [
  {
    title: "Welcome to BBS College",
    link: "/slider/slide/apply/1.webp",
  },
  {
    title: "We are here to help you",
    link: "/slider/slide/apply/2.webp",
  },
  {
    title: "We are here to help you",
    link: "/slider/slide/apply/3.webp",
  },
  {
    title: "We are here to help you",
    link: "/slider/slide/apply/4.webp",
  },
  // {
  //   title: "We are here to help you",
  //   link: "/slider/slide_5.webp",
  // },
];

export const homeCourses = [
  {
    title: "D. Pharma",
    category: 'Diploma Courses',
    subHead: "Diploma in Pharmacy",
    subTitle:
      "D. Pharma is a diploma course in pharmacy, providing fundamental knowledge in pharmaceutical sciences.",
    image: '/courses/coursesSection/mpharma.webp',
    link: '/d-pharm'
  },
  {
    title: "B.Tech",
    category: 'Bachelor Courses',
    subHead: "Computer Science & Engineering",
    subTitle:
      "B.Tech is a four-year undergraduate degree focused on engineering and technology.",
    image: '/courses/coursesSection/btcs.webp',
    link: '/computer-science-engineering'
  },
  {
    title: "B.Tech",
    category: 'Bachelor Courses',
    subHead: "Civil Engieerning",
    subTitle:
      "M.Tech is a postgraduate degree specializing in engineering and technology.",
    image: '/courses/coursesSection/btech-computer-science.webp',
    link: '/computer-science-engineering',
  },
  {
    title: "B.Tech",
    category: 'Bachelor Courses',
    subHead: "Mechanical Engieerning",
    subTitle:
      "M.Tech is a postgraduate degree specializing in engineering and technology.",
    image: '/courses/coursesSection/btech-mechanical.webp',
    link: '/mechanical-engineering',
    // link:''
  },
  {
    title: "B.Tech",
    category: 'Bachelor Courses',
    subHead: "Electric & Electronics",
    subTitle:
      "M.Tech is a postgraduate degree specializing in engineering and technology.",
    image: '/courses/coursesSection/mechanical.webp',
    link: '/electrical-electronics-engineering'
    // link:''
  },
  {
    title: "BCA",
    category: 'Bachelor Courses',
    subHead: "Bachelor of Computer Application",
    subTitle:
      "BCA is an undergraduate degree program focusing on computer applications and software development.",
    image: '/courses/coursesSection/mca.webp',
    link: '/bca'
  },
  {
    title: "BBA",
    category: 'Bachelor Courses',
    subHead: "Bachelor of Business Administration",
    subTitle:
      "BBA is an undergraduate program providing a comprehensive understanding of business management principles.",
    image: '/courses/coursesSection/cs.webp',
    link: '/bba'
  },

  {
    title: "B.A. LLB.",
    category: 'Bachelor Courses',
    subHead: "Bachelor of Art &  Administrative Law",
    subTitle: "B.A. LLB. is an integrated undergraduate program combining arts and law studies.",
    image: '/courses/coursesSection/bba.webp',
    link: '/ba-llb'
  },

  {
    title: "B. Pharma",
    category: 'Bachelor Courses',
    subHead: "Bachelor of Pharmacy",
    subTitle:
      "B. Pharma is an undergraduate degree program focusing on pharmaceutical studies and practices.",
    image: '/courses/coursesSection/pharma.webp',
    link: '/b-pharm'
  },
  {
    title: "MBA",
    category: 'Master Courses',
    subHead: "Master of Business Administration",
    subTitle:
      "MBA is a postgraduate degree in business administration, focusing on management and leadership skills.",
    image: '/courses/coursesSection/dpharma.webp',
    link: '/mba'
  },
  {
    title: "LLB",
    category: 'Bachelor Courses',
    subHead: "Bachelor of Law",
    subTitle:
      "LLB is an undergraduate degree in law, providing foundational knowledge and skills in legal principles and practices.",
    image: '/courses/coursesSection/llb.webp',
    link: '/llb'
  },
  {
    title: "M.Tech",
    category: 'Master Courses',
    subHead: "Computer-Aided Design (CAD) and Computer-Aided Mfg. (CAM)",
    subTitle:
      "CAD (Computer-Aided Design) creates digital models, while CAM (Computer-Aided Manufacturing) controls manufacturing processes.",
    image: '/courses/coursesSection/mtech.webp',
    link: '/m-tech-cad-cam'
  },




];

export const applyForHomePage = [
  {
    bgImage: "/home/applyFor/applyFor.webp",
  },
];

export const stateOfArt = [
  {
    id: 1,
    image: "/home/internationalization/Photo 8 NEW.webp",
    title: "",
    paragraph: "",
    subTitle: [
      {
        heading: "24+ ",
        subHeading: "Years of Academic Excellence",
      },
      {
        heading: "15000+ ",
        subHeading: "Placements Record",
      },
      {
        heading: "Dedicated ",
        subHeading: "to Innovative Education",
      },
      {
        heading: "Excellent ",
        subHeading: "Linkage with Industry",
      },
      {
        heading: "State of Art ",
        subHeading: "Infrastructure",
      },
      {
        heading: "20000+  ",
        subHeading: "PAN India Students",
      },
    ],
  },
];

export const international_sec = [
  {
    id: 1,
    image: "/home/internationalization/2.webp",
    title: "INTERNATIONAL EXPOSURE",
    paragraph:
      "BBS Group of Institutions established the Corporate Relations and Training Cell (CRTC) to forge a solid and enduring partnership between industry and academia. The CRTC makes sure that the students receive the most up-to-date tools and skills available on the market, including all components that enable the students to become well-suited and prepared for the job market and fierce competition. This is done with the input and assistance of the corporate world. Events like expert lectures by renowned experts in modern technologies, confidence building, stress & time management, and behavioural development are organised in order to fully explore students’ skills.",
    subTitle: [],
  },
];

export const innovative = [
  {
    id: 1,
    title: "INNOVATIVE LEARNING ENVIRONMENT",
    subTitle:
      "The college classroom is an important place where students and teachers learn and grow together. It is a place where collaboration occurs as well as idea-sharing and relationship-building. Instructors are one of the most influential figures in the classroom,",
    image: "/home/innovative/innovative.webp",
    link:'/academic-facilities/lecture-theater'
  },
  {
    id: 2,
    title: "RESEARCH & DEVELOPMENT",
    subTitle:
    "The college aims to have research centres in which faculty and students from various institutions outside the college besides the faculty and students from this college who are interested enhancing their qualifications register for their research",
    image: "/home/innovative/research.webp",
    link:'/academic-facilities/laboratories'
  },
  {
    id: 3,
    title: "INTERNATIONAL EXPOSURE",
    subTitle:
    "To ensure that the students are well equipped with the necessary technical skills to meet global standards.To inculcate sincerity and an urge to serve the society and the country as well. To develop ",
    image: "/home/innovative/international.webp",
    link:"/academic-facilities/conference-hall"
  },
];

export const institution = [
  {
    title: "BBS College of Engineering & Technology",
    image: "/bbsEngineering.webp"
  },
  {
    title: "BBS College of Pharmacy and Polytechnic",
    image: "/bbs-Pharmacy.webp"
  },
  {
    title: "BBS Institute of Professional Studies",
    image: "/bbsProfessional.webp"
  },
  {
    title: "BBS Institute of Law",
    image: "/bbsLaw.webp"
  },
];
export const Bbsgroupinstitution = [
  {
    title: "BBS College of Engineering & Technology",
    collegeCode:"138",
    approvedBy:'AICTE & Affiliated to AKTU',
    link:"/",
    image: "/bbsEngineering.webp"
  },
  {
    title: "BBS Institute of Professional Studies",
    collegeCode:"",
    approvedBy:'AICTE & Affiliated to PRSU Prayagraj',
    link:"/bbs-professional-studies",
    image: "/bbsProfessional.webp"
  },
   {
    title: "⁠BBS Institute of Law",
    collegeCode:"",
    approvedBy:'BCI New Delhi & Affiliated to PRSU Prayagraj',
    link:"https://bbsil.in",
    image: "/bbsLaw.webp"
  },
  {
    title: " ⁠BBS Institute of Pharmacy & Polytechnic",
    collegeCode:"",
    approvedBy:'PCI, AICTE New Delhi & Affiliated to PRSU Prayagraj',
    link:"/bbs-pharmacy",
    image: "/bbs-Pharmacy.webp"
  }
];


export const ERROR_MESSAGES: any = {
  'required': 'This field is required',
  'maxLength': 'Max length exceeded',
  'minLength': 'Min length not met',
  'min': 'Min value not met',
  'max': 'Max value exceeded'
};

export const REGEX: any = {
  PHONE: /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/,
  EMAIL: /\S+@\S+\.\S+/
};

export const TITLE_META_CONFIG: any = {
  "/": {
    title: "BBS | Success Begins Here",
    metaTags: [
      { name: "description", content: "The college classroom is an important place where students and teachers learn and grow together. It is a place where collaboration occurs as well as idea-sharing and relationship-building. Instructors are one of the most influential figures in the classroom," }
    ]
  },
  "/home": {
    title: "BBS | Success Begins Here",
    metaTags: [
      { name: "description", content: "The college classroom is an important place where students and teachers learn and grow together. It is a place where collaboration occurs as well as idea-sharing and relationship-building. Instructors are one of the most influential figures in the classroom," }
    ]
  },
  "/contact-us": {
    title: "Contact Us | BBS",
    metaTags: [
      { name: "description", content: "In this competitive era where the world is focused on ‘quantity’, we focus on ‘quality’. We know the worth of the word ‘passion’ and ‘commitment’. And focussing on all these we make sure that we build a strong foundation in carving the best in our students." }
    ]
  },
  "/academic-facilities/lecture-theater":{
    title: "Lecture Theaters",
    metaTags: [
      { name: "description", content: "BBS Group of institutions has 73 classrooms which are built like amphitheater, so that the teacher can give equal attention to all the students. 24 out of these are tutorial rooms. All these classrooms are Air-Conditioned." }
    ]
  },
  "/academic-facilities/conference-hall":{
    totle: "Conference Halls",
    metaTags: [
      { name: "description", content: "With State-of-the-art auditoriums, BBS group f institutions has a capacity to host 500+ people in its Conference hall. Students, faculty and guests can easily organise events, workshops and guest lectures. The conference halls are equipped with sound system, projector and green rooms and are air conditioned to cater to the need of audiences" }
    ]
  },
  "/academic-facilities/laboratories":{
    title :"Laboratories",
    metaTags: [
      { name: "description", content: "BBS Group of institutions has a total of 35 well equipped labs where the students get a hands-on experience on various emerging technologies through which they get an opportunity to expand their practical understanding of how a particular phenomenon works." }
    ]
  },
  "/academic-facilities/libraries":{
    title: "Libraries",
    metaTags: [
      { name: "description", content: "The Central Library's operations and services are fully computerized. For this, we have specialized user-friendly open source software. In order to ease the track and circulation of the books/journals we also Bar-Code based computerized circulation system." }
    ]
  },
  "/campus-facilities/medical-facilities":{
    title: "Medical Facilities",
    metaTags: [
      { name: "description", content: "A sound mind and creative intellect can only flourish in a healthy body. Just as important a good teacher is for stimulating the mind of a student or a sports instructor for physical fitness, there is a crucial role of a physician to keep the body healthy and disease-free" }
    ]
  },
  "/campus-facilities/hostel":{
    title: "Hostel",
    metaTags: [
      { name: "description", content: "Hundreds of students from all across the country live in the hostels, which comes closest to being 'a home away from home'. Institutions provides well-furnished hostel facility to its outstation candidates. The campus hostels are surrounded by lush green lawns and playing fields. The separate facilities for boys and girls, caring wardens and a tight security ensures a pleasant stay allowing you to focus on your academics. The hostels have complete power backup. Facilities for indoor games like TT, carom, chess, Television etc. are also available." }
    ]
  },
  "/sports-facility/sports-overview":{
    title: "Sports Overview",
    metaTags: [
      { name: "description", content: "BBS Group of Institutions firmly believes in the saying, 'In a healthy body resides a healthy mind'. Sports get their due in the university in such a way that faculty, staff members as well as students take active participation in the activities" }
    ]
  },
  "/sports-facility/in-door-games":{
    title: "In Door Games",
    metaTags: [
      { name: "description", content: "The sports department makes sure that all the latest and top-of-the-line equipment are made available to those having interest in the various sports-related activities as offered by the institutions. These equipments are all of top-notch quality and bear the same standards as those offered by the best of the best in the market. The students request, from time to time, additions in the repertoire of sports-related goods and they are fulfilled by the college." }
    ]
  },
  "/sports-facility/sports-ground":{
    title: "Sports Ground",
    metaTags: [
      { name: "description", content: "The playing fields for various outdoor sports deserve special mention as they are spread across the college campus. Verdant surroundings are the hallmark of the college and these playing grounds are no exception to the same. All the playing grounds are located strategically across the college thereby making sports part of one's life no matter where the person is in the university." }
    ]
  },
  "/sports-facility/annual-sports":{
    title: "Annual Sports",
    metaTags: [
      { name: "description", content: "The sports department organizes events round the year be it national level, state level, inter-collegiate level, inter-departmental level, intra-departmental level as well as hall of residence level." }
    ]
  },
  "/d-pharm":{
    title: "D.Pharm.",
    metaTags: [
      { name: "description", content: "The Diploma in Pharmacy is a short course for candidates who want to start a career in the field of pharmacy. Rather than pursuing a long-term pharmacy course, the D. Pharm. course is an ideal option for students who want to jump-start their career as a pharmacist. Completing D. Pharm is a good start to understanding the basics of pharmacy programs and then moving on to advanced courses such as B. Pharm." }
    ]
  },
  "/computer-science-engineering":{
    title:"Computer Science & Engineering",
    metaTags: [
      { name: "description", content: "CRAFTED TO CULTIVATE ENGINEERS PREPARED FOR THE CHALLENGES OF TOMORROW " }
    ]
  },
  "/civil-engineering":{
    title: "Civil Engineering",
    metaTags: [
      { name: "description", content: "B.Tech Civil Engineering program combines knowledge in mathematics, physics, mechanics, geotechnical engineering, materials science, hydraulics, and statistical analysis to prepare students for infrastructure design and development" }
    ]
  },
  "/mechanical-engineering":{
    title: "Mechanical Engineering",
    metaTags: [
      { name: "description", content: "CRAFTED TO CULTIVATE ENGINEERS PREPARED FOR THE CHALLENGES OF TOMORROW." }
    ]
  },
  "/electrical-electronics-engineering":{
    title: "Electrical & Electronics",
    metaTags: [
      { name: "description", content: "Practical Learning: Our program emphasizes hands-on experience and practical application of electrical and electronics engineering concepts through laboratory experiments, projects, and industrial training." }
    ]
  },
 "/apply-online":{
  title: "Apply Online",
  metaTags: [
    { name: "description", content: "Preparing students to make meaningful contributions to society as engaged citizens and leaders in a complex world" }
  ]
 },
 "/photo-gallery":{
  title: "Gallery",
  metaTags: [
    { name: "description", content: "In this competitive era where the world is focused on ‘quantity’, we focus on ‘quality’. We know the worth of the word ‘passion’ and ‘commitment’. And focussing on all these we make sure that we build a strong foundation in carving the best in our students." }
  ]
 },"/bba":{
  title:"BBA",
  metaTags: [
    { name: "description", content: "The BBA program provides students with the skills and knowledge essential for success in the business world, including leadership, entrepreneurship, strategic thinking, research, communication, and ethical behavior. Students gain an understanding of how the corporate world works through industry visits, summer i" }
  ]
 },
 "/mba":{
  title: "MBA",
  metaTags: [
    { name: "description", content: "MBA curriculum is carefully designed to ensure a balance between theoretical knowledge and practical application. Students engage in rigorous coursework that combines lectures, case studies, group projects, and interactive discussions to ensure they develop critical thinking, problem-solving, and decision-making skills. The program also focuses on ethical leadership, effective communication, and a global perspective, preparing students to lead with integrity in a diverse and interconnected business environment. One of the great features of the MBA program is that it has a faculty comprised of renowned academics and experienced industry professionals. These acclaimed instructors bring a wealth of real-world expertise to the classroom, bridging the gap between theory and practice. Additionally,BBS group of institutions fosters a collaborative and inclusive learning environment, encouraging students to actively participate and learn from their peers. Core areas of expertise include:" }
  ]
 }
};
// export const BlogsData = [
//   {
//     id: "1",
//     title: "How Internships Help BBA Students Build Real Experience",
//     subTitle:
//       "We all read a lot in our BBA (Bachelor of Business Administration) classes about marketing, finance, and management. But the truth is, reading about business is very different from living it. That’s why BBA internships matter so much. They give us a real look at how work actually happens, how teams deal with pressure, and how decisions are made in real offices. It’s like stepping out of theory and walking into real business life.",
//     image: "/blogImage/blogFeature.jpg",
//      alt:"Bba Feature",
//     link: "/blogs/bba-internships",
//     category: "Admissions",
//   },
//   {
//     id: 2,
//     title: "Top B.Tech Branches with the Best Career Opportunities",
//     subTitle:
//       "After clearing 12th boards, many Indian parents want their children to become engineers, but when students hear about the different branches of the B.Tech, they panic or get confused. In this confusion, they often end up picking the wrong branch because they do not fully understand the career opportunities linked with each option. Choosing becomes even tougher when every branch sounds important, and everyone around gives different advice. With the right information explained in a clear way, it becomes much easier to see which path actually fits your interests and future goals.",
//     image: "/blogImage/bestBtechCourse/btechBLogBanner.webp",
//      alt:"Best B.Tech Course Feature",
//     link: "blogs/best-btech-course-options",
//     category: "Campus Life",
//   },
//   {
//     id: 3,
//     title: "BA. LL.B. (Hons) 2026: Start Your Law Career with Full Course, Roles and Salary Guide",
//     subTitle:
//       "If you have ever watched a court scene and felt like you want to protect people’s rights or work on big company deals, then a future in law might excite you. BA. LL.B. (Hons) 2026 can help you build that future right after class 12th. This course gives knowledge of society and law together, with added focus on in depth legal study and research through honours papers. In this guide, you will find complete details on course duration, fees, syllabus, jobs, roles, and more. Think of it like a friendly road map for your law career.",
//     image: "/blogImage/baLLbCourse/llbBLogBanner.webp",
//      alt:"LLb Blog",
//     link: "blogs/ba-llb-hons-course",
//     category: "Campus Life",
//   },
//     {
//     id: 4,
//     title: "MBA 2026 Complete Guide: Course, Fees, and Career Scope",
//     subTitle:
//       "MBA is becoming more popular every year. In this blog we will explain why. We will show what an MBA course is, who it helps, how admissions work in India, the main types of programs, typical fees and duration, and the jobs you can get after. Read this and you will know which MBA course might suit you and how it can help your career.",
//     image: "/blogImage/mbaCourse/mbaBlockBanner.webp",
//      alt:"Mba Blog",
//     link: "blogs/mba-course",
//     category: "Campus Life",
//   },
//   {
//     id: 5,
//     title: "Comprehensive Guide on BCA Courses: Everything You Need To Know For Your Career",
//     subTitle:
//       "If you want to build your own software or apps and use those skills to earn well in the future, the BCA course is one of the most practical ways to start. It teaches you how technology works from the inside and to create one. This blog helps you understand every detail about the BCA course.",
//     image: "/blogImage/bcaCourseGuide/BlogBCACourse.webp",
//      alt:"BCA Course Blog",
//     link: "blogs/bca-course-guide",
//     category: "Campus Life",
//   },
//   {
//     id: 6,
//     title: "Best Jobs After MCA in India: Complete Career Guide",
//     subTitle:
//       "If you are worrying about jobs while doing MCA or BCA, that is actually a wise thought. Thinking early about your career gives you a clear edge. MCA offers a wide scope, but many students do not know which path to choose. This blog will help you understand the job options after MCA, the skills you should focus on, and how to move step by step toward a stable and satisfying career.",
//     image: "/blogImage/mcaJobs/BlogMCAJobs.webp",
//      alt:"Mca jobs Blog",
//     link: "blogs/mca-jobs",
//     category: "Campus Life",
//   },
//   {
//     id: 7,
//     title: "B.Tech in AI and ML: Complete Guide and Career Scope",
//     subTitle:
//       "Every day you use apps and tools that can learn from data and make smart decisions. If you want to know how these systems are built, B.Tech AI & ML teaches you the full process step by step. In this guide, you will learn what the course covers, what the syllabus includes, the tools you work with, the skills you develop, and the career options you can aim for.",
//     image: "/blogImage/btechAi/BtechBLogBanner.webp",
//      alt:"Btech ai blog",
//     link: "blogs/b-tech-ai-ml-complete-guide-career-scope",
//     category: "Campus Life",
//   },
//   {
//     id: 8,
//     title: "Best Jobs After B.Tech: Career Paths Explained",
//     subTitle:
//       "After B.Tech, the main question is which jobs after B.Tech to pick. Your branch, skills, college, and city decide a lot. In private companies in India, most freshers start at 3 to 6 LPA. Government and PSU jobs after B.Tech usually pay more (8+ LPA) but need exams like GATE. This guide lists real options branch by branch.",
//     image: "/blogImage/jobsAfterBtech/btechJobsBanner.webp",
//      alt:"Btech jobs blog",
//     link: "blogs/jobs-after-btech",
//     category: "Campus Life",
//   },
//   {
//     id: 9,
//     title: "Benefits of Internships During Engineering Studies",
//     subTitle:
//       "Want a fast way to prove you have real work skills, not just good marks? Engineering internships do that for you. They show you exactly how engineering jobs run in real life. They let you learn tools that are important on the job. They also help to find work after college. If you study engineering, doing one or two engineering internships while in college can shift how you think about your future job. It gets you much better prepared.",
//     image: "/blogImage/engineeringInternship/engineeringInternshipsBanner.webp",
//      alt:"Engineering Internships blog",
//     link: "blogs/engineering-internships",
//     category: "Campus Life",
//   },
//   {
//     id: 10,
//     title: "Steps to Start a Legal Career in India",
//     subTitle:
//       "Many people watch lawyers in court and wonder how they got there. The path to legal careers in India starts with good studies and real training. Legal careers are not just about courtrooms. They include corporate jobs, research, and even international work. Knowing the basic steps helps you see how legal careers begin and grow in India.",
//     image: "/blogImage/legalCareer/legalCareerBanner.webp",
//      alt:"Legal Career",
//     link: "blogs/legal-career",
//     category: "Campus Life",
//   },
//   {
//     id: 11,
//     title: "How to Select the Best Engineering College for Your Career ",
//     subTitle:
//       "Picking the right engineering college is a big deal for your future. A lot of students only look at entrance exam scores and skip other important stuff. A good college builds strong technical skills, gives real practice, and gets you ready for jobs. Before you decide on the best engineering colleges, compare them well with real facts.",
//     image: "/blogImage/bestEngineeringColleges/bestEngineeringCollegesBanner.webp",
//      alt:"Best Engineering Colleges",
//     link: "blogs/best-engineering-colleges",
//     category: "Campus Life",
//   }
// ];

export const BlogsDataCategory = [
  {
    id: 1,
    category: "Admissions",
  },
   {
    id: 2,
    category: "Campus Life",
  },
  {
    id: 3,
    category: "Courses & Careers",
  },
  {
    id: 4,
    category: "Study Tips",
  },
   {
    id: 5,
    category: "Placements",
  },
  {
    id: 6,
    category: "Skill development ",
  },
   {
    id: 7,
    category: "Events & Activities",
  },
   {
    id: 8,
    category: "Student Stories",
  }
];

// type Blog = {
//   id: number;
//   title: string;
//   description: string;
// };

// export const blogsData: Blog[] = [
//   {
//     id: 1,
//     title: "BBA Blog",
//     description: "BBA course, scope and career details.",
//   },
//   {
//     id: 2,
//     title: "BTech Blog",
//     description: "Engineering syllabus, colleges and future.",
//   },
//   {
//     id: 3,
//     title: "MBA Blog",
//     description: "MBA entrance, colleges and placements.",
//   },
// ];


// interface BlogPoint {
//   id: number;
//   text: string;
// }
// interface BlogTableRow {
//   id: number;
//   cols: string[];
//   link:string;
// }
// interface BlogFaq {
//   id: number;
//   question: string;
//   answer: string;
// }
// interface infoSections {
//   id: number;
//   title: string;
//   description: string;
// }

// interface BlogTable {
//   id: number;
//   headers: string[];    
//   rows: BlogTableRow[];     
// }
// interface BlogSteps {
//   id: number;
//   title: string;    
//   subTitle: string;
//      table?: BlogTable; 
//   subTitleLast?: string; 
//    subTitleLastHighlights?: string; 
//    documentsHeading?:string 
//   documents?:string[]    
// }

// type BlogSection ={
//       id: number;
//       heading?: string;
//       image?: string;
//       content?:string;
//       contentStart?: string;
//       contentLast?: string;
//       contentSections?:infoSections[]
//       points?: BlogPoint[]
//       tableSteps?:BlogSteps[]
//       table?: BlogTable;
//       showSerial?: boolean;
//       steps?:BlogSteps[];
//       isFaqs?:boolean;
//       faqs?: BlogFaq[];
//       hero?:boolean;
//       contentDescription?:any; // check markdown content
//     }

// export interface Blog1 {
//   id: number;
//   slug: string;
//   seo: {
//     title: any;
//     description: any;
//     keywords: any;
//   };
//   sections: BlogSection[];
// }

// export const blogsData1 :Blog1[]=[
// {
//     id: 1,
//     slug: "bba-internships",
//     seo: {
//       title: "How BBA Internship Builds Real Experience for Students",
//       description:
//         "Discover how a BBA internship helps students gain real work experience, develop skills, and explore top career opportunities after BBA across India.",
//       keywords: "BBA internship",
//     },

//     sections: [
//       {
//         id: 101,
//         hero:true,
//         heading: "How Internships Help BBA Students Build Real Experience",
//         content:
//           "We all read a lot in our [BBA](https://en.wikipedia.org/wiki/Bachelor_of_Business_Administration) (Bachelor of Business Administration) classes about marketing, finance, and management. But the truth is, reading about business is very different from living it. That’s why BBA internships matter so much. They give us a real look at how work actually happens, how teams deal with pressure, and how decisions are made in real offices. It’s like stepping out of theory and walking into real business life.",
//       },

//       {
//         id: 102,
//         heading: "What Is an Internship for BBA Students",
//         image: '/blogImage/blogBbaStudent.webp',
//         contentStart:
//           "A BBA internship is a short period during which we work with a company to learn how businesses run. It’s a chance to take what we study in class and use it in real situations. Usually, students do internships during holidays or in the final semesters of the BBA degree.",
//           contentLast:"We don’t just sit and watch others work. We get small tasks, attend meetings, and help with projects. It’s where we begin to know how the various departments talk, plan, and solve problems. Such an experience brings the lessons in our course in BBA to life and practicality."
//       },

//       {
//         id: 103,
//         heading: "Why Practical Experience Matters in BBA",
//         contentStart:"In business studies, knowing theory isn’t enough. We must understand how it works when it is with real money, time, and people. It is through BBA internships that we start to understand how ideas become outcomes. We notice how strategies are used in real settings.",
//         contentLast:"This mix of study and practice helps us grow faster and makes us more ready for real job opportunities after BBA.",
//         image: "/blogImage/BlogPractical.webp",
//         points: [
//           { id: 1, text: "We learn how teamwork builds progress." },
//           { id: 2, text: "We see how time, targets, and pressure shape daily work." },
//           { id: 3, text: "We understand what managers expect from new employees." },
//         ],
//       },
//       {
//         id: 104,
//         heading: "How Internships Bridge the Gap Between Theory and Practice",
//         image: "/blogImage/blogInternship.webp",
//         contentStart:
//           "Our BBA subjects teach us about business models, planning, and organization. But during a BBA internship, we see how all that fits together in real workplaces. It’s where theory meets practice.",
//          contentLast:"When we work with teams, handle reports, or assist with small decisions, we begin to understand what the books were trying to teach. This experience fills the gap between classroom lessons and real-world understanding." 
         
//       },
//       {
//         id: 105,
//         heading: "Learning How Real Businesses Work",
//         contentStart:"A BBA internship shows how companies actually run every day. We get to see how plans turn into actions and how every team has a role in reaching goals.",
//         contentLast:"All this helps us build a clear idea of how a company functions from start to finish.",
//         image: "/blogImage/blogBusinesses.webp",
//         points: [
//           { id: 1, text: "We learn about reporting and documentation." },
//           { id: 2, text: "We attend team discussions and observe coordination." },
//           { id: 3, text: "We see how performance is tracked and reviewed." },
//           { id: 4, text: "We notice how managers solve daily issues." },
//         ],
//       },
//     {
//         id: 106,
//         heading: "Building Key Management and Communication Skills",
//         contentStart:"Working in a company gives us a chance to build important soft skills that no textbook can teach. A BBA internship helps us become better at:",
//         contentLast:"These are the habits that shape how we work and communicate. Over time, they make us more capable and comfortable in professional spaces.",
//         image: "/blogImage/blogCommunication.webp",
//         points: [
//           { id: 1, text: "Writing simple, professional messages and reports." },
//           { id: 2, text: "Speaking clearly during meetings." },
//           { id: 3, text: "Listening and responding to feedback." },
//           { id: 4, text: "Handling small responsibilities with confidence." },
//         ],
//       },
//       {
//         id: 107,
//         heading: "Understanding Different Business Departments",
//         contentStart:"Every company has many parts working together. During a BBA internship, we see how these departments connect and depend on each other.",
//         contentLast:"Watching this teamwork helps us understand which area interests us the most. It also guides us when choosing a specialization later in our BBA course or career.",
//         image: "/blogImage/blogUnderstanding.webp",
//         points: [
//           { id: 1, text: "HR looks after hiring, training, and employee growth." },
//           { id: 2, text: "Finance keeps track of budgets and expenses." },
//           { id: 3, text: "Marketing studies customer needs and plans strategies." },
//           { id: 4, text: "Operations ensure smooth workflow and quality output." },
//         ],
//       },
//       {
//         id: 108,
//         heading: "Exploring Career Interests and Strengths",
//         contentStart :"Internships are an excellent alternative to determining what sort of work to be in. Some of us love people, whereas others like data or planning. The actual employment reveals our strengths and the areas we should improve on.",
//           contentLast:"This specificity assists in case we have to plan on the next step after having done our BBA, may it be during higher studies or completing an online course, or seeking job opportunities. It is a clever method of determining where we will fit better in the business world.",
//       },
//       {
//         id: 109,
//         heading: "Networking With Industry Professionals",
//         contentStart:
//           "During a BBA internship, we meet people already working in the field. These connections can be useful later. Good communication and teamwork during this time can build relationships that open doors in the future.",
//           contentLast:"We learn how to introduce ourselves, talk with professionals, and build trust. These are small steps that often lead to bigger opportunities later in our journey.",
//       },
//        {
//         id: 110,
//         heading: "Boosting Resume and Job Opportunities",
//         contentStart:"A BBA internship adds strong value to our resume. It shows we’ve already worked in a real business environment, even if only for a short time.",
//         contentLast:"Employers prefer people who already understand how offices work, and internships help us become exactly that.",
//         image: "/blogImage/blogResume.webp",
//         points: [
//           { id: 1, text: "It helps us talk confidently in interviews." },
//           { id: 2, text: "It gives us stories of real experience to share." },
//           { id: 3, text: "It proves we understand the basics of teamwork and deadlines." },
//           { id: 4, text: "It gives us a clear edge over other freshers applying for the same job opportunities." },
//         ],
//       },
//       {
//         id: 111,
//         heading: "Developing Professional Confidence and Work Habits",
//         contentStart:"Professional habits take time to build, and BBA internships help us form them early.",
//         contentLast:"Such habits define how we behave in all our future roles. Most of the students observe that they are able to work more efficiently than before, are able to talk better, and think more practically after an internship.",
//         image: "/blogImage/blogDevelop.webp",
//         points: [
//           { id: 1, text: "We learn to be punctual and organized." },
//           { id: 2, text: "We manage tasks with discipline." },
//           { id: 3, text: "We accept feedback without fear." },
//           { id: 4, text: "We take responsibility and initiative." },
//         ],
//       },
//       {
//         id: 112,
//         heading: "How to Find and Choose the Right Internship",
//         contentStart:"It is not difficult to find the right internship when it is planned. Begin by asking them which aspect of business is the most interesting to them: finance, marketing, HR, or operations. You see, we know that, and we may take simple measures:",
//         contentLast:"A well-chosen internship teaches more than we expect, and the lessons stay with us throughout our BBA degree and beyond.",
//         points: [
//           { id: 1, text: "Make a clear, short resume that highlights our skills." },
//           { id: 2, text: "Ask teachers, seniors, or alumni for guidance." },
//           { id: 3, text: "Look for internships that match our specialization." },
//           { id: 4, text: "Read internship details carefully, including duration, learning goals, and work type." },
//                { id: 5, text: "Set small personal goals like improving writing, speaking, or teamwork." },
//         ],
//       },
//       {
//         id: 113,
//         heading: "Why BBS College Is a Good Choice for BBA Students",
//         image: "/blogImage/blogGoodChoice.webp",
//         content:
//           "At [BBS College](/), we focus on helping students learn both from books and real-life experiences. We give practical training, workshops, and BBA internship opportunities so students can use what they study in real work situations. Our teachers are experienced, the course is updated, and we give strong support for jobs. With modern classrooms, industry visits, and skill-based learning, BBS College helps students grow and get ready for good career opportunities after BBA." 
//       },
//        {
//         id: 114,
//         heading: "Conclusion",
//         content:
//           "A BBA internship is not considered of achieving experience. It is up to creating a good base to develop. It not only makes it easier to know how business is, but it also instills successful habits and enables us to earn better pay and scope of work in the future.",
//           contentStart:"Internships turn lessons from our [BBA course](/bba) into real skills. They make us have confidence, recognize more easily, and equip us for the next phase of life.",
//           contentLast:"For every student aiming to grow after BBA, an internship is more than a task; it’s the first real step into the world of business."
//       },

//     ],
//   },
//   {
//     id: 2,
//     slug: "best-btech-course-options",
//     seo: {
//       title: "Top B.Tech Branches with the Best Career Opportunities",
//       description:
//         "Discover the top B.Tech best course options, career paths and branches to choose after 12th. Learn which engineering field offers strong growth and jobs.",
//         keywords:""
//     },

//    sections: [
//       {
//         id: 201,
//         hero:true,
//         heading: "Top B.Tech Branches with the Best Career Opportunities",
//         content:
//           "After clearing 12th boards, many Indian parents want their children to become engineers, but when students hear about the different branches of the B.Tech, they panic or get confused. In this confusion, they often end up picking the wrong branch because they do not fully understand the career opportunities linked with each option. Choosing becomes even tougher when every branch sounds important, and everyone around gives different advice. With the right information explained in a clear way, it becomes much easier to see which path actually fits your interests and future goals.",
//       },

//       {
//         id: 202,
//         heading: "What is B.Tech",
//         content:"B.Tech is a four-year engineering degree where you learn to solve real problems using science and technology. These four years include classroom learning, lab work, and practical tasks. Each branch has its own subjects, its own course details, and its own type of jobs. Before taking admission in India, you should check the duration, fees, subjects, and job roles associated with the branch you want. When you understand these things, choosing the B.Tech best course becomes easier.",
//       },
//       {
//         id: 203,
//         heading: "Computer Science Engineering",
//         image: "/blogImage/bestBtechCourse/computerScienceEngineering.webp",
//         content:"Computer Science is one of the most common branches because almost every company uses software and digital systems. CSE is a four-year course that covers programming, software design, networks, systems, and many computer-related subjects. Students who enjoy logical thinking usually feel comfortable here. CSE often appears in many courses' lists when students search for the best B.Tech course.",
//       },

//       {
//         id: 204,
//         heading: "Best Career Opportunities",
//         points: [
//           { id: 1, text: "Software development" },
//           { id: 2, text: "Front-end or back-end roles" },
//           { id: 3, text: "System and architecture planning" },
//           { id: 4, text: "Network and security work" },
//           { id: 5, text: "Mobile app development" },
//           { id: 6, text: "Cloud and server handling" },
//           { id: 7, text: "Software testing and quality checks" },
//         ],
//       },
//       {
//         id: 205,
//         heading: "Artificial Intelligence and Machine Learning",
//         image: "/blogImage/bestBtechCourse/machineLearning.webp",
//         content:"AI and ML teach you how to build systems that learn and make decisions on their own. This four-year degree covers algorithms, neural networks, automation, and data training. Many students look at this branch when they want a B.Tech best course linked with future technology.",
//       },
// {
//         id: 206,
//         heading: "Best Career Opportunities",
//         points: [
//           { id: 1, text: "AI model training" },
//           { id: 2, text: "Machine learning engineer" },
//           { id: 3, text: "Natural language work" },
//           { id: 4, text: "Computer vision projects" },
//           { id: 5, text: "Automation system roles" },
//           { id: 6, text: "Research in computing" },
//           { id: 7, text: "Predictive analytics" },
//         ],
//       },
//       {
//         id: 207,
//         heading: "Data Science Engineering",
//         image: "/blogImage/bestBtechCourse/datascienceengineering.webp",
//         content:"Data Science focuses on understanding large sets of information. Students learn statistics, data cleaning, pattern study, and tools used to make business decisions. This branch also takes four years and suits students who like numbers. It is often chosen by those searching for the B.Tech. best course for data-based careers.",
//         contentStart:
//           "",
//          contentLast:"" 
//       },
//       {
//         id: 208,
//         heading: "Best Career Opportunities",
//         points: [
//           { id: 1, text: "Data analyst" },
//           { id: 2, text: "Data engineer" },
//           { id: 3, text: "Business intelligence" },
//           { id: 4, text: "ML data support" },
//           { id: 5, text: "Data visualization" },
//           { id: 6, text: "Research-based modeling" },
//           { id: 7, text: "Risk study roles" },
//         ],
//       },
//       {
//         id: 209,
//         heading: "Electronics and Communication Engineering",
//         image: "/blogImage/bestBtechCourse/electronicsEngineering.webp",
//         content:"ECE teaches circuits, electronic devices, signals, and communication systems. It is linked with mobile networks, IoT, and hardware design. This four-year branch suits students who enjoy working with electronic tools and systems.",
//       },
//       {
//         id: 210,
//         heading: "Best Career Opportunities",
//         points: [
//           { id: 1, text: "Network planning" },
//           { id: 2, text: "Embedded system work" },
//           { id: 3, text: "Chip and microcontroller design" },
//           { id: 4, text: "Signal processing" },
//           { id: 5, text: "IoT testing" },
//           { id: 6, text: "Electronic device checks" },
//           { id: 7, text: "Hardware support" },
//         ],
//       },
//       {
//         id: 211,
//         heading: "Electrical & Electronics Engineering",
//         image: "/blogImage/bestBtechCourse/electricalEngineering.webp",
//         content:"Electrical & Electronics Engineering deals with power, wiring, machines, and large electrical systems. It is one of the oldest branches and still has a strong demand. This four-year degree is preferred by students who want stable job options across many sectors.",
//       },
//       {
//         id: 212,
//         heading: "Best Career Opportunities",
//         points: [
//           { id: 1, text: "Power plant operation" },
//           { id: 2, text: "Electrical design" },
//           { id: 3, text: "Control system engineering" },
//           { id: 4, text: "Energy management" },
//           { id: 5, text: "Industrial automation" },
//           { id: 6, text: "Electrical safety" },
//           { id: 7, text: "Renewable energy projects" },
//         ],
//       },
//       {
//         id: 213,
//         heading: "Mechanical Engineering",
//         image: "/blogImage/bestBtechCourse/mechanicalEngineeringatBBS.webp",
//         content:"Mechanical Engineering covers machines, engines, tools, and equipment. Students learn how different parts work together and how movement is created. This four-year degree is chosen by students who enjoy building things and understanding physical systems. It often appears in the B.Tech best course list because of its wide job range.",
//       },
//       {
//         id: 214,
//         heading: "Best Career Opportunities",
//         points: [
//           { id: 1, text: "Machine design" },
//           { id: 2, text: "Production and manufacturing" },
//           { id: 3, text: "Quality testing" },
//           { id: 4, text: "Thermal system maintenance" },
//           { id: 5, text: "Automotive industry work" },
//           { id: 6, text: "Industrial equipment planning" },
//           { id: 7, text: "Research in materials" },
//         ],
//       },
//       {
//         id: 215,
//         heading: "Civil Engineering",
//         image: "/blogImage/bestBtechCourse/civilEngineering.webp",
//         content:"Civil Engineering focuses on building roads, bridges, buildings, and other structures. Students who like field work and project-based tasks usually choose this four-year branch. It is one of the core engineering branches in India.",
//       },
//       {
//         id: 216,
//         heading: "Best Career Opportunities",
//         points: [
//           { id: 1, text: "Building planning" },
//           { id: 2, text: "Construction supervision" },
//           { id: 3, text: "Surveying and layout" },
//           { id: 4, text: "Structural analysis" },
//           { id: 5, text: "Water and waste planning" },
//           { id: 6, text: "Transport system design" },
//           { id: 7, text: "Quality inspection" },
//         ],
//       },
//       {
//         id: 217,
//         heading: "Information Technology",
//         image: "/blogImage/bestBtechCourse/informationTechnology.webp",
//         content:"IT is close to computer science but more focused on systems, networks, and practical computer use. This four-year degree suits students who enjoy hands-on work. Many prefer IT while searching for the B.Tech best course in private college options.",
//       },
//       {
//         id: 218,
//         heading: "Best Career Opportunities",
//         points: [
//           { id: 1, text: "System administration" },
//           { id: 2, text: "IT support" },
//           { id: 3, text: "Network setup" },
//           { id: 4, text: "Cybersecurity" },
//           { id: 5, text: "Database management" },
//           { id: 6, text: "Cloud service work" },
//           { id: 7, text: "Software testing" },
//         ],
//       },
//       {
//         id: 219,
//         heading: "Biotechnology Engineering",
//         image: "/blogImage/bestBtechCourse/biotechnologyEngineering.webp",
//         content:"Biotechnology mixes biology with technology. Students learn genetics, microbiology, and lab-based subjects. This four-year degree is ideal for students who like biology and want jobs related to research or development.",
//       },
//       {
//         id: 220,
//         heading: "Best Career Opportunities",
//         points: [
//           { id: 1, text: "Lab research" },
//           { id: 2, text: "Food and agriculture research" },
//           { id: 3, text: "Bio product development" },
//           { id: 4, text: "Environmental testing" },
//           { id: 5, text: "Genetic study" },
//           { id: 6, text: "Quality checks" },
//           { id: 7, text: "Enzyme and chemical development" },
//         ],
//       },
//       {
//         id: 221,
//         heading: "Robotics and Automation",
//         image: "/blogImage/bestBtechCourse/roboticsandAutomation.webp",
//         content:"Robotics and Automation teaches how to build automated machines and systems. Students learn sensors, programming, mechanics, and control systems. This four-year branch is growing fast because industries are moving toward automation.", 
//       },
//       {
//         id: 222,
//         heading: "Best Career Opportunities",
//         points: [
//           { id: 1, text: "Robot design" },
//           { id: 2, text: "Automation engineering" },
//           { id: 3, text: "Sensor development" },
//           { id: 4, text: "Industrial robotics" },
//           { id: 5, text: "Smart machine research" },
//           { id: 6, text: "Vision-based programming" },
//           { id: 7, text: "Tool testing" },
//         ],
//       },
//        {
//         id: 223,
//         heading: "Which B. Tech Course Is Best",
//         image: "/blogImage/bestBtechCourse/bestBTechCollege.webp",
//         contentStart:
//           "There is no single best B. Tech course that works for every student. The right choice depends on what you enjoy, the subjects you like, the entrance exam you want to prepare for, the fees you can manage, and the kind of jobs you want later. If you like coding, CSE, IT, or AI may work well. If you like machines, mechanical or robotics may feel right. If you like circuits, electrical or ECE may be better. Students who enjoy biology often choose biotechnology. Look at the details, understand the duration, and choose the branch that fits your long-term goals.",
//          contentLast:"If you want the right start in engineering, explore [BBS College](/). It is known among the best engineering colleges in UP and offers courses that help you build clear skills and a stable future." 
//       },
//      {
//         id: 224,
//         heading: "Conclusion",
//         content:
//           "B.Tech has numerous branches, and each branch is going to give a new kind of future. When you know what each branch teaches and how it relates to the jobs, it would be much easier to choose the best B.Tech course. Instead, take some time and reflect on what you are interested in, your strengths, and what you will do once you have completed your degree. A good beginning may bring a good and sound career in engineering in the future.",
//       },

//     ],
//   },
//   {
//     id: 3,
//     slug: "ba-llb-hons-course",
//     seo: {
//       title: "BA LLB 2026 Course Details, Eligibility, Fees, Jobs & Salary",
//       description:
//         "Explore BA LLB 2026 course details, eligibility, age limit, fees, syllabus, subjects, career roles and salary. Simple guide to start your law career.",
//         keywords:""
//     },

//     sections: [
//       {
//         id: 301,
//         hero:true,
//         heading:
//           "BA. LL.B. (Hons) 2026: Start Your Law Career with Full Course, Roles and Salary Guide",
//         content:
//           "If you have ever watched a court scene and felt like you want to protect people’s rights or work on big company deals, then a future in law might excite you. [BA. LL.B.](https://en.wikipedia.org/wiki/Bachelor_of_Laws) (Hons) 2026 can help you build that future right after class 12th. This course gives knowledge of society and law together, with added focus on in depth legal study and research through honours papers. In this guide, you will find complete details on course duration, fees, syllabus, jobs, roles, and more. Think of it like a friendly road map for your law career.",
          
//       },
// {
//         id: 302,
//         heading: "What is BA. LL.B. (Hons)",
//         image: "/blogImage/baLLbCourse/whatsBaLLb.webp",
//         content:"BA. LL.B. (Hons) 2026 is a 5 year integrated law course where you study arts and legal subjects together in one degree. You do not need to complete a separate BA first. Along with general law learning, the course allows deeper study in selected law areas, helping you build stronger subject clarity."
//       },
//       {
//         id: 303,
//         heading: "Why choose BA. LL.B. (Hons) in 2026",
//         points: [
//           { id: 1, text: "Strong demand for legal experts in India" },
//           { id: 2, text: "Growth in cyber safety and corporate legal jobs" },
//           { id: 3, text: "More career options in the government and private fields" },
//           { id: 4, text: "Saves time compared to doing two separate degrees" },
//           { id: 5, text: "Helpful if you later want to become a judge or do an LLM" },
//         ],
//       },
//       {
//         id: 304,
//         heading: "Course Highlights",
//         image: "/blogImage/baLLbCourse/courses.webp",
//       },
//         {
//         id: 305,
//         heading: "Duration and Course Structure",
//         contentLast:"This structure helps students learn theory and real world practical skills together.",
//         table: {
//           id: 1,
//           headers: ["Feature", "Details"],
//           rows: [
//             { id: 1, cols: ["Course Duration", "5 years full time"],link:""
//              },
//             { id: 2, cols: ["Time Period", "10 semesters"], link:"" },
//             { id: 3, cols: ["Learning Mode", "Classroom plus training"], link:"" },
//             { id: 4, cols: ["Key Activities", "Moot courts, internships, drafting, court visits"], link:"" },
//           ],
//         },
//       },
//       {
//         id: 306,
//         heading: "Integrated Degree Benefits",
//         points: [
//           { id: 1, text: "One combined course instead of BA plus LLB" },
//           { id: 2, text: "Humanities knowledge helps in legal reasoning" },
//           { id: 3, text: "Better understanding of clients and society" },
//           { id: 4, text: "Saves one full year compared to separate degrees" }
//         ],
//       },
//       {
//         id: 307,
//         heading: "Subjects You Will Study (Year wise)",
//         contentStart:"You will study different subjects each year. Here is a simple view.",
//         contentLast:"The syllabus gives skills that help in courts and company jobs.",
//          table: {
//           id: 2,
//           headers: ["Year", "Focus Area", "Subjects"],
//           rows: [
//             {
//               id: 1,
//               cols: ["1 and 2", "Basics of Arts and Law", "Sociology, Political Science, English, History, Constitutional Law"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["3", "Main Law Foundation", "Criminal Law, Civil Procedures, Family Law, Contracts, Property Law"],
//                link:""
//             },
//             {
//               id: 3,
//               cols: ["4", "Corporate and Administrative Laws", "Company Law, Tax Law, Labour Law, Administrative Law"],
//                link:""
//             },
//             {
//               id: 4,
//               cols: ["5", "Advanced Legal Areas", "Cyber Law, IPR, International Law, Legal Drafting, Practical Clinics"],
//                link:""
//             }
//           ],
//         },
//       },
//  {
//         id: 308,
//         heading: "Skills You Will Learn",
//         contentLast:"These benefits help a lot in both jobs and higher studies.",
//         points: [
//           { id: 1, text: "Strong writing and communication" },
//           { id: 2, text: "Public speaking" },
//           { id: 3, text: "Legal research" },
//           { id: 4, text: "Logical thinking" },
//           { id: 5, text: "Case handling and problem solving" }
//         ],
//       },
//        {
//         id: 309,
//         heading: "Eligibility and Admission Process",
//         image: "/blogImage/baLLbCourse/admission.webp",
//         showSerial: true,
//           steps: [
//         {
//           id: 1,
//           title: "12th Marks Requirement",
//           subTitle:
//             "To join BA. LL.B. (Hons) 2026, students should have 50 to 55 percent marks in class 12. Some relaxation may apply for reserved category students as per rules.",
//             },
//         {
//           id: 2,
//           title: "Age Limit",
//           subTitle:
//             "Most entrance exams do not keep a strict age limit now, so any student after 12th can apply.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Entrance Exams for BA. LL.B. (Hons)",
//           subTitle:
//             "Some colleges take admission through national or state entrance tests. Scores play an important role in top colleges.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 4,
//           title: "Direct Admission in Private Colleges",
//           subTitle:
//             "Some private colleges offer admission based on class 12 marks or their own selection process.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 5,
//           title: "Documents Needed",
//           subTitle: "Keep these ready at the time of counseling or admission.",
//           documentsHeading:"",
//           documents: [
//             "Class 10 and 12 mark sheets",
//             "ID proof",
//             "Passport size photographs",
//             "Entrance exam scorecard (if applicable)",
//             "Caste certificate (if required)",
//           ],
//         },
//       ],
//       },
//       {
//         id: 310,
//         heading: "Top Entrance Exams for BA. LL.B. (Hons)",
//         contentLast:"These exams check how well you understand logic, English and general knowledge.",
// table: {
//           id: 1,
//           headers: ["Exam Name", "Who Accepts It", "Key Focus"],
//           rows: [
//             {
//               id: 1,
//               cols: ["CLAT", "National Law Universities", "Legal aptitude, GK, reasoning"],
//               link:"https://consortiumofnlus.ac.in/clat-2026/",
//             },
//             {
//               id: 2,
//               cols: ["AILET", "NLU Delhi", "Law and reasoning based test"],link:"https://nationallawuniversitydelhi.in/",
//             },
//             {
//               id: 3,
//               cols: ["CUET", "Central Universities", "General test and subjects"],
//               link:"https://cuet.nta.nic.in/",
//             },
//             {
//               id: 4,
//               cols: ["LSAT India", "Private universities", "Analytical and logical skills"],  
//               link:"https://www.lsac.org/blog/tag/lsat-india",
//             },
//             {
//               id: 5,
//               cols: ["State Law Exams", "State colleges", "Varies by state pattern"],
//               link:""
//             },
//           ],
//         },
//       },
//       {
//         id: 311,
//         heading: "Fee Structure in Government and Private Colleges",
//         contentSections:[
//   {
//     id: 1,
//     title: "Average Fees for Government Colleges: ",
// description:"₹ 20,000 to ₹2 lakh for the full course duration."

//   },
//    {
//     id: 2,
//       title: "Average Fees Private Colleges:",
// description:"3 lakh to 15 lakh, depending on location, reputation, and facilities."
//   }
// ],
//         image: "/blogImage/baLLbCourse/fees.webp", 
//       },
//       {
//         id: 312,
//         contentLast:"Always compare fees, placements, and training before selecting any college.",
//         table: {
//           id: 2,
//           headers: ["College Type", "Approx Fees"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Government", "Low and affordable"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["Private", "Higher but better campus facilities"],
//                link:""
//             }
//           ],
//         },
//       },
//        {
//         id: 313,
//         heading: "Syllabus Overview",
//         showSerial: true,
//          contentLast:"All these details make BA. LL.B. (Hons) 2026 a complete practical course." ,
//           steps: [
//         {
//           id: 1,
//           title: "Core Law Subjects",
//           subTitle:
//             "",
//             documentsHeading:"",
//           documents: ["Constitution","Crimes and Punishments","Civil laws","Contracts and companies","Labour and taxation rules"],
//         },
//         {
//           id: 2,
//           title: "Arts and Humanities Subjects",
//           subTitle:
//             "",
//             documentsHeading:"",
//           documents: ["History of society","Economics and business basics","Political systems","English writing and speaking"],
//         },
//         {
//           id: 3,
//           title: "Moot Court and Internships",
//           subTitle:
//             "Students argue in a training court to build confidence. Internships under lawyers or firms give real case experience.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 4,
//           title: "Practical Training and Court Visits",
//           subTitle:
//             "Watching real hearings helps understand how judges, police, and lawyers actually work.",
//             documentsHeading:"",
//           documents: [],
//         }
//       ],
//       },
//       {
//         id: 314,
//         heading: "Career Paths After BA. LL.B. (Hons)",
//         contentSections:[
//   {
//     id: 1,
//     title: "Advocate",
// description:"Argue cases in courts and help clients get justice."

//   },
//    {
//     id: 2,
//       title: "Legal Advisor in Companies",
// description:"Guide companies on contracts and compliance so they follow rules safely."
//   },
//   {
//     id: 3,
//       title: "Government Law Jobs",
// description:"Work in public prosecution or legal offices that handle government legal matters."
//   },
//   {
//     id: 4,
//        title: "Judiciary Preparation",
// description:"After BA. LL.B. Hons 2026, you can prepare for Civil Judge exams to become a judicial officer."
//   },
//   {
//     id: 5,
//        title: "Corporate Law and Big Law Firms",
// description:"Work on business deals like mergers, finance and technology regulations."
//   },
//   {
//     id: 6,
//        title: "Legal Journalism and LPO",
// description:"Write news articles related to law or support international legal work through outsourcing companies."
//   }
// ],
//         image: "/blogImage/baLLbCourse/careerPath.webp",
//       },
//       {
//         id: 315,
//         heading: "Salary After BA. LL.B. (Hons)",
//          tableSteps: [
//         {
//           id: 1,
//           title: "Salary in Litigation",
//           subTitle:
//             "Income depends on clients and cases. Experience brings bigger earnings.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Salary in Companies",
//           subTitle:
//             "Corporate roles offer stable pay and clearer promotion plans.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Starting Salary vs Experienced Salary",
//           subTitle:
//             "Freshers earn less but skilled lawyers build strong earning power with time.",
//             documentsHeading:"",
//           documents: [],
//         }
//       ],
//         table: {
//           id: 2,
//           headers: ["Field", "Starting Salary", "Growth with Experience"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Litigation", "Low at first", "Very high with success"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["Corporate Jobs", "3 to 6 lakh per year", "10 to 20 lakh or more"],
//                link:""
//             },
//             {
//               id: 3,
//               cols: ["Govt Legal Jobs", "Fixed pay scale", "Regular promotions"],
//                link:""
//             },
            
//           ],
//         },
//       },
//         {
//         id: 316,
//         heading: "Future Scope of Law in India",
//         image: "/blogImage/baLLbCourse/futureScope.webp",
//          showSerial: true,
//           steps: [
//         {
//           id: 1,
//           title: "Growth in the Legal Sector",
//           subTitle:
//             "More businesses and new rules are creating increased demand for lawyers",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "High Demand in Corporate and Tech Law",
//           subTitle:
//             "Cybersecurity, fintech companies, and data protection laws need trained lawyers.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "International Opportunities",
//           subTitle:
//             "After BA. LL.B. Hons 2026, you can study or work abroad by clearing the required exams of that country.",
//             documentsHeading:"",
//           documents: [],
//         }
//       ],
//       },
//        {
//         id: 317,
//         heading: "How to Prepare for BA. LL.B. (Hons) Admission",
//         image: "/blogImage/baLLbCourse/prepareForLLb.webp",
//          showSerial: true,
//          contentLast:"Good books make your preparation strong and save a lot of time." ,
//           steps: [
//         {
//           id: 1,
//           title: "Focus Subjects in 12th",
//           subTitle:
//             "English and social science topics help in understanding legal subjects.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Entrance Exam Preparation Tips",
//           subTitle:
//             "",
//             documentsHeading:"",
//           documents: ["Read newspapers daily","Practice reasoning and maths basics","Try online mock tests","Solve previous papers"],
//         },
//         {
//           id: 3,
//           title: "Useful Books and Study Sources",
//           subTitle:
//             "You can use",
//             documentsHeading:"",
//           documents: ["NCERT books for basics","Logical reasoning books","Current affairs monthlies","Online platforms for practice"],
//         }
//       ],
//       },
//       {
//         id: 318,
//         heading: "Job Roles After BA. LL.B. (Hons)",
//         contentLast:"Each job role has a different work style and earnings. You can choose based on interest.",
//         table: {
//           id: 1,
//           headers: ["Job Role", "Work Area"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Criminal Lawyer", "Crime related cases"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["Civil Lawyer", "Land, money and disputes"],
//                link:""
//             },
//             {
//               id: 3,
//               cols: ["Corporate Lawyer", "Business and company matters"],
//                link:""
//             },
//             {
//               id: 4,
//               cols: ["Family Lawyer", "Divorce, marriage, and family issues"],
//                link:""
//             },
//             {
//               id: 5,
//               cols: ["Property Lawyer", "Real estate and ownership"],
//                link:""
//             },
//             {
//               id: 6,
//               cols: ["Cyber Crime Lawyer", "Internet fraud and hacking cases"],
//                link:""
//             },
            
//           ],
//         },
//       },
//         {
//         id: 319,
//         heading: "Final Advice for BA. LL.B. (Hons) Aspirants",
//          showSerial: true,
//         contentStart:
//           "Students who enjoy reading, researching, and helping others with fair solutions.",
//          contentLast:"This course gives you many opportunities, but dedication is the most important part." ,
//           steps: [
//         {
//           id: 1,
//           title: "Tips for Success in a Law Career",
//           subTitle:
//             "English and social science topics help in understanding legal subjects.",
//             documentsHeading:"",
//           documents: ["Keep improving communication","Do internships every year","Make a good network of senior lawyers","Stay updated on new topics and laws"],
//         }
//       ],
//       },
//        {
//         id: 320,
//         heading: "Conclusion",
//         content:`BA. LL.B. Hons 2026 can launch your law career with a strong foundation. This course combines arts knowledge with legal training, enabling you to understand both society and law. It offers many career paths in courts, government, and global companies. If you are ready to learn with passion and patience, this journey can lead to a respected and rewarding profession.If you are planning to study law, [BBS College](/) can be a smart choice. It is known as one of the [best college for LLB in UP](/llb), offering quality learning and practical legal training`,
//       },
//       {
//         id: 321,
//         isFaqs:true,
//         heading: "FAQs",
//         faqs: [
//           {
//             id: 1,
//             question: " Why choose BA LL.B. (Hons) over regular BA LL.B.",
//             answer:
//               "BA LL.B. (Hons) offers deeper study in selected law subjects and includes research work. It is more valued by big law firms, while regular BA LLB gives more general legal knowledge.",
//           },
//           {
//             id: 2,
//             question: "Difference between LLB and BA LLB",
//             answer:
//               "LLB is a 3 year law course done after graduation. BA LLB is a 5 year integrated course done after class 12 with arts and law together.",
//           },
//            {
//             id: 3,
//             question: "Is BA LLB a good course",
//             answer:
//               "Yes, BA LLB is a good course for students who want a career in law. It offers many job options in courts, companies, and government offices.",
//           },
//            {
//             id: 4,
//             question: "What will happen after BA LLB course",
//             answer:
//               "After BA LLB, you can work as a lawyer, join companies as legal staff, prepare for judge exams, apply for government jobs, or study further like LLM.",
//           },
//         ],
//       },
//     ],
//   },
//   {
//     id: 4,
//     slug: "mba-course",
//     seo: {
//       title: "MBA 2026 Complete Guide: Courses, Fees, Eligibility, Career Scope",
//       description:
//         "Learn about MBA courses in India for 2026. Know eligibility, fees, duration, types of MBA, and career growth to choose the right MBA course for your future.",
//         keywords:""
//     },

//     sections: [
//       {
//         id: 401,
//         hero:true,
//         heading:
//           "MBA 2026 Complete Guide: Course, Fees, and Career Scope",
//         content:
//           "MBA is becoming more popular every year. In this blog we will explain why. We will show what an MBA course is, who it helps, how admissions work in India, the main types of programs, typical fees and duration, and the jobs you can get after. Read this and you will know which MBA course might suit you and how it can help your career.",
          
//       },
// {
//         id: 402,
//         heading: "What is MBA Course",
//         image: "/blogImage/mbaCourse/mba.webp",
//         contentStart:
//           "An MBA course teaches how businesses run. It mixes practical skills and theory. In an MBA course we learn finance basics, marketing ideas, operations, people management, and strategy.Most programs use case studies, group work, projects, and internships so you can apply what you learn.",
//       },
//       {
//         id: 403,
//         heading: "Why MBA Still Matters in 2026",
//         points: [
//           { id: 1, text: "Managers use data and tools more now, so an MBA course helps build tech aware leadership." },
//           { id: 2, text: "It lets people move from specialist roles to management faster." },
//           { id: 3, text: "For founders, MBA courses give structure in finance, planning, and go-to-market strategy." }
//         ],
//       },
//       {
//         id: 404,
//         heading: "Who Should Do an MBA",
//         image: "/blogImage/mbaCourse/anMba.webp",
//         content:"Not everyone needs an MBA course. We think it fits people who want to move into management, change fields, or start a business.",
//       },
//         {
//         id: 405,
//         heading: "Skills MBA Helps You Build",
//         points: [
//           { id: 1, text: "Strategic thinking and planning" },
//           { id: 2, text: "Communication and team leading" },
//           { id: 3, text: "Basic finance and budgeting" },
//           { id: 4, text: "Data reading and decision making" }
//         ],
//       },
//         {
//         id: 406,
//         heading: "Career Goals MBA Fits Best",
//         points: [
//           { id: 1, text: "Move from technical role to project or people management" },
//           { id: 2, text: "Switch function or industry" },
//           { id: 3, text: "Build a startup with business know-how" },
//         ],
//       },
//       {
//         id: 407,
//         heading: "Eligibility for MBA 2026",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Basic Education Requirements",
//           subTitle:
//             "Most MBA courses ask for a bachelor's degree from a recognised university. Marks needed vary by program. For integrated programs see the details below.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Work Experience Rules",
//           subTitle:
//             "",
//             documentsHeading:"",
//           documents: ["Full time MBA accepts freshers and early career professionals.","Executive MBA is for mid or senior managers.","Part time and online formats welcome working learners."],
//         },
//         {
//           id: 3,
//           title: "Age Limits and Flexibility",
//           subTitle:
//             "",
//             documentsHeading:"",
//           documents: ["There is usually no strict age limit. Many courses are flexible to fit different life stages"],
//         }
//       ],
//       },
//       {
//         id: 408,
//         heading: "MBA Admission Process 2026",
//         image: "/blogImage/mbaCourse/admissionProcess.webp",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Entrance Exams Overview",
//           subTitle:
//             "Many programs use entrance tests that check verbal, quantitative, and logical skills. These scores remain a major part of selection.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Direct Admission Options",
//           subTitle:
//             "Some courses offer seats through academic record, interviews, or management quotas. Rules differ by program.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Selection Stages Explained",
//           subTitle:
//             "",documentsHeading:"",
//           documents: ["Test score or written exam","Personal interview or group discussion","Essays or statement of purpose in some programs","Review of academic and work record"],
//         }
//       ],
//       },
//         {
//         id: 409,
//         heading: "Types of MBA Courses List and Details",
//         contentLast:"This list helps you match the right format to your life stage and goals.",
//         table: {
//           id: 1,
//           headers: ["Course Type", "Typical Duration","Who it suits","Mode"],
//           rows: [
//             { id: 1, cols: ["Full Time MBA", "2 years","Fresh graduates and early professionals","On campus"],link:""
//              },
//             { id: 2, cols: ["Part Time MBA", "2–4 years","Working professionals","Evenings or weekends"], link:"" },
//             { id: 3, cols: ["Executive MBA", "1–2 years","Senior managers with experience","Weekend or modular"], link:"" },
//             { id: 4, cols: ["Online MBA", "1–2 years","Anyone needing flexibility","Fully online"], link:"" },
//             { id: 5, cols: ["Distance MBA", "2–3 years","Those who cannot attend campus","Correspondence or blended"], link:"" },
//             { id: 6, cols: ["Integrated MBA", "5 years","Students after Class 12 (Higher Secondary)","Straight entry from school"], link:"" },
//           ],
//         },
//       },
//       {
//         id: 410,
//         heading: "MBA Specialisations Explained",
//         contentStart:"We often choose a specialization so we gain deep skills in one area. Common options include:",
//         contentLast:"Pick a specialization that aligns with your skills and demand in the industry.",
//         image: "/blogImage/mbaCourse/mbaSpecialisations.webp",
//         points: [
//           { id: 1, text: "Finance: corporate finance, investments, risk management." },
//           { id: 2, text: "Marketing: brand building, digital marketing, sales strategy." },
//           { id: 3, text: "Human Resource Management: hiring, training, culture." },
//           { id: 4, text: "Operations Management: supply chain, production, process control." },
//            { id: 5, text: "Business Analytics: data analysis, decision models." },
//           { id: 6, text: "International Business: global markets and trade." },
//           { id: 7, text: "Entrepreneurship: building and scaling startups." }
//         ],
//       },

//        {
//         id: 411,
//         heading: "MBA Course Structure and Subjects",
//         image: "/blogImage/mbaCourse/mbaCourse.webp",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "First Year Core Subjects",
//           subTitle:
//             "The first year usually covers core subjects that all students take:",
//           documents: ["Accounting and financial reporting","Marketing fundamentals","Organisational behaviour","Managerial economics","Quantitative methods and statistics"],
//         },
//         {
//           id: 2,
//           title: "Second Year Specialization Subjects",
//           subTitle:
//             "In the second year we focus on specialization subjects and electives related to our chosen field.",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Projects and Internships",
//           subTitle:
//             "",
//           documents: ["Summer internships between years give real work exposure.","Final projects often solve real business problems or develop a business plan."],
//         }
//       ],
//       },
//       {
//         id: 412,
//         heading: "MBA Fees in India 2026",
//         image: "/blogImage/mbaCourse/mbaFees.webp",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Government College Fee Range",
//           subTitle:
//             "Many government colleges offer MBA courses at lower fees. These are usually state or central institutions where fees stay affordable and depend on the state and program structure. But for some government institutes like IIMs have much higher fees. These fees reflect global level teaching, campus facilities, and strong industry exposure, even though they are government institutions.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Private College Fee Range",
//           subTitle:
//             "Private colleges have a wide range of fees. Higher fees often come with better infrastructure, industry exposure, and placement support, but this varies by institute.",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Online and Distance MBA Fees",
//           subTitle:
//             "Online and distance MBA courses tend to be more affordable and fit working budgets. Note that for legal validity in India an online MBA must be UGC approved. Without UGC approval the certification may not be valid for government roles or further higher studies.",
//           documents: [],
//         }
//       ],
//       },
//     {
//         id: 413,
//          tableSteps: [
//       ],
//         table: {
//           id: 2,
//           headers: ["Program Type", "Typical Fee Range"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Government colleges", "Low to moderate"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["Private colleges", "Moderate to high"],
//                link:""
//             },
//             {
//               id: 3,
//               cols: ["Online / Distance (UGC-approved)", "Low to moderate"],
//                link:""
//             },
            
//           ],
//         },
//       },
//         {
//         id: 414,
//         heading: "Career Scope After MBA",
//         image: "/blogImage/mbaCourse/careerScope.webp",
//          showSerial: false,
//          contentLast:"Career progress depends on our performance, network, and continuous learning." ,
//           steps: [
//         {
//           id: 1,
//           title: "Entry Level Job Roles",
//           subTitle:
//             "",
//           documents: ["Management trainee","Business analyst","Sales or marketing executive","Financial analyst"],
//         },
//         {
//           id: 2,
//           title: "Mid Level Growth Paths",
//           subTitle:
//             "",
//           documents: ["Team leader or project manager","Product manager or senior analyst","HR or operations manager"],
//         },
//         {
//           id: 3,
//           title: "Leadership and Management Roles",
//           subTitle:
//             "",
//           documents: ["Head of function","General manager","Senior director or CXO track"],
//         }
//       ],
//       },
      
//        {
//         id: 415,
//         heading: "Salary After MBA in India",
//         image: "/blogImage/mbaCourse/salary.webp",
//         showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Average Starting Salary",
//           subTitle:
//             "Starting [salary](https://in.indeed.com/career-advice/finding-a-job/careers-with-an-mba) differs by specialization and institute type. Analytics and finance often start higher. Marketing and HR start moderately and can grow fast with results.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Salary by Specialisation",
//           subTitle:
//             "",
//           documents: ["Finance and analytics generally have higher starting pay.","Marketing and operations reward performance and experience."],
//         },
//         {
//           id: 3,
//           title: "Salary Growth Over Time",
//           subTitle:
//             "With promotions and experience salaries rise significantly, especially in leadership positions.",
//           documents: [],
//         },
//       ],
//       },
//         {
//         id: 416,
//         heading: "MBA Jobs by Industry",
//         points: [
//           { id: 1, text: "Banking and Finance: corporate roles, risk, wealth management." },
//           { id: 2, text: "Consulting: strategy and operations advisory." },
//           { id: 3, text: "IT and Technology: product, business analysis, sales." },
//             { id: 4, text: "Manufacturing and Operations: supply chain and plant roles." },
//           { id: 5, text: "Startups: roles in growth, product, and operations." },
//         ],
//       },
//         {
//         id: 417,
//         heading: "MBA With and Without Work Experience",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Is Freshers' MBA Worth It",
//           subTitle:
//             "A fresher MBA can kickstart a career switch and faster growth if we use internships and projects well.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Best Specialisations for Freshers",
//           subTitle:
//             "Marketing and operations suit freshers well. Analytics or finance need comfort with numbers.",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "How Experience Adds Value",
//           subTitle:
//             "Experience gives practical context. It helps in class discussions and improves placement chances.",
//           documents: [],
//         },
//         {
//           id: 4 ,
//           title: "Best MBA Types for Working Professionals",
//           subTitle:
//             "Part time, executive, and online MBA courses let working people learn while they work and apply new skills immediately.",
//           documents: [],
//         },
//       ],
//       },
//       {
//         id: 418,
//         heading: "Skills Needed to Succeed in MBA",
//         contentLast:"We should build these skills before joining and sharpen them during the course.",
//         points: [
//           { id: 1, text: "Clear communication and writing" },
//           { id: 2, text: "Problem solving and logical thinking" },
//           { id: 3, text: "Leadership and decision making" },
//           { id: 4, text: "Basic data skills and spreadsheet comfort" },
//         ],
//       },
//       {
//         id: 419,
//         heading: "Common MBA Mistakes to Avoid",
//         contentLast:"Avoid these so we get long term value from the degree.",
//         points: [
//           { id: 1, text: "Choosing a specialization only for short term pay." },
//           { id: 2, text: "Ignoring hands-on skill building and networking." },
//           { id: 3, text: "Only focusing on placement numbers and not learning." },
//           { id: 4, text: "Not using internships and projects to build real work examples." },
//         ],
//       },
//        {
//         id: 420,
//         heading: "MBA 2026 Future Trends",
//         contentLast:"We should keep learning to stay relevant.",
//         points: [
//           { id: 1, text: "AI and data driven management will shape decisions." },
//           { id: 2, text: "Green and sustainable business practices will grow." },
//           { id: 3, text: "Global and remote leadership skills will be more important." },
//         ],
//       },
//         {
//         id: 421,
//         heading: "Is MBA Worth It in 2026",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Cost vs Career Growth",
//           subTitle:
//             "An MBA can pay back when it helps us move into higher roles, switch into better fields, or build a business. Compare total fees, living cost, and likely salary gain before choosing.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "MBA for Job vs Business",
//           subTitle:
//             "For job seekers an MBA course helps in placements and clarity. For entrepreneurs, it gives useful tools, but practical experience remains crucial.",
//           documents: [],
//         },
//       ],
//       },
//        {
//         id: 422,
//         heading: "Conclusion",
//           contentStart:"We have covered the main details about MBA courses in India in 2026. We explained eligibility, types, subjects, fees, duration, and career paths. If you plan carefully and use internships, projects, and networking well, an MBA can help you reach leadership roles or grow your business. Pick the right format, check UGC approval for online programs, and focus on skills that bring real value.",
//           contentLast:`Ready to take the next step in your MBA journey? [BBS College](/), one of the [best private MBA colleges in UP](/mba), offers industry focused MBA courses with practical learning and strong career support. Apply now and start building a future ready management career.`
//       },
//       {
//         id: 423,
//         heading: "FAQs",
//         faqs: [
//           {
//             id: 1,
//             question: "Which MBA Course is Best for Future",
//             answer:
//               "MBA courses in business analytics, finance, operations, and entrepreneurship are good for the future. These areas match new business needs and offer better long term career growth in India.",
//           },
//           {
//             id: 2,
//             question: "MBA Course Eligibility",
//             answer:
//               "MBA course eligibility usually needs a bachelor degree from a recognised university. Some programs also look at entrance test scores, work experience, and minimum marks during selection.",
//           },
//            {
//             id: 3,
//             question: "Best Courses After MBA",
//             answer:
//               "After MBA, courses in data analytics, finance, product management, operations, or leadership help you grow faster. These courses build practical skills and make you ready for higher roles.",
//           },
//            {
//             id: 4,
//             question: "Types of MBA Courses List",
//             answer:
//               "Types of MBA courses include full time MBA, part time MBA, executive MBA, online MBA, distance MBA, and integrated MBA. Each type suits different career stages and work schedules.",
//           },
//         ],
//       },
//     ],
//   },
//    {
//     id: 5,
//     slug: "bca-course-guide",
//     seo: {
//       title: "BCA Course Guide: Eligibility, Subjects, Career & Salary",
//       description:
//         "Complete guide to the BCA course in India. Learn about eligibility, duration, subjects, admission process, career options, and salary in simple words.",
//         keywords:""
//     },

//     sections: [
//       {
//         id: 501,
//         hero:true,
//         heading:
//           "Comprehensive Guide on BCA Courses: Everything You Need To Know For Your Career",
//         content:
//           "If you want to build your own software or apps and use those skills to earn well in the future, the BCA course is one of the most practical ways to start. It teaches you how technology works from the inside and to create one. This blog helps you understand every detail about the BCA course.",
          
//       },
// {
//         id: 502,
//         heading: "What Is BCA",
//         image: "/blogImage/bcaCourseGuide/whatIsBca.webp",
//         contentStart:
//           "Bachelor of Computer Applications (BCA) course teaches how computers and software work. You learn to write code, build basics of apps and websites, work with databases, and understand networks. It mixes theory and hands-on work so you can start working or study more later.",
//       },
//       {
//         id: 503,
//         heading: "Why Choose BCA",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Demand for IT Skills",
//           subTitle:
//             "Many businesses need people who can make and run software. The BCA course gives practical skills that are useful in many jobs.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Early Entry into Tech Field",
//           subTitle:
//             "This course lets you start a tech career soon after finishing school. You don’t wait many years to begin.",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Affordable Compared to Other IT Degrees",
//           subTitle:
//             "The BCA course is often cheaper than long engineering programs. It gives a good start at lower cost.",
//           documents: [],
//         }
//       ],
//       },
//       {
//         id: 504,
//         heading: "BCA Course Overview",
//         image: "/blogImage/bcaCourseGuide/bcaCourseOverview.webp",
//          showSerial: false,
//          contentLast:"" ,
//           steps: [
//         {
//           id: 1,
//           title: "Course Duration",
//           subTitle:
//             "The usual BCA course lasts three years. Under NEP 2020, some colleges offer a four-year BCA Honours option. The four-year option helps if you want to study for a master’s abroad.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Course Structure",
//           subTitle:
//             "You study in class, do lab work, finish small projects each term, and do a final major project. Some colleges include short internships.",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Types of BCA Programs",
//           subTitle:
//             "",
//           documents: ["Regular three-year BCA course","Four-year honours BCA course","Specialised tracks","Distance or online programs"],
//         }
//       ],
//       },
//        {
//         id: 505,
//         heading: "Different Types of BCA Courses",
//          showSerial: false,
//         contentStart:
//           "BCA is not limited to one format. Today, colleges offer different types of BCA programs based on student interest and industry demand.",
//           steps: [
//         {
//           id: 1,
//           title: "General BCA",
//           subTitle:
//             "This is the most common type. It gives you overall knowledge of computers without focusing on one special area.",
//           documents: [],
//         },
//       ],
      
//       },
//       {
//         id: 506,
//         heading: "Specialised BCA Courses",
//         contentSections:[
//   {
//     id: 1,
//     title: "BCA in Artificial Intelligence and Machine Learning ",
// description:"Learn to create smart programs that can predict, recognise patterns, and automate tasks."

//   },
//    {
//     id: 2,
//       title: "BCA in Cyber Security",
// description:"Learn how to protect websites, systems, and data from hacking and cyber attacks."
//   },
//    {
//     id: 3,
//       title: "BCA in Data Science and Analytics",
// description:"Learn how to study large amounts of data and find useful information for companies."
//   },
//    {
//     id: 4,
//       title: "BCA in Cloud Computing",
// description:"Learn how software and data are managed on internet servers instead of personal computers."
//   }
// ],
//         contentStart:
//           "Many colleges now offer BCA programs that focus on specific modern technologies.",
//       },
//       {
//         id: 507,
//         heading: "New and Upcoming BCA Courses",
//         contentSections:[
//   {
//     id: 1,
//     title: "BCA in AR and VR ",
// description:"Learn to build apps and games for virtual and augmented reality."

//   },
//    {
//     id: 2,
//       title: "BCA in Blockchain",
// description:"Understand the system behind secure digital transactions and record keeping."
//   },
//    {
//     id: 3,
//       title: "BCA in Internet of Things (IoT)",
// description:"Learn how devices like home appliances and cars connect and communicate through the internet."
//   },
//    {
//     id: 4,
//       title: "BCA in Full Stack Development",
// description:"Learn to build complete websites from front end to back end"
//   }
// ],
//         contentStart:
//           "These courses focus on future technologies that are growing quickly.",
//       },
//         {
//         id: 508,
//         heading: "Comparison of BCA Course Types",
//         table: {
//           id: 1,
//           headers: ["Course Type", "Main Focus","Popular Job Role"],
//           rows: [
//             { id: 1, cols: ["General BCA", "Overall computer basics","Software Developer"],link:""
//              },
//             { id: 2, cols: ["AI and ML", "Smart systems","AI Engineer"], link:"" },
//             { id: 3, cols: ["Cyber Security", "System protection","Security Analyst"], link:"" },
//             { id: 4, cols: ["Data Science", "Data study","Data Analyst"], link:"" },
//             { id: 5, cols: ["Cloud Computing", "Online servers","Cloud Engineer"], link:"" },
//             { id: 6, cols: ["AR and VR", "Digital applications","Game Developer"], link:"" },
//           ],
//         },
//       },
//       {
//         id: 509,
//         heading: "Integrated Course Types",
//         contentSections:[
//   {
//     id: 1,
//     title: "BCA LLB",
// description:"BCA LLB is an integrated degree where you study computer subjects and law together. You learn coding, software, and internet basics along with legal systems and digital rights. At the end, you receive two degrees."

//   },
//    {
//     id: 2,
//       title: "Integrated BCA + MCA",
// description:"Five-year program combining BCA and MCA. You learn both basic and advanced computer topics to get stronger tech jobs."
//   },
//    {
//     id: 3,
//       title: "Integrated BCA + MBA",
// description:"Five-year program combining BCA and MBA. You learn tech first, then business and management for leadership roles in tech."
//   }
// ],
//       },
//       {
//         id: 510,
//         heading: "Eligibility for BCA",
//         image: "/blogImage/bcaCourseGuide/eligibility.webp",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Educational Qualification",
//           subTitle:
//             "To apply you need to pass 10+2 from a recognised board.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Mathematics Requirement",
//           subTitle:
//             "In many top colleges in India, Mathematics or Informatics Practices in Class 12 is required. Private colleges sometimes accept other streams, but options may be fewer later. This point affects your future choices.",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Minimum Marks Required",
//           subTitle:
//             "Most colleges ask for about 45 to 50 percent in 10+2, but each college sets its own rules",
//           documents: [],
//         },
//         {
//           id: 4,
//           title: "Age Limit Criteria",
//           subTitle:
//             "Usually there is no strict age limit",
//           documents: [],
//         }
//       ],
//       },
//        {
//         id: 511,
//         heading: "BCA Admission Process",
//         image: "/blogImage/bcaCourseGuide/admission.webp",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Merit Based Admission",
//           subTitle:
//             "Some colleges give seats based on 10+2 marks.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Entrance Exam Based Admission",
//           subTitle:
//             "Other colleges hold tests that check math, logic, and basic computer skills.",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Common Admission Steps",
//           subTitle:
//             "Apply, take the test if needed, go to counselling, and finish enrollment. Check each college for exact steps.",
//           documents: [],
//         }
//       ],
//       },
//       {
//         id: 512,
//         heading: "BCA Subjects and Syllabus",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Core Subjects",
//           subTitle:
//             "The main subjects in the BCA course include:",
//           documents: ["Programming basics","Data structures","Databases","Operating systems","Networks","Software engineering","Web development"],
//         },
//         {
//           id: 2,
//           title: "Programming Languages Taught",
//           subTitle:
//             "You learn C and C++, then higher-level languages like Java or Python, and web tools such as HTML, CSS, and JavaScript. You also learn SQL for databases.",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Practical and Lab Work",
//           subTitle:
//             "Each term has lab sessions and mini projects. The final year has a larger project that brings all learning together.",
//           documents: [],
//         }
//       ],
//       },
//     {
//         id: 513,
//         heading: "Suggested Semester-Wise Subject List",
//         contentStart:"A [common plan](https://www.shiksha.com/bca-bachelor-of-computer-applications-syllabus-chp) used by many colleges in India (note: this is a basic common syllabus, and many colleges make their own changes to it):",
//         table: {
//           id: 10,
//           headers: ["Semester", "Subjects"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Semester 1", "Computer Fundamentals, Programming in C, Discrete Mathematics, Digital Logic, Communication Skills"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["Semester 2", "Data Structures, Object Oriented Programming, Operating Systems, Statistics, Environmental Studies"],
//                link:""
//             },
//             {
//               id: 3,
//               cols: ["Semester 3", "Database Management Systems, Java or Python, Computer Networks, Web Basics, Software Engineering"],
//                link:""
//             },
//             {
//               id: 4,
//               cols: ["Semester 4", "Advanced Web Development, Data Analysis Basics, Linux, Computer Architecture, Project Work"],
//                link:""
//             },
//             {
//               id: 5,
//               cols: ["Semester 5", "Mobile App Basics, Cloud Concepts, Information Security, Elective Subject, Internship"],
//                link:""
//             },
//             {
//               id: 6,
//               cols: ["Semester 6", "Advanced Programming, Elective Subject, Final Year Project, Project Viva-Voce"],
//                link:""
//             },
            
//           ],
//         },
//       },
//         {
//         id: 514,
//         heading: "Skills You Learn in BCA",
//         image: "/blogImage/bcaCourseGuide/skillDevelopment.webp",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Technical Skills",
//           subTitle:
//             "You gain hands-on skills in coding, building simple apps, using databases, and working with systems.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Problem Solving Skills",
//           subTitle:
//             "The BCA course teaches you to break a problem into parts, design solutions, and fix errors.",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Communication Skills",
//           subTitle:
//             "You learn to explain your work, write basic reports, and work with teammates.",
//           documents: [],
//         }
//       ],
//       },
//       {
//         id: 515,
//         heading: "Career Options After BCA",
//         contentStart:"After the BCA course you can work in roles such as:",
//         contentLast:"Many graduates start in support or testing jobs and move to development with practice and projects.",
//         points: [
//           { id: 1, text: "Software developer" },
//           { id: 2, text: "Web developer." },
//           { id: 3, text: "Data analyst" },
//             { id: 4, text: "System administrator" },
//           { id: 5, text: "Digital marketing roles" },
//           { id: 6, text: "Technical support engineer" },
//           { id: 7, text: "Quality assurance tester" },
//         ],
//       },
//          {
//         id: 516,
//         heading: "Higher Studies After BCA",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "MCA After BCA",
//           subTitle:
//             "MCA in India is now a two-year program. It used to be three years. This shorter MCA makes higher study faster. If you aim for top institutes, prepare for the NIMCET exam.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "MBA After BCA",
//           subTitle:
//             "An MBA fits those who want business or management roles.",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Short Term Certification Courses",
//           subTitle:
//             "Small courses in web, data, cloud, or security help your job chances and skill set.",
//           documents: [],
//         }
//       ],
//       },
      
//        {
//         id: 517,
//         heading: "Useful Free Courses and Certifications for BCA Students",
//         image: "/blogImage/bcaCourseGuide/certification.webp",
//         showSerial: false,
//          contentLast:"These short courses strengthen your profile during the BCA course." ,
//           steps: [
//         {
//           id: 1,
//           title: "Programming and Development",
//           subTitle:
//             "Free courses on Python, Java, data structures, and web development add real value while you study",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Data and System Skills",
//           subTitle:
//             "Learn basic SQL, data handling, Linux, and networking to stand out.",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Soft Skills",
//           subTitle:
//             "Work on communication, resume writing, and interview practice.",
//           documents: [],
//         },
//       ],
//       },
//       {
//         id: 518,
//         heading: "Job Sectors for BCA Graduates",
//         content:"Graduates from the BCA course find work in IT services, startups, banks, government teams, and as freelancers. The course fits many sectors.",
//       },
//       {
//         id: 519,
//         heading: "Salary After BCA",
//         image: "/blogImage/bcaCourseGuide/salary.webp",
//         showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Starting Salary in India",
//           subTitle:
//             "Fresh graduates usually get entry-level pay. Exact numbers change by company and city.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Salary Growth with Experience",
//           subTitle:
//             "As skills improve, pay rises. Learning new tools speeds this up.",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "What Mostly Affects Salary",
//           subTitle:
//             "Your pay depends mainly on how well you can code, your project work, and the city you work in.",
//           documents: [],
//         },
//       ],
//       },
//        {
//         id: 520,
//         heading: "BCA vs Other Courses",
//         contentLast:"BTech students often get higher starting offers than BCA course graduates in campus hiring. Keep this in mind when you plan",
//         table: {
//           id: 11,
//           headers: ["Feature", "BCA","BSc Computer Science","BTech Computer Science"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Duration", "3 or 4 years","3 years","4 years"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["Focus", "Software and applications","Theory-based learning","Engineering-focused learning"],
//                link:""
//             },
//             {
//               id: 3,
//               cols: ["Cost", "Lower","Medium","Higher"],
//                link:""
//             },
//             {
//               id: 4,
//               cols: ["Campus Placements", "Moderate","Moderate","Usually higher starting packages"],
//                link:""
//             },
            
//           ],
//         },
//       },
//       {
//         id: 521,
//         heading: "Advantages of BCA",
//         points: [
//           { id: 1, text: "Short or flexible duration" },
//           { id: 2, text: "Practical learning you can use quickly" },
//           { id: 3, text: "Lower cost" },
//             { id: 4, text: "Good start for IT work" },
//         ],
//       },
//       {
//         id: 522,
//         heading: "Is BCA a Good Career Choice",
//         showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Future Scope of BCA",
//           subTitle:
//             "Tech keeps growing. If you keep learning, the BCA course stays useful and opens many paths.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Who Will Benefit Most from BCA",
//           subTitle:
//             "This course suits students who like coding, want early job entry, and will keep improving their skills.",
//           documents: [],
//         },
//       ],
//       }, 
//       {
//         id: 523,
//         heading: "Conclusion",
//         content:"The BCA course is a simple and practical way to begin a tech career. It teaches useful skills, fits many job paths, and allows further study. Do small projects, take short courses, and make a good resume to grow faster.",
//       },  
//        {
//         id: 524,
//         heading: "Ready to build your future in the tech world?",
//           contentStart:`Choose [BBS College](/), a trusted [BCA college in Prayagraj](/bca), and build strong computer and software skills for your future. With experienced faculty, practical learning, and a student-friendly environment, BBS College supports you at every step of your BCA course.`,
//           contentLast:`Apply now and take your first step toward a successful career in technology.`
//       }
//     ],
//   },
//   {
//     id: 6,
//     slug: "mca-jobs",
//     seo: {
//       title: "Best Jobs After MCA in India | Career Guide & MCA Jobs",
//       description:
//         "Explore top MCA jobs in India, skills needed, salary, government roles, and future opportunities. Simple career guide for MCA graduates.",
//         keywords:""
//     },

//     sections: [
//       {
//         id: 601,
//      hero:true,
//         heading:
//           "Best Jobs After MCA in India: Complete Career Guide",
//         content:
//           "If you are worrying about jobs while doing MCA or BCA, that is actually a wise thought. Thinking early about your career gives you a clear edge. MCA offers a wide scope, but many students do not know which path to choose. This blog will help you understand the job options after MCA, the skills you should focus on, and how to move step by step toward a stable and satisfying career.",
          
//       },
//       {
//         id: 602,
//         heading: "Why MCA Is A Good Degree For Your Career",
//         content:"MCA gives a broad base to build a tech career. With the right practice and a few special skills, you can reach high-value roles. Many people use this degree as a direct route into software and data work, or into stable government posts if they want security.",
//       },

//       {
//         id: 603,
//         heading: "Core Technical Jobs",
//         image: "/blogImage/mcaJobs/CoreTechnicalJobs.webp",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Software Developer",
//           subTitle:
//             "A software developer builds and maintains software for computers, websites, and mobile applications. The role includes coding, fixing bugs, adding features, and working with teams to deliver reliable products.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Web Developer",
//           subTitle:
//             "Works on websites and web applications, including frontend, backend, or full-stack development.",  
//             documentsHeading:"Skills",
//           documents: ["HTML, CSS, JavaScript","Java, Python, or JavaScript (backend)","Basic databases and APIs","Git and basic testing"],
//         },
//         {
//           id: 3,
//           title: "Mobile App Developer",
//           subTitle:
//             "Builds applications for Android or iOS with a focus on performance and user experience",
//             documentsHeading:"Required Skills",
//           documents: ["Android (Java/Kotlin) or iOS (Swift)","Java, Python, C#, or JavaScript","Basic data structures and algorithms","Mobile UI basics","API integration","Git version control","Problem solving"],
//         },
//         {
//           id: 4,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Optional / Good to Have",
//           documents: ["App testing and debugging"],
//         },
//         {
//           id: 5,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Hiring Sectors",
//           documents: ["IT service companies","Product-based companies","Fintech, SaaS, and e-commerce platforms"],
//         },
//         {
//           id: 6,
//           title: "Hardware Engineer",
//           subTitle:
//             "A hardware engineer works with physical devices and embedded systems. The role may include testing, firmware, and device tuning.",
//             documentsHeading:"Skills",
//           documents: ["Basic electronics and embedded C","Firmware programming and testing","Device troubleshooting"],
//         },
//         {
//           id: 7,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Sectors",
//           documents: ["IoT and device firms","Manufacturing and hardware vendors","Research labs"],
//         },
//         {
//           id: 8,
//           title: "Networking Engineer",
//           subTitle:
//             "A networking engineer builds and maintains networks. You keep connections fast and solve outages.",
//             documentsHeading:"Skills",
//           documents: ["Routing and switching fundamentals","Network troubleshooting and monitoring","Protocol knowledge, such as TCP/IP"],
//         },
//         {
//           id: 9,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Sectors",
//           documents: ["Telecom and ISPs","Data centers","Large corporate networks"],
//         },
//         {
//           id: 10,
//           title: "Quality Assurance Tester",
//           subTitle:
//             "A QA tester checks software before it reaches users. You find bugs and make sure the product works as expected.",
//             documentsHeading:"Skills",
//           documents: ["Manual testing and writing test cases","Test automation basics","Attention to detail and reporting skills"],
//         },
//         {
//           id: 11,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Sectors",
//           documents: ["Product companies","QA service providers","Startups"],
//         },
//          {
//           id: 12,
//           title: "Database Manager",
//           subTitle:
//             "A database manager handles and maintains data systems to ensure data is secure, fast, and available for applications.",
//             documentsHeading:"Skills",
//           documents: ["SQL and NoSQL databases","Backup and recovery","Query optimization"],
//         },
//         {
//           id: 13,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Sectors",
//           documents: ["Banking and finance","Analytics companies","E-commerce and payments"],
//         },
//       ],
//       },
//       {
//         id: 604,
//         heading: "Government Jobs For MCA Graduates",
//         image: "/blogImage/mcaJobs/governmentJobs.webp",
//          showSerial: true,
//           steps: [
//         {
//           id: 1,
//           title: "E-Governance Roles",
//           subTitle:
//             "The government runs apps like DigiLocker and UMANG and hires tech people to manage them.",
//             documentsHeading:"Roles",
//           documents: ["AI or ML engineer","DevOps engineer for cloud servers","Full-stack developer for portals"],
//         },
//         {
//           id: 2,
//           title: "Banking Tech (Specialist Officer)",
//           subTitle:
//             "Public banks now need IT experts for digital banking and security.",
//              documentsHeading:"Roles",
//           documents: ["IT Specialist Officer","Data analyst","Cybersecurity expert"],
//         },
//         {
//           id: 3,
//           title: "Research and Space Organizations",
//           subTitle:
//             "These departments hire MCA graduates for software-heavy work.",
//             documentsHeading:"Roles",
//           documents: ["Scientist or engineer","Technical assistant for computing systems"],
//         },
//         {
//           id: 4,
//           title: "Defense and Intelligence",
//           subTitle:
//             "Tech roles focused on national security.",
//             documentsHeading:"Roles",
//           documents: ["Cybersecurity analyst","Information management officer"],
//         }
//       ],
//       },
//        {
//         id: 605,
//         heading: "Quick Guide",
//         table: {
//           id: 1,
//           headers: ["Goal", "Exam / Hiring Body","Role"],
//           rows: [
//             { id: 1, cols: ["Banking", "IBPS SO / SBI SO","Officer"],link:""
//              },
//             { id: 2, cols: ["National IT", "NIC / NIELIT","Programmer"], link:"" },
//             { id: 3, cols: ["Space / Defense","ISRO / DRDO","Scientist"], link:"" },
//             { id: 4, cols: ["Data Science", "Data study","Data Analyst"], link:"" },
//             { id: 5, cols: ["Railways","RRB / CRIS","IT Engineer"], link:"" },
//             { id: 6, cols: ["Public safety","SSC CGL","Assistant"], link:"" },
//           ],
//         },
//       },
//        {
//         id: 606,
//         heading: "Private Jobs For MCA Graduates",
//         image: "/blogImage/mcaJobs/privateJobs.webp",
//          showSerial: true,
//         contentStart:
//           "The private sector offers many MCA jobs with fast growth and good pay. Hiring is based on your skills, projects, and interviews. Work areas often include software, data, cloud, security, and testing. Top Companies That Hire In India are:",
//           steps: [
//         {
//           id: 1,
//           title: "Service-Based Companies",
//           subTitle:
//             "These companies hire many MCA graduates through campus drives and national-level tests.",
//             subTitleLast:"These roles usually focus on client projects, support work, and steady learning.",
//             documentsHeading:"Examples",
//           documents: ["TCS through the NQT exam","Infosys for System Engineer and similar roles","Wipro, through the Elite and Turbo programs","HCLTech for software and infrastructure roles","Tech Mahindra for telecom and software projects"],
//         },
//         {
//           id: 2,
//           title: "Product-Based Companies",
//           subTitle:
//             "These companies are harder to enter but offer high salaries and strong growth.",
//             subTitleLast:"These roles focus on building and improving their own products.",
//              documentsHeading:"Examples",
//           documents: ["Google and Microsoft for software development roles","Amazon for cloud and e-commerce tech roles","Adobe for students strong in DSA and problem-solving","Oracle for database, Java, and cloud roles","Zoho, which values skills and projects"],
//         },
//         {
//           id: 3,
//           title: "Startups and Fintech Companies",
//           subTitle:
//             "Startups and fintech firms hire MCA graduates for web, app, and backend development.",
//             subTitleLast:"These companies offer fast growth and practical learning.",
            
//             documentsHeading:"Examples",
//           documents: ["Paytm and PhonePe for digital payment systems","Flipkart and Swiggy for app and data roles","Razorpay for API and fintech systems","Zomato for full-stack and app work"],
//         },
//       ],
//       },
//      {
//         id: 607,
//         heading: "Difference in Hiring Style",
//         contentLast:"Private jobs give faster learning, better pay over time, and more career options.",
//         table: {
//           id: 1,
//           headers: ["Feature", "Service Based","Product Based"],
//           rows: [
//             { id: 1, cols: ["Hiring method", "Exams and mass hiring","Interviews and skill tests"],link:""
//              },
//             { id: 2, cols: ["Starting salary","₹3.5 to ₹7 LPA","₹12 to ₹40+ LPA"], link:"" },
//             { id: 3, cols: ["Work focus","Client projects and support","Building their own products"], link:"" },
//             { id: 4, cols: ["Main requirement", "Basic coding and aptitude","Strong DSA and problem-solving"], link:"" },
//           ],
//         },
//       },  
//      {
//         id: 608,
//         heading: "Salary You Can Expect As A Fresher",
//         contentStart:"Salary varies by role, city, and skill. Here are common starting ranges to set expectations.",
//         table: {
//           id: 12,
//           headers: ["Role", "Typical fresher range (INR per year)"],
//           rows: [
//             { id: 1, cols: ["Software developer", "₹3 LPA to ₹7 LPA"],link:""
//              },
//             { id: 2, cols: ["Web / App developer","₹3 LPA to ₹6 LPA"], link:"" },
//             { id: 3, cols: ["Database manager / Sysadmin","₹3 LPA to ₹5 LPA"], link:"" },
//             { id: 4, cols: ["Data scientist (entry)","₹4 LPA to ₹8 LPA"], link:"" },
//             { id: 5, cols: ["Cloud / Security entry roles","₹4 LPA to ₹8 LPA"], link:"" },
//           ],
//         },
//       }, 
//        {
//         id: 609,
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "",
//           subTitle:
//             "",
//             subTitleLast:"",
//             documentsHeading:"What Affects Pay",
//           documents: ["Your projects and internships","The city and company size","Any certificates or special skills"],
//         }
//       ],
//       },
       
//       {
//         id: 610,
//         heading: "High-Demand Specialized Jobs in",
//         image: "/blogImage/mcaJobs/highDemand.webp",
//         showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "AI engineer",
//           subTitle:
//             "An AI engineer builds smart systems that can learn and make decisions. This role works with machine learning models, automation, and intelligent tools used in modern software.",
//             documentsHeading:'Skills',
//           documents: ["Python and machine learning libraries","Deep learning basics and data handling","Model training and evaluation"],
//         },
//         {
//           id: 2,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Sectors",
//           documents: ["AI startups","Product companies","Healthcare, finance, retail, and automation firms"],
//         },
//         {
//           id: 3,
//           title: "Data Scientist",
//           subTitle:
//             "A data scientist finds meaning in large data sets. You build models that help the business make better choices.",
//             documentsHeading:"Skills",
//           documents: ["Statistics and Python or R","Machine learning basics","Data cleaning and visualization"],
//         },
//         {
//           id: 4,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Sectors",
//           documents: ["Analytics firms","Retail and finance","Healthcare and adtech"],
//         },
//         {
//           id: 5,
//           title: "Cloud Architect",
//           subTitle:
//             "A cloud architect plans how systems run on cloud platforms. You choose services, set up scaling, and keep systems reliable.",
//             documentsHeading:"Skills",
//           documents: ["AWS, Azure, or GCP basics","Containers and infrastructure as code","Network and security knowledge"],
//         },
//         {
//           id: 6,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Sectors",
//           documents: ["Cloud service teams","SaaS companies","Large enterprises moving to the cloud"],
//         },
//         {
//           id: 7,
//           title: "Security Expert And Ethical Hacker",
//           subTitle:
//             "A security expert checks systems for weak points and fixes them. Ethical hackers test defenses so real attacks do not succeed.",
//             documentsHeading:"Skills",
//           documents: ["Penetration testing and vulnerability scanning","Secure coding awareness","Basic cryptography and security tools"],
//         },
//         {
//           id: 8,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Sectors",
//           documents: ["Cybersecurity firms","Banks and finance","Large IT companies and defense"],
//         },
//       ],
//       },
//        {
//         id: 611,
//         heading: "Jobs In Planning And Management",
//         image: "/blogImage/mcaJobs/jobsPlanning.webp",
//         showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "System Analyst",
//           subTitle:
//             "A system analyst links business needs with technical work. You write clear requirements and help the team build the right solution.",
//             documentsHeading:'Skills',
//           documents: ["Requirement gathering and documentation","Basic UML and flow diagrams","Communication with users and developers"],
//         },
//         {
//           id: 2,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Sectors",
//           documents: ["IT consulting","Product teams","Enterprise IT departments"],
//         },
//         {
//           id: 3,
//           title: "IT Project Manager",
//           subTitle:
//             "An IT project manager plans and runs projects. You set timelines, manage resources, and keep stakeholders informed.",
//             documentsHeading:"Skills",
//           documents: ["Project planning and tracking","Agile or Scrum methods","Team coordination and simple budgeting"],
//         },
//         {
//           id: 4,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Sectors",
//           documents: ["Consulting firms","Product development teams","Service delivery units"],
//         },
//         {
//           id: 5,
//           title: "Software Consultant",
//           subTitle:
//             "A software consultant studies client problems and suggests solutions. You guide choices and help implement the right tools.",
//             documentsHeading:"Skills",
//           documents: ["Client communication and requirement analysis","Solution mapping and demoing","Ability to adapt to new tools quickly"],
//         },
//         {
//           id: 6,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Sectors",
//           documents: ["Consulting companies","System integrators","Enterprise customers"],
//         },
//         {
//           id: 7,
//           title: "Technical Architect",
//           subTitle:
//             "A technical architect designs the whole system layout for large projects. You make sure parts fit, and the system can grow.",
//             documentsHeading:"Skills",
//           documents: ["System and service design","Integration and performance planning","Deep knowledge of a technology stack"],
//         },
//         {
//           id: 8,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"Sectors",
//           documents: ["Product engineering teams","Large enterprise architecture groups","Cloud and platform companies"],
//         },
//       ],
//       },
//       {
//         id: 612,
//         heading: "What To Study After Your Degree",
//         showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Doing a PhD",
//           subTitle:
//             `A PhD is a good choice if you like deep study, research, and teaching. You pick one topic and work on it for a few years to find new ideas or solve real problems. This usually takes 3 to 5 years.\n\n During this time, you read research papers, write your own papers, and work under a guide.\n\n A PhD is useful if you want to:
//             `,
//             subTitleLast:'This path needs patience and a strong interest in one subject rather than a quick job.',
//           documents: ["Become a professor or lecturer","Work in research labs","Join advanced research teams in tech organizations.","Build expertise in areas like AI, data science, cybersecurity, cloud systems, or software engineering."],
//         },
//         {
//           id: 2,
//           title: "Getting Special Certifications",
//           subTitle:
//             "Short courses and certificates quickly boost your profile. Choose certificates that match the MCA jobs you want.",
//             documentsHeading:"Useful Certifications",
//           documents: ["Cloud: AWS, Azure, Google Cloud","Data and ML: Data science certificates, TensorFlow basics","Security: CEH, CompTIA Security+","DevOps: Docker, Kubernetes, CI CD tools","Project: Scrum Master or PMP"],
//         },
//         {
//           id: 3,
//           title: "",
//           subTitle:
//             "",
//             documentsHeading:"How They Help",
//           documents: ["Show clear skills to employers","Open higher pay and specialized roles"],
//         },
        
//       ],
//       },
      
//       {
//         id: 613,
//         heading: "Conclusion",
//         content:"MCA gives you many clear paths. Start with a role that fits your interests, build small projects, and add one or two special skills. That mix opens good MCA jobs and long-term growth. If you want steady work, explore government roles. Keep learning, stay active on small projects, and choose paths that match your skills and interests.", 
//       },  
//        {
//         id: 614,
//         heading: "Looking to build a strong future after graduation?",
//           contentStart:`Join[BBS College](/), the[Best MCA College in Prayagraj](/mca), where learning goes beyond books. Get the right skills, real guidance, and the support you need to move towards better MCA jobs. Take the first step today and plan your career the right way.`,
//       }
//     ],
//   },
//    {
//     id: 7,
//     slug: "b-tech-ai-ml-complete-guide-career-scope",
//     seo: {
//       title: "B Tech AI & ML Course Guide: Syllabus & Career Scope",
//       description:
//         "Explore B Tech AI & ML course, syllabus, skills, tools, salary, and career scope. Clear guide for students planning a future in AI and ML",
//         keywords:"B Tech AI & ML"
//     },

//     sections: [
//       {
//         id: 701,
//      hero:true,
//         heading:
//           "B.Tech in AI and ML: Complete Guide and Career Scope ",
//         content:
//           "Every day you use apps and tools that can learn from data and make smart decisions. If you want to know how these systems are built, B.Tech AI & ML teaches you the full process step by step. In this guide, you will learn what the course covers, what the syllabus includes, the tools you work with, the skills you develop, and the career options you can aim for.",
          
//       },
//       {
//         id: 702,
//         heading: "What is a B.Tech in AI and ML?",
//         image: "/blogImage/btechAi/BtechInAI.webp",
//          content:
//           "B.Tech AI & ML is an engineering degree where you learn to build systems that learn from data. You study coding, math, machine learning methods, and how to make models work in real life. The course includes classroom study, lab practice, and projects. The syllabus is made to help you understand data, logic, and problem solving.",},
//        {
//         id: 703,
//         heading: "Course Duration and How the Program Is Structured",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Four year course overview",
//              table: {
//           id: 1,
//           headers: ["Year","Main focus"],
//           rows: [
//             { id: 1, cols: ["Year 1", "Programming basics, engineering subjects, mathematics"],link:""
//              },
//             { id: 2, cols: ["Year 2", "Data structures, probability, core computer science"], link:"" },
//             { id: 3, cols: ["Year 3","AI and ML subjects, labs, small projects"], link:"" },
//             { id: 4, cols: ["Year 4", "Advanced topics, electives, internship or final project"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Balance of theory, labs, and projects",
//           subTitle:
//             "In B.Tech AI & ML, you learn through theory, lab work, and projects. Theory helps you understand concepts. Labs help you practice coding and working with data. Projects help you apply what you learned from the syllabus.",
//             documentsHeading:"",
//           documents: [],
//         },
       
  
//       ],
//       },
//        {
//         id: 704,
//         heading: "Important Subjects You Study",
//         contentLast:"These [subjects](https://www.shiksha.com/engineering/ai-ml-courses-syllabus-chp) build the base needed in B.Tech AI & ML",
//         table: {
//           id: 1,
//           headers: ["Subject area", "What you learn"],
//           rows: [
//             { id: 1, cols: ["Programming and data structures","Writing proper code and handling data"],link:""
//              },
//             { id: 2, cols: ["Core AI and ML subjects", "Machine learning, deep learning, NLP, computer vision"], link:"" },
//             { id: 3, cols: ["Mathematics and statistics","Linear algebra, calculus, probability, statistics"], link:"" },
//             { id: 4, cols: ["Data handling","Databases, data cleaning, feature creation"], link:"" },
//           ],
//         },
//       },
//         {
//         id: 705,
//         heading: "Tools and Technologies You Learn",
//         contentSections:[
//   {
//     id: 1,
//     title: "Python and ML libraries",
// description:"such as TensorFlow, PyTorch, scikit-learn, and Keras."

//   },
//    {
//     id: 2,
//       title: "Data analysis and visualization tools",
// description:"like Pandas, NumPy, and Matplotlib"
//   },
//    {
//     id: 3,
//       title: "Cloud and AI platforms",
// description:"for training and deploying models"
//   }
// ],
//         contentStart:
//           "You learn tools that are used in real jobs.",
//           contentLast:
//           "These tools are an important part of the course and syllabus.",
//       },
//          {
//         id: 706,
//         heading: "Skills You Need to Succeed",
//         image: "/blogImage/btechAi/skillDevelopment.webp",
//         contentSections:[
//   {
//     id: 1,
//     title: "Coding and problem solving",
// description:"You should be able to write code and solve problems step by step."

//   },
//    {
//     id: 2,
//       title: "Working with data and models",
// description:"You learn how to clean data, train models, and check their performance."
//   },
//    {
//     id: 3,
//       title: "Project work and teamwork",
// description:"You work on projects with others and learn to present your work clearly."
//   },
//   {
//     id: 4,
//       title: "Human skills that AI cannot replace",
// description:"Communication, logical thinking, and ethical decisions are very important."
//   }
// ],
//       },
//        {
//         id: 707,
//         heading: "Career Scope After BTech in AI and ML",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Top job roles you can apply for",
//              table: {
//           id: 1,
          
//           headers: ["Role","What you do"],
//           rows: [
//             { id: 1, cols: ["AI & ML Engineer", "Build and deploy machine learning models"],link:""
//              },
//             { id: 2, cols: ["Machine Learning Engineer", "Manage model pipelines and deployment"], link:"" },
//             { id: 3, cols: ["Data Scientist","Study data and find useful insights"], link:"" },
//             { id: 4, cols: ["NLP Engineer", "Work on language based systems"], link:"" },
//             { id: 5, cols: ["Research Engineer", "Work on new AI methods"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//             subTitleLast:"After B.Tech AI & ML, you can apply for these roles in many industries.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Industries hiring AI and ML graduates",
//           subTitle:
//             "",  
//             subTitleLast:"These industries use AI for better systems and smart decisions.",
//             documentsHeading:"",
//           documents: ["IT and software companies","Finance and banking","Healthcare and biotech","E commerce and retail","Automotive and manufacturing"],
//         },
       
  
//       ],
//       },
//        {
//         id: 708,
//         heading: "Salary Expectations and Top Hiring Locations",
//         image: "/blogImage/btechAi/salary.webp",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Expected pay for freshers and experts",
//              table: {
//           id: 1,
          
//           headers: ["Experience level","Salary range in India per year"],
//           rows: [
//             { id: 1, cols: ["Freshers", "₹6 LPA to ₹10 LPA (higher with strong projects and top colleges)"],link:""
//              },
//             { id: 2, cols: ["Mid level", "₹12 LPA to ₹30 LPA"], link:"" },
//             { id: 3, cols: ["Senior level","₹30 LPA and above"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//             subTitleLast:"Pay depends on your skills and the company.",
//             subTitleLastHighlights:`If you want to learn more about [the best BTech courses with strong career opportunities,](/blogs/best-btech-course-options) check our blog.`,
            
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Top cities and regions for AI jobs",
//             table: {
//           id: 1,
          
//           headers: ["City","Reason for demand"],
//           rows: [
//             { id: 1, cols: ["Bengaluru", "Many tech companies and startups"],link:""
//              },
//             { id: 2, cols: ["Hyderabad", "Product based companies"], link:"" },
//             { id: 3, cols: ["Pune","Engineering and software hubs"], link:"" },
//              { id: 4, cols: ["Mumbai", "Corporate and finance roles"], link:"" },
//             { id: 5, cols: ["Delhi NCR","Tech firms and consulting companies"], link:"" },
//           ],
//         },
//           subTitle:
//             "",  
//             subTitleLast:"",
//             documentsHeading:"",
//           documents: [],
//         },
       
  
//       ],
//       },
//         {
//         id: 709,
//         heading: "Future Trends in AI and ML",
//         image: "/blogImage/btechAi/futureTrends.webp",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Where the technology is going",
//           subTitle:
//             "",
//             subTitleLast:"AI will grow more in generative models and systems that work with text, image, and audio together. Better tools for running models at scale will be important. This keeps B.Tech AI & ML graduates ready for new roles.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "How to stay relevant in a changing market",
//           subTitle:
//             "",  
//             subTitleLast:"Keep building real projects. Learn how to deploy models. Follow new tools and updates. Improve communication and teamwork skills.",
//             documentsHeading:"",
//           documents: [],
//         },
       
  
//       ],
//       },
//         {
//         id: 710,
//         heading: "Conclusion",
//           contentStart:"B.Tech AI & ML gives you a strong path into a fast growing field. Focus on coding, math, tools, and projects from the course and syllabus. Keep learning and you can build a strong career in AI and ML.",
//           contentLast:`Join [BBS College](/) of Engineering & Technology today and start learning at the [best BTech college in UP](/btech-aiml) for the future.`
//       },
     
  
//     ],
//   },
//   {
//     id: 8,
//     slug: "jobs-after-btech",
//     seo: {
//       title: "Best Jobs After B.Tech: Career Paths & Salary Guide",
//       description:
//         "Explore top jobs after B.Tech with salary ranges, career opportunities, and government options. Find the right path for your engineering future.",
//         keywords:"jobs after B.Tech"
//     },

//     sections: [
//       {
//         id: 801,
//      hero:true,
//         heading:
//           "Best Jobs After B.Tech: Career Paths Explained",
//         content:
//          `After [B.Tech,](https://en.wikipedia.org/wiki/Bachelor_of_Technology) the main question is which jobs after B.Tech to pick. Your branch, skills, college, and city decide a lot. In private companies in India, most freshers start at 3 to 6 LPA. Government and PSU jobs after B.Tech usually pay more (8+ LPA) but need exams like GATE. This guide lists real options branch by branch.`,
          
//       },

//            {
//         id: 802,
//         heading: "Computer Science Engineering Jobs",
//         image: "/blogImage/jobsAfterBtech/cseJobs.webp",
//          content:
//           "CSE gives you tons of jobs after B.Tech since tech never stops growing.",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Private Sector Jobs in IT and Tech",
//              table: {
//           id: 1,
          
//           headers: ["Job Title","Fresher Salary (LPA)"],
//           rows: [
//             { id: 1, cols: ["Software Developer","3.5 to 7"],link:""
//              },
//             { id: 2, cols: ["Data Scientist","4 to 8 (needs strong projects)"], link:"" },
//             { id: 3, cols: ["Machine Learning Engineer","4.5 to 9 (skilled candidates)"], link:"" },
//              { id: 4, cols: ["DevOps / Cloud Engineer","4 to 8"], link:"" },
//               { id: 5, cols: ["Product Manager","Rare for freshers"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//             subTitleLast:"Most guys start with developer roles in jobs after B.Tech. Data science and ML need extra projects and practice to land well. A product manager is tough right out of college.",
//             subTitleLastHighlights:`Hot trend: AI, cloud, and cybersecurity are opening up high-demand jobs after B.Tech.`,
            
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Government Jobs for CSE Graduates",
//           subTitle:
//             "",  
//             subTitleLast:"These give solid stability for serious prep.",
//             documentsHeading:"",
//           documents: ["DRDO scientist and research posts","NIC and government IT officer roles","PSU IT jobs via GATE (example ~ BEL, ECIL)"],
//         },
       
  
//       ],
//       },
//         {
//         id: 803,
//         heading: "Information Technology Engineering Jobs",
//         image: "/blogImage/jobsAfterBtech/itJobs.webp",
//          content:
//           "IT paths look a lot like CSE but lean more toward systems and networks.",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Private IT Company Roles",
//              table: {
//           id: 1,
          
//           headers: ["Job Title","Fresher Salary (LPA)"],
//           rows: [
//             { id: 1, cols: ["System Analyst","3.5 to 6"],link:""
//              },
//             { id: 2, cols: ["Network Engineer","3 to 6"], link:"" },
//              { id: 3, cols: ["Database Administrator","3.5 to 6"], link:"" },
//               { id: 4, cols: ["IT Consultant","4 to 7"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//             subTitleLast:"",
//             subTitleLastHighlights:`Hot trend: Cloud support and security roles pay better as demand grows for jobs after B.Tech.`,
            
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Government IT and Technical Posts",
//           subTitle:
//             "",  
//             subTitleLast:"",
//             documentsHeading:"",
//           documents: ["IT officer posts in central/state departments","PSU technical roles (example ~ BSNL technical)"],
//         },
       
  
//       ],
//       },
//        {
//         id: 804,
//         heading: "Mechanical Engineering Jobs",
//         image: "/blogImage/jobsAfterBtech/mechanicalEngJobs.webp",
//          content:
//           "Mechanical is hands-on engineering work, mostly in factories and plants.",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Private Manufacturing and Design Jobs",
//              table: {
//           id: 1,
          
//           headers: ["Job Title","Fresher Salary (LPA)"],
//           rows: [
//             { id: 1, cols: ["Design Engineer","3 to 6"],link:""
//              },
//             { id: 2, cols: ["Production Engineer","3 to 5"], link:"" },
//              { id: 3, cols: ["Automation Engineer","3.5 to 6"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//             subTitleLast:"",
//             subTitleLastHighlights:`Hot trend: Electric vehicles and renewable energy are pushing new demand and better pay in jobs after B.Tech.`,
            
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Government Mechanical Engineer Posts",
//           subTitle:
//             "",  
//             subTitleLast:"",
//             documentsHeading:"",
//           documents: ["BHEL, ONGC, and other PSU roles","Government plant and maintenance posts"],
//         },
       
  
//       ],
//       },
//       {
//         id: 805,
//         heading: "Civil Engineering Jobs",
//         image: "/blogImage/jobsAfterBtech/civilEngJobs.webp",
//          content:
//           "Civil connects straight to buildings, roads, and public stuff.",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Private Construction and Infrastructure Jobs",
//              table: {
//           id: 1,
          
//           headers: ["Job Title","Fresher Salary (LPA)"],
//           rows: [
//             { id: 1, cols: ["Site Engineer","3 to 5"],link:""
//              },
//             { id: 2, cols: ["Structural Engineer","3.5 to 6"], link:"" },
//              { id: 3, cols: ["Project Engineer","4 to 6"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//             subTitleLast:"",
//             subTitleLastHighlights:`Hot trend: Big infra projects, metro work, and smart cities mean steady career opportunities and jobs after B.Tech.`,
            
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Government Civil Engineer Jobs",
//           subTitle:
//             "",  
//             subTitleLast:"",
//             documentsHeading:"",
//           documents: ["PWD and municipal engineering posts","Railway engineering services"],
//         },
       
  
//       ],
//       },
//       {
//         id: 806,
//         heading: "Electrical Engineering Jobs",
//         image: "/blogImage/jobsAfterBtech/electricalEngJobs.webp",
//          content:
//           "Electrical covers power and control systems.",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Private Power and Energy Jobs",
//              table: {
//           id: 1,
          
//           headers: ["Job Title","Fresher Salary (LPA)"],
//           rows: [
//             { id: 1, cols: ["Power Systems Engineer","3.5 to 6"],link:""
//              },
//             { id: 2, cols: ["Renewable Energy Engineer","3.5 to 6"], link:"" },
//              { id: 3, cols: ["Control Systems Engineer","3.5 to 6"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//             subTitleLast:"",
//             subTitleLastHighlights:`Hot trend: Solar, wind, and EV charging are creating fresh options in jobs after B.Tech.`,
            
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Government Electrical Engineer Posts",
//           subTitle:
//             "",  
//             subTitleLast:"",
//             documentsHeading:"",
//           documents: ["State electricity boards and PSUs","Engineering services exams"],
//         },
       
  
//       ],
//       },
//          {
//         id: 807,
//         heading: "Electronics and Communication Engineering Jobs",
//         image: "/blogImage/jobsAfterBtech/ElectronicsEngJobs.webp",
//          content:
//           "ECE mixes hardware with communication tech.",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Private Electronics and Telecom Jobs",
//              table: {
//           id: 1,
          
//           headers: ["Job Title","Fresher Salary (LPA)"],
//           rows: [
//             { id: 1, cols: ["Embedded Engineer","4 to 8"],link:""
//              },
//             { id: 2, cols: ["Telecom Engineer","3.5 to 6"], link:"" },
//              { id: 3, cols: ["VLSI Engineer","5 to 10 (if skilled)"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//             subTitleLast:"VLSI and embedded pay more with good hands-on skills from your college.",
//             subTitleLastHighlights:`Hot trend: Chip design, 5G, and AI hardware are growing fast for jobs after B.Tech.`,
            
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Government ECE Engineer Posts",
//           subTitle:
//             "",  
//             subTitleLast:"",
//             documentsHeading:"",
//           documents: ["ISRO, DRDO technical roles","Bharat Electronics Limited and similar PSUs"],
//         },
//       ],
//       },
//         {
//         id: 808,
//         heading: "Chemical Engineering Jobs",
//         image: "/blogImage/jobsAfterBtech/ChemicalEngJob.webp",
//          content:
//           "Chemical is all about process plants and safety.",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Private Chemical and Process Industry Jobs",
//              table: {
//           id: 1,
          
//           headers: ["Job Title","Fresher Salary (LPA)"],
//           rows: [
//             { id: 1, cols: ["Process Engineer","3.5 to 6"],link:""
//              },
//             { id: 2, cols: ["Plant Operations Engineer","3 to 6"], link:"" },
//              { id: 3, cols: ["R&D Engineer","4 to 6"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//             subTitleLast:"Higher R&D usually needs an M.Tech or a PhD.",
//             subTitleLastHighlights:``,
            
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Government Chemical Engineer Posts",
//           subTitle:
//             "",  
//             subTitleLast:"",
//             documentsHeading:"",
//           documents: ["IOCL, ONGC, and refinery PSUs","Fertilizer plant engineering posts"],
//         },
//       ],
//       },
//        {
//         id: 809,
//         heading: "Biotechnology Engineering Jobs",
//         image: "/blogImage/jobsAfterBtech/BiotechEngJobs.webp",
//          content:
//           "Biotech blends biology with engineering systems.",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Private Pharma and Research Jobs",
//              table: {
//           id: 1,
          
//           headers: ["Job Title","Fresher Salary (LPA)"],
//           rows: [
//             { id: 1, cols: ["Bioprocess Engineer","3.5 to 6"],link:""
//              },
//             { id: 2, cols: ["Clinical Research Associate","3 to 6"], link:"" },
//              { id: 3, cols: ["Bioinformatics Analyst","4 to 8 (often needs MSc)"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//             subTitleLast:"Many lab and R&D roles pay better after higher studies.",
//             subTitleLastHighlights:``,
            
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Government Lab and Research Posts",
//           subTitle:
//             "",  
//             subTitleLast:"",
//             documentsHeading:"",
//           documents: ["CSIR labs and ICMR posts","Agricultural and health research institutes"],
//         },
//       ],
//       },
//       {
//         id: 810,
//         heading: "AI and ML Jobs",
//         image: "/blogImage/jobsAfterBtech/AiMiJobs.webp",
//          content:
//           "AI and Machine Learning are growing fast and creating new jobs after B.Tech. Companies are using data and smart systems in many industries.",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Private AI and ML Roles",
//              table: {
//           id: 1,
          
//           headers: ["Job Title","Fresher Salary (LPA)"],
//           rows: [
//             { id: 1, cols: ["Machine Learning Engineer","4.5 to 8"],link:""
//              },
//             { id: 2, cols: ["Data Scientist","4 to 7"], link:"" },
//              { id: 3, cols: ["AI Engineer","5 to 9"], link:"" },
//              { id: 4, cols: ["Data Analyst","3.5 to 6"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//             subTitleLast:"Strong coding skills and real projects are important to enter this field.",
//             subTitleLastHighlights:``,
            
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Government AI and ML Posts",
//           subTitle:
//             "",  
//             subTitleLast:"These roles offer stable jobs after B.Tech with steady growth.",
//             documentsHeading:"",
//           documents: ["DRDO technical roles","ISRO data posts","NIC analyst positions"],
//         },
//       ],
//       },
//       {
//         id: 811,
//         heading: "Automobile Engineering Jobs",
//         image: "/blogImage/jobsAfterBtech/AutoMobileEngJobs.webp",
//          content:
//           "Automobiles focus on vehicles and production.",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Private Automobile Company Jobs",
//              table: {
//           id: 1,
          
//           headers: ["Job Title","Fresher Salary (LPA)"],
//           rows: [
//             { id: 1, cols: ["Vehicle Design Engineer","3.5 to 6"],link:""
//              },
//             { id: 2, cols: ["Powertrain Engineer","3.5 to 6"], link:"" },
//              { id: 3, cols: ["Test Engineer","3 to 6"], link:"" },
//           ],
//         },
//           subTitle:
//             "",
//             subTitleLast:"",
//             subTitleLastHighlights:`Hot trend: EV manufacturing and battery tech are bringing new jobs after B.Tech.`,
            
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Government Transport and PSU Jobs",
//           subTitle:
//             "",  
//             subTitleLast:"",
//             documentsHeading:"",
//           documents: ["Vehicle test centers and PSU manufacturing units"],
//         },
//       ],
//       },
          
      
//         {
//         id: 810,
//         heading: "Conclusion",
//           contentStart:"Most private jobs after B.Tech start around 3 to 6 LPA. Your college, city, and skills can push it higher. Government and PSU roles give better starting pay but need exams like GATE. Focus on practical skills, solid internships, and certifications like AWS or GATE prep that beats branch alone. Pick what you actually enjoy, build real projects, and you'll land good jobs after B.Tech with solid career growth.",
//           contentLast:`Start your journey with one of the [top B.Tech colleges in UP. BBS College](/computer-science-engineering) offers quality education, modern labs, and strong placement support to help you build a successful career.`
//       },
     
  
//     ],
//   },
//   {
//     id: 9,
//     slug: "engineering-internships",
//     seo: {
//       title: "Engineering Internships: Benefits for Engineering Students",
//       description:
//         "Discover the benefits of engineering internships, how students gain real skills, industry exposure, and better career opportunities through internships.",
//         keywords:"Engineering Internships"
//     },

//     sections: [
//       {
//         id: 901,
//      hero:true,
//         heading:
//           "Benefits of Internships During Engineering Studies",
//         content:
//           "Want a fast way to prove you have real work skills, not just good marks? Engineering internships do that for you. They show you exactly how engineering jobs run in real life. They let you learn tools that are important on the job. They also help to find work after college. If you study engineering, doing one or two engineering internships while in college can shift how you think about your future job. It gets you much better prepared.",
          
//       },
//       {
//         id: 902,
//         heading: "What Is an Internship in Engineering?",
//         image: "/blogImage/engineeringInternship/whatIsanInternship.webp",
//          content:
//           "An internship means a short time working at a company, lab, or small startup. You become part of a team. You follow a guide or mentor. You take on real jobs that help the project move forward. Some engineering internships pay you. Some do not pay. A lot now come as an online internship. Most run from a few weeks up to a few months.",},
//       {
//         id: 903,
//         heading: "Practical Skills Gained from Internship",
//         contentStart:"Here are the usual skills students gain from engineering internships. It also shows what kind of work helps you learn each one.",
//         contentLast:"These real skills mostly come from engineering internships. Owners want people who have them.",
//         table: {
//           id: 90,
//           headers: ["Engineering Field","Practical Skills Learned","Example Work During Internship"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Mechanical Engineering","CAD design, machine testing, and manufacturing process understanding","Making 3D models in CAD software, helping put machines together"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["Civil Engineering","Site checks, construction planning, basic structural analysis","Assisting engineers review building plans or watching site work"],
//                link:""
//             },
//             {
//               id: 3,
//               cols: ["Electrical Engineering","Circuit design, testing electrical setups, using measuring tools","Testing circuits, looking at power supply systems"],
//                link:""
//             },
//             {
//               id: 4,
//               cols: ["Computer Science / IT","Programming, fixing bugs, software testing, version control","Writing code, removing errors, using tools like Git"],
//                link:""
//             },
//             {
//               id: 5,
//               cols: ["Electronics Engineering","PCB design, microcontroller coding, circuit testing","Putting together small circuits or checking sensors"],
//                link:""
//             },
//             {
//               id: 6,
//               cols: ["Chemical Engineering","Process watching, lab tests, safety rules","Helping check plant processes or doing lab work"],
//                link:""
//             },
            
//           ],
//         },
//       },
//        {
//         id: 904,
//         heading: "Industry Exposure for Engineering Students",
//         image: "/blogImage/engineeringInternship/industryExposure.webp",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Understanding How Engineering Companies Work",
//           subTitle:
//             "",
//             subTitleLast:"In engineering internships, you watch how teams get built. You see projects start as ideas and end as real products. You notice how strict time plans guide everything. This lets students think way past what books and classes teach.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Learning Industry Tools and Technologies",
//           subTitle:
//             "",  
//             subTitleLast:"Engineering internships open doors to tools that colleges might not have much of. You get to try version control, CAD, simulation programs, or test setups. Practice with them helps you work quicker and add more value from day one on a job.",
//             documentsHeading:"",
//           documents: [],
//         },
//          {
//           id: 3,
//           title: "Working with Experienced Engineers",
//           subTitle:
//             "",  
//             subTitleLast:"You see how experienced engineers make plans, run tests, and fix things. The quick tips and smart habits you pick up here do not show up easily in textbooks.",
//             documentsHeading:"",
//           documents: [],
//         },
       
  
//       ],
//       },
//       {
//         id: 905,
//         heading: "Career Benefits of Engineering Internships",
//         image: "/blogImage/engineeringInternship/careerBenefits.webp",
//         contentLast:"Check out [Best Jobs After B.Tech: Career Paths Explained](/blogs/jobs-after-btech) to explore top career options and choose the right path after engineering.",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Stronger Resume for Future Jobs",
//           subTitle:
//             "",
//             subTitleLast:"A resume with actual work experience jumps out. Companies want to see jobs you finished and what came from them. List the projects and your part in them when you apply.",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Higher Chances of Campus Placement",
//           subTitle:
//             "",  
//             subTitleLast:"Many companies hire back the interns they liked first. If you show you pick up fast and get work done, you could get a job offer before you even finish college.",
//             documentsHeading:"",
//           documents: [],
//         },
//          {
//           id: 3,
//           title: "Better Career Direction and Specialisation Choice",
//           subTitle:
//             "",  
//             subTitleLast:"After one or two engineering internships, you learn what work you enjoy most. This makes picking classes, extra subjects, and a job direction much clearer.",
//             documentsHeading:"",
//           documents: [],
//         },
       
  
//       ],
//       },
//       {
//         id: 906,
//         heading: "Networking Opportunities Through Internships",
//         contentStart:"Engineering internships put you next to people who can help later on. Here are easy ways to build those links:",
//         contentLast:"Solid links can bring job ideas, recommendations, or new chances later.",
//         image: "/blogImage/engineeringInternship/networking.webp",
//         points: [
//           { id: 1, text: "Chat with team members and ask short, helpful questions." },
//           { id: 2, text: "Stay connected with mentors even after the internship stops." },
//           { id: 3, text: "Put your work up on a portfolio or GitHub." },
//           { id: 4, text: "Ask for a quick note about your work or a reference." },
//         ],
//       },
//        {
//         id: 907,
//         heading: "Self-Improvements",
//         contentSections:[
//   {
//     id: 1,
//     title: "Improving Confidence",
// description:"Doing real work and hearing feedback makes you trust your own abilities more."

//   },
//    {
//     id: 2,
//       title: "Professional Behaviour",
// description:"You pick up how to sit in meetings, handle comments, and stick to basic office rules."
//   },
//   {
//     id: 3,
//       title: "Learning Workplace Discipline",
// description:"Set hours, regular updates, and due dates teach you to plan and keep at it every day."
//   },
//   {
//     id: 4,
//        title: "Handling Responsibilities and Deadlines",
// description:"When your part counts for the team, you get good at finishing on time and dealing with stress."
//   },
// ],
//         image: "",
//       },
//       {
//         id: 908,
//         heading: "Platforms to Find Engineering Internships",
//         contentStart:"Here are spots where lots of students find engineering internships. Try more than one and start applying soon.",
//         contentLast:"Good summer engineering internships usually open from December to April for May-July times. Longer six-month ones ask for earlier applications. In India, many engineering internships pay between ₹5,000 and ₹50,000 a month, based on the place and job.",
// table: {
//           id: 1,
//           headers: ["Platform","What it offers"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Internshala", "Lots of options across branches, lists, pay and needed skills"],
//               link:"https://internshala.com/",
//             },
//             {
//               id: 2,
//               cols: ["LinkedIn","Company updates and ways to reach recruiters directly"],link:"https://www.linkedin.com/",
//             },
//             {
//               id: 3,
//               cols: ["Naukri.com","Big job site with filters just for internships"],
//               link:"https://www.naukri.com/",
//             },
//             {
//               id: 4,
//               cols: ["Indeed","Listings from around the world, simple apply button"],  
//               link:"https://in.indeed.com/",
//             },
//             {
//               id: 5,
//               cols: ["Glassdoor","Jobs plus reviews of companies and interview advice"],
//               link:"https://www.glassdoor.co.in/index.htm"
//             },
//             {
//               id: 6,
//               cols: ["Wellfound (AngelList)","Strong for tech and startup jobs, mostly software"],
//               link:"https://wellfound.com/"
//             },
//             {
//               id: 7,
//               cols: ["AICTE National Internship Portal","Backed by government, many checked and safe options"],
//               link:"https://internship.aicte-india.org/internshipbygoogle.php"
//             },
//             {
//               id: 8,
//               cols: ["Unstop","Mix of contests, hackathons, and internship openings"],
//               link:"https://unstop.com/"
//             },
//           ],
//         },
//       },
//        {
//         id: 603,
//         heading: "Ways to look better when applying :",
//         image: "",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "",
//           subTitle:
//             "",
//           documents: ["Make a clean resume that highlights your projects.","Write a short note saying why you match the role.","Send to plenty of companies, not only a couple.","Add links to college projects or GitHub."],
//         },
//         {
//           id: 2,
//           title: "Note for branches :",
//           subTitle:
//             "software and computer science, see more online internship options. Branches like mechanical and civil often find more on-site or factory roles through company sites or college placement offices.",  
//             documentsHeading:"",
//           documents: [],
//         },
//       ],
//       },
//         {
//         id: 710,
//         heading: "Conclusion",
//           contentStart:"Engineering internships hand you skills, real tools, team time, and a better sense of where your job can go. They grow both your tech side and your personal side. Aim to grab at least one during your studies. Choose something that tests you, ask away, do tasks well, and keep picking up new things. These habits make starting your first real job feel way smoother.",
//           contentLast:`Join [BBS College,](/) one of the [best private engineering colleges in UP,](/computer-science-engineering) and start building a strong future in engineering today.`
//       },
     
  
//     ],
//   },
//     {
//     id: 10,
//     slug: "legal-career",
//     seo: {
//       title: "Steps to Start Legal Careers in India: Courses, Exams Guide",
//       description:
//         "Learn the steps to start legal careers in India. Know law courses, entrance exams, internships, and career paths after a law degree.",
//         keywords:"Legal Careers"
//     },

//     sections: [
//       {
//         id: 1001,
//      hero:true,
//         heading:
//           "Steps to Start a Legal Career in India",
//         content:
//           "Many people watch lawyers in court and wonder how they got there. The path to legal careers in India starts with good studies and real training. Legal careers are not just about courtrooms. They include corporate jobs, research, and even international work. Knowing the basic steps helps you see how legal careers begin and grow in India.",
          
//       },
//       {
//         id: 1002,
//         heading: "What Are Legal Careers in India?",
//         image: "/blogImage/legalCareer/whatAreLegalCareers.webp",
//          content:
//           "Legal careers mean different jobs that use law knowledge. You can fight cases in court, give legal advice to companies, help make laws, teach, or do research. In short, legal careers are jobs where you use law to solve problems or guide people.",
//            steps: [
//         {
//           id: 1,
//           title: "Common places law graduates work:",
//           subTitle:
//             "",  
//             subTitleLast:"Some choose more international work, like deals across borders. Others stay with local issues. Each path needs skills like good talking, clear writing, or deep research.",
//             documentsHeading:"",
//           documents: ["Courts and cases for clients","Corporate legal teams in businesses","Government offices and policy teams","Universities and research places for legal studies","NGOs and groups that give free legal help"],
//         },
//       ],},
//       {
//         id: 1003,
//         heading: "Law Courses in India",
//         contentStart:"You pick courses based on where you are now and what you want later.",
//         contentLast:"If you aim for corporate or international law, an LLM or short course can help a lot",
//         table: {
//           id: 100,
//           headers: ["Course","Duration","Who it fits","Main focus"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Integrated law course","5 years","After Class 12","Law plus other subjects"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["LLB","3 years","After any degree","Main law topics and practice"],
//                link:""
//             },
//             {
//               id: 3,
//               cols: ["LLM","1–2 years","After LLB","Deep topics and expert area"],
//                link:""
//             },
//             {
//               id: 4,
//               cols: ["Diploma / Certificate","Few months to 1 year","People already working","Special skills like tax or cyber law"],
//                link:""
//             }, 
//           ],
//         },
//       },
//        {
//         id: 1003,
//         heading: "Law Entrance Exams in India",
//         image: "/blogImage/legalCareer/lawEntranceExams.webp",
//         contentStart:"Most good courses need an entrance test. These check reading, thinking, and basic news knowledge.",
//          content:
//           "",
//            steps: [
//         {
//           id: 1,
//           title: "Main national and common exams",
//           subTitle:
//             "",  
//             subTitleLast:"LSAT India has stopped now. Use old papers, watch the time, and read daily news for prep.",
//             documentsHeading:"",
//           documents: ["CLAT (Common Law Admission Test)","AILET (All India Law Entrance Test)","SLAT (Symbiosis Law Admission Test)","State and university tests like MH CET Law"],
//         },
//       ],},
//        {
//         id: 1003,
//         heading: "Career Paths After a Law Degree",
//         contentStart:"A law degree opens many roads. Think about what you like most before you choose.",
//         contentLast:"In January 2026, news about 2.52 lakh people took the AIBE 20. Around 69.21% passed. This shows lots of legal careers in India.",
//         table: {
//           id: 100,
//           headers: ["Path","What you do","Typical roles"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Litigation","Fight for clients in court","Advocate, trial lawyer"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["Corporate law","Help companies with deals and rules","In-house counsel, legal associate"],
//                link:""
//             },
//             {
//               id: 3,
//               cols: ["Government work","Handle policy and public law","Legal officer, prosecutor"],
//                link:""
//             },
//             {
//               id: 4,
//               cols: ["Academia","Teach law and do research","Lecturer, researcher"],
//                link:""
//             }, 
//             {
//               id: 5,
//               cols: ["Compliance and advisory","Check if firms follow laws","Compliance officer, consultant"],
//                link:""
//             }, 
//             {
//               id: 6,
//               cols: ["Legal services","Help with papers and support","Paralegal, legal analyst"],
//                link:""
//             }, 
//           ],
//         },
//         steps: [
//         {
//           id: 1,
//           title: "Steps to become an advocate",
//           subTitle:
//             "",  
//             subTitleLast:"No age limit, and you can try as many times as needed for AIBE.",
//             documentsHeading:"",
//           documents: ["1. Join your State Bar Council. Bring your degree, ID, and fees.","2. Pass the All India Bar Examination (AIBE). It is an open-book on basic law.","3. Get the Certificate of Practice. Then you can take cases in any court in India."],
//         },
//       ],
        
//       },
//        {
//         id: 1004,
//         heading: "Internships and Practical Training",
//         image: "/blogImage/legalCareer/internships.webp",
//         contentStart:"Real work is key. Bar Council says to do internships during the course, for about 12 to 20 weeks total. Start early, like year two or three, to learn skills and meet people.",
//          content:
//           "",
//            steps: [
//         {
//           id: 1,
//           title: "Good places for internships",
//           subTitle:
//             "",  
//             subTitleLast:"",
//             documentsHeading:"",
//           documents: ["Law firms and corporate legal teams","Courts and judges’ offices","NGOs and legal help groups","Government legal offices"],
//         },
//       ],},
//       {
//         id: 1005,
//         heading: "Common Mistakes Law Students Should Avoid",
//          content:
//           "",
//            steps: [
//         {
//           id: 1,
//           title: "Some mistakes slow you down. Stay away from these.",
//           subTitle:
//             "",  
//             subTitleLast:"Build talking, writing, and case reading habits from the start.",
//             documentsHeading:"",
//           documents: ["Waiting for internships till last year","Only reading books and skipping real work","Not practising writing papers or court mocks","Missing simple tech like online filing and law tools","Copying others instead of finding your own way"],
//         },
//       ],},  
//         {
//         id: 1006,
//         heading: "Conclusion",
//           contentStart:"Starting a legal career in India begins with the right studies and training. First, choose the law course that matches your education, then prepare for entrance exams and complete your law degree. Internships during your studies help you understand real legal work. After graduation, you can practice in court by enrolling with the State Bar Council and passing the AIBE, or move into corporate, research, or other legal careers, depending on your interests.",
//           contentLast:`Start your journey in legal careers with [BBS College.](/) Apply now and take admission in one of the [best law colleges in UP.](/ba-llb) Here, you not only learn theory but also gain real-life practical experience through an updated syllabus and case studies. You also get guidance from experienced teachers and regular exposure to practical legal work.`
//       },
     
  
//     ],
//   },
//    {
//     id: 11,
//     slug: "best-engineering-colleges",
//     seo: {
//       title: "How to Select the Best Engineering Colleges for Your Career",
//       description:
//         "Learn how to choose the best engineering colleges. Check accreditation, faculty, placements, curriculum, and fees before selecting the right college.",
//         keywords:"best engineering colleges"
//     },

//     sections: [
//       {
//         id: 1011,
//      hero:true,
//         heading:
//           "How to Select the Best Engineering College for Your Career",
//         content:
//           "Picking the right engineering college is a big deal for your future. A lot of students only look at entrance exam scores and skip other important stuff. A good college builds strong technical skills, gives real practice, and gets you ready for jobs. Before you decide on the best engineering colleges, compare them well with real facts.",
          
//       },
//       {
//         id: 1012,
//         heading: "Importance of the Right Engineering College",
//         image: "/blogImage/bestEngineeringColleges/engineeringCollege.webp",
//          content:
//           `The college you pick shapes your skills and job future a lot. Engineering is not just theory from books. You have to learn by doing labs, projects, and solving real problems.
          
// A good college setup helps you learn more quickly and pick up useful experience. Many of the best engineering colleges focus on both book stuff and hands-on learning.`,
//            steps: [
//         {
//           id: 1,
//           title: "Good engineering colleges usually offer:",
//           subTitle:
//             "",  
//             subTitleLast:"When you study in places with good rules and systems, you mostly get better tech knowledge and feel more ready for jobs.",
//             documentsHeading:"",
//           documents: ["Better teachers and study help","New labs and learning tools","Chances for internships and seeing real company work","Active tech clubs and project work","Job placement help and career advice"],
//         },
//       ],},
//       {
//         id: 1013,
//         heading: "Check College Accreditation and Approval",
//          image: "/blogImage/bestEngineeringColleges/checkCollege.webp",
//         content:`Before you think about labs or job placements, first check if the college is properly accredited and recognized.
          
// Engineering colleges in India have to follow national rules. Checking approvals makes sure the college keeps good quality in studies. Many of the best engineering colleges have a solid approval history.`,
//       steps: [
//         {
//           id: 1,
//           title: "Key things to check:",
//           subTitle:
//             "",  
//             subTitleLast:"",
//             documentsHeading:"",
//           documents: ["AICTE approval: The college must have approval from All India Council for Technical Education. This is needed for all engineering colleges in India.","NBA accreditation: The National Board of Accreditation checks each engineering program. If it has an NBA, the program usually meets better study and job rules.","NAAC grade: The National Assessment and Accreditation Council checks the whole college. Higher grades mean better teaching and setups.","NIRF ranking: The National Institutional Ranking Framework ranks colleges all over India. In the engineering list, it helps compare on research, teaching, and jobs."],
//         },
//          {
//           id: 2,
//           title: "Always check these on the official sites:",
//           subTitle:
//             "",  
//             subTitleLast:"Using real official sites keeps the info correct.",
//             documentsHeading:"",
//           documents: ["AICTE website","NBA accreditation website","NAAC portal","NIRF ranking website"],
//         },
//       ],
//       },
//       {
//         id: 1014,
//         heading: "Look at the College Reputation and Faculty Quality",
//          image: "/blogImage/bestEngineeringColleges/collegeReputation.webp",
//         content:`How people talk about a college shows its real long-term record in teaching, research, and jobs.
          
// A simple way to compare is see the NIRF ranking in the engineering section. Colleges high up usually have good teachers, do research, and help students get better jobs. That’s why many check rankings when picking the best engineering colleges.

// Teachers matter a lot. Good ones with experience explain tough things clearly and guide projects well.`,
//       steps: [
//         {
//           id: 1,
//           title: "Check these:",
//           subTitle:
//             "",  
//             subTitleLast:"Talking to students there now or old students (alumni) can tell you about real teaching quality and the college feel.",
//             documentsHeading:"",
//           documents: ["Qualifications and experience of teachers","Research or papers done by teachers","If teachers worked in industry","Number of students per teacher"],
//         }
//       ],
//       },
//        {
//         id: 10014,
//         heading: "Examine Infrastructure and Facilities",
//         contentStart:`Engineering needs lots of practical work. Good setups let you try things out in experiments and projects. The best engineering colleges put money into new labs and tech stuff.
          
// Look at these:`,
// contentLast:"Strong setups help build real skills and fresh ideas.",
//  table: {
//           id: 100,
//           headers: ["Facility","Why it matters","What to check"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Laboratories","Practical learning and experiments","Updated equipment and regular lab sessions"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["Workshops","Hands-on technical training","Proper tools and machines"],
//                link:""
//             },
//             {
//               id: 3,
//               cols: ["Library","Study and research support","Books, journals, and digital resources"],
//                link:""
//             },
//             {
//               id: 4,
//               cols: ["Computer labs","Coding and simulation work","Modern computers and the required software"],
//                link:""
//             }, 
//             {
//               id: 5,
//               cols: ["Internet access","Online learning and research","Reliable campus internet"],
//                link:""
//             }, 
//             {
//               id: 6,
//               cols: ["Student clubs","Skill development","Active coding, robotics, and technical clubs"],
//                link:""
//             }, 
//           ],
//         },
         
//     },
//        {
//         id: 1015,
//         heading: "Analyse Placement Records",
//         image: "/blogImage/bestEngineeringColleges/analysePlacement.webp",
//         contentStart:"Placement numbers tell you how good the college is at helping get jobs after you complete your course. But check them carefully.",
//          content:
//           "",
//            steps: [
//         {
//           id: 1,
//           title: "Look for:",
//           subTitle:
//             "",  
//             subTitleLast:"Check real placement reports or NIRF data, not just college ads. Good placements are why some are called among the best engineering colleges.",
//             documentsHeading:"",
//           documents: ["Placement results over the last three years","Internship chances while studying","Different kinds of companies that come"],
//         },
//       ],
//    },
//       {
//         id: 1016,
//         heading: "",
//         contentLast:"Seeing how it goes over the years shows the true job picture.",
//          content:
//           "",
//       table: {
//           id: 100,
//           headers: ["Placement Factor","What to look for"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Placement percentage","Consistent results over multiple years"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["Median salary","Stable or improving salary trends"],
//                link:""
//             },
//             {
//               id: 3,
//               cols: ["Internship opportunities","Regular internships during study"],
//                link:""
//             },
//             {
//               id: 4,
//               cols: ["Company diversity","Companies from different sectors"],
//                link:""
//             }, 
//           ],
//         },}, 
//          {
//         id: 1018,
//         heading: "Check Industry Exposure",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "Internships and training opportunities",
//           subTitle:
//             "Internships let you work in real companies and learn actual stuff. Colleges that get you internships make you better ready for jobs.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 2,
//           title: "Industry partnerships and collaborations",
//           subTitle:
//             "Some colleges tie up with companies for workshops, training, and guest talks. These show you what companies really expect.",
//             documentsHeading:"",
//           documents: [],
//         },
//         {
//           id: 3,
//           title: "Live projects and practical learning",
//           subTitle:
//             "Doing live projects lets you use tech knowledge on real issues. It builds skills, teamwork, and problem-solving.",
//             documentsHeading:"",
//           documents: [],
//         }
//       ],
//       }, 
//         {
//         id: 1019,
//         heading: "Evaluate Course Curriculum",
//          showSerial: false,
//           steps: [
//         {
//           id: 1,
//           title: "",
//           subTitle:
//             "",
//             subTitleLast:"Also, check if the college is autonomous or linked to a good university. Autonomous ones update courses faster and add new topics more quickly.",
//             documentsHeading:"",
//           documents: ["Updated syllabus and modern subjects: Tech moves fast, so courses should have new things like artificial intelligence, machine learning, data science, and cloud computing.","Practical learning and project work: Courses need labs, design projects, and technical tasks. These give real hands-on experience.","Flexibility to choose electives: Electives let you pick subjects you like or that fit your job plans."],
//         }
//       ],
//       }, 
//         {
//         id: 1020,
//         heading: "Compare Fees and Financial Support",
//         contentStart:`Money is important too. Look at the total cost for the whole course, not just one year's fee.`,
// contentLast:"Knowing full costs helps plan better.",
//  table: {
//           id: 100,
//           headers: ["Expense Area","What to check"],
//           rows: [
//             {
//               id: 1,
//               cols: ["Tuition fees","Total cost for all years"],
//                link:""
//             },
//             {
//               id: 2,
//               cols: ["Hostel and living costs","Accommodation, food, and travel"],
//                link:""
//             },
//             {
//               id: 3,
//               cols: ["Scholarships","Merit based or need based support"],
//                link:""
//             },
//             {
//               id: 4,
//               cols: ["Education loans","Loan options and repayment plans"],
//                link:""
//             }, 
//             {
//               id: 5,
//               cols: ["Extra charges","Lab fees, exam fees, and other costs"],
//                link:""
//             }
//           ],
//         },
         
//     },
//         {
//         id: 1022,
//         heading: "Conclusion",
//           contentStart:"Choosing an engineering college needs a careful look at approvals, teachers, setups, placements, and courses. Use real info from official places to avoid mistakes. When you check these properly, you can pick from the best engineering colleges that give good learning, real skills, and strong future job chances.",
//           contentLast:`Explore [BBS College,](/) one of [the best private engineering colleges in UP,](/btech-aiml) offering strong academics, modern labs, and career-focused engineering programs.`
//       },
//     ],
//   },
    
//     ]

    export const blogsMarkdownData=[
        {
    id: 1,
    bannerImg:"/blogImage/blogFeature.jpg",
    category: "Campus Life",
    slug: "bba-internships",
      seoTitle: "How BBA Internship Builds Real Experience for Students",
      seoDescription:
        "Discover how a BBA internship helps students gain real work experience, develop skills, and explore top career opportunities after BBA across India.",
        seoKeywords:"BBA internship",
 
    title:
          "How Internships Help BBA Students Build Real Experience",
        description:
          "We all read a lot in our [BBA](https://en.wikipedia.org/wiki/Bachelor_of_Business_Administration) (Bachelor of Business Administration) classes about marketing, finance, and management. But the truth is, reading about business is very different from living it. That’s why BBA internships matter so much. They give us a real look at how work actually happens, how teams deal with pressure, and how decisions are made in real offices. It’s like stepping out of theory and walking into real business life.",
                content:`


##  What Is an Internship for BBA Students

![Bba Student](/blogImage/blogBbaStudent.webp)

A BBA internship is a short period during which we work with a company to learn how businesses run. It’s a chance to take what we study in class and use it in real situations. Usually, students do internships during holidays or in the final semesters of the BBA degree.

We don’t just sit and watch others work. We get small tasks, attend meetings, and help with projects. It’s where we begin to know how the various departments talk, plan, and solve problems. Such an experience brings the lessons in our course in BBA to life and practicality.

## Why Practical Experience Matters in BBA

![Bba Student](/blogImage/BlogPractical.webp)

In business studies, knowing theory isn’t enough. We must understand how it works when it is with real money, time, and people. It is through BBA internships that we start to understand how ideas become outcomes. We notice how strategies are used in real settings.

- We learn how teamwork builds progress.
- We see how time, targets, and pressure shape daily work.
- We understand what managers expect from new employees.

**This mix of study and practice helps us grow faster and makes us more ready for real job opportunities after BBA.**



## How Internships Bridge the Gap Between Theory and Practice


![Engineering College](/blogImage/blogInternship.webp)

Our BBA subjects teach us about business models, planning, and organization. But during a BBA internship, we see how all that fits together in real workplaces. It’s where theory meets practice.

When we work with teams, handle reports, or assist with small decisions, we begin to understand what the books were trying to teach. This experience fills the gap between classroom lessons and real-world understanding.

## Learning How Real Businesses Work

![Engineering College](/blogImage/blogBusinesses.webp)

A BBA internship shows how companies actually run every day. We get to see how plans turn into actions and how every team has a role in reaching goals.

- We learn about reporting and documentation.
- We attend team discussions and observe coordination.
- We see how performance is tracked and reviewed.
- We notice how managers solve daily issues.

**All this helps us build a clear idea of how a company functions from start to finish.**

## Building Key Management and Communication Skills

![Engineering College](/blogImage/blogCommunication.webp)

Working in a company gives us a chance to build important soft skills that no textbook can teach. A BBA internship helps us become better at:

- Writing simple, professional messages and reports.
- Speaking clearly during meetings.
- Listening and responding to feedback.
- Handling small responsibilities with confidence.

**These are the habits that shape how we work and communicate. Over time, they make us more capable and comfortable in professional spaces.**

## Understanding Different Business Departments

![Engineering College](/blogImage/blogUnderstanding.webp)

Every company has many parts working together. During a BBA internship, we see how these departments connect and depend on each other.

- HR looks after hiring, training, and employee growth.
- Finance keeps track of budgets and expenses.
- Marketing studies customer needs and plans strategies.
- Operations ensure smooth workflow and quality output.

**Watching this teamwork helps us understand which area interests us the most. It also guides us when choosing a specialization later in our BBA course or career.**

## Exploring Career Interests and Strengths

Internships are an excellent alternative to determining what sort of work to be in. Some of us love people, whereas others like data or planning. The actual employment reveals our strengths and the areas we should improve on.

This specificity assists in case we have to plan on the next step after having done our BBA, may it be during higher studies or completing an online course, or seeking job opportunities. It is a clever method of determining where we will fit better in the business world.

## Networking With Industry Professionals

During a BBA internship, we meet people already working in the field. These connections can be useful later. Good communication and teamwork during this time can build relationships that open doors in the future.

We learn how to introduce ourselves, talk with professionals, and build trust. These are small steps that often lead to bigger opportunities later in our journey.

## Boosting Resume and Job Opportunities

![Engineering College](/blogImage/blogResume.webp)

A BBA internship adds strong value to our resume. It shows we’ve already worked in a real business environment, even if only for a short time.

- It helps us talk confidently in interviews.
- It gives us stories of real experience to share.
- It proves we understand the basics of teamwork and deadlines.
- It gives us a clear edge over other freshers applying for the same job opportunities.

**Employers prefer people who already understand how offices work, and internships help us become exactly that.**

## Developing Professional Confidence and Work Habits

![Engineering College](/blogImage/blogDevelop.webp)

Professional habits take time to build, and BBA internships help us form them early.

- We learn to be punctual and organized.
- We manage tasks with discipline.
- We accept feedback without fear.
- We take responsibility and initiative.

**Such habits define how we behave in all our future roles. Most of the students observe that they are able to work more efficiently than before, are able to talk better, and think more practically after an internship.**

## How to Find and Choose the Right Internship

It is not difficult to find the right internship when it is planned. Begin by asking them which aspect of business is the most interesting to them: finance, marketing, HR, or operations. You see, we know that, and we may take simple measures:

- Make a clear, short resume that highlights our skills.
- Ask teachers, seniors, or alumni for guidance.
- Look for internships that match our specialization.
- Read internship details carefully, including duration, learning goals, and work type.
- Set small personal goals like improving writing, speaking, or teamwork.

**A well-chosen internship teaches more than we expect, and the lessons stay with us throughout our BBA degree and beyond.**

## Why BBS College Is a Good Choice for BBA Students

![Engineering College](/blogImage/blogGoodChoice.webp)

At [BBS College](/), we focus on helping students learn both from books and real-life experiences. We give practical training, workshops, and BBA internship opportunities so students can use what they study in real work situations. Our teachers are experienced, the course is updated, and we give strong support for jobs. With modern classrooms, industry visits, and skill-based learning, BBS College helps students grow and get ready for good career opportunities after BBA.

## Conclusion

Internships turn lessons from our [BBA course](/bba) into real skills. They make us have confidence, recognize more easily, and equip us for the next phase of life.

A BBA internship is not considered of achieving experience. It is up to creating a good base to develop. It not only makes it easier to know how business is, but it also instills successful habits and enables us to earn better pay and scope of work in the future.

For every student aiming to grow after BBA, an internship is more than a task; it's the first real step into the world of business.
  `
  },
        {
    id: 2,
    bannerImg:"/blogImage/bestBtechCourse/btechBLogBanner.webp",
    category: "Campus Life",
    slug: "best-btech-course-options",
      seoTitle: "Top B.Tech Branches with the Best Career Opportunities",
      seoDescription:
        "Discover the top B.Tech best course options, career paths and branches to choose after 12th. Learn which engineering field offers strong growth and jobs.",
        seoKeywords:"",
 
    title:
          "Top B.Tech Branches with the Best Career Opportunities",
        description:
          "After clearing 12th boards, many Indian parents want their children to become engineers, but when students hear about the different branches of the B.Tech, they panic or get confused. In this confusion, they often end up picking the wrong branch because they do not fully understand the career opportunities linked with each option. Choosing becomes even tougher when every branch sounds important, and everyone around gives different advice. With the right information explained in a clear way, it becomes much easier to see which path actually fits your interests and future goals.",
                content:`


##  What is B.Tech

B.Tech is a four-year engineering degree where you learn to solve real problems using science and technology. These four years include classroom learning, lab work, and practical tasks. Each branch has its own subjects, its own course details, and its own type of jobs. Before taking admission in India, you should check the duration, fees, subjects, and job roles associated with the branch you want. When you understand these things, choosing the B.Tech best course becomes easier.

## Computer Science Engineering

![Computer Science Engineering](/blogImage/bestBtechCourse/computerScienceEngineering.webp)

Computer Science is one of the most common branches because almost every company uses software and digital systems. CSE is a four-year course that covers programming, software design, networks, systems, and many computer-related subjects. Students who enjoy logical thinking usually feel comfortable here. CSE often appears in many courses' lists when students search for the best B.Tech course. 

## Best Career Opportunities

- Software development
- Front-end or back-end roles
- System and architecture planning
- Network and security work
- Mobile app development
- Cloud and server handling
- Software testing and quality checks

## Artificial Intelligence and Machine Learning

![Artificial Intelligence](/blogImage/bestBtechCourse/machineLearning.webp)

AI and ML teach you how to build systems that learn and make decisions on their own. This four-year degree covers algorithms, neural networks, automation, and data training. Many students look at this branch when they want a B.Tech best course linked with future technology.

## Best Career Opportunities

- AI model training
- Machine learning engineer
- Natural language work
- Computer vision projects
- Automation system roles
- Research in computing
- Predictive analytics

## Data Science Engineering

![Data Science Engineering](/blogImage/bestBtechCourse/datascienceengineering.webp)

Data Science focuses on understanding large sets of information. Students learn statistics, data cleaning, pattern study, and tools used to make business decisions. This branch also takes four years and suits students who like numbers. It is often chosen by those searching for the B.Tech. best course for data-based careers.

## Best Career Opportunities

- Data analyst
- Data engineer
- Business intelligence
- ML data support
- Data visualization
- Research-based modeling
- Risk study roles

## Electronics and Communication Engineering

![Electronics and Communication Engineering](/blogImage/jobsAfterBtech/ElectronicsEngJobs.webp)

ECE teaches circuits, electronic devices, signals, and communication systems. It is linked with mobile networks, IoT, and hardware design. This four-year branch suits students who enjoy working with electronic tools and systems.

## Best Career Opportunities

- Network planning
- Embedded system work
- Chip and microcontroller design
- Signal processing
- IoT testing
- Electronic device checks
- Hardware support


## Electrical & Electronics Engineering

![Electronics Engineering](/blogImage/bestBtechCourse/electricalEngineering.webp)

Electrical & Electronics Engineering deals with power, wiring, machines, and large electrical systems. It is one of the oldest branches and still has a strong demand. This four-year degree is preferred by students who want stable job options across many sectors.

## Best Career Opportunities
- Power plant operation
- Electrical design
- Control system engineering
- Energy management
- Industrial automation
- Electrical safety
- Renewable energy projects

## Mechanical Engineering

![Mechanical Engineering](/blogImage/bestBtechCourse/mechanicalEngineeringatBBS.webp)

Mechanical Engineering covers machines, engines, tools, and equipment. Students learn how different parts work together and how movement is created. This four-year degree is chosen by students who enjoy building things and understanding physical systems. It often appears in the B.Tech best course list because of its wide job range.

## Best Career Opportunities
- Machine design
- Production and manufacturing
- Quality testing
- Thermal system maintenance
- Automotive industry work
- Industrial equipment planning
- Research in materials

## Civil Engineering

![Civil Engineering](/blogImage/bestBtechCourse/civilEngineering.webp)

Civil Engineering focuses on building roads, bridges, buildings, and other structures. Students who like field work and project-based tasks usually choose this four-year branch. It is one of the core engineering branches in India.

## Best Career Opportunities
- Building planning
- Construction supervision
- Surveying and layout
- Structural analysis
- Water and waste planning
- Transport system design
- Quality inspection

## Information Technology

![Information Technology](/blogImage/bestBtechCourse/informationTechnology.webp)

IT is close to computer science but more focused on systems, networks, and practical computer use. This four-year degree suits students who enjoy hands-on work. Many prefer IT while searching for the B.Tech best course in private college options.

## Best Career Opportunities
- System administration
- IT support
- Network setup
- Cybersecurity
- Database management
- Cloud service work
- Software testing

## Biotechnology Engineering

![Biotechnology Engineering](/blogImage/bestBtechCourse/biotechnologyEngineering.webp)

Biotechnology mixes biology with technology. Students learn genetics, microbiology, and lab-based subjects. This four-year degree is ideal for students who like biology and want jobs related to research or development.

## Best Career Opportunities
- Lab research
- Food and agriculture research
- Bio product development
- Environmental testing
- Genetic study
- Quality checks
- Enzyme and chemical development

## Robotics and Automation

![Robotics and Automation](/blogImage/bestBtechCourse/roboticsandAutomation.webp)

Robotics and Automation teaches how to build automated machines and systems. Students learn sensors, programming, mechanics, and control systems. This four-year branch is growing fast because industries are moving toward automation.

## Best Career Opportunities

- Robot design
- Automation engineering
- Sensor development
- Industrial robotics
- Smart machine research
- Vision-based programming
- Tool testing

## Which B. Tech Course Is Best

![Which B. Tech Course Is Best](/blogImage/bestBtechCourse/bestBTechCollege.webp)

There is no single best B. Tech course that works for every student. The right choice depends on what you enjoy, the subjects you like, the entrance exam you want to prepare for, the fees you can manage, and the kind of jobs you want later. If you like coding, CSE, IT, or AI may work well. If you like machines, mechanical or robotics may feel right. If you like circuits, electrical or ECE may be better. Students who enjoy biology often choose biotechnology. Look at the details, understand the duration, and choose the branch that fits your long-term goals.

If you want the right start in engineering, explore [BBS College](/). It is known among the best engineering colleges in UP and offers courses that help you build clear skills and a stable future.

## Conclusion

B.Tech has numerous branches, and each branch is going to give a new kind of future. When you know what each branch teaches and how it relates to the jobs, it would be much easier to choose the best B.Tech course. Instead, take some time and reflect on what you are interested in, your strengths, and what you will do once you have completed your degree. A good beginning may bring a good and sound career in engineering in the future.
  `
  },
      {
    id: 3,
    bannerImg:"/blogImage/baLLbCourse/llbBLogBanner.webp",
    category: "Campus Life",
    slug: "ba-llb-hons-course",
      seoTitle: "BA LLB 2026 Course Details, Eligibility, Fees, Jobs & Salary",
      seoDescription:
        "Explore BA LLB 2026 course details, eligibility, age limit, fees, syllabus, subjects, career roles and salary. Simple guide to start your law career.",
        seoKeywords:"",
 
    title:
          "BA. LL.B. (Hons) 2026: Start Your Law Career with Full Course, Roles and Salary Guide",
        description:
          "If you have ever watched a court scene and felt like you want to protect people’s rights or work on big company deals, then a future in law might excite you. [BA. LL.B.](https://en.wikipedia.org/wiki/Bachelor_of_Laws) (Hons) 2026 can help you build that future right after class 12th. This course gives knowledge of society and law together, with added focus on in depth legal study and research through honours papers. In this guide, you will find complete details on course duration, fees, syllabus, jobs, roles, and more. Think of it like a friendly road map for your law career.",
                content:`


##  What is BA. LL.B. (Hons)

![ What is BA. LL.B. (Hons)](/blogImage/baLLbCourse/whatsBaLLb.webp)

BA. LL.B. (Hons) 2026 is a 5 year integrated law course where you study arts and legal subjects together in one degree. You do not need to complete a separate BA first. Along with general law learning, the course allows deeper study in selected law areas, helping you build stronger subject clarity.

## Why choose BA. LL.B. (Hons) in 2026

- Strong demand for legal experts in India
- Growth in cyber safety and corporate legal jobs
- More career options in the government and private fields
- Saves time compared to doing two separate degrees
- Helpful if you later want to become a judge or do an LLM

## Course Highlights

![Course Highlights](/blogImage/baLLbCourse/courses.webp)

| Feature        | Details       | 
|-------------|---------------------|
| Course Duration  | 5 years full time  | 
| Time Period   | 10 semesters   | 
| Learning Mode     | Classroom plus training     |
| Key Activities     | Moot courts, internships, drafting, court visits     | 

This structure helps students learn theory and real world practical skills together.

## Integrated Degree Benefits

- One combined course instead of BA plus LLB
- Humanities knowledge helps in legal reasoning
- Better understanding of clients and society
- Saves one full year compared to separate degrees

## Subjects You Will Study (Year wise)

You will study different subjects each year. Here is a simple view.

| Year        | Focus Area       | Subjects |
|-------------| ---------------------|------------------|
| 1 and 2  | Basics of Arts and Law  | Sociology, Political Science, English, History, Constitutional Law |
| 3   | Main Law Foundation   | Criminal Law, Civil Procedures, Family Law, Contracts, Property Law |
| 4     | Corporate and Administrative Laws     | Company Law, Tax Law, Labour Law, Administrative Law |
| 5     | Advanced Legal Areas     | Cyber Law, IPR, International Law, Legal Drafting, Practical Clinics |

The syllabus gives skills that help in courts and company jobs.

## Skills You Will Learn

- Strong writing and communication
- Public speaking
- Legal research
- Logical thinking
- Case handling and problem solving

These benefits help a lot in both jobs and higher studies.

## Eligibility and Admission Process

![Admission Process](/blogImage/baLLbCourse/admission.webp)

### 1 . 12th Marks Requirement

To join BA. LL.B. (Hons) 2026, students should have 50 to 55 percent marks in class 12. Some relaxation may apply for reserved category students as per rules.

### 2 . Age Limit

Most entrance exams do not keep a strict age limit now, so any student after 12th can apply.

### 3 . Entrance Exams for BA. LL.B. (Hons)

Some colleges take admission through national or state entrance tests. Scores play an important role in top colleges.

### Direct Admission in Private Colleges

Some private colleges offer admission based on class 12 marks or their own selection process.

### 5 . Documents Needed

- Class 10 and 12 mark sheets
- ID proof
- Passport size photographs
- Entrance exam scorecard (if applicable)
- Caste certificate (if required)

## Top Entrance Exams for BA. LL.B. (Hons)

| Exam Name        | Who Accepts It       | Key Focus |
|-------------| ---------------------|------------------|
| [CLAT](https://consortiumofnlus.ac.in/clat-2026/)  | National Law Universities | Legal aptitude, GK, reasoning |
| [AILET](https://nationallawuniversitydelhi.in/)   | NLU Delhi   | Law and reasoning based test |
| [CUET](https://cuet.nta.nic.in/)     | Central Universities     | General test and subjects |
| [LSAT India](https://www.lsac.org/blog/tag/lsat-india)     | Private universities     | Analytical and logical skills |
| State Law Exams    | State colleges     | Varies by state pattern|

These exams check how well you understand logic, English and general knowledge.

## Fee Structure in Government and Private Colleges

![fee](/blogImage/baLLbCourse/fees.webp)

- **Average Fees for Government Colleges:** ₹ 20,000 to ₹2 lakh for the full course duration.

- **Average Fees Private Colleges:*** 3 lakh to 15 lakh, depending on location, reputation, and facilities.

| College Type        | Approx Fees       | 
|-------------| ---------------------|
| Government  | Low and affordable | 
| Private   | Higher but better campus facilities   |

Always compare fees, placements, and training before selecting any college.

## Syllabus Overview

### 1 . Core Law Subjects

- Constitution
- Crimes and Punishments
- Civil laws
- Contracts and companies
- Labour and taxation rules

### 2 . Arts and Humanities Subjects

- History of society
- Economics and business basics
- Political systems
- English writing and speaking

### 3 . Moot Court and Internships

Students argue in a training court to build confidence. Internships under lawyers or firms give real case experience.

### Practical Training and Court Visits

Watching real hearings helps understand how judges, police, and lawyers actually work.

**All these details make BA. LL.B. (Hons) 2026 a complete practical course.**

## Career Paths After BA. LL.B. (Hons)

![After BA. LL.B.](/blogImage/baLLbCourse/careerPath.webp)

- **Advocate:** Argue cases in courts and help clients get justice.
- **Legal Advisor in Companies:** Guide companies on contracts and compliance so they follow rules safely.
- **Government Law Jobs:** Work in public prosecution or legal offices that handle government legal matters.
- **Judiciary Preparation:** After BA. LL.B. Hons 2026, you can prepare for Civil Judge exams to become a judicial officer.
- **Corporate Law and Big Law Firms:** Work on business deals like mergers, finance and technology regulations.
- **Legal Journalism and LPO:** Write news articles related to law or support international legal work through outsourcing companies.

## Salary After BA. LL.B. (Hons)

| Field        | Starting Salary       | Growth with Experience |
|-------------| ---------------------|------------------|
| Litigation  | Low at first | Very high with success |
| Corporate Jobs   | 3 to 6 lakh per year   | 10 to 20 lakh or more |
| Govt Legal Jobs     | Fixed pay scale     | Regular promotions |

### Salary in Litigation

Income depends on clients and cases. Experience brings bigger earnings.

### Salary in Companies

Corporate roles offer stable pay and clearer promotion plans.

### Starting Salary vs Experienced Salary

Freshers earn less but skilled lawyers build strong earning power with time.

## Future Scope of Law in India

![Future Scope of Law in India](/blogImage/baLLbCourse/futureScope.webp)

### 1 . Growth in the Legal Sector

More businesses and new rules are creating increased demand for lawyers

### 2 . High Demand in Corporate and Tech Law

Cybersecurity, fintech companies, and data protection laws need trained lawyers.

### 3 . International Opportunities

After BA. LL.B. Hons 2026, you can study or work abroad by clearing the required exams of that country.

## How to Prepare for BA. LL.B. (Hons) Admission

![Admission](/blogImage/baLLbCourse/prepareForLLb.webp)

### 1 . Focus Subjects in 12th

English and social science topics help in understanding legal subjects.

### 2 . Entrance Exam Preparation Tips

- Read newspapers daily
- Practice reasoning and maths basics
- Try online mock tests
- Solve previous papers

### 3 . Useful Books and Study Sources

- You can use
- NCERT books for basics
- Logical reasoning books
- Current affairs monthlies
- Online platforms for practice

Good books make your preparation strong and save a lot of time.

## Job Roles After BA. LL.B. (Hons)

| Job Role        | Work Area       | 
|-------------| ---------------------|
| Criminal Lawyer  | Crime related cases | 
| Civil Lawyer   | Land, money and disputes   |
| Corporate Lawyer     | Business and company matters    |
| Family Lawyer | Divorce, marriage, and family issues |
| Property Lawyer | Real estate and ownership |
| Cyber Crime Lawyer | Internet fraud and hacking cases |

Each job role has a different work style and earnings. You can choose based on interest.

## Final Advice for BA. LL.B. (Hons) Aspirants

Students who enjoy reading, researching, and helping others with fair solutions.

### 1 . Tips for Success in a Law Career

English and social science topics help in understanding legal subjects.

- Keep improving communication
- Do internships every year
- Make a good network of senior lawyers
- Stay updated on new topics and laws

### This course gives you many opportunities, but dedication is the most important part.

## Conclusion

BA. LL.B. Hons 2026 can launch your law career with a strong foundation. This course combines arts knowledge with legal training, enabling you to understand both society and law. It offers many career paths in courts, government, and global companies. If you are ready to learn with passion and patience, this journey can lead to a respected and rewarding profession.If you are planning to study law, [BBS College](/) can be a smart choice. It is known as one of the [best college for LLB in UP](/llb), offering quality learning and practical legal training


## FAQs

### Q. Why choose BA LL.B. (Hons) over regular BA LL.B.?

BA LL.B. (Hons) offers deeper study in selected law subjects and includes research work. It is more valued by big law firms, while regular BA LLB gives more general legal knowledge.

### Q. Difference between LLB and BA LLB?

LLB is a 3 year law course done after graduation. BA LLB is a 5 year integrated course done after class 12 with arts and law together.

### Q. Is BA LLB a good course?

Yes, BA LLB is a good course for students who want a career in law. It offers many job options in courts, companies, and government offices.

### Q. What will happen after BA LLB course?

After BA LLB, you can work as a lawyer, join companies as legal staff, prepare for judge exams, apply for government jobs, or study further like LLM.

  `
  },
      {
    id: 4,
    bannerImg:"/blogImage/mbaCourse/mbaBlockBanner.webp",
    category: "Campus Life",
    slug: "mba-course",
      seoTitle: "MBA 2026 Complete Guide: Courses, Fees, Eligibility, Career Scope",
      seoDescription:
        "Learn about MBA courses in India for 2026. Know eligibility, fees, duration, types of MBA, and career growth to choose the right MBA course for your future.",
        seoKeywords:"",
 
    title:
          "MBA 2026 Complete Guide: Course, Fees, and Career Scope",
        description:
          "MBA is becoming more popular every year. In this blog we will explain why. We will show what an MBA course is, who it helps, how admissions work in India, the main types of programs, typical fees and duration, and the jobs you can get after. Read this and you will know which MBA course might suit you and how it can help your career.",
                content:`


##  What is MBA Course

![What is MBA Course](/blogImage/mbaCourse/mba.webp)

An MBA course teaches how businesses run. It mixes practical skills and theory. In an MBA course we learn finance basics, marketing ideas, operations, people management, and strategy.Most programs use case studies, group work, projects, and internships so you can apply what you learn.

## Why MBA Still Matters in 2026

- Managers use data and tools more now, so an MBA course helps build tech aware leadership.
- It lets people move from specialist roles to management faster.
- For founders, MBA courses give structure in finance, planning, and go-to-market strategy.

## Who Should Do an MBA

![Who Should Do an MBA](/blogImage/mbaCourse/anMba.webp)

Not everyone needs an MBA course. We think it fits people who want to move into management, change fields, or start a business.

## Skills MBA Helps You Build

- Strategic thinking and planning
- Communication and team leading
- Basic finance and budgeting
- Data reading and decision making

## Career Goals MBA Fits Best

- Move from technical role to project or people management
- Switch function or industry
- Build a startup with business know-how

## Eligibility for MBA 2026

### Basic Education Requirements

Most MBA courses ask for a bachelor's degree from a recognised university. Marks needed vary by program. For integrated programs see the details below.

### Work Experience Rules

- Full time MBA accepts freshers and early career professionals.
- Executive MBA is for mid or senior managers.
- Part time and online formats welcome working learners.

### Age Limits and Flexibility

- There is usually no strict age limit. Many courses are flexible to fit different life stages

## MBA Admission Process 2026

![MBA Admission Process 2026](/blogImage/mbaCourse/admissionProcess.webp)

### Entrance Exams Overview

Many programs use entrance tests that check verbal, quantitative, and logical skills. These scores remain a major part of selection.

### Direct Admission Options

Some courses offer seats through academic record, interviews, or management quotas. Rules differ by program.

### Selection Stages Explained

- Test score or written exam
- Personal interview or group discussion
- Essays or statement of purpose in some programs
- Review of academic and work record

## Types of MBA Courses List and Details


| Course Type        | Typical Duration       |  Who it suits        | Mode       | 
|-------------|---------------------|-------------|---------------------|
| Full Time MBA  | 2 years  |  Fresh graduates and early professionals        | On campus       | 
| Part Time MBA   | 2–4 years   |  Working professionals        | Evenings or weekends       | 
| Executive MBA     | 1–2 years     | 	Senior managers with experience        | Weekend or modular       | 
| Online MBA     | 1–2 years     |  Anyone needing flexibility        | Fully online       | 
| Distance MBA     | 2–3 years       | Those who cannot attend campus       | 	Correspondence or blended     | 
| Integrated MBA     |  5 years        | Students after Class 12 (Higher Secondary)       | Straight entry from school |

This list helps you match the right format to your life stage and goals.

## MBA Specialisations Explained

![MBA Specialisations Explained](/blogImage/mbaCourse/mbaSpecialisations.webp)

We often choose a specialization so we gain deep skills in one area. Common options include:

- **Finance:** corporate finance, investments, risk management.
- **Marketing:** brand building, digital marketing, sales strategy.
- **Human Resource Management:** hiring, training, culture.
- **Operations Management:** supply chain, production, process control.
- **Business Analytics:** data analysis, decision models.
- **International Business:** global markets and trade.
- **Entrepreneurship:** building and scaling startups.

Pick a specialization that aligns with your skills and demand in the industry.

## MBA Course Structure and Subjects

![Course Structure and Subjects](/blogImage/mbaCourse/mbaCourse.webp)

### First Year Core Subjects

The first year usually covers core subjects that all students take:

- Accounting and financial reporting
- Marketing fundamentals
- Organisational behaviour
- Managerial economics
- Quantitative methods and statistics

### Second Year Specialization Subjects

In the second year we focus on specialization subjects and electives related to our chosen field.

### Projects and Internships

- Summer internships between years give real work exposure.
- Final projects often solve real business problems or develop a business plan.

## MBA Fees in India 2026

![MBA Fees](/blogImage/mbaCourse/mbaFees.webp)

### Government College Fee Range

Many government colleges offer MBA courses at lower fees. These are usually state or central institutions where fees stay affordable and depend on the state and program structure. But for some government institutes like IIMs have much higher fees. These fees reflect global level teaching, campus facilities, and strong industry exposure, even though they are government institutions.

### Private College Fee Range

Private colleges have a wide range of fees. Higher fees often come with better infrastructure, industry exposure, and placement support, but this varies by institute.

### Online and Distance MBA Fees

Online and distance MBA courses tend to be more affordable and fit working budgets. Note that for legal validity in India an online MBA must be UGC approved. Without UGC approval the certification may not be valid for government roles or further higher studies.

| Program Type        | Typical Fee Range       | 
|-------------|---------------------|
| Government colleges  | Low to moderate  | 
| Private colleges   | Moderate to high   | 
| Online / Distance (UGC-approved)    | Low to moderate    |
 

## Career Scope After MBA

![Scope After MBA](/blogImage/mbaCourse/careerScope.webp)

### Entry Level Job Roles

- Management trainee
- Business analyst
- Sales or marketing executive
- Financial analyst

### Mid Level Growth Paths

- Team leader or project manager
- Product manager or senior analyst
- HR or operations manager

### Leadership and Management Roles

- Head of function
- General manager
- Senior director or CXO track

 Career progress depends on our performance, network, and continuous learning.

## Salary After MBA in India

![Salary After MBA in India](/blogImage/mbaCourse/salary.webp)

### Average Starting Salary

Starting [salary](https://in.indeed.com/career-advice/finding-a-job/careers-with-an-mba) differs by specialization and institute type. Analytics and finance often start higher. Marketing and HR start moderately and can grow fast with results.

### Salary by Specialisation

- Finance and analytics generally have higher starting pay.
- Marketing and operations reward performance and experience

### Salary Growth Over Time

With promotions and experience salaries rise significantly, especially in leadership positions.

## MBA Jobs by Industry

- Banking and Finance: corporate roles, risk, wealth management.
- Consulting: strategy and operations advisory.
- IT and Technology: product, business analysis, sales.
- Manufacturing and Operations: supply chain and plant roles.
- Startups: roles in growth, product, and operations.

## MBA With and Without Work Experience

### Is Freshers' MBA Worth It

A fresher MBA can kickstart a career switch and faster growth if we use internships and projects well.

### Best Specialisations for Freshers

Marketing and operations suit freshers well. Analytics or finance need comfort with numbers.

### How Experience Adds Value

Experience gives practical context. It helps in class discussions and improves placement chances.

### Best MBA Types for Working Professionals

Part time, executive, and online MBA courses let working people learn while they work and apply new skills immediately.

## Skills Needed to Succeed in MBA

- Clear communication and writing
- Problem solving and logical thinking
- Leadership and decision making
- Basic data skills and spreadsheet comfort

We should build these skills before joining and sharpen them during the course.

## Common MBA Mistakes to Avoid

- Choosing a specialization only for short term pay.
- Ignoring hands-on skill building and networking.
- Only focusing on placement numbers and not learning.
- Not using internships and projects to build real work examples.

Avoid these so we get long term value from the degree.

## MBA 2026 Future Trends

- AI and data driven management will shape decisions.
- Green and sustainable business practices will grow.
- Global and remote leadership skills will be more important.

We should keep learning to stay relevant.

## Is MBA Worth It in 2026

### Cost vs Career Growth

An MBA can pay back when it helps us move into higher roles, switch into better fields, or build a business. Compare total fees, living cost, and likely salary gain before choosing.

### MBA for Job vs Business

For job seekers an MBA course helps in placements and clarity. For entrepreneurs, it gives useful tools, but practical experience remains crucial.

## Conclusion

We have covered the main details about MBA courses in India in 2026. We explained eligibility, types, subjects, fees, duration, and career paths. If you plan carefully and use internships, projects, and networking well, an MBA can help you reach leadership roles or grow your business. Pick the right format, check UGC approval for online programs, and focus on skills that bring real value.

Ready to take the next step in your MBA journey? [BBS College](/), one of the [best private MBA colleges in UP](/mba), offers industry focused MBA courses with practical learning and strong career support. Apply now and start building a future ready management career.

## FAQs

### Q. Which MBA Course is Best for Future?

MBA courses in business analytics, finance, operations, and entrepreneurship are good for the future. These areas match new business needs and offer better long term career growth in India.

### Q. MBA Course Eligibility?

MBA course eligibility usually needs a bachelor degree from a recognised university. Some programs also look at entrance test scores, work experience, and minimum marks during selection.

### Q. Best Courses After MBA?

After MBA, courses in data analytics, finance, product management, operations, or leadership help you grow faster. These courses build practical skills and make you ready for higher roles.

### Q. Types of MBA Courses List?

Types of MBA courses include full time MBA, part time MBA, executive MBA, online MBA, distance MBA, and integrated MBA. Each type suits different career stages and work schedules.

  `
  },
     {
    id: 5,
    bannerImg:"/blogImage/bcaCourseGuide/BlogBCACourse.webp",
    category: "Campus Life",
    slug: "bca-course-guide",
      seoTitle: "BCA Course Guide: Eligibility, Subjects, Career & Salary",
      seoDescription:
        "Complete guide to the BCA course in India. Learn about eligibility, duration, subjects, admission process, career options, and salary in simple words.",
        seoKeywords:"",
 
    title:
          "Comprehensive Guide on BCA Courses: Everything You Need To Know For Your Career",
        description:
          "If you want to build your own software or apps and use those skills to earn well in the future, the BCA course is one of the most practical ways to start. It teaches you how technology works from the inside and to create one. This blog helps you understand every detail about the BCA course.",
                content:`


##  What Is BCA

![What Is BCA](/blogImage/bcaCourseGuide/whatIsBca.webp)

Bachelor of Computer Applications (BCA) course teaches how computers and software work. You learn to write code, build basics of apps and websites, work with databases, and understand networks. It mixes theory and hands-on work so you can start working or study more later.

## Why Choose BCA

### Demand for IT Skills

Many businesses need people who can make and run software. The BCA course gives practical skills that are useful in many jobs.

### Early Entry into Tech Field

This course lets you start a tech career soon after finishing school. You don't wait many years to begin.

### Affordable Compared to Other IT Degrees

The BCA course is often cheaper than long engineering programs. It gives a good start at lower cost.

## BCA Course Overview

![BCA Course Overview](/blogImage/bcaCourseGuide/bcaCourseOverview.webp)

### Course Duration

The usual BCA course lasts three years. Under NEP 2020, some colleges offer a four-year BCA Honours option. The four-year option helps if you want to study for a master's abroad.

### Course Structure

You study in class, do lab work, finish small projects each term, and do a final major project. Some colleges include short internships.

### Types of BCA Programs

- Regular three-year BCA course
- Four-year honours BCA course
- Specialised tracks
- Distance or online programs

## Different Types of BCA Courses

BCA is not limited to one format. Today, colleges offer different types of BCA programs based on student interest and industry demand.

### General BCA

This is the most common type. It gives you overall knowledge of computers without focusing on one special area.

## Specialised BCA Courses

Many colleges now offer BCA programs that focus on specific modern technologies.

- **BCA in Artificial Intelligence and Machine Learning :** Learn to create smart programs that can predict, recognise patterns, and automate tasks.
- **BCA in Cyber Security:** Learn how to protect websites, systems, and data from hacking and cyber attacks.
- **BCA in Data Science and Analytics:** Learn how to study large amounts of data and find useful information for companies.
- **BCA in Cloud Computing:** Learn how software and data are managed on internet servers instead of personal computers.

## New and Upcoming BCA Courses

These courses focus on future technologies that are growing quickly.

- **BCA in AR and VR :** Learn to build apps and games for virtual and augmented reality.
- **BCA in Blockchain:** Understand the system behind secure digital transactions and record keeping.
- **BCA in Internet of Things (IoT):** Learn how devices like home appliances and cars connect and communicate through the internet.
- **BCA in Full Stack Development:** Learn to build complete websites from front end to back end

## Comparison of BCA Course Types

| Course Type        | Main Focus       | Popular Job Role       |
|-------------|---------------------|---------------------|
| General BCA  | Overall computer basics  | Software Developer     |
| AI and ML   | Smart systems  | AI Engineer     |
| Cyber Security    | System protection     | Security Analyst     |
| Data Science    | Data study    | Data Analyst     |
| Cloud Computing     | Online servers     | Cloud Engineer specialist     |
| AR and VR     | Digital applications     | Game Developer     |

## Integrated Course Types

- **BCA LLB:** BCA LLB is an integrated degree where you study computer subjects and law together. You learn coding, software, and internet basics along with legal systems and digital rights. At the end, you receive two degrees.
- **Integrated BCA + MCA:** Five-year program combining BCA and MCA. You learn both basic and advanced computer topics to get stronger tech jobs.
- **Integrated BCA + MBA:** Five-year program combining BCA and MBA. You learn tech first, then business and management for leadership roles in tech.

## Eligibility for BCA

![Eligibility for BCA](/blogImage/bcaCourseGuide/eligibility.webp)

### Educational Qualification

To apply you need to pass 10+2 from a recognised board.

### Mathematics Requirement

In many top colleges in India, Mathematics or Informatics Practices in Class 12 is required. Private colleges sometimes accept other streams, but options may be fewer later. This point affects your future choices.

### Minimum Marks Required

Most colleges ask for about 45 to 50 percent in 10+2, but each college sets its own rules

### Age Limit Criteria

Usually there is no strict age limit

## BCA Admission Process

![BCA Admission Process](/blogImage/bcaCourseGuide/admission.webp)

### Merit Based Admission

Some colleges give seats based on 10+2 marks.

### Entrance Exam Based Admission

Other colleges hold tests that check math, logic, and basic computer skills.

### Common Admission Steps

Apply, take the test if needed, go to counselling, and finish enrollment. Check each college for exact steps.

## BCA Subjects and Syllabus

### Core Subjects

The main subjects in the BCA course include:

- Programming basics
- Data structures
- Databases
- Operating systems
- Networks
- Software engineering
- Web development

### Programming Languages Taught

You learn C and C++, then higher-level languages like Java or Python, and web tools such as HTML, CSS, and JavaScript. You also learn SQL for databases.

### Practical and Lab Work

Each term has lab sessions and mini projects. The final year has a larger project that brings all learning together.

## Suggested Semester-Wise Subject List

A [common plan](https://www.shiksha.com/bca-bachelor-of-computer-applications-syllabus-chp) used by many colleges in India (note: this is a basic common syllabus, and many colleges make their own changes to it):

| Semester        | Subjects       |
|-------------|---------------------|
| Semester 1  | Computer Fundamentals, Programming in C, Discrete Mathematics, Digital Logic, Communication Skills  |
| Semester 2  | Data Structures, Object Oriented Programming, Operating Systems, Statistics, Environmental Studies  |
| Semester 3  | Database Management Systems, Java or Python, Computer Networks, Web Basics, Software Engineering  |
| Semester 4  | Advanced Web Development, Data Analysis Basics, Linux, Computer Architecture, Project Work  |
| Semester 5  | Mobile App Basics, Cloud Concepts, Information Security, Elective Subject, Internship  |
| Semester 6  | Advanced Programming, Elective Subject, Final Year Project, Project Viva-Voce  |

## Skills You Learn in BCA

![Learn in BCA](/blogImage/bcaCourseGuide/skillDevelopment.webp)

### Technical Skills

You gain hands-on skills in coding, building simple apps, using databases, and working with systems.

### Problem Solving Skills

The BCA course teaches you to break a problem into parts, design solutions, and fix errors.

### Communication Skills

You learn to explain your work, write basic reports, and work with teammates.

## Career Options After BCA

After the BCA course you can work in roles such as:

- Software developer
- Web developer
- Data analyst
- System administrator
- Digital marketing roles
- Technical support engineer
- Quality assurance tester

Many graduates start in support or testing jobs and move to development with practice and projects.

## Higher Studies After BCA

### MCA After BCA

MCA in India is now a two-year program. It used to be three years. This shorter MCA makes higher study faster. If you aim for top institutes, prepare for the NIMCET exam.

### MBA After BCA

An MBA fits those who want business or management roles.

### Short Term Certification Courses

Small courses in web, data, cloud, or security help your job chances and skill set.

## Useful Free Courses and Certifications for BCA Students

![Certifications](/blogImage/bcaCourseGuide/certification.webp)

### Programming and Development

Free courses on Python, Java, data structures, and web development add real value while you study

### Data and System Skills

Learn basic SQL, data handling, Linux, and networking to stand out.

### Soft Skills

Work on communication, resume writing, and interview practice.

These short courses strengthen your profile during the BCA course.

## Job Sectors for BCA Graduates

Graduates from the BCA course find work in IT services, startups, banks, government teams, and as freelancers. The course fits many sectors.

## Salary After BCA

![Salary](/blogImage/bcaCourseGuide/salary.webp)

### Starting Salary in India

Fresh graduates usually get entry-level pay. Exact numbers change by company and city.

### Salary Growth with Experience

As skills improve, pay rises. Learning new tools speeds this up.

### What Mostly Affects Salary

Your pay depends mainly on how well you can code, your project work, and the city you work in.

## BCA vs Other Courses

| Feature        | BCA       | BSc Computer Science       | BTech Computer Science       |
|-------------|---------------------|---------------------|---------------------|
| Duration  | 3 or 4 years  | 3 years  | 4 years     |
| Focus   | Software and applications   | Theory-based learning   | Engineering-focused learning     |
| Cost    | Lower     | Medium    | Higher     |
| Campus Placements    | Moderate    | Moderate    | Usually higher starting packages     |

BTech students often get higher starting offers than BCA course graduates in campus hiring. Keep this in mind when you plan

## Advantages of BCA

- Short or flexible duration
- Practical learning you can use quickly
- Lower cost
- Good start for IT work

## Is BCA a Good Career Choice

### Future Scope of BCA

Tech keeps growing. If you keep learning, the BCA course stays useful and opens many paths.

### Who Will Benefit Most from BCA

This course suits students who like coding, want early job entry, and will keep improving their skills.

## Conclusion

The BCA course is a simple and practical way to begin a tech career. It teaches useful skills, fits many job paths, and allows further study. Do small projects, take short courses, and make a good resume to grow faster.


## Ready to build your future in the tech world?

Choose [BBS College](/), a trusted [BCA college in Prayagraj](/bca), and build strong computer and software skills for your future. With experienced faculty, practical learning, and a student-friendly environment, BBS College supports you at every step of your BCA course.

Apply now and take your first step toward a successful career in technology.
  `
  },
   {
    id: 6,
    bannerImg:"/blogImage/mcaJobs/BlogMCAJobs.webp",
    category: "Campus Life",
    slug: "mca-jobs",
      seoTitle: "Best Jobs After MCA in India | Career Guide & MCA Jobs",
      seoDescription:
        "Explore top MCA jobs in India, skills needed, salary, government roles, and future opportunities. Simple career guide for MCA graduates.",
        seoKeywords:"",
 
    title:
          "Best Jobs After MCA in India: Complete Career Guide",
        description:
          "If you are worrying about jobs while doing MCA or BCA, that is actually a wise thought. Thinking early about your career gives you a clear edge. MCA offers a wide scope, but many students do not know which path to choose. This blog will help you understand the job options after MCA, the skills you should focus on, and how to move step by step toward a stable and satisfying career.",
                content:`


##  Why MCA Is A Good Degree For Your Career

MCA gives a broad base to build a tech career. With the right practice and a few special skills, you can reach high-value roles. Many people use this degree as a direct route into software and data work, or into stable government posts if they want security.

## Core Technical Jobs

![Core Technical Jobs](/blogImage/mcaJobs/CoreTechnicalJobs.webp)

### Software Developer

A software developer builds and maintains software for computers, websites, and mobile applications. The role includes coding, fixing bugs, adding features, and working with teams to deliver reliable products.

### Web Developer

Works on websites and web applications, including frontend, backend, or full-stack development.

#### Skills

- HTML, CSS, JavaScript
- Java, Python, or JavaScript (backend)
- Basic databases and APIs
- Git and basic testing

### Mobile App Developer

Builds applications for Android or iOS with a focus on performance and user experience

#### Required Skills

- Android (Java/Kotlin) or iOS (Swift)
- Java, Python, C#, or JavaScript
- Basic data structures and algorithms
- Mobile UI basics
- API integration
- Git version control
- Problem solving

#### Optional / Good to Have

- App testing and debugging

#### Hiring Sectors

- IT service companies
- Product-based companies
- Fintech, SaaS, and e-commerce platforms

### Hardware Engineer

A hardware engineer works with physical devices and embedded systems. The role may include testing, firmware, and device tuning.

#### Skills

- Basic electronics and embedded C
- Firmware programming and testing
- Device troubleshooting

#### Sectors

- IoT and device firms
- Manufacturing and hardware vendors
- Research labs

### Networking Engineer

A networking engineer builds and maintains networks. You keep connections fast and solve outages.

#### Skills

- Routing and switching fundamentals
- Network troubleshooting and monitoring
- Protocol knowledge, such as TCP/IP

#### Sectors

- Telecom and ISPs
- Data centers
- Large corporate networks

### Quality Assurance Tester

A QA tester checks software before it reaches users. You find bugs and make sure the product works as expected.

#### Skills

- Manual testing and writing test cases
- Test automation basics
- Attention to detail and reporting skills

#### Sectors

- Product companies
- QA service providers
- Startups

### Database Manager

A database manager handles and maintains data systems to ensure data is secure, fast, and available for applications.

#### Skills

- SQL and NoSQL databases
- Backup and recovery
- Query optimization

#### Sectors

- Banking and finance
- Analytics companies
- E-commerce and payments

## Government Jobs For MCA Graduates

![MCA Graduates](/blogImage/mcaJobs/governmentJobs.webp)

### 1 . E-Governance Roles

The government runs apps like DigiLocker and UMANG and hires tech people to manage them.

#### Roles

- AI or ML engineer
- DevOps engineer for cloud servers
- Full-stack developer for portals

### 2 . Banking Tech (Specialist Officer)

Public banks now need IT experts for digital banking and security.

#### Roles

- IT Specialist Officer
- Data analyst
- Cybersecurity expert

### 3 . Research and Space Organizations

These departments hire MCA graduates for software-heavy work.

#### Roles

- Scientist or engineer
- Technical assistant for computing systems

### 4 . Defense and Intelligence

Tech roles focused on national security.

#### Roles

- Cybersecurity analyst
- Information management officer

## Quick Guide

| Goal       | Exam / Hiring Body      | Role       |
|-------------|---------------------|---------------------|
| Banking  | IBPS SO / SBI SO  | Officer     |
| National IT   | NIC / NIELIT   | Programmer     |
| Space / Defense     | ISRO / DRDO     | Scientist     |
| Data Science    | Data study    | Data Analyst    |
| Railways     | RRB / CRIS     | IT Engineer     |
| Public safety     | SSC CGL     | Assistant     |

## Private Jobs For MCA Graduates

![Private Jobs](/blogImage/mcaJobs/privateJobs.webp)

The private sector offers many MCA jobs with fast growth and good pay. Hiring is based on your skills, projects, and interviews. Work areas often include software, data, cloud, security, and testing. Top Companies That Hire In India are:

### 1 . Service-Based Companies

These companies hire many MCA graduates through campus drives and national-level tests.

#### Examples

- TCS through the NQT exam
- Infosys for System Engineer and similar roles
- Wipro, through the Elite and Turbo programs
- HCLTech for software and infrastructure roles
- Tech Mahindra for telecom and software projects

These roles usually focus on client projects, support work, and steady learning.

### 2 . Product-Based Companies

These companies are harder to enter but offer high salaries and strong growth.

#### Examples

- Google and Microsoft for software development roles
- Amazon for cloud and e-commerce tech roles
- Adobe for students strong in DSA and problem-solving
- Oracle for database, Java, and cloud roles
- Zoho, which values skills and projects

These roles focus on building and improving their own products.

### 3 . Startups and Fintech Companies

Startups and fintech firms hire MCA graduates for web, app, and backend development.

#### Examples

- Paytm and PhonePe for digital payment systems
- Flipkart and Swiggy for app and data roles
- Razorpay for API and fintech systems
- Zomato for full-stack and app work

These companies offer fast growth and practical learning.

## Difference in Hiring Style

| Feature       | Service Based       | Product Based       |
|-------------|---------------------|---------------------|
| Hiring method  | Exams and mass hiring  | Interviews and skill tests     |
| Starting salary   | ₹3.5 to ₹7 LPA   | ₹12 to ₹40+ LPA     |
| Work focus     | Client projects and support     | Building their own products     |
| Main requirement     | Basic coding and aptitude     | Strong DSA and problem-solving     |

Private jobs give faster learning, better pay over time, and more career options.

## Salary You Can Expect As A Fresher

Salary varies by role, city, and skill. Here are common starting ranges to set expectations.

| Role       | Typical fresher range (INR per year)      |
|-------------|---------------------|
| Software Developer  | ₹3 LPA to ₹7 LPA     |
| Web / App developer   | ₹3 LPA to ₹6 LPA     |
| Database manager / Sysadmin     | ₹3 LPA to ₹5 LPA     |
| Data scientist (entry)     | ₹4 LPA to ₹8 LPA    |
| Cloud / Security entry roles     | ₹4 LPA to ₹8 LPA     |

#### What Affects Pay

- Your projects and internships
- The city and company size
- Any certificates or special skills

## High-Demand Specialized Jobs in

![High-Demand Jobs](/blogImage/mcaJobs/highDemand.webp)

### AI engineer

An AI engineer builds smart systems that can learn and make decisions. This role works with machine learning models, automation, and intelligent tools used in modern software.

#### Skills

- Python and machine learning libraries
- Deep learning basics and data handling
- Model training and evaluation

#### Sectors

- AI startups
- Product companies
- Healthcare, finance, retail, and automation firms

### Data Scientist

A data scientist finds meaning in large data sets. You build models that help the business make better choices.

#### Skills

- Statistics and Python or R
- Machine learning basics
- Data cleaning and visualization

#### Sectors

- Analytics firms
- Retail and finance
- Healthcare and adtech

### Cloud Architect

A cloud architect plans how systems run on cloud platforms. You choose services, set up scaling, and keep systems reliable.

#### Skills

- AWS, Azure, or GCP basics
- Containers and infrastructure as code
- Network and security knowledge

#### Sectors

- Cloud service teams
- SaaS companies
- Large enterprises moving to the cloud

### Security Expert And Ethical Hacker

A security expert checks systems for weak points and fixes them. Ethical hackers test defenses so real attacks do not succeed.

#### Skills

- Penetration testing and vulnerability scanning
- Secure coding awareness
- Basic cryptography and security tools

#### Sectors

- Cybersecurity firms
- Banks and finance
- Large IT companies and defense

## Jobs In Planning And Management

![Jobs In Planning](/blogImage/mcaJobs/jobsPlanning.webp)

### System Analyst

A system analyst links business needs with technical work. You write clear requirements and help the team build the right solution.

#### Skills

- Requirement gathering and documentation
- Basic UML and flow diagrams
- Communication with users and developers

#### Sectors

- IT consulting
- Product teams
- Enterprise IT departments

### IT Project Manager

An IT project manager plans and runs projects. You set timelines, manage resources, and keep stakeholders informed.

#### Skills

- Project planning and tracking
- Agile or Scrum methods
- Team coordination and simple budgeting

#### Sectors

- Consulting firms
- Product development teams
- Service delivery units

### Software Consultant

A software consultant studies client problems and suggests solutions. You guide choices and help implement the right tools.

#### Skills

- Client communication and requirement analysis
- Solution mapping and demoing
- Ability to adapt to new tools quickly

#### Sectors

- Consulting companies
- System integrators
- Enterprise customers

### Technical Architect

A technical architect designs the whole system layout for large projects. You make sure parts fit, and the system can grow.

#### Skills

- System and service design
- Integration and performance planning
- Deep knowledge of a technology stack

#### Sectors

- Product engineering teams
- Large enterprise architecture groups
- Cloud and platform companies

## What To Study After Your Degree

### Doing a PhD

A PhD is a good choice if you like deep study, research, and teaching. You pick one topic and work on it for a few years to find new ideas or solve real problems. This usually takes 3 to 5 years.

During this time, you read research papers, write your own papers, and work under a guide.

A PhD is useful if you want to:

- Become a professor or lecturer
- Work in research labs
- Join advanced research teams in tech organizations
- Build expertise in areas like AI, data science, cybersecurity, cloud systems, or software engineering

This path needs patience and a strong interest in one subject rather than a quick job.

### Getting Special Certifications

Short courses and certificates quickly boost your profile. Choose certificates that match the MCA jobs you want.

#### Useful Certifications

- **Cloud:** AWS, Azure, Google Cloud
- **Data and ML:** Data science certificates, TensorFlow basics
- **Security:** CEH, CompTIA Security+
- **DevOps:** Docker, Kubernetes, CI/CD tools
- **Project:** Scrum Master or PMP

#### How They Help

- Show clear skills to employers
- Open higher pay and specialized roles

## Conclusion

MCA gives you many clear paths. Start with a role that fits your interests, build small projects, and add one or two special skills. That mix opens good MCA jobs and long-term growth. If you want steady work, explore government roles. Keep learning, stay active on small projects, and choose paths that match your skills and interests.

## Looking to build a strong future after graduation?

Join[BBS College](/), the[Best MCA College in Prayagraj](/mca), where learning goes beyond books. Get the right skills, real guidance, and the support you need to move towards better MCA jobs. Take the first step today and plan your career the right way.

  `
  },
  {
    id: 7,
    bannerImg:"/blogImage/btechAi/BtechBLogBanner.webp",
    category: "Campus Life",
    slug: "b-tech-ai-ml-complete-guide-career-scope",
      seoTitle: "B Tech AI & ML Course Guide: Syllabus & Career Scope",
      seoDescription:
        "Explore B Tech AI & ML course, syllabus, skills, tools, salary, and career scope. Clear guide for students planning a future in AI and ML",
        seoKeywords:"B Tech AI & ML",
 
    title:
          "B.Tech in AI and ML: Complete Guide and Career Scope",
        description:
          "Every day you use apps and tools that can learn from data and make smart decisions. If you want to know how these systems are built, B.Tech AI & ML teaches you the full process step by step. In this guide, you will learn what the course covers, what the syllabus includes, the tools you work with, the skills you develop, and the career options you can aim for.",
                content:`


##  What is a B.Tech in AI and ML?

![AI and ML](/blogImage/btechAi/BtechInAI.webp)

B.Tech AI & ML is an engineering degree where you learn to build systems that learn from data. You study coding, math, machine learning methods, and how to make models work in real life. The course includes classroom study, lab practice, and projects. The syllabus is made to help you understand data, logic, and problem solving.

## Course Duration and How the Program Is Structured

### Four year course overview

| Year       | Main focus       |
|-------------|---------------------|
| Year 1  | Programming basics, engineering subjects, mathematics  |
| Year 2  | Data structures, probability, core computer science   |
| Year 3  | AI and ML subjects, labs, small projects   |
| Year 4  | Advanced topics, electives, internship or final project   |

### Balance of theory, labs, and projects

In B.Tech AI & ML, you learn through theory, lab work, and projects. Theory helps you understand concepts. Labs help you practice coding and working with data. Projects help you apply what you learned from the syllabus

## Important Subjects You Study

| Subject area       | What you learn       |
|-------------|---------------------|
| Programming and data structures  | Writing proper code and handling data  |
| Core AI and ML subjects  | Machine learning, deep learning, NLP, computer vision   |
| Mathematics and statistics  | Linear algebra, calculus, probability, statistics  |
| Data handling  | Databases, data cleaning, feature creation   |

These [subjects](https://www.shiksha.com/engineering/ai-ml-courses-syllabus-chp) build the base needed in B.Tech AI & ML

## Tools and Technologies You Learn

You learn tools that are used in real jobs.

- **Python and ML libraries:** such as TensorFlow, PyTorch, scikit-learn, and Keras.
- **Data analysis and visualization tools:** like Pandas, NumPy, and Matplotlib
- **Cloud and AI platforms:** for training and deploying models

These tools are an important part of the course and syllabus.

## Skills You Need to Succeed

![Skills You Need to Succeed](/blogImage/btechAi/skillDevelopment.webp)

- **Coding and problem solving:** You should be able to write code and solve problems step by step.
- **Working with data and models:** You learn how to clean data, train models, and check their performance.
- **Project work and teamwork:** You work on projects with others and learn to present your work clearly.
- **Human skills that AI cannot replace:** Communication, logical thinking, and ethical decisions are very important.

## Career Scope After B.Tech in AI and ML

### Top job roles you can apply for

| Role       | What you do       |
|-------------|---------------------|
| AI & ML Engineer  | Build and deploy machine learning models  |
| Machine Learning Engineer   | Manage model pipelines and deployment  |
|  Data Scientist   | Study data and find useful insights  |
| NLP Engineer    | Work on language based systems  |
| Research Engineer    | Work on new AI methods  |

After B.Tech AI & ML, you can apply for these roles in many industries.

### Industries hiring AI and ML graduates

- IT and software companies
- Finance and banking
- Healthcare and biotech
- E commerce and retail
- Automotive and manufacturing

These industries use AI for better systems and smart decisions.

## Salary Expectations and Top Hiring Locations

![Hiring Locations](/blogImage/btechAi/salary.webp)

### Expected pay for freshers and experts

| Experience level       | Salary range in India per year      | 
|-------------|---------------------|
| Freshers  | ₹6 LPA to ₹10 LPA (higher with strong projects and top colleges)    | 
| Mid level    | ₹12 LPA to ₹30 LPA     | 
| Senior level   | ₹30 LPA and above     | 

Pay depends on your skills and the company.

 If you want to learn more about [the best BTech courses with strong career opportunities,](/blogs/best-btech-course-options) check our blog.



### Top cities and regions for AI jobs

| City       | Reason for demand       |
|-------------|---------------------|
| Bengaluru  | Many tech companies and startups  |
| Hyderabad   | Product based companies |
| Pune    | Engineering and software hubs  |
| Mumbai    | Corporate and finance roles  |
| Delhi NCR     | Tech firms and consulting companies  |

## Future Trends in AI and ML

![Future Trends](/blogImage/btechAi/futureTrends.webp)

### Where the technology is going

AI will grow more in generative models and systems that work with text, image, and audio together. Better tools for running models at scale will be important. This keeps B.Tech AI & ML graduates ready for new roles.

### How to stay relevant in a changing market

Keep building real projects. Learn how to deploy models. Follow new tools and updates. Improve communication and teamwork skills.


## Conclusion

B.Tech AI & ML gives you a strong path into a fast growing field. Focus on coding, math, tools, and projects from the course and syllabus. Keep learning and you can build a strong career in AI and ML.

Join [BBS College](/) of Engineering & Technology today and start learning at the [best BTech college in UP](/btech-aiml) for the future.


  `
  },
  {
    id: 8,
    bannerImg:"/blogImage/jobsAfterBtech/btechJobsBanner.webp",
    category: "Campus Life",
    slug: "jobs-after-btech",
      seoTitle: "Best Jobs After B.Tech: Career Paths & Salary Guide",
      seoDescription:
        "Explore top jobs after B.Tech with salary ranges, career opportunities, and government options. Find the right path for your engineering future.",
        seoKeywords:"jobs after B.Tech",
 
    title:
          "Best Jobs After B.Tech: Career Paths Explained",
        description:
          `After [B.Tech,](https://en.wikipedia.org/wiki/Bachelor_of_Technology) the main question is which jobs after B.Tech to pick. Your branch, skills, college, and city decide a lot. In private companies in India, most freshers start at 3 to 6 LPA. Government and PSU jobs after B.Tech usually pay more (8+ LPA) but need exams like GATE. This guide lists real options branch by branch.`,
                content:`


##  Computer Science Engineering Jobs

![Engineering Jobs](/blogImage/jobsAfterBtech/cseJobs.webp)

CSE gives you tons of jobs after B.Tech since tech never stops growing.

### Private Sector Jobs in IT and Tech

| Job Title       | Fresher Salary (LPA)       |
|-------------|---------------------|
| Software Developer | 3.5 to 7 |
| Data Scientist   | 4 to 8 (needs strong projects)  |
| Machine Learning Engineer    | 4.5 to 9 (skilled candidates)  |
| DevOps / Cloud Engineer     | 4 to 8  |
| Product Manager     | Rare for freshers  |

Most guys start with developer roles in jobs after B.Tech. Data science and ML need extra projects and practice to land well. A product manager is tough right out of college.

**Hot trend:** AI, cloud, and cybersecurity are opening up high-demand jobs after B.Tech.

### Government Jobs for CSE Graduates

- DRDO scientist and research posts
- NIC and government IT officer roles
- PSU IT jobs via GATE (example ~ BEL, ECIL)

These give solid stability for serious prep.

## Information Technology Engineering Jobs

![IT job](/blogImage/jobsAfterBtech/itJobs.webp)

IT paths look a lot like CSE but lean more toward systems and networks.

### Private IT Company Roles

| Job Title       | Fresher Salary (LPA)       |
|-------------|---------------------|
| System Analyst  | 3.5 to 6 |
| Network Engineer   | 3 to 6  |
| Database Administrator    | 3.5 to 6  |
| IT Consultant     | 4 to 7 |

**Hot trend:** Cloud support and security roles pay better as demand grows for jobs after B.Tech.

### Government IT and Technical Posts

- IT officer posts in central/state departments
- PSU technical roles (example ~ BSNL technical)


## Mechanical Engineering Jobs

![](/blogImage/jobsAfterBtech/mechanicalEngJobs.webp)

Mechanical is hands-on engineering work, mostly in factories and plants.

### Private Manufacturing and Design Jobs

| Job Title       | Fresher Salary (LPA)       |
|-------------|---------------------|
| Design Engineer  | 3 to 6 |
| Production Engineer   | 3 to 5  |
| Automation Engineer    | 3.5 to 6  |

**Hot trend:** Electric vehicles and renewable energy are pushing new demand and better pay in jobs after B.Tech.

### Government Mechanical Engineer Posts

- BHEL, ONGC, and other PSU roles
- Government plant and maintenance posts

## Civil Engineering Jobs

![Civil Engineering Jobs](/blogImage/jobsAfterBtech/civilEngJobs.webp)

Civil connects straight to buildings, roads, and public stuff.

### Private Construction and Infrastructure Jobs

| Job Title       | Fresher Salary (LPA)       |
|-------------|---------------------|
| Site Engineer  | 3 to 5 |
| Structural Engineer   | 3.5 to 6  |
| Project Engineer    | 4 to 6  |

**Hot trend:** Big infra projects, metro work, and smart cities mean steady career opportunities and jobs after B.Tech.

### Government Civil Engineer Jobs

- PWD and municipal engineering posts
- Railway engineering services

## Electrical Engineering Jobs

![Electrical Engineering Jobs](/blogImage/jobsAfterBtech/electricalEngJobs.webp)

Electrical covers power and control systems.

### Private Power and Energy Jobs

| Job Title       | Fresher Salary (LPA)       |
|-------------|---------------------|
| Power Systems Engineer  | 3.5 to 6 |
| Renewable Energy Engineer   | 3.5 to 6  |
| Control Systems Engineer   | 3.5 to 6  |

**Hot trend:** Solar, wind, and EV charging are creating fresh options in jobs after B.Tech.

### Government Electrical Engineer Posts

- State electricity boards and PSUs
- Engineering services exams


## Electronics and Communication Engineering Jobs

![Communication Engineering Jobs](/blogImage/jobsAfterBtech/ElectronicsEngJobs.webp)

ECE mixes hardware with communication tech.

### Private Electronics and Telecom Jobs

| Job Title      | Fresher Salary (LPA)       |
|-------------|---------------------|
| Embedded Engineer  | 4 to 8 |
| Telecom Engineer   | 3.5 to 6 |
| VLSI Engineer    | 5 to 10 (if skilled)  |

VLSI and embedded pay more with good hands-on skills from your college.

**Hot trend:** Chip design, 5G, and AI hardware are growing fast for jobs after B.Tech.

### Government ECE Engineer Posts

- ISRO, DRDO technical roles
- Bharat Electronics Limited and similar PSUs


## Chemical Engineering Jobs

![Chemical Engineering](/blogImage/jobsAfterBtech/ChemicalEngJob.webp)

Chemical is all about process plants and safety.

### Private Chemical and Process Industry Jobs

| Job Title       | Fresher Salary (LPA)       |
|-------------|---------------------|
| Process Engineer  | 3.5 to 6 |
| Plant Operations Engineer   | 3 to 6  |
| R&D Engineer    | 4 to 6  |

Higher R&D usually needs an M.Tech or a PhD.

## Government Chemical Engineer Posts

- IOCL, ONGC, and refinery PSUs
- Fertilizer plant engineering posts


## Biotechnology Engineering Jobs

![Biotechnology Engineering Jobs](/blogImage/jobsAfterBtech/BiotechEngJobs.webp)

Biotech blends biology with engineering systems.

### Private Pharma and Research Jobs

| Job Title       | Fresher Salary (LPA)       |
|-------------|---------------------|
| Bioprocess Engineer | 3.5 to 6 |
| Clinical Research Associate  | 3 to 6  |
| Bioinformatics Analyst    | 4 to 8 (often needs MSc)  |

Many lab and R&D roles pay better after higher studies.

### Government Lab and Research Posts

- CSIR labs and ICMR posts
- Agricultural and health research institutes


## AI and ML Jobs

![AI and ML Jobs](/blogImage/jobsAfterBtech/AiMiJobs.webp)

AI and Machine Learning are growing fast and creating new jobs after B.Tech. Companies are using data and smart systems in many industries.

### Private AI and ML Roles

| Job Title       | Fresher Salary (LPA)       |
|-------------|---------------------|
| Machine Learning Engineer  | 4.5 to 8 |
| Data Scientist   | 4 to 7  |
| AI Engineer    | 5 to 9  |
| Data Analyst     | 3.5 to 6 |

Strong coding skills and real projects are important to enter this field.

### Government AI and ML Posts

- DRDO technical roles
- ISRO data posts
- NIC analyst positions

These roles offer stable jobs after B.Tech with steady growth.


## Automobile Engineering Jobs

![Automobile Engineering Jobs](/blogImage/jobsAfterBtech/AutoMobileEngJobs.webp)

Automobiles focus on vehicles and production.


### Private Automobile Company Jobs

| Job Title       | Fresher Salary (LPA)       |
|-------------|---------------------|
| Vehicle Design Engineer  | 3.5 to 6 |
| Powertrain Engineer   | 3.5 to 6  |
| Test Engineer    | 3 to 6  |

**Hot trend:** EV manufacturing and battery tech are bringing new jobs after B.Tech.

### Government Transport and PSU Jobs

- Vehicle test centers and PSU manufacturing units


## Conclusion

Most private jobs after B.Tech start around 3 to 6 LPA. Your college, city, and skills can push it higher. Government and PSU roles give better starting pay but need exams like GATE. Focus on practical skills, solid internships, and certifications like AWS or GATE prep that beats branch alone. Pick what you actually enjoy, build real projects, and you'll land good jobs after B.Tech with solid career growth.

Start your journey with one of the [top B.Tech colleges in UP. BBS College](/computer-science-engineering) offers quality education, modern labs, and strong placement support to help you build a successful career.
  `
  },
  {
    id: 9,
    bannerImg:"/blogImage/engineeringInternship/engineeringInternshipsBanner.webp",
    category: "Campus Life",
    slug: "engineering-internships",
      seoTitle: "Engineering Internships: Benefits for Engineering Students",
      seoDescription:
        "Discover the benefits of engineering internships, how students gain real skills, industry exposure, and better career opportunities through internships.",
        seoKeywords:"Engineering Internships",
 
    title:
          "Benefits of Internships During Engineering Studies",
        description:
          `Want a fast way to prove you have real work skills, not just good marks? Engineering internships do that for you. They show you exactly how engineering jobs run in real life. They let you learn tools that are important on the job. They also help to find work after college. If you study engineering, doing one or two engineering internships while in college can shift how you think about your future job. It gets you much better prepared.`,
                content:`


##  What Is an Internship in Engineering?

![What Is an Internship in Engineering](/blogImage/engineeringInternship/whatIsanInternship.webp)

An internship means a short time working at a company, lab, or small startup. You become part of a team. You follow a guide or mentor. You take on real jobs that help the project move forward. Some engineering internships pay you. Some do not pay. A lot now come as an online internship. Most run from a few weeks up to a few months.


## Practical Skills Gained from Internship

Here are the usual skills students gain from engineering internships. It also shows what kind of work helps you learn each one.

| Engineering Field       | Practical Skills Learned       | Example Work During Internship |
|-------------|---------------------|---------------------|
| Mechanical Engineering  | CAD design, machine testing, and manufacturing process understanding | Making 3D models in CAD software, helping put machines together |
| Civil Engineering  | Site checks, construction planning, basic structural analysis  | Assisting engineers review building plans or watching site work |
| Electrical Engineering    | Circuit design, testing electrical setups, using measuring tools  | Testing circuits, looking at power supply systems
| Computer Science / IT     | Programming, fixing bugs, software testing, version control  | Writing code, removing errors, using tools like Git |
| Electronics Engineering    | PCB design, microcontroller coding, circuit testing  | Putting together small circuits or checking sensors |
| Chemical Engineering     | Process watching, lab tests, safety rules  | Helping check plant processes or doing lab work |

These real skills mostly come from engineering internships. Owners want people who have them.

## Industry Exposure for Engineering Students

![Industry Exposure](/blogImage/engineeringInternship/industryExposure.webp)

### Understanding How Engineering Companies Work

In engineering internships, you watch how teams get built. You see projects start as ideas and end as real products. You notice how strict time plans guide everything. This lets students think way past what books and classes teach.

### Learning Industry Tools and Technologies

Engineering internships open doors to tools that colleges might not have much of. You get to try version control, CAD, simulation programs, or test setups. Practice with them helps you work quicker and add more value from day one on a job.

### Working with Experienced Engineers

You see how experienced engineers make plans, run tests, and fix things. The quick tips and smart habits you pick up here do not show up easily in textbooks.

## Career Benefits of Engineering Internships

![Career Benefits](/blogImage/engineeringInternship/careerBenefits.webp)

### Stronger Resume for Future Jobs

A resume with actual work experience jumps out. Companies want to see jobs you finished and what came from them. List the projects and your part in them when you apply.

### Higher Chances of Campus Placement

Many companies hire back the interns they liked first. If you show you pick up fast and get work done, you could get a job offer before you even finish college.

### Better Career Direction and Specialisation Choice

After one or two engineering internships, you learn what work you enjoy most. This makes picking classes, extra subjects, and a job direction much clearer.

### Check out [Best Jobs After B.Tech: Career Paths Explained](/blogs/jobs-after-btech) to explore top career options and choose the right path after engineering.


## Networking Opportunities Through Internships

![Networking](/blogImage/engineeringInternship/networking.webp)

Engineering internships put you next to people who can help later on. Here are easy ways to build those links:

- Chat with team members and ask short, helpful questions.
- Stay connected with mentors even after the internship stops.
- Put your work up on a portfolio or GitHub.
- Ask for a quick note about your work or a reference.

Solid links can bring job ideas, recommendations, or new chances later.

## Self-Improvements

- **Improving Confidence:** Doing real work and hearing feedback makes you trust your own abilities more.
- **Professional Behaviour:** You pick up how to sit in meetings, handle comments, and stick to basic office rules.
- **Learning Workplace Discipline:** Set hours, regular updates, and due dates teach you to plan and keep at it every day.
- **Handling Responsibilities and Deadlines:** When your part counts for the team, you get good at finishing on time and dealing with stress.


## Platforms to Find Engineering Internships

Here are spots where lots of students find engineering internships. Try more than one and start applying soon.

| Platform       | What it offers       |
|-------------|---------------------|
| [Internshala](https://internshala.com/)  | Lots of options across branches, lists, pay and needed skills |
| [LinkedIn](https://www.linkedin.com/)    | Company updates and ways to reach recruiters directly |
| [Naukri.com](https://www.naukri.com/)   | Big job site with filters just for internships |
| [Indeed](https://in.indeed.com/) | Listings from around the world, simple apply button |
| [Glassdoor](https://www.glassdoor.co.in/index.htm) | Jobs plus reviews of companies and interview advice |
| [Wellfound ](https://wellfound.com/)(AngelList) | Strong for tech and startup jobs, mostly software |
| [AICTE National Internship Portal](https://internship.aicte-india.org/internshipbygoogle.php) | Backed by government, many checked and safe options |
| [Unstop](https://unstop.com/) | Mix of contests, hackathons, and internship openings |


Good summer engineering internships usually open from December to April for May-July times. Longer six-month ones ask for earlier applications. In India, many engineering internships pay between ₹5,000 and ₹50,000 a month, based on the place and job.

## Ways to look better when applying :

- Make a clean resume that highlights your projects.
- Write a short note saying why you match the role.
- Send to plenty of companies, not only a couple.
- Add links to college projects or GitHub.

### Note for branches :

software and computer science, see more online internship options. Branches like mechanical and civil often find more on-site or factory roles through company sites or college placement offices.


## Conclusion

Engineering internships hand you skills, real tools, team time, and a better sense of where your job can go. They grow both your tech side and your personal side. Aim to grab at least one during your studies. Choose something that tests you, ask away, do tasks well, and keep picking up new things. These habits make starting your first real job feel way smoother.

Join [BBS College,](/) one of the [best private engineering colleges in UP,](/computer-science-engineering) and start building a strong future in engineering today.

  `
  },
  {
    id: 10,
    bannerImg:"/blogImage/legalCareer/legalCareerBanner.webp",
    category: "Campus Life",
    slug: "legal-career",
      seoTitle: "Steps to Start Legal Careers in India: Courses, Exams Guide",
      seoDescription:
        "Learn the steps to start legal careers in India. Know law courses, entrance exams, internships, and career paths after a law degree.",
        seoKeywords:"Legal Careers",
 
    title:
          "Steps to Start a Legal Career in India",
        description:
          `Many people watch lawyers in court and wonder how they got there. The path to legal careers in India starts with good studies and real training. Legal careers are not just about courtrooms. They include corporate jobs, research, and even international work. Knowing the basic steps helps you see how legal careers begin and grow in India.`,
                content:`


## What Are Legal Careers in India?

![Engineering College](/blogImage/legalCareer/whatAreLegalCareers.webp)


Legal careers mean different jobs that use law knowledge. You can fight cases in court, give legal advice to companies, help make laws, teach, or do research. In short, legal careers are jobs where you use law to solve problems or guide people.

### Common places law graduates work:

- Courts and cases for clients
- Corporate legal teams in businesses
- Government offices and policy teams
- Universities and research places for legal studies
- NGOs and groups that give free legal help

Some choose more international work, like deals across borders. Others stay with local issues. Each path needs skills like good talking, clear writing, or deep research.

## Law Courses in India

You pick courses based on where you are now and what you want later.

| Course      | Duration       | Who it fits       | Main focus       |
|-------------|---------------------|---------------------|---------------------|
| Integrated law course  | 5 years  | After Class 12  | Law plus other subjects |
| LLB   | 3 years  | After any degree  | Main law topics and practice |
| LLM   | 1-2 years  | After LLB  | Deep topics and expert area |
| Diploma / Certificate   | Few months to 1 year  | People already working  | Special skills like tax or cyber law |

If you aim for corporate or international law, an LLM or short course can help a lot

## Law Entrance Exams in India

![Law Entrance Exams](/blogImage/legalCareer/lawEntranceExams.webp)

Most good courses need an entrance test. These check reading, thinking, and basic news knowledge.

### Main national and common exams

- CLAT (Common Law Admission Test)
- AILET (All India Law Entrance Test)
- SLAT (Symbiosis Law Admission Test)
- State and university tests like MH CET Law

LSAT India has stopped now. Use old papers, watch the time, and read daily news for prep.


## Career Paths After a Law Degree

A law degree opens many roads. Think about what you like most before you choose.

| Path      | What you do       | Typical roles       | 
|-------------|---------------------|---------------------|
| Litigation  | Fight for clients in court  | Advocate, trial lawyer  | 
| Corporate law   | Help companies with deals and rules | In-house counsel, legal associate  | 
| Government work   | Handle policy and public law  | Legal officer, prosecutor  | 
| Academia   | Teach law and do research  | Lecturer, researcher |
| Compliance and advisory   | Check if firms follow laws  | Compliance officer, consultant | 
| Legal services   | Help with papers and support | Paralegal, legal analyst

### Steps to become an advocate

- **1.** Join your State Bar Council. Bring your degree, ID, and fees.
- **2.** Pass the All India Bar Examination (AIBE). It is an open-book on basic law.
- **3.** Get the Certificate of Practice. Then you can take cases in any court in India.

No age limit, and you can try as many times as needed for AIBE.

### In January 2026, news about 2.52 lakh people took the AIBE 20. Around 69.21% passed. This shows lots of legal careers in India.

## Internships and Practical Training

![Internships](/blogImage/legalCareer/internships.webp)

Real work is key. Bar Council says to do internships during the course, for about 12 to 20 weeks total. Start early, like year two or three, to learn skills and meet people.

### Good places for internships

- Law firms and corporate legal teams
- Courts and judges' offices
- NGOs and legal help groups
- Government legal offices

## Common Mistakes Law Students Should Avoid

### Some mistakes slow you down. Stay away from these.

- Waiting for internships till last year
- Only reading books and skipping real work
- Not practising writing papers or court mocks
- Missing simple tech like online filing and law tools
- Copying others instead of finding your own way

Build talking, writing, and case reading habits from the start.


## Conclusion

Starting a legal career in India begins with the right studies and training. First, choose the law course that matches your education, then prepare for entrance exams and complete your law degree. Internships during your studies help you understand real legal work. After graduation, you can practice in court by enrolling with the State Bar Council and passing the AIBE, or move into corporate, research, or other legal careers, depending on your interests.

Start your journey in legal careers with [BBS College.](/) Apply now and take admission in one of the [best law colleges in UP.](/ba-llb) Here, you not only learn theory but also gain real-life practical experience through an updated syllabus and case studies. You also get guidance from experienced teachers and regular exposure to practical legal work.
  `
  },
  {
    id: 11,
    bannerImg:"/blogImage/bestEngineeringColleges/bestEngineeringCollegesBanner.webp",
    category: "Campus Life",
    slug: "best-engineering-colleges",
      seoTitle: "How to Select the Best Engineering Colleges for Your Career",
      seoDescription:
        "Learn how to choose the best engineering colleges. Check accreditation, faculty, placements, curriculum, and fees before selecting the right college.",
        seoKeywords:"best engineering colleges",
 
    title:
          "How to Select the Best Engineering College for Your Career",
        description:
          "Picking the right engineering college is a big deal for your future. A lot of students only look at entrance exam scores and skip other important stuff. A good college builds strong technical skills, gives real practice, and gets you ready for jobs. Before you decide on the best engineering colleges, compare them well with real facts.",
                content:`


##  Importance of the Right Engineering College

![Engineering College](/blogImage/bestEngineeringColleges/engineeringCollege.webp)

The college you pick shapes your skills and job future a lot. Engineering is not just theory from books. You have to learn by doing labs, projects, and solving real problems.
          
A good college setup helps you learn more quickly and pick up useful experience. Many of the best engineering colleges focus on both book stuff and hands-on learning.

### Good engineering colleges usually offer:

- Better teachers and study help
- New labs and learning tools
- Chances for internships and seeing real company work
- Active tech clubs and project work
- Job placement help and career advice

When you study in places with good rules and systems, you mostly get better tech knowledge and feel more ready for jobs.




## Check College Accreditation and Approval

![Engineering College](/blogImage/bestEngineeringColleges/checkCollege.webp)

Before you think about labs or job placements, first check if the college is properly accredited and recognized.
          
Engineering colleges in India have to follow national rules. Checking approvals makes sure the college keeps good quality in studies. Many of the best engineering colleges have a solid approval history.

### Key things to check:

- **AICTE approval:** The college must have approval from All India Council for Technical Education. This is needed for all engineering colleges in India.

- **NBA accreditation:** The National Board of Accreditation checks each engineering program. If it has an NBA, the program usually meets better study and job rules.

- **NAAC grade:** The National Assessment and Accreditation Council checks the whole college. Higher grades mean better teaching and setups.

- **NIRF ranking:** The National Institutional Ranking Framework ranks colleges all over India. In the engineering list, it helps compare on research, teaching, and jobs.

### Always check these on the official sites:

- AICTE website
- NBA accreditation website
- NAAC portal
- NIRF ranking website

Using real official sites keeps the info correct.

## Look at the College Reputation and Faculty Quality

![College Reputation](/blogImage/bestEngineeringColleges/collegeReputation.webp)

How people talk about a college shows its real long-term record in teaching, research, and jobs.
          
A simple way to compare is see the NIRF ranking in the engineering section. Colleges high up usually have good teachers, do research, and help students get better jobs. That’s why many check rankings when picking the best engineering colleges.

Teachers matter a lot. Good ones with experience explain tough things clearly and guide projects well.

### Check these:

- Qualifications and experience of teachers
- Research or papers done by teachers
- If teachers worked in industry
- Number of students per teacher

Talking to students there now or old students (alumni) can tell you about real teaching quality and the college feel.

## Examine Infrastructure and Facilities

Engineering needs lots of practical work. Good setups let you try things out in experiments and projects. The best engineering colleges put money into new labs and tech stuff.
          
Look at these: 

| Expense Area        | Why it matters       | What to check  |
|-------------|---------------------|-------|
| Laboratories  | Practical learning and experiments  | Updated equipment and regular lab sessions     |
| Workshops   | Hands-on technical training   | Proper tools and machines     |
| Library     | Study and research support     | Books, journals, and digital resources     |
| Computer labs     | Coding and simulation work     | Modern computers and the required software     |
| Internet access     | Online learning and research     | Reliable campus internet     |
| Student clubs     | Skill development     | Active coding, robotics, and technical clubs     |

Strong setups help build real skills and fresh ideas.

## Analyse Placement Records

![Placement Records](/blogImage/bestEngineeringColleges/analysePlacement.webp)

Placement numbers tell you how good the college is at helping get jobs after you complete your course. But check them carefully.
          
### Look for:

- Placement results over the last three years
- Internship chances while studying
- Different kinds of companies that come

Check real placement reports or NIRF data, not just college ads. Good placements are why some are called among the best engineering colleges.

| Placement Factor        | What to look for       |
|-------------|---------------------|
| Placement percentage  | Consistent results over multiple years     |
| Median salary   | Stable or improving salary trends     |
| Internship opportunities     | Regular internships during study     |
| Company diversity     | Companies from different sectors     |

Seeing how it goes over the years shows the true job picture.

## Check Industry Exposure

### Internships and training opportunities

Internships let you work in real companies and learn actual stuff. Colleges that get you internships make you better ready for jobs.

### Industry partnerships and collaborations
          
Some colleges tie up with companies for workshops, training, and guest talks. These show you what companies really expect.

### Live projects and practical learning
Doing live projects lets you use tech knowledge on real issues. It builds skills, teamwork, and problem-solving.

## Evaluate Course Curriculum

- **Updated syllabus and modern subjects:** Tech moves fast, so courses should have new things like artificial intelligence, machine learning, data science, and cloud computing.
- **Practical learning and project work:** Courses need labs, design projects, and technical tasks. These give real hands-on experience.
- **Flexibility to choose electives:** Electives let you pick subjects you like or that fit your job plans.

Also, check if the college is autonomous or linked to a good university. Autonomous ones update courses faster and add new topics more quickly.

## Compare Fees and Financial Support

Money is important too. Look at the total cost for the whole course, not just one year's fee.

| Expense Area        | What to check       |
|-------------|---------------------|
| Tuition fees  | Total cost for all years     |
| Hostel and living costs   | Accommodation, food, and travel     |
| Scholarships     | Merit based or need based support     |
| Education loans     | Loan options and repayment plans     |
| Extra charges     | Lab fees, exam fees, and other costs     |

Knowing full costs helps plan better.




## Conclusion

Choosing an engineering college needs a careful look at approvals, teachers, setups, placements, and courses. Use real info from official places to avoid mistakes. When you check these properly, you can pick from the best engineering colleges that give good learning, real skills, and strong future job chances.

Explore [BBS College,](/) one of [the best private engineering colleges in UP,](/btech-aiml) offering strong academics, modern labs, and career-focused engineering programs.
  `
  },
    ] 
      


