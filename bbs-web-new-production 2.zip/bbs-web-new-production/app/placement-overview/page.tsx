'use client';
import Image from 'next/image';
import { useEffect, useState } from 'react';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import 'animate.css';
import { Swiper, SwiperSlide } from 'swiper/react';

import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

import {
  Navigation,
  Pagination,
  Mousewheel,
  Keyboard,
  Autoplay,
} from 'swiper/modules';
import KeyDiffrentiator from '../key-differentiator/page';
import SeoWrapper from '../common/SeoWrapper';

const PlacementOverview = () => {
  const desktopBanner = '/banner/placementD.webp';
  const mobileBanner = '/banner/placementM.webp';

  const [banner, setBanner] = useState(desktopBanner);

  const getBodyWidth = (evt: any) => {
    if (evt.target.innerWidth > 768) {
      setBanner(desktopBanner);
    } else setBanner(mobileBanner);
  };

  useEffect(() => {
    if (window) {
      window.addEventListener('resize', getBodyWidth);
      const screenWidth = window.screen.width;
      console.log('Screen Width:', screenWidth);

      if (screenWidth > 768) {
        setBanner(desktopBanner);
      } else setBanner(mobileBanner);
    }
    return () => window && window.removeEventListener('resize', getBodyWidth);
  }, []);

  const achievers = [
    {
      name: 'Nikhil Kumar',
      company: 'Valmet Flow Control',
      profile: 'Project Manager',
      package: '50',
      image: '/placement/achivers/NikhilKumar.webp',
    },
    {
      name: 'Ankur Srivastava',
      company: 'Deloitte Touche Tohmatsu India',
      profile: 'Associate Director',
      package: '41',
      image: '/placement/achivers/AnkurSrivastava.webp',
    },

    {
      name: 'Amar Shukla',
      company: 'Ericsson Global India Pvt Ltd',
      profile: 'Artificial Intelligence Architect',
      package: '40',
      image: '/placement/achivers/AmarShukla.webp',
    },
    {
      name: 'Swayam Prakash',
      company: 'Oracle',
      profile: 'Senior Principal Consultant',
      package: '30',
      image: '/placement/achivers/SwayamPrakash.webp',
    },
    {
      name: 'Shipra Parihar',
      company: 'The Economist',
      profile: 'Senior Software Engineer',
      package: '25',
      image: '/placement/achivers/ShipraParihar.webp',
    },
    {
      name: 'Shweta Parihar ',
      company: 'BSNL',
      profile: 'Junior Telecom Officer',
      package: '12',
      image: '/placement/achivers/ShwetaParihar.webp',
    },
  ];

  const CRTC = [
    'Career Counselling',
    'Guest Lectures',
    'Pre-Placement Talks',
    'Industrial Trainings & Visits',
    'Internships',
    'Workshops',
    'Personality Development Program',
    'Assessment Tests',
    'Campus Placements',
    'Alumni Connect',
  ];

  return (
    <>
      <SeoWrapper
        title="Top Placement-Wise College in UP | Engineering & Polytechnic"
        description="BBS Group of Institutions, a top engineering and polytechnic college in UP, offers industry-linked training, corporate lectures, and skill development for strong placements."
      >
        {/* ---------------hero section--------------------- */}
        <div className="md:-mt-[6.7rem]">
          <Image
            unoptimized={true}
            src={banner}
            width={1600}
            height={1000}
            alt="Placement Overview"
            loading="lazy"
            className="placementSlider"
          />
        </div>

        {/* ---------------Overview--------------------- */}

        <div className="grid lg:grid-cols-2 grid-cols-1 gap-16 lg:px-32 md:px-16 px-12 py-16">
          {/* left side------------------ */}
          <div>
            <h1>Overview</h1>
            <div className="text-justify">
              <h4>
                BBS Group of Institutions established the Corporate Relations
                and Training Cell (CRTC) to forge a solid and enduring
                partnership between industry and academia. The CRTC makes sure
                that the students receive the most up-to-date tools and skills
                available on the market, including all components that enable
                the students to become well-suited and prepared for the job
                market and fierce competition. This is done with the input and
                assistance of the corporate world. Events like expert lectures
                by renowned experts in modern technologies, confidence building,
                stress & time management, and behavioural development are
                organised in order to fully explore students&apos; skills.
              </h4>
              <h4>
                These skill sets shape them in accordance with the competitive
                market requirements and instil confidence in them by developing
                both leadership traits and managerial skills while yet being
                sensitive to the compassion of others. In addition to all of
                these activities, the CRTC prioritises case studies, industrial
                visits, and hands-on training throughout the entire academic
                year without interfering with the regular academic schedule of
                teaching and learning.
              </h4>
              <h4>
                By training the students in the aspects of technical, soft
                skills, and aptitude, the CRTC training department hopes to help
                employers meet business standards.
              </h4>
              <h4>
                The constant placement outcomes show the effectiveness of these
                training programs. Every year, a number of corporate houses
                visit the institution to find and hire young, talented students.
              </h4>
              <h4>
                To close the gap between industry and academics, guest lectures
                and mock interview sessions are organised with the assistance of
                industry professionals.
              </h4>
            </div>
          </div>

          {/* Rigth side------------------ */}
          <div className="flex ">
            <div className="grid md:grid-cols-2 grid-cols-1 m-auto gap-8 text-whiteCol">
              {/* 1st------------------ */}
              <div className="bg-pink p-12 relative " data-aos="fade-right">
                <div
                  className="bg-[#00000060] hover:bg-primary absolute h-full w-[10%] top-0 left-0"
                  data-aos="fade-right"
                ></div>
                <h2 className="text-5xl relative z-20 text-center m-0">
                  3000+
                </h2>
                <h3 className="uppercase text-center m-0">Placement Offers</h3>
              </div>

              {/* 2nd------------------ */}
              <div className="bg-seaGreen p-12 relative " data-aos="fade-right">
                <div
                  className="bg-[#00000060] hover:bg-primary absolute h-full w-[10%] top-0 left-0"
                  data-aos="fade-right"
                ></div>
                <h2 className="text-5xl relative z-20 text-center m-0">
                  6.3 LPA
                </h2>
                <h3 className="uppercase text-center m-0">
                  Average CTC (Overall)
                </h3>
              </div>

              {/* 3rd------------------ */}
              <div
                className="bg-secondary text-primary p-12 relative "
                data-aos="fade-right"
              >
                <div
                  className="bg-[#00000060] hover:bg-primary absolute h-full w-[10%] top-0 left-0"
                  data-aos="fade-right"
                ></div>
                <h2 className="text-5xl relative z-20 text-center m-0">
                  51.36 Lakh
                </h2>
                <h3 className="uppercase text-center m-0">Highest CTC</h3>
              </div>

              {/* 4th------------------ */}
              <div className="bg-primary p-12 relative " data-aos="fade-right">
                <div
                  className="bg-[#00000060] hover:bg-primary absolute h-full w-[10%] top-0 left-0"
                  data-aos="fade-right"
                ></div>
                <h2 className="text-5xl relative z-20 text-center m-0">80%</h2>
                <h3 className="uppercase text-center m-0">
                  Median Placement Ratio
                </h3>
              </div>
            </div>
          </div>
        </div>

        {/* ---------------Key Differentiators--------------------- */}

        <KeyDiffrentiator />

        <div className="md:mt-20 mt-10">
          <RecruitersComapnies />
        </div>

        {/* Placement Success Stories-------------------------------------- */}

        <div className=" px-5  relative z-10 rounded-xl m-auto  shadow-md bg-whiteCol ">
          <div className=" m-auto md:px-16 px-4">
            <div className="p-6">
              <h3 className="bg-pink text-center font-semibold  px-8 py-2 rounded-full text-whiteCol w-max ">
                Placement Success Stories :
              </h3>
              <h4 className="text-justify py-6">
                &emsp;&emsp;Our placement success stories speak volumes about
                the quality of education and training imparted at BBS Group of
                Institutions. Our alumni have secured placements in prestigious
                companies across various sectors, both in India and abroad. From
                IT giants and consulting firms to manufacturing companies and
                financial institutions, our alumni are making their mark in the
                professional world and contributing to the success of their
                organizations.
                <br />
                <br />
                &emsp;&emsp;At BBS Group of Institutions, we are committed to
                empowering our students to achieve their career aspirations and
                realize their full potential. Through our robust placement
                support services, we strive to bridge the gap between education
                and employment, ensuring that our students are well-equipped to
                succeed in today&apos;s competitive job market.
                <br />
              </h4>
            </div>
          </div>
        </div>

        {/* -------------------------CRTC-------------------------------- */}
        <div className="bg-primary md:p-16 p-8 ">
          <div>
            <h2 className="text-5xl text-secondary mb-4 text-center">
              CRTC looks after the following{' '}
            </h2>
            <div
              data-aos="fade-right"
              className="grid lg:grid-cols-3 sm:w-[80%] m-auto md:grid-cols-2 grid-cols-1 gap-6 "
            >
              {CRTC.map((list: any, index) => (
                <h3
                  key={index}
                  className=" px-4 py-4 bg-whiteCol text-2xl font-semibold rounded-lg"
                >
                  {list}
                </h3>
              ))}
            </div>
          </div>
        </div>

        {/* -------------------------achievers-------------------------------- */}
        <div className=" w-[90%] m-auto lg:p-16 md:p-8 p-4 ">
          <div className="m-auto">
            <Swiper
              slidesPerView={1}
              cssMode={true}
              navigation={true}
              autoplay={{
                delay: 2500,
                disableOnInteraction: false,
              }}
              pagination={{
                clickable: true,
              }}
              mousewheel={true}
              loop={true}
              keyboard={true}
              modules={[Navigation, Pagination, Mousewheel, Autoplay, Keyboard]}
              className=""
            >
              <div>
                {achievers.map((slide: any, index: number) => (
                  <SwiperSlide className="" key={index}>
                    {
                      <div
                        key={index}
                        className="m-auto flex md:flex-row flex-col  justify-between md:p-16"
                      >
                        <div className="hidden lg:block m-auto ">
                          <Image
                            unoptimized={true}
                            src={'/placement/arhand.webp'}
                            width={300}
                            height={60}
                            alt="Arhand"
                            loading="lazy"
                            className=" "
                            style={{ width: '250px', height: '250px' }}
                          />
                        </div>

                        <div className="p-8">
                          <h2 className="uppercase text-6xl text-seaGreen">
                            Achievers
                          </h2>
                          <h2 className="text-8xl text-pink">
                            {slide.package}
                          </h2>
                          <h3>Lakh Per Annum</h3>
                          <h2 className="text-5xl">{slide.name}</h2>
                          <h3>{slide.profile}</h3>
                        </div>
                        <Image
                          src={slide.image}
                          unoptimized={true}
                          width={400}
                          height={60}
                          alt="Achievers"
                          loading="lazy"
                          className="rounded-full border-3 border-whiteCol m-auto"
                          style={{ width: '300px', height: '300px' }}
                        />
                      </div>
                    }
                  </SwiperSlide>
                ))}
              </div>
            </Swiper>
          </div>
        </div>
      </SeoWrapper>
    </>
  );
};

export default PlacementOverview;
