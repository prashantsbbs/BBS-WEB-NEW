'use client';
import Image from 'next/image';
import 'animate.css';
import { bbsLabs } from '../constant/bbsLabs';
import Arrow from '../../app/common/arrow';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import CampusHiglight from '../common/campusHiglight';
import NewsEventsSection from '../home/news&events';
import { useEffect, useState } from 'react';
import AppService from '../services';
import Head from 'next/head';
import SeoWrapper from '../common/SeoWrapper';

const lawSchoolFeatures = [
  {
    title: 'Experienced Faculty',
    description:
      'Our faculty members are renowned experts in their respective fields, providing students with unparalleled guidance and mentorship.',
  },
  {
    title: 'Practical Learning',
    description:
      'We believe in learning by doing. Through moot court competitions, internships, and practical training sessions, students gain real-world experience and hone their advocacy skills.',
  },
  {
    title: 'Holistic Development',
    description:
      'Beyond academics, we focus on the holistic development of our students, nurturing their leadership abilities, ethical values, and commitment to social justice.',
  },
  {
    title: 'Industry Connections',
    description:
      'We maintain strong ties with the legal profession, government agencies, and corporate entities, facilitating networking opportunities and career advancement for our students.',
  },
  {
    title: 'State-of-the-Art Facilities',
    description:
      'Our campus boasts modern infrastructure, well-equipped libraries, and cutting-edge technology, providing students with an enriching learning environment.',
  },
];

const coursesOffered = [
  {
    title: 'Bachelor of Arts and Bachelor of Laws (BALLB(Hons)) - 5 years',
    link: 'ba-llb',
    intake: '120',
  },
  {
    title: 'Bachelor of Laws (LLB) - 3 years',
    link: 'llb',
    intake: '120',
  },
];

const mission = [
  {
    goal: 'To offer affordable education accessible to individuals from all backgrounds within professional studies.',
  },
  {
    goal: 'To provide cutting-edge technical, legal, and other professional courses, emphasizing the cultivation of ethical career values.',
  },
  {
    goal: 'To cultivate skilled and competent professionals dedicated to addressing societal needs within professional studies.',
  },
  {
    goal: 'To enhance the employability and entrepreneurial spirit of stakeholders within professional studies.',
  },
  {
    goal: 'To promote a culture of innovation and lifelong learning among students and faculty within professional studies.',
  },
];

const defaultState = {
  isLoading: false,
  newsList: [],
  eventList: [],
};
const BBSLaw = () => {
  const [state, setState] = useState(defaultState);

  const fetchNewsList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getNewsList();
    if (!error) {
      setState((prev: any) => ({ ...prev, newsList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  const fetchEventList = async () => {
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getEventList();
    if (!error) {
      setState((prev: any) => ({ ...prev, eventList: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  useEffect(() => {
    fetchNewsList();
    fetchEventList();
  }, []);

  return (
    <>
      <SeoWrapper
        title="Best Law College in UP for BCI-Approved Legal Studies"
        description="Join the best law college in UP at BBS Institute of Law. Learn with modern classrooms, legal library, moot courts, and career support for future lawyers."
        keywords="best law college in up"
      >
        <div className="bg-gray pb-6 mb-3">
          {/* why BBS */}
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              src={'/bbsLaw2.webp'}
              width={1600}
              height={1000}
              unoptimized={true}
              alt={'BBS Law'}
              className=" bgImage_about   "
            />
          </div>

          <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
            <h2 className="">Welcome to BBS Institute of Law</h2>
            <h4 className="text-justify">
              &emsp;&emsp;BBS Institute of Law is BCI-approved and widely listed
              as the best law college in UP. We are affiliated to Prof. Rajendra
              Singh (Rajju Bhaiya) University, Prayagraj. Our private institute
              trains students to become ethical, skilled, and job-ready lawyers.
              At our college, teaching mixes clear classroom lessons with
              hands-on practice. Students take part in moot courts, internships,
              legal aid clinics, and case studies. Our teachers and visiting
              lawyers guide students step by step.
              <br />
            </h4>
          </div>

          <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
            <h3 className="bg-pink font-semibold px-8 py-2 rounded-r-full text-whiteCol w-max ">
              About BBSIL :
            </h3>
            <h4 className="text-justify">
              &emsp;&emsp;Our institute ranks among the top law colleges in UP
              and draws students from Saharanpur, Ghaziabad, Pratapgarh, and
              nearby towns. Modern classrooms, a legal library, and career
              support help students prepare for court work, corporate law, or
              government service. Choose BBS Institute of Law for trusted,
              BCI-approved legal education and a clear path to a law career.
              <br />
            </h4>
          </div>
        </div>

        <div className="bg-gray pb-6 ">
          <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
            <h3 className="bg-pink font-semibold px-8  mb-6  py-2 rounded-full m-auto text-whiteCol w-max ">
              Courses Offered:
            </h3>
            <div className="grid lg:grid-cols-2 grid-cols-1">
              {coursesOffered.map((list: any, index) => (
                <Link key={index} href={list.link}>
                  <Image
                    src={'/icon/graduateLogo.webp'}
                    width={100}
                    unoptimized={true}
                    height={50}
                    alt="courses Offered Logo"
                    className="m-auto"
                  />
                  <h3 className=" font-semibold text-center hover:text-pink">
                    {list.title}
                  </h3>
                  <h3 className=" font-semibold text-center hover:text-pink">
                    Intake : {list.intake}
                  </h3>
                </Link>
              ))}
            </div>

            <div>
              <h4>
                Our flagship programs, the BALLB (5 years) and LLB (3 years),
                are meticulously crafted to equip students with a strong
                foundation in legal principles, critical thinking skills, and
                practical expertise. Taught by a distinguished faculty
                comprising experienced legal scholars, practitioners, and
                industry experts, our courses offer a blend of theoretical
                knowledge and hands-on learning opportunities.
              </h4>
            </div>
          </div>
        </div>

        {/* Mission Vision */}
        <div className="grid md:grid-cols-2 grid-cols-1  ">
          <div className="bg-secondary p-8">
            <div className="p-5 lg:p-20 sm:p-10 m-auto animate__animated animate__zoomIn">
              <div
                className={`p-4 animate__animated animate__zoomIn flex m-auto bg-primary rounded-full w-[100px] h-[100px]`}
              >
                <Image
                  src="/about/vision.svg"
                  alt="Vision"
                  className="m-auto"
                  unoptimized={true}
                  width={200}
                  height={150}
                />
              </div>
              <h1 className="">Vision</h1>

              <h3 className="text-justify">
                At BBS Professional Studies, our vision is to foster the growth
                and refinement of our students&apos; talents during their
                formative years, molding them into exemplary professionals of
                tomorrow. With a steadfast commitment to holistic development,
                our aim is to empower students with the technical and management
                acumen required to excel in the dynamic landscape of their
                chosen fields. We aspire to nurture the leaders of tomorrow!
              </h3>
            </div>
          </div>
          <div className="bg-whiteCol p-8">
            <div className="p-5 lg:p-20 sm:p-10 m-auto animate__animated animate__zoomIn">
              <div
                className={`p-4 animate__animated animate__zoomIn flex m-auto bg-primary rounded-full w-[100px] h-[100px]`}
              >
                <Image
                  src="/about/mission.svg"
                  alt="Mission"
                  className="m-auto"
                  unoptimized={true}
                  width={200}
                  height={150}
                />
              </div>
              <h2 className="text-5xl">Mission</h2>
              <div className="text-left flex gap-5">
                <div className="">
                  {mission.map((list: any, index) => (
                    <>
                      <div key={index} className="flex gap-6">
                        <Arrow />
                        <h3 className="m-0">{list.goal}</h3>
                      </div>
                    </>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-primary flex p-6 ">
          <div className="md:w-[80%] w-[90%] m-auto rounded-xl bg-whiteCol p-6">
            <h2 className="text-center">Why Choose BBS Institute of Law?</h2>
            <div className="lg:columns-2 columns-1 ">
              {lawSchoolFeatures.map((list: any, index) => (
                <>
                  <div className="m-2">
                    <h3 className="font-semibold text-pink">{list.title}</h3>
                    <h4 className="text-justify pb-6">{list.description}</h4>
                  </div>
                </>
              ))}
            </div>
          </div>
        </div>

        <div></div>

        <div className=" px-5  relative z-10 rounded-xl m-auto  shadow-md bg-whiteCol ">
          <div className=" m-auto md:px-16 px-4">
            <div className="p-6">
              <h3 className="bg-pink text-center font-semibold  px-8 py-2 rounded-full text-whiteCol w-max ">
                Join Us:
              </h3>
              <h4 className="text-justify py-6">
                &emsp;&emsp;Whether you aspire to be a legal practitioner,
                policymaker, corporate counsel, or social activist, BBS
                Institute of Law is the perfect launchpad for your legal career.
                Explore our website to learn more about our programs, faculty,
                admission process, and campus life. Join us on this
                transformative journey towards becoming the legal leaders of
                tomorrow.
                <br />
              </h4>
              <Link href={'/contact-us'}>
                <ButtonCustom
                  btnColor="primary"
                  btnText="Contact Us"
                  textCol="whiteCol"
                />
              </Link>
            </div>
          </div>
        </div>

        <CampusHiglight />
        <NewsEventsSection
          newsList={state.newsList}
          eventList={state.eventList}
        />
      </SeoWrapper>
    </>
  );
};

export default BBSLaw;
