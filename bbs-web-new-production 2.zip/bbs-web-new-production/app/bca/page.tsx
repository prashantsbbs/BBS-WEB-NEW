'use client';
import Image from 'next/image';
import 'animate.css';
import Arrow from '../common/arrow';
import ScrollTrigger from 'react-scroll-trigger';
import { useEffect, useState } from 'react';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import MasterCourse from '../eligibility-criteria/masterCourse';
import SwiperComponent from '../home/congracts-section/swiper';
import CourseSlider from '../common/courseSlider';
import FutureReadyEng from '../common/futureReadyEng';
import AppService from '../services';
import Head from 'next/head';
import SeoWrapper from '../common/SeoWrapper';

const programHighlights = [
  {
    highlight:
      'Practical Learning: Our BCA program focuses on hands-on learning and practical application of computer science concepts through laboratory exercises, coding projects, and real-world applications.',
  },
  {
    highlight:
      'Industry Integration: We collaborate with leading IT companies to provide internships, industry visits, and collaborative projects, giving students firsthand exposure to the latest technologies and industry practices.',
  },
  {
    highlight:
      'Specialized Curriculum: Our curriculum is designed to cover a wide range of topics including programming languages, database management, web development, and software engineering, allowing students to develop expertise in their areas of interest.',
  },
  {
    highlight:
      'Innovation and Research: We encourage innovation and research in computer science through project-based learning, seminars, and participation in hackathons and coding competitions, fostering creativity and problem-solving skills.',
  },
  {
    highlight:
      'Global Perspective: Our program offers a global perspective by exposing students to international trends, emerging technologies, and cross-cultural experiences through guest lectures, exchange programs, and collaboration with universities abroad.',
  },
];

const careerProspectus = [
  '    Technical Analyst',
  'Network Support Executive',
  'Technical Support Developer',
  'Web Developer',
  'System Support Manager',
  'Web Designer',
];

const majorTrack = [
  { track: 'Programming Fundamentals' },
  { track: 'Database Management' },
  { track: 'Web Development' },
  { track: 'Software Engineering' },
  { track: 'Information Security' },
];

const faculty = [
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
];

const defaultState = {
  isLoading: false,
  facultyList: [],
};

const departmentId = 6;
const Bca = () => {
  const defaultAnimation = {
    courseOverview: false,
    highlights: false,
  };

  const [animationStart, setAnimationStart] = useState(defaultAnimation);
  const [state, setState] = useState(defaultState);
  const fetchFacultyList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getFacultyList();
    if (!error) {
      // Rehan Code for Category Filtering
      const facultyList = data.filter(
        (item: any) => item?.attributes?.department?.data?.id === departmentId
      );

      setState((prevState) => ({
        ...prevState,
        facultyList,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchFacultyList();
  }, []);

  return (
    <>
      <SeoWrapper
        title="Best BCA College in UP for Advanced Computing Courses"
        description="Join the best BCA college in UP at BBS College. Learn programming, AI, ML, IoT, cybersecurity, and more with expert faculty and practical career-ready skills."
        keywords="Best BCA College in UP"
      >
        {/* Hero Sectino */}
        <section>
          <div className="handleoverlflow w-[80%] m-auto grid md:grid-cols-2 grid-cols-1 justify-center items-center md:px-6 px-3 py-12">
            <div>
              <Image
                unoptimized={true}
                src={'/courses/bca-icon.webp'}
                width={90}
                height={20}
                alt="BCA Icon"
                className="animate__animated animate__fadeInLeftBig my-4 rotateAnimate"
              />
              <div>
                <h2 className="">UG Degree</h2>
                <div className="bg-secondary h-2 w-full"></div>
              </div>
              <h1 className="m-0">
                BCA <br /> Bachelor of Computer Application{' '}
              </h1>
            </div>

            <div className="md:p-8 py-4">
              <Image
                unoptimized={true}
                src={'/courses/bca.webp'}
                width={600}
                height={20}
                alt="BCA"
                className="animate__animated animate__fadeInRight rounded-lg"
              />
            </div>
          </div>
        </section>

        {/* Course Overveiw */}

        <section className="bg-gray handleoverlflow">
          <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-24 px-6">
            <div data-aos="fade-right" className={`p-6 `}>
              <div>
                <h2>COURSE OVERVIEW</h2>
                <h4 className="text-justify">
                  The BCA program at BBS College of Engineering & Technology is
                  designed to give students strong knowledge in computers and
                  technology. Recognized as the best BCA college in UP, our
                  program teaches programming languages, databases, web
                  development, and other modern technologies.
                  <br />
                  <br />
                  We focus on both theory and practical skills. Students learn
                  problem-solving, critical thinking, and analysis through
                  various course modules. Classes include web technologies, AI
                  and ML, IoT, network security, advanced Java programming, and
                  applied statistics. Expert faculty and guest lecturers guide
                  students step by step.
                  <br />
                  <br />
                  Our program also offers a wide range of electives such as data
                  science, blockchain technology, cybersecurity, data mining,
                  and intellectual property rights. With this combination of
                  learning and practice, BBS is the top choice for students who
                  want quality education and career-ready skills in computing.
                </h4>
              </div>

              <div className="">
                <h2 className="uppercase">Major Tracks</h2>
                <div className="grid md:grid-cols-2 grid-cols-1">
                  {majorTrack.map((item, index) => (
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h3 className="m-2">{item.track}</h3>
                    </div>
                  ))}
                </div>
              </div>
              <div className="">
                <h2 className="uppercase">Advanced Options of Study</h2>
                <div className="grid md:grid-cols-2 grid-cols-1">
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">M.Tech.</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">MBA</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">Other PG Course</h3>
                  </div>
                </div>
              </div>
            </div>

            <div className={`m-auto `} data-aos="fade-left">
              <div className="bg-secondary p-4 m-4 md:mr-12">
                <div className="p-4">
                  <h3 className="m-0">Duration</h3>
                  <h2 className="m-0">3 Years</h2>
                </div>
                <div className="p-4">
                  <h3 className="m-0">Programme Name</h3>
                  <h2 className="m-0">BCA</h2>
                </div>
              </div>
              <div className="bg-primary text-whiteCol p-4 m-4 md:ml-12">
                <div className="p-4">
                  <h2 className="m-0">Eligibility</h2>
                  <h5 className="text-justify mt-0">
                    Passed 10+2 examination with at least 50% marks in any
                    stream with maths as subject of study
                  </h5>
                </div>
                <div className="p-4">
                  <Link href={'apply-online'} target="blank">
                    <ButtonCustom
                      btnColor={'secondary'}
                      btnText={'Apply Online'}
                      textCol={'primary'}
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Program Highliths */}

        <section className="md:p-12 py-6 " data-aos="zoom-in-up">
          <div className="w-[80%] m-auto bg-primary p-6 text-whiteCol">
            <div>
              <h2 className="text-secondary">Programme Highlights</h2>
              <div
                className={`md:columns-2 columns-1 
                            ${
                              animationStart.highlights
                                ? 'animate__animated animate__fadeInRight animate__slower'
                                : ''
                            }`}
              >
                {programHighlights.map((list: any, index) => (
                  <>
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h4 className="m-2">{list.highlight}</h4>
                    </div>
                  </>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Future Ready */}
        <FutureReadyEng
          department={
            <>
              Department of <br />
              Bachelor of Computer Application
            </>
          }
          image={'/futureReady/bcaCenter.webp'}
        />

        {/* Advanced Options of Study */}
        <section data-aos="fade-up-right" className="md:p-12 py-6  bg-gray">
          <div className="w-[80%] m-auto bg-secondary rounded-xl p-6 text-whiteCol">
            <div>
              <h2 className="text-primary  text-center">Career Prospects</h2>
              <div className=" grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3   m-auto ">
                {careerProspectus.map((career: any, index) => (
                  <h3
                    key={index}
                    className="bg-whiteCol rounded-md drop-shadow-md px-6 py-2
                    text-primary m-0"
                  >
                    {career}
                  </h3>
                ))}
              </div>
            </div>
          </div>
        </section>
        {/* </ScrollTrigger> */}

        {/* Top Recruiters */}
        <div className="mt-12">
          <RecruitersComapnies />
        </div>

        {/* Eligibility  */}
        {/* <div className="md:p-12 p-8 ">
        <Eligibility EligibilityTable={EligibilityTable} />
      </div> */}

        {/* Faculty  */}
        {!!state.facultyList.length && (
          <div className="  bg-primary flex">
            <div className="lg:w-[85%] w-[90%] m-auto md:p-16 p-4  ">
              <h2 className="m-auto text-secondary text-center p-4">
                Our Faculty
              </h2>
              <CourseSlider elements={state.facultyList} />
            </div>
          </div>
        )}
      </SeoWrapper>
    </>
  );
};
export default Bca;
