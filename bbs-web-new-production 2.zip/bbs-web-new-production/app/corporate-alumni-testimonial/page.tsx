"use client";
import Image from "next/image";

const alumniTestimonial = [
    {
      name: "Varun Kant",
      image:'/alumniTestimonial/VarunKant.webp',
      branch: "CE",
      batch: "2009-2013",
      comment: "From this campus, I got a chance to present a technical model to former President of India, Dr. A. P. J. Abdul Kalam Sir."
    },
    {
      name: "Swati Gupta",
      image:'/alumniTestimonial/SwatiGupta.webp',
      branch: "CSE",
      batch: "2006-2010",
      comment: "BBS delivers value-based and ethical education."
    },
    {
      name: "Brijesh Tripathi",
      image:'/alumniTestimonial/BrijeshTripathi.webp',
      branch: "ECE",
      batch: "2005-2009",
      comment: "Had a great learning experience through BBS' innovative and encouraging environment."
    },
    {
      name: "Vikas Pandey",
      image:'/alumniTestimonial/VikasPandey.webp',
      branch: "EN",
      batch: "2012-2016",
      comment: "Supportive staff members in all departments. Especially the Training & Placement Dept."
    },
    {
      name: "Akhilesh Tripathi",
      image:'/alumniTestimonial/AkhileshTripathi.webp',
      branch: "ECE",
      batch: "2003-2007",
      comment: "It is through BBS College and its vivid teaching methods, that I got selected as a scientist in Dept. of Atomic Energy - BARC."
    }
  ];

const corporateAlumniTestimonial = () => {
  return (
    <>
      <div className="md:w-[85%] w-[95%] m-auto p-4">
        <div className="text-center pb-4">
          <h1 className="text-primary">Alumni Testimonials</h1>
          <h4>
          Corporate alumni testimonials are succinct reflections from past employees on their experiences with a company, offering insights into its culture and values. They serve as endorsements to attract new talent and enhance the company&apso;s reputation.
          </h4>
        </div>

        <div className="grid xl:grid-cols-5 lg:grid-cols-3  md:grid-cols-2 grid-cols-1 gap-16">
            {alumniTestimonial.map((list: any, index) => (
              <div key={index}>
                <div className="m-auto  text-center animate__animated animate__slideInLeft">
                  <Image
                  
                    src={list.image}
                    width={400}
                    height={400}
                    alt={"Corporate Alumni"}
                    unoptimized={true}
                    className=" rounded-xl alumniTestimonial   "
                  />
                  <div className="">

                  <h4 className="font-semibold m-0 bg-secondary min-h-[200px] p-4 my-2 text-black rounded-lg">{list.comment}</h4>
                  <h2 className="font-semibold text-pink m-0">{list.name}</h2>
                  <h4 className="font-semibold m-0 ">{list.branch}</h4>
                  <h4 className="font-semibold m-0">{list.batch}</h4>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>
    </>
  );
};

export default corporateAlumniTestimonial;
