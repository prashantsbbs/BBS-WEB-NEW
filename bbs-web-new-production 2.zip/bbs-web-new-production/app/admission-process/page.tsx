"use client";

import Image from "next/image";
import Arrow from "../common/arrow";

const AdmissionProcess = () => {
  const documentRequired = [
    { title: "Filled application form " },
    { title: "Photocopy of Qualifying Test Score Card" },
    { title: "Photocopy of Educational Mark Sheets" },
    { title: "Aadhar Card " },
    { title: "4 Photographs " },
    { title: "GAP certificate (If Applicable)" },
  ];

  return (
    <>
      {/* Admission Procedure */}
      <div className="w-[80vw] p-5   relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol my-8">
        <div>
          <h2 className="text-center">ADMISSION PROCESS</h2>

          <div className="flex flex-col md:flex-row">
            <Image
              src={"/megaMenu/campusgallery.webp"}
              width={800}
              height={1000}
              alt={"Campus Gallery"}
              unoptimized={true}
              style={{width:'50%'}}
              className=" bgImage w-1/3 "
            />
            <h4 className="text-justify p-6">
              &emsp;&emsp; Our admission process is meticulously crafted to recognize and embrace the sharpest intellects and individuals poised to make significant contributions to our vibrant and diverse community. We are dedicated to upholding principles of fairness, transparency, and equitable opportunities for all applicants. Application forms for admission are accessible via both online and traditional offline channels, ensuring accessibility and inclusivity for every aspiring candidate. Through our comprehensive approach, we strive to foster a culture of excellence and diversity, welcoming talented individuals from all walks of life to join our esteemed institution.
            </h4>
          </div>
        </div>
      </div>

      <div className="bg-primary ">
        <div className="w-[80vw] rounded-xl md:p-6 p-3 m-auto">
          <div className="bg-whiteCol rounded-xl p-4 my-4 shadow-xl ">
            <h2>
              Step{" "}
              <span className="bg-primary inline-flex ml-2 mb-1  w-[30px] h-0.5 items-center"></span>
            </h2>
            <div className="flex md:flex-row flex-col ">
              <h1 className="text-6xl m-0 text-secondary bg-primary w-max h-max p-4 mr-4">
                01
              </h1>
              <h2>
                Collect the application form in Person from the Institutions.
              </h2>
            </div>
            <h4 className="font-bold m-0">
              BBS GROUP OF INSTITUTIONS
              <br />
              Gaddopur, Phaphamau, Prayagraj-211013
            </h4>
          </div>

          <div className="bg-whiteCol rounded-xl p-4 my-4 shadow-xl ">
            <h2>
              Step{" "}
              <span className="bg-primary inline-flex ml-2 mb-1  w-[30px] h-0.5 items-center"></span>
            </h2>
            <div className="flex md:flex-row flex-col ">
              <h2 className="text-6xl m-0 text-secondary bg-primary w-max h-max p-4 mr-4">
                02
              </h2>
              <h2>
                Applicants are required to submit their academic transcripts
                from previous educational institutions with a filled Application
                Form for review.{" "}
              </h2>
            </div>
          </div>

          <div className="bg-whiteCol rounded-xl p-4 my-4 shadow-xl ">
            <h2>
              Step{" "}
              <span className="bg-primary inline-flex ml-2 mb-1  w-[30px] h-0.5 items-center"></span>
            </h2>
            <div className="flex md:flex-row flex-col ">
              <h2 className="text-6xl m-0 text-secondary bg-primary w-max h-max p-4 mr-4">
                03
              </h2>
              <h2>Documents Required at the time of Admission</h2>
               </div>
             
             <div className="grid md:grid-cols-3 grid-cols-1">
               {documentRequired.map((document:any) =>(
                <>
                <div className="flex gap-4">
              <Arrow />
                <h4 className="m-0 mb-3 mt-3">{document.title}</h4>

                </div>
                </>
              ))}
              </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AdmissionProcess;
