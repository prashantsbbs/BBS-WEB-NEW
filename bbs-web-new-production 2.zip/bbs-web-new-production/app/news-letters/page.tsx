'use client';
import Link from 'next/link';
import { Eye, Download } from 'lucide-react';
import dayjs from 'dayjs';
import { useEffect, useState } from 'react';
import AppService from '../services';

const defaultState: any = {
  newsLetters: [],
  isLoading: false,
};

export default function NewsletterPage() {
  const [state, setState] = useState(defaultState);

  const fetchNewsLetterList = async () => {
    const query = '&sort=createdAt:desc';
    setState((prev: any) => ({ ...prev, isLoading: true }));
    const { data, error } = await AppService.getNewsLetterList(query);
    if (!error) {
      setState((prev: any) => ({ ...prev, newsLetters: data }));
    }
    setState((prev: any) => ({ ...prev, isLoading: false }));
  };

  useEffect(() => {
    fetchNewsLetterList();
  }, []);

  console.log(state.newsLetters);

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 px-4 py-10 sm:px-6">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mb-8 text-center">
          📩 News Letters
        </h1>

        <ul className="space-y-6">
          {state.newsLetters.map((newsletter: any = {}) => (
            <li
              key={newsletter.id}
              className="bg-white p-6 rounded-2xl shadow-md border hover:shadow-lg transition"
            >
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                {/* Title & Date */}
                <div>
                  <h2 className="text-lg sm:text-xl font-semibold text-gray-800">
                    {newsletter?.attributes?.Title}
                  </h2>
                  <span className="text-sm text-gray-500">
                    {dayjs(newsletter?.attributes?.Date).format(
                      'ddd, DD MMM YYYY hh:mm A'
                    )}
                  </span>
                </div>

                {/* Buttons */}
                <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                  {/* View PDF */}
                  <Link
                    href={
                      newsletter?.attributes?.File?.data?.[0]?.attributes
                        ?.url || '#'
                    }
                    target="_blank"
                    className="flex justify-center items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 text-white text-sm font-medium shadow hover:scale-105 hover:shadow-lg transition-transform w-full sm:w-auto"
                  >
                    <Eye className="w-4 h-4" />
                    View
                  </Link>

                  {/* Download PDF */}
                  <a
                    href={
                      newsletter?.attributes?.File?.data?.[0]?.attributes
                        ?.url || '#'
                    }
                    download
                    className="flex justify-center items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 text-white text-sm font-medium shadow hover:scale-105 hover:shadow-lg transition-transform w-full sm:w-auto"
                  >
                    <Download className="w-4 h-4" />
                    Download
                  </a>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </main>
  );
}
