'use client'
import Image from 'next/image'
import 'animate.css';



const DirectorsMessage = () =>{
    return(
        <>
            <div className='grid md:grid-cols-2 grid-cols-1 gap-2 
             bgHalf '>
                <div className='m-auto lg:p-16 md:p-10 p-5 animate__animated animate__slideInLeft'>
                <Image 
                unoptimized={true}
            src={'/imagePlaceholder.webp'} 
            width={700}
            height={150}
            alt={'Image Placeholder'}
            className=' bgImage  shadow-2xl'
            />
                

                </div>

                <div className='lg:p-10 sm:p-8 p-10 mt-10 text-whiteCol'>
                    <h1 className='mb-8  text-secondary'>Director’s Message</h1>
                    <h3 className='text-justify'>
                    &emsp;&emsp;In the journey of more than two decade of BBS Group of Institutions; we have put down many milestones in terms of students’ facilities, expansion, diversity and richness of academic programs, academic collaborations, industry-institution interaction, research contribution, and addition to infrastructure & admin facilities.
                    <br/><br/>
                    &emsp;&emsp;Aspiring to be among the Nation’s top institutions amidst challenges and arising competition for world-class infrastructure, new teaching tools and increasing expectation to deliver quality content and finest learning experience, we have an excellent infrastructure.  
                    <br/><br/>
                    &emsp;&emsp;All the hostel rooms are double bed, air cooled and well ventilated. Separate volleyball and badminton courts, football and cricket ground are provided within the hostel premises. Various other services like security, games & sports facilities, cafeteria, etc. are available within the campus. The security of the hostel is entrusted to a security agency and a medical officer regularly visits the hostel to provide immediate assistance to inmates in case of need. 
                    <br/><br/>
                    &emsp;&emsp;We are ready to fulfill the gap between industry demand and students’ skill. We provide required training to the students. We have a competent team for training and placement which ensure maximum selection at high package.
                    <br/><br/>
                    &emsp;&emsp;I invite future Engineers, Pharmacists and Managers to be a part of an academically focused, technically equipped and visionary institute for their sure success.

</h3>
                    <h2 className='text-secondary   m-0'>Dr. Ashutosh Srivastava </h2>
                    <h4 className='m-0'>Director, BBSCET, Prayagraj.
</h4>
                

                </div>

            </div>
        </>
    )
}

export default DirectorsMessage