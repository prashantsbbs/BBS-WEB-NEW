'use client';
import Link from 'next/link';
import { CircleArrowRight, HeartPulse, Trophy, FlaskConical } from "lucide-react";
const TermsConditions = () => {

  return (
    <>
<div className=" bg-cover lifeBBS bg-no-repeat  relative bg-center justify-center flex p-6 md:p-16">
<div className="flex flex-col gap-4 w-10/12 md:w-[80%] bg-whiteCol p-6 rounded-sm">
<h1 className="text-3xl text-primary border-b border-primary px-2 tracking-wide font-medium">
  Terms & Conditions
</h1>
<div className='flex flex-col gap-6 p-6 bg-gray rounded-lg border border-[#e2e2e2] shadow'>
    <div className='flex flex-col gap-4'>
    <h4 className='text-sm -mb-1 text-[#555]'><strong className=''>Last Updated:</strong> March 2026</h4>
    <p className='text-xs text-[#2f2e2e] tracking-wide leading-relaxed'>
        Welcome to the official website of BBS Group of Institutions, Phaphamau, Prayagraj, Uttar Pradesh. By accessing or using this website, you agree to comply with these Terms & Conditions. The website is intended to provide general information about the school, including its academic programs, admission procedures, and activities. Users are expected to use the website responsibly and must not attempt unauthorized access, misuse the website, or reproduce any content without permission.
        <br />
        <br />
        All content available on this website, including text, images, graphics, logos, and documents, is the property of BBS Group of Institutions unless otherwise stated. Unauthorized use or distribution of this material is strictly prohibited. Information related to admissions, eligibility, and fee structure is provided for general guidance only, and the school management reserves the right to modify policies or admission procedures at any time without prior notice.
        <br />
        <br />
        While the school strives to keep the information on the website accurate and up to date, it does not guarantee the completeness or reliability of the content. The website may contain links to external websites for reference; however, BBS Group of Institutions is not responsible for the content or privacy practices of such third-party sites. The school shall not be liable for any damages arising from the use of this website or the inability to access it.
        <br />
        <br />
        Any personal information submitted through enquiry or admission forms will be used only for school-related communication and administrative purposes. BBS Group of Institutions reserves the right to update or change these Terms & Conditions at any time. These terms are governed by the laws of India, and any disputes shall fall under the jurisdiction of courts located in Phaphamau, Prayagraj, Uttar Pradesh.
    </p></div>
<div className='p-4 border-l-4 bg-[#E7EAF0] border-primary-new-light text-[#2f2e2e]'>
    <p className='text-xs font-semibold'>Contact Information</p>
    <p className='py-2 text-xs'>For any queries regarding these Terms & Conditions, please contact BBS Group of Institutions, Phaphamau, Prayagraj, Uttar Pradesh  211013, India. Phone: 1800-1200-407, Mobile: +91-7607000961 , 7607000962 , 7607000963.</p>
</div>
</div>
</div></div>


    </>
  );
};

export default TermsConditions;



