'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../common/button';
import { international_sec, stateOfArt } from '../constant/constant';
import { useEffect } from 'react';
import { useState } from 'react';

const TheInstitute = () => {
  const defaultState = {
    mobileBanner: false,
  };

  const [state, setState] = useState(defaultState);

  const getBodyWidth = (evt: any) => {
    if (evt.target.innerWidth < 768) {
      setState((prev: any) => ({ mobileBanner: true }));
    } else setState((prev: any) => ({ mobileBanner: false }));
  };

  useEffect(() => {
    if (window) {
      window.addEventListener('resize', getBodyWidth);
      const screenWidth = window.screen.width;

      if (screenWidth < 768) {
        setState((prev: any) => ({ mobileBanner: true }));
      } else setState((prev: any) => ({ mobileBanner: false }));
    }
    return () => window && window.removeEventListener('resize', getBodyWidth);
  }, []);

  return (
    <>
      <div className="bg-gray ">
        {/* why BBS */}
        <div className="m-auto   animate__animated animate__slideInLeft">
          {state.mobileBanner ? (
            <Image
              unoptimized={true}
              src={'/banner/bannerAboutM.webp'}
              width={1000}
              height={1000}
              alt={'Banner About'}
              className=" bgImage_aboutM   "
            />
          ) : (
            <Image
              unoptimized={true}
              src={'/banner/bannerAbout.webp'}
              width={1400}
              height={1000}
              alt={'Banner About'}
              className=" bgImage_aboutD   "
            />
          )}
        </div>

        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <h1 className="text-pink">BBS Group of Institutions, Prayagraj</h1>
          <h2 className="">
            A Beacon of Quality Education and Holistic Development
          </h2>
          <h4 className="text-justify">
            &emsp;&emsp;Established in 2002 by the esteemed social worker and
            Member of Legislative Assembly, Sri Babu Bhola Singh ji, BBS Group
            of Institutions, Prayagraj has emerged as a leading educational
            conglomerate in the region. With its flagship institution, BBS
            College of Engineering and Technology, the group has garnered a
            reputation for excellence in teaching and research across various
            disciplines. Situated on the Prayagraj - Lucknow National Highway at
            Phaphamau, the institution boasts state-of-the-art infrastructure
            and a sprawling campus spanning 27 acres.
            <br />
            <br />
            <h2>A Hub of Educational Excellence:</h2>
            &emsp;&emsp;BBS Group of Institutions is committed to providing
            quality education in engineering and technology, management,
            pharmacy, science, and legal domains. With a diverse portfolio of 15
            undergraduate and postgraduate programs offered through its 8
            institutions, the group caters to the educational aspirations of
            students from various backgrounds. Accredited by prestigious
            regulatory bodies such as AICTE, BCI, PCI, AKTU, BTE, ASU and UGC,
            the group ensures adherence to the highest standards of education.{' '}
            <br />
            <br />
            <h2>Cultivating a Diverse Learning Environment:</h2>
            &emsp;&emsp;The campus of BBS Group of Institutions serves as a
            melting pot of cultures, attracting students from different parts of
            Uttar Pradesh and beyond. This diverse student body enriches the
            learning experience, fostering cross-cultural interactions and
            providing invaluable exposure to native students. With separate
            hostel facilities for boys and girls, the institution ensures a safe
            and conducive living environment for all its students. <br />
            <br />
            <h2>A Commitment to Excellence:</h2>
            &emsp;&emsp;In an era where quantity often takes precedence over
            quality, BBS Group of Institutions remains steadfast in its
            commitment to excellence. Emphasizing the values of passion and
            commitment, the institution focuses on nurturing well-rounded
            individuals equipped with both knowledge and character. With over 22
            years of dedicated service in the field of education, the
            institution takes pride in its track record of holistic student
            development.
            <br />
            <br />
            <h2>Standing Out in the Crowd:</h2>
            &emsp;&emsp;BBS Group of Institutions distinguishes itself through
            its unwavering dedication to quality education and holistic student
            development. From its world-class infrastructure to its esteemed
            faculty and diverse student community, every aspect of the
            institution reflects its commitment to excellence. As it continues
            to evolve as a leading center of education, BBS Group of
            Institutions remains dedicated to shaping the leaders of tomorrow
            with a strong foundation built on passion, commitment, and
            integrity.
            <br />
          </h4>
        </div>
      </div>

      {/* highlights */}
      {stateOfArt.map((section: any, index: number) => (
        <div
          key={index}
          className="bg-bg-black relative   text-center items-center grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1 gap-6 p-6 text-whiteCol w-full backgroundImage    "
        >
          {section.subTitle.map((tag: any, index: number) => (
            <>
              <div key={index} className=" text-center  ">
                <h2 className="text-secondary font-semibold md:text-4xl text-2xl">
                  {tag.heading}
                </h2>
                <h4 className="md:text-xl text-md">{tag.subHeading}</h4>
              </div>
            </>
          ))}
        </div>
      ))}
    </>
  );
};

export default TheInstitute;
