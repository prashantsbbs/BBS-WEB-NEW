'use client';

import Image from 'next/image';

const backgroundUrl = '/placement/placement-back.webp';

const recruitmentInformation = [
  {
    title: 'Dress Code',
    description:
      'Students are expected to adhere to the college uniform. Wearing a coat or blazer is optional.',
  },
  {
    title: 'Timeliness',
    description:
      'Candidates are required to arrive at the venue at least thirty minutes before the scheduled time for the Pre-Placement Talk (PPT). Punctuality is essential for each stage of the process.',
  },
  {
    title: 'Attendance Policy',
    description:
      'Students arriving more than ten minutes late for the Pre-Placement Talk will be denied entry and marked as absent.',
  },
  {
    title: 'Required Documents',
    description:
      'For any Recruitment Process, candidates must bring: University identity card, Two copies of Curriculum Vitae (CV), Two passport-size photographs',
  },
  {
    title: 'Stationery',
    description:
      'Students should bring their own stationery, including a writing board, HB pencil, pen, eraser, and stapler, as these items will not be provided by the Placement Cell.',
  },
];

const PlacementProcess = () => {
  return (
    <>
      {/* ---------------------------------hero ------------------------- */}

      <div
        className="lg:flex relative  "
        style={{
          backgroundImage: `url(${backgroundUrl})`,
          height: 'auto',
          backgroundSize: 'cover',
        }}
      >
        <div className="lg:w-1/2 w-full text-whiteCol lg:my-auto  lg:px-16 px-8 lg:py-44 pt-10 ">
          <h1 className="text-secondary">Placements Process</h1>
          <h4 className="text-justify">
            BBS Group of Institutions stands as a top choice for leading
            multinational corporations (MNCs) seeking to hire skilled graduates
            across diverse fields including Engineering, Management, Law,
            Science, and more. With over a hundred companies conducting campus
            placement drives annually, BBS Group attracts top talent and ensures
            their successful recruitment based on performance. Our institution
            prides itself on its exceptional placement track record, providing
            promising career opportunities for budding professionals.
          </h4>
        </div>

        <div className="lg:absolute md:bottom-0 right-20 flex    ">
          <img
            src={'/placement/placement-person.webp'}
            alt="Search Image"
            className=" w-[525px] m-auto"
          />
        </div>
      </div>

      {/* ---------------------------------student at BBS ------------------------- */}
      <div className="grid md:grid-cols-2 bg-gray grid-cols-1 md:px-32 px-8 md:py-16 py-8">
        <div className="flex">
          <div className="m-auto">
            <h3 className="font-semibold">
              Students at BBS Group of Institutions are encouraged to explore
              the online profiles of recruiting companies and assess their
              interest in participating in specific recruitment processes. If
              interested, students can apply online to the Placement Centre for
              consideration.
            </h3>
            <h4>
              Registered students will receive timely notifications about
              recruiter visits through email and the university website.
            </h4>
            <h4>
              Students attending recruitment sessions and opting to take the
              written test after the Pre-placement talk must adhere to the
              entire procedure unless they are eliminated at any stage.
              Defaulters will be barred from applying for future recruitment
              opportunities.
            </h4>
          </div>
        </div>

        <div>
          <Image
            src={'/placement/info-graphic.webp'}
            unoptimized={true}
            width={1000}
            height={20}
            alt="Info Graphic"
            className=" "
          />
        </div>
      </div>

      {/* ---------------------------------guidelines ------------------------- */}
      <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-32 px-8 md:py-16 py-8">
        <div className="flex bg-primary p-6 rounded-lg text-whiteCol">
          <div className="m-auto">
            <h3 className="font-semibold">
              Guidelines have been established to prioritize securing employment
              opportunities for every student at BBS Group of Institutions. The
              following restrictions are in place:
            </h3>

            <h4>
              Students selected by two employers must wait for their batchmates
              to receive fair opportunities before participating in additional
              recruitment processes. The Head of the Placement Cell holds
              discretion in certain cases.
            </h4>
            <h4>
              A student is considered selected if their name appears in the
              final list of successful candidates. If placed on the waiting
              list, they may apply for and attend other company recruitments.
            </h4>
            <h4>
              Students receiving offer letters from multiple recruiters must
              choose one offer before completing their program and notify others
              through the Placement Cell.
            </h4>
          </div>
        </div>

        <div className="flex bg-primary p-6 rounded-lg text-whiteCol">
          <div className="m-auto">
            <h3 className="font-semibold">
              Key points to remember on the day of recruiter visits:
            </h3>

            {recruitmentInformation.map((list: any, index) => (
              <h4 key={index}>{list.description}</h4>
            ))}
          </div>
        </div>
      </div>

      {/* ---------------------------------policy ------------------------- */}

      <div className="flex bg-gray-dark  m-auto p-6  ">
        <div className="m-auto w-[80%]">
          <h4 className="font-semibold text-justify">
            This policy is subject to changes at any stage at the discretion of
            the CRC/Institute&#39;s authorities. Any modifications or updates
            will be communicated promptly to all relevant stakeholders, ensuring
            transparency and compliance with the evolving needs of our
            institution.
          </h4>
        </div>
      </div>
    </>
  );
};
export default PlacementProcess;
