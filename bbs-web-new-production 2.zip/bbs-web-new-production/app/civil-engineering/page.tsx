'use client';
import Image from 'next/image';
import 'animate.css';
import Arrow from '../common/arrow';
import ScrollTrigger from 'react-scroll-trigger';
import { useEffect, useState } from 'react';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import MasterCourse from '../eligibility-criteria/masterCourse';

import SwiperComponent from '../home/congracts-section/swiper';
import CourseSlider from '../common/courseSlider';
import FutureReadyEng from '../common/futureReadyEng';
import AppService from '../services';
import SeoWrapper from '../common/SeoWrapper';

const programHighlights = [
  {
    highlight:
      'Practical Learning: Emphasis on hands-on experience and practical application of civil engineering principles through laboratory work and field projects.',
  },
  {
    highlight:
      'Industry Engagement: Collaboration with leading civil engineering firms for internships, site visits, and real-world projects, providing students with valuable industry exposure.',
  },
  {
    highlight:
      'Skill Development: Offering courses and workshops to enhance technical skills in areas such as structural analysis, transportation engineering, and construction management.',
  },
  {
    highlight:
      'Innovation and Research: Encouraging innovation and research in civil engineering through projects, seminars, and industry collaborations, fostering a culture of continuous learning and advancement.',
  },
  {
    highlight:
      'Global Perspective: Exposure to international best practices and global challenges in civil engineering through guest lectures, exchange programs, and participation in international conferences and competitions.',
  },
];

const careerProspectus = [
  'Software Developer',
  'Testing Engineer',
  'System Analyst',
  'Technical Support Engineer',
  'IT Technical Content Developer',
  'System Database Administrator',
];

const majorTrack = [
  { track: 'Infrastructure Construction Engineering & Management' },
  { track: 'Structural Analysis & Design Materials' },
  { track: 'Geotechnical and Foundation Engineering' },
  {
    track:
      'Transportation (Roads, Bridges, Railway, Airport, Docks, and Harbors)',
  },
  { track: 'Environmental Engineering' },
  { track: 'Career Prospects' },
  { track: 'Site Engineers' },
  { track: 'Maintenance Engineer' },
  { track: 'Structural Consultants' },
  { track: 'Construction Management Consultants' },
  { track: 'Project Managers' },
  { track: 'Surveying Consultants' },
];

const faculty = [
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
];

const defaultState = {
  isLoading: false,
  facultyList: [],
};

const departmentId = 3;
const CivilEngineering = () => {
  const defaultAnimation = {
    courseOverview: false,
    highlights: false,
  };

  const [animationStart, setAnimationStart] = useState(defaultAnimation);

  const onEnterViewport = () => {
    setAnimationStart((prev) => ({
      ...prev,
      courseOverview: true,
      highlights: true,
    }));
  };

  const onExitViewport = () => {
    setAnimationStart((prev) => ({
      ...prev,
      courseOverview: true,
      highlights: true,
    }));
  };

  const [state, setState] = useState(defaultState);
  const fetchFacultyList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getFacultyList();
    if (!error) {
      // Rehan Code for Category Filtering
      const facultyList = data.filter(
        (item: any) => item?.attributes?.department?.data?.id === departmentId
      );

      setState((prevState) => ({
        ...prevState,
        facultyList,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchFacultyList();
  }, []);
  return (
    <>
      <SeoWrapper
        title="Best Civil Engineering College in UP | B.Tech Program"
        description="Study B.Tech Civil Engineering at BBS College of Engineering, the best civil engineering college in UP, with hands-on learning, design projects, and expert faculty."
      >
        {/* Hero Sectino */}
        <section>
          <div className="handleoverlflow w-[80%] m-auto grid md:grid-cols-2 grid-cols-1 justify-center items-center md:px-6 px-3 py-12">
            <div>
              <Image
                src={'/courses/civil-icon.webp'}
                unoptimized={true}
                width={90}
                height={20}
                alt="Civil Icon"
                className="animate__animated animate__fadeInLeftBig my-4 rotateAnimate"
              />
              <div>
                <h2 className="">UG Degree</h2>
                <div className="bg-secondary h-2 w-full"></div>
              </div>
              <h1 className="m-0">
                B.Tech. <br /> Civil Engineering
              </h1>
            </div>

            <div className="md:p-8 p-4">
              <Image
                unoptimized={true}
                src={'/courses/civil-engineering.webp'}
                width={600}
                height={20}
                alt="Civil Engineering"
                className="animate__animated animate__fadeInRight"
              />
            </div>
          </div>
        </section>

        {/* Course Overveiw */}

        <section className="bg-gray handleoverlflow">
          <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-24 px-6">
            <div data-aos="fade-right" className={`p-6 `}>
              <div>
                <h2>COURSE OVERVIEW</h2>
                <h4 className="text-justify">
                  &emsp;&emsp;The B.Tech Civil Engineering program at one of the
                  best civil engineering colleges in UP combines knowledge in
                  mathematics, physics, mechanics, geotechnical engineering,
                  materials science, hydraulics, and statistical analysis to
                  prepare students for infrastructure design and development.
                  <br />
                  <br />
                  &emsp;&emsp;Students learn to manage projects in a
                  multidisciplinary environment, applying engineering and
                  management principles while considering environmental, legal,
                  financial, and ethical constraints. The program emphasizes
                  design thinking, helping students develop strong
                  problem-solving skills in the field of civil engineering.
                  <br />
                  <br />
                  &emsp;&emsp;Through practical projects, assignments, and
                  industry internships in areas such as underwater technology,
                  civil engineering, and construction management, students gain
                  hands-on experience. These opportunities make them
                  industry-ready and help build a strong career at the best
                  college for civil engineering in UP.
                </h4>
              </div>

              <div className="">
                <h2 className="uppercase">Major Tracks</h2>
                <div className="grid md:grid-cols-2 grid-cols-1">
                  {majorTrack.map((item, index) => (
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h3 className="m-2">{item.track}</h3>
                    </div>
                  ))}
                </div>
              </div>
              <div className="">
                <h2 className="uppercase">Advanced Options of Study</h2>
                <div className="grid md:grid-cols-2 grid-cols-1">
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">M.Tech.</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">MBA</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">Other PG Course</h3>
                  </div>
                </div>
              </div>
            </div>

            <div className={`m-auto `} data-aos="fade-left">
              <div className="bg-secondary p-4 m-4 md:mr-12">
                <div className="p-4">
                  <h3 className="m-0">Duration</h3>
                  <h2 className="m-0">4 Years</h2>
                </div>
                <div className="p-4">
                  <h3 className="m-0">Programme Name</h3>
                  <h2 className="m-0">B.Tech Civil Engineering</h2>
                </div>
              </div>
              <div className="bg-primary text-whiteCol p-4 m-4 md:ml-12">
                <div className="p-4">
                  <h2 className="m-0">Eligibility</h2>
                  <h3 className="mb-0 text-secondary uppercase">B. Tech.</h3>
                  <h5 className="text-justify mt-0">
                    Passed 10+2 examination with Physics and Mathematics as
                    compulsory subjects along with Chemistry / Computer Science.
                    With at least 50% marks in the above subjects, taken
                    together and 50% marks overall
                  </h5>
                  <h3 className="mb-0 text-secondary uppercase">
                    B. Tech. (Lateral Entry).
                  </h3>
                  <h5 className="text-justify m-0">
                    With at least 50% in 3 years Diploma recognized by Board of
                    Technical Education / University or B Sc (PCM)
                  </h5>
                </div>
                <div className="p-4">
                  <Link href={'apply-online'} target="blank">
                    <ButtonCustom
                      btnColor={'secondary'}
                      btnText={'Apply Online'}
                      textCol={'primary'}
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Program Highliths */}

        <section className="md:p-12 py-6 " data-aos="zoom-in-up">
          <div className="w-[80%] m-auto bg-primary p-6 text-whiteCol">
            <div>
              <h2 className="text-secondary">Programme Highlights</h2>
              <div
                className={`md:columns-2 columns-1 
                            ${
                              animationStart.highlights
                                ? 'animate__animated animate__fadeInRight animate__slower'
                                : ''
                            }`}
              >
                {programHighlights.map((list: any, index) => (
                  <>
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h4 className="m-2">{list.highlight}</h4>
                    </div>
                  </>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Future Ready */}
        <FutureReadyEng
          department={
            <>
              Department of <br />
              Civil Engineering
            </>
          }
        />

        {/* Advanced Options of Study */}

        <section data-aos="fade-up-right" className="md:p-12 py-6  bg-gray">
          <div className="w-[80%] m-auto bg-secondary rounded-xl p-6 text-whiteCol">
            <div>
              <h2 className="text-primary  text-center">Career Prospects</h2>
              <div className=" grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3   m-auto ">
                {careerProspectus.map((career: any, index) => (
                  <h3
                    key={index}
                    className="bg-whiteCol rounded-md drop-shadow-md px-6 py-2
                    text-primary m-0"
                  >
                    {career}
                  </h3>
                ))}
              </div>
            </div>
          </div>
        </section>
        {/* </ScrollTrigger> */}

        {/* Top Recruiters */}
        <div className="mt-12">
          <RecruitersComapnies />
        </div>

        {/* Eligibility  */}
        {/* <div className="md:p-12 p-8 ">
        <Eligibility EligibilityTable={EligibilityTable} />
      </div> */}

        {/* Faculty  */}
        {!!state.facultyList.length && (
          <div className="  bg-primary flex">
            <div className="lg:w-[85%] w-[90%] m-auto md:p-16 p-4  ">
              <h2 className="m-auto text-secondary text-center p-4">
                Our Faculty
              </h2>
              <CourseSlider elements={state.facultyList} />
            </div>
          </div>
        )}
      </SeoWrapper>{' '}
    </>
  );
};
export default CivilEngineering;
