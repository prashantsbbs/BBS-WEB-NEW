import React from "react";
import Image from "next/image";

const UnderConstruction = () => {
  return (
   
    <div className="flex items-center justify-center h-[calc(100vh-300px)] bg-gray-100">
      <h1 className="sr-only">Under Construction</h1>
    <div className="text-center p-6 bg-white rounded-lg shadow-lg max-w-sm">
      <div className="mb-4 flex justify-center">
        <Image
          src="/icon/warning.webp"
          width={24}
          height={24}
          alt="Warning"
          unoptimized={true}
        />
      </div>
      <h2 className="text-xl font-semibold text-gray-800 mb-2">We are Building Something Awesome!</h2>
      <p className="text-gray-600 mb-4">This page is currently under construction. We will be here soon with more updates.</p>
      <p className="text-gray-500 text-sm">If you have any questions, feel free to <a href="mailto:contact@yourdomain.com" className="text-blue-600">reach out to us.</a></p>
    </div>
  </div>
  
  );
};

export default UnderConstruction;