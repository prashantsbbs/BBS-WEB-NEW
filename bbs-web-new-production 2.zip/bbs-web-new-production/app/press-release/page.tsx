'use client';
import { useEffect, useMemo, useState } from 'react';
import BreadcrumbGallery from '../common/galleryBreadcrumb';
import Card from './cards';
import AppService from '../services';

const cardData = [
  {
    id: 1,
    img: '/press-release/1.webp',
    title: 'Title 1',
    date: 'Tue Aug 19 2020 22:18:29 GMT+0530 (India Standard Time)',
  },
  {
    id: 2,
    img: '/press-release/2.webp',
    title: 'Title 2',
    date: 'Tue Sep 19 2021 22:18:29 GMT+0530 (India Standard Time)',
  },
  {
    id: 3,
    img: '/imagePlaceholder.webp',
    title: 'Title 3',
    date: 'Tue Apr 19 2022 22:18:29 GMT+0530 (India Standard Time)',
  },
  {
    id: 4,
    img: '/press-release/1.webp',
    title: 'Title 5',
    date: 'Tue May 19 2020 22:18:29 GMT+0530 (India Standard Time)',
  },
  {
    id: 5,
    img: '/imagePlaceholder.webp',
    title: 'Title 6',
    date: 'Tue Apr 19 2023 22:18:29 GMT+0530 (India Standard Time)',
  },
  {
    id: 6,
    img: '/press-release/2.webp',
    title: 'Title 4',
    date: 'Tue July 19 2021 22:18:29 GMT+0530 (India Standard Time)',
  },
];

const currentYear = new Date().getFullYear();
const years = ['Select Year', , currentYear];

const formatDate = (dateString: any) => {
  const date = new Date(dateString);
  const year = date.getFullYear();
  let month = (date.getMonth() + 1).toString().padStart(2, '0');
  let day = date.getDate().toString().padStart(2, '0');
  return `${year}-${month}-${day}`;
};

cardData.forEach((item) => {
  item.date = formatDate(item.date);
});

for (let i = 1; i <= 5; i++) {
  let previousYear = currentYear - i;
  years.push(previousYear);
}

const currentMonth = [
  'Select Month',
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

const PressRelease = () => {
  const [state, setState] = useState({
    selectedYear: '',
    selectedMonth: '',
    data: cardData,
    isLoading: false,
    pressReleaseList: [],
  });

  const fetchPressReleaseList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: false }));
    const { data, error } = await AppService.getPressReleaseList();
    if (error) {
    } else {
      setState((prevState) => ({ ...prevState, pressReleaseList: data }));
    }
    setState((prevState) => ({ ...prevState, isLoading: true }));
  };

  const handleYear = (e: any) => {
    const selectedYear = parseInt(e.target.value);
    setState((prevState: any) => ({
      ...prevState,
      selectedYear,
    }));
    setState((prevState) => ({ ...prevState, selectedMonth: '' }));
  };

  const handleMonth = (e: any) => {
    const selectedMonth = e.target.value;
    setState((prevState) => ({ ...prevState, selectedMonth }));
  };

  const filteredCardData = state.data.filter((card) => {
    const [year, month] = card.date.split('-');
    return state.selectedMonth.length === 0 || state.selectedMonth == '0'
      ? year == state.selectedYear
      : year == state.selectedYear && +month === +state.selectedMonth;
  });

  useEffect(() => {
    fetchPressReleaseList();
  }, []);

  const pressReleaseList = useMemo(() => {
    return state.pressReleaseList.filter((item: any) => {
      if (state.selectedYear && state.selectedMonth) {
        const date = new Date(item?.attributes?.date);
        return (
          date.getFullYear() === +state.selectedYear &&
          date.getMonth() === +state.selectedMonth - 1
        );
      } else {
        return true;
      }
    });
  }, [state.pressReleaseList, state.selectedYear, state.selectedMonth]);

  return (
    <div className="bg-[#d6d5d53a]">
      <h1 className="sr-only">Press release</h1>
      <BreadcrumbGallery componentName={'Press Release'} />
      {/* Year and Month selection */}
      <div className="flex w-fit mx-auto mt-10">
        <select
          name="year"
          onChange={handleYear}
          value={state.selectedYear}
          className="mr-4 px-4 py-2 text-base border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
        >
          {years.map((year, index) => (
            <option key={index} value={year}>
              {year}
            </option>
          ))}
        </select>
        <select
          name="month"
          onChange={handleMonth}
          value={state.selectedMonth}
          className="px-4 py-2 text-base border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
          disabled={!state.selectedYear}
        >
          {state.selectedYear ? (
            currentMonth.map((month, index) => (
              <option key={index} value={index}>
                {month}
              </option>
            ))
          ) : (
            <option>Select Month</option>
          )}
        </select>
      </div>
      {/* Display filtered cards */}
      {pressReleaseList.length ? (
        <div className="md:py-20 py-10 md:px-32 px-10 grid grid-cols-3 lg:gap-20 gap-8 justify-center items-center  mx-auto my-auto image-grid-container ">
          {pressReleaseList.map((card: any) => (
            <Card key={card.id} id={card.id} card={card} />
          ))}
        </div>
      ) : (
        <p className="text-center text-xl py-14">Not Found</p>
      )}
    </div>
  );
};

export default PressRelease;
