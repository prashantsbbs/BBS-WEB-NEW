'use client';

import AppService from '@/app/services';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useState } from 'react';

const cardData = [
  {
    id: 1,
    img: '/press-release/1.webp',
    title: 'Title 1',
    date: '2022-11-15',
  },
  {
    id: 2,
    img: '/press-release/2.webp',
    title: 'Title 2',
    date: '2024-06-16',
  },
  {
    id: 3,
    img: '/imagePlaceholder.webp',
    title: 'Title 3',
    date: '2021-03-17',
  },
  {
    id: 4,
    img: '/press-release/1.webp',
    title: 'Title 5',
    date: '2020-12-05',
  },
  {
    id: 5,
    img: '/imagePlaceholder.webp',
    title: 'Title 6',
    date: '2024-02-09',
  },
  {
    id: 6,
    img: '/press-release/2.webp', // Random image link
    title: 'Title 4',
    date: '2023-08-21', // Random date
  },
];

const FullView = ({ params }: { params: { id: number } }) => {
  const [pressRelease, setPressRelease] = useState<any>({});
  const [isLoading, setIsLoading] = useState(false);
  const index = +params.id;

  const fetchPressRelease = async (id: any) => {
    setIsLoading(true);
    const { data, error } = await AppService.getPressRelease(id);
    if (error) {
    } else {
      setPressRelease(data);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchPressRelease(index);
  }, [index]);

  return (
    <div className="xl:max-w-[96%] p-8 md:p-20 h-full w-full relative">
      <Link href={'/press-release'}>
        <Image
          src={'/svg/crossIcon.svg'}
          unoptimized={true}
          width={15}
          height={50}
          alt="Cross Icon"
          style={{ background: 'black' }}
          className=" border border-[rgb(0 0 0 / 22%)] shadow-lg p-2 rounded-full w-10  absolute md:top-10 top-[-1.5rem] md:right-6  right-[5px]  cursor-pointer hover:scale-110 xl:mt-0 my-10"
        />
      </Link>
      <div className="mt-2 max-w-fit mx-auto flex flex-col  items-center border border-gray-100 shadow-lg rounded-lg p-3">
        <div className="flex-shrink-0 mb-6 md:mb-0  w-full md:w-auto">
          <Image
            width={700}
            unoptimized={true}
            height={400}
            loading="lazy"
            src={pressRelease?.attributes?.media?.data?.attributes?.url}
            alt="Press Release Fullview"
            className="object-cover rounded-lg w-full"
          />
        </div>
        <div className="w-full">
          <div className="mb-4 md:mb-0">
            <h1 className="text-xl font-semibold">
              {pressRelease?.attributes?.title}
            </h1>
            <p className="text-sm text-gray-500">
              {pressRelease?.attributes?.date
                ? new Date(pressRelease?.attributes?.date).toLocaleDateString()
                : '-'}
            </p>
          </div>
          <p className="text-sm text-gray-600 leading-relaxed">
            {/* Description content goes here */}
          </p>
        </div>
      </div>
    </div>
  );
};

export default FullView;
