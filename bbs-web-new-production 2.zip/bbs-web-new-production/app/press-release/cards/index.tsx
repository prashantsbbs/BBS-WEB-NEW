import Image from "next/image";
import Link from "next/link";

const Card = ({ id, card }: any) => {
  return (
    <>
      <Link href={`/press-release/${id}`}>
        <div className=" max-w-[522.400px]  sm:min-w-[400px] min-w-[350px] h- flex flex-col bg-whiteCol border border-[#0000002d] rounded-xl overflow-hidden shadow-md  hover:shadow-2xl transition-all duration-300 m-auto relative">
          <div>
            <Image
              src={card?.attributes?.media?.data?.attributes?.url}
              width={300}
              height={50}
              loading="lazy"
              alt="Press Release Card"
              unoptimized={true}
              className="w-full h-[280px]"
            />
          </div>
          <div className="w-full md:w-2/3 p-3 md:p-4">
            <h2 className="text-base md:text-lg font-semibold text-gray-800 mb-1">
              {card?.attributes?.title}
            </h2>
            <h3 className="text-xs md:text-sm text-gray-700">
              Date: {card?.attributes?.date ? new Date(card?.attributes?.date).toLocaleDateString() : '-'}
            </h3>
          </div>
        </div>
      </Link>
    </>
  );
};

export default Card;