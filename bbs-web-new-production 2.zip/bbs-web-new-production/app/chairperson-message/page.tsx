"use client";
import Image from "next/image";
import "animate.css";

const ChairPersonMessage = () => {
  return (
    <>
      <div
        className="grid md:grid-cols-2 grid-cols-1 gap-2 
             bgHalf "
      >
        <div className='m-auto lg:p-16 md:p-10 p-5 animate__animated animate__slideInLeft'>
                <Image 
            src={'/chairperson_1.webp'} 
            width={700}
            unoptimized={true}
            height={150}
            alt={'Chair Person'}
            className=' bgImage  shadow-2xl'
            />
                

                </div>

        <div className="lg:p-10 sm:p-8 p-10 mt-10 text-whiteCol">
          <h1 className="mb-8  text-secondary">Chairperson&#39;s Message</h1>
          <h3 className="text-justify">
            &emsp;&emsp;The responsibilities of technical colleges in our
            country are gradually increasing. Besides preparing young
            technocrats and managers to meet further challenges and to prosper
            the values, culture and ethics in the society are also to be kept in
            mind. By keeping this in mind; we have established different
            institutions of B. B.S. Group time to time.
            <br />
            <br />
            &emsp;&emsp; B.B.S. College of Engineering & Technology is incipient
            to take admissions for the new session. During a short span of time
            the college has emerged into a fully grown up-to-date and technical
            conscious institute. It has created a niche for itself in the
            academic life of the country. Emergence of conscious thinking and
            pioneer engineering approaches are moulding the educational setup
            into the new frame.
            <br />
            <br />
            &emsp;&emsp; My thanks and best wishes to all the staff members of
            the group, faculty members, students and especially to Directors of
            all the Colleges under B.B.S. Group of Institutions, eminent
            professors for their sincere efforts and dedication. I am confident
            while making promise to the new entrants that we are determined to
            give them the best in a perfect and Wishing Good Luck.
          </h3>
          <h2 className="text-secondary m-0  ">
            Smt. Madhuri Singh
          </h2>
          <h4 className="m-0">Chairperson, BBS Group of Institutions</h4>
        </div>
      </div>
    </>
  );
};

export default ChairPersonMessage;
