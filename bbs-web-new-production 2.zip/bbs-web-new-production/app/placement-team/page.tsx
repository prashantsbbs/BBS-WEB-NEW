"use client";
import Image from "next/image";

const crtcTeam = [
  {
    name: "Mr. Divyasen Singh",
    position: "Director - CRTC ",
    email: "directortp@bbs.ac.in",
    mobile: "9794444536",
    image: "/placement/team/divyasen_1.webp",
  },
  {
    name: "Mr. Vivek Chandra",
    position: "Head - CRTC ",
    email: "tpo@bbs.ac.in",
    mobile: "8853885824",
    image: "/placement/team/vivek.webp",
  },
  {
    name: "Dr. Sameeksha Singh",
    position: "Manager - CRTC ",
    email: "mail@bbs.ac.in",
    image: "/placement/team/sameeksha_1.webp",
  },
];

const PlacementTeam = () => {
  return (
    <>
      <div className="md:w-[85%] w-[95%] m-auto p-4">
        <div className="text-center pb-4">
          <h1 className="text-primary">BBS Placement Team</h1>
          <h3>
            Corporate Relations and Training Cell (CRTC), the training and
            placement department of BBS Group of Institutions, Prayagraj.
          </h3>
        </div>

        <div className="grid md:grid-cols-3 grid-cols-1 gap-16">
            {crtcTeam.map((list: any, index) => (
              <div key={index}>
                <div className="m-auto   animate__animated animate__slideInLeft">
                  <Image
                  unoptimized={true}
                    src={list.image}
                    width={500}
                    height={400}
                    alt={"Crtc Team"}
                    className=" rounded-xl   "
                  />
                  <h2 className="font-semibold text-pink">{list.name}</h2>
                  <h4 className="font-semibold m-0 ">{list.position}</h4>
                  <h4 className="font-semibold m-0">{list.email}</h4>
                  <h4 className="font-semibold m-0">{list.mobile}</h4>
                </div>
              </div>
            ))}
        </div>
      </div>
    </>
  );
};

export default PlacementTeam;
