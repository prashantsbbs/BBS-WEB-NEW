"use client";
import AppService from "@/app/services";
import Image from "next/image";
import { useEffect, useState } from "react";
import { BlocksRenderer } from "@strapi/blocks-react-renderer";
import { useRouter } from "next/navigation";

interface StateType {
  news: any,
  isLoading: boolean
}
const defaultState: StateType = {
  news: {},
  isLoading: false
};

const NewsSinglePage = ({ params }: { params: { id: String } }) => {
  const [state, setState] = useState(defaultState);
const router = useRouter();
  const fetchNews = async (id: any) => {
    setState(prevState => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getNews(id);
    if (!error) {
      setState(prevState => ({ ...prevState, news: data }));
    } else {
      const redirectURL = params.id === 'contact-us' ? '/contact-us' : '/news';
      router.push(redirectURL)
    }
    setState(prevState => ({ ...prevState, isLoading: false }));
  };


  useEffect(() => {
    fetchNews(params.id)
  }, [params.id]);

  return (
    <>
    <div>
      <div className="m-auto mt-5  w-[80%] m-auto animate__animated animate__slideInLeft ">
        <div>
          {state.news.id  &&
          <Image
            src={state.news?.attributes?.media?.data?.attributes?.url || ""}
            width={1000}
            height={1000}
            alt={"News Single"}
            unoptimized={true}
            className=" bgImage_news  rounded-xl "
          />}
        <div className="bg-secondary md:w-1/3 ml-auto -mt-20 relative z-10">
          <h1 className="text-xl p-4 mb-4 text-justify font-semibold">{state.news?.attributes?.description}</h1>
        </div>
        </div>

        <div>
          <BlocksRenderer
            content={state.news?.attributes?.content || []}
          />
        </div>
      </div>
    </div>
  </>
  );
};

export default NewsSinglePage;
