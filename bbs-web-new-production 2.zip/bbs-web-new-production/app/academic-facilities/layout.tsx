'use client';
import Image from 'next/image';
import 'animate.css';
import Breadcrumb from '../common/breadcurb';
import {
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useState,
} from 'react';
import LectureTheatre from './lecture-theater/page';
import ConferenceHall from './conference-hall/page';
import Libraries from './libraries/page';
import AcademicBreadcrumb from '../common/academicBreadcrumb';
import { usePathname } from 'next/navigation';
import Laboratories from './laboratories/page';
import Link from 'next/link';

const AcademicFailities = ({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) => {
  const defaultState: any = {
    activeHead: 0,
  };

  const [state, setState] = useState(defaultState);

  const heads = [
    {
      title: 'Lecture Theaters',
      active: 0,
      url: '/academic-facilities/lecture-theater',
    },
    {
      title: 'Conference Hall',
      active: 1,
      url: '/academic-facilities/conference-hall',
    },
    {
      title: 'Laboratories',
      active: 2,
      url: '/academic-facilities/laboratories',
    },
    { title: 'Libraries', active: 3, url: '/academic-facilities/libraries' },
  ];

  let pathname = usePathname();

  useEffect(() => {
    heads.map((page: any) => {
      if (pathname === page.url) {
        setState((prev: any) => ({ ...prev, activeHead: page.active }));
      }
    });
  }, [pathname]);

  const handleActiveMenu = (activeMenu: any, url: any) => {
    setState((prev: any) => ({ ...prev, activeHead: activeMenu }));
  };

  return (
    <>
      <div className="bg-gray ">
        <AcademicBreadcrumb componentName={'Academic  Facilities'} />

        <div className="bg-primary text-whiteCol py-5 ">
          <div className="flex md:flex-row flex-col text-center justify-between items-center	 w-3/4 m-auto   cursor-pointer ">
            {heads.map((head, index) => (
              <div key={index}>
                <Link href={head.url}>
                  <h3
                    className="px-4 my-2"
                    onClick={() => handleActiveMenu(index, head.url)}
                  >
                    {head.active !== state.activeHead ? (
                      head.title
                    ) : (
                      <div className="bg-secondary animate__animated animate__fadeInLeft rounded-md m-0 px-2 py-1 m-auto w-max	 text-primary">
                        {head.title}
                      </div>
                    )}
                  </h3>
                </Link>
              </div>
            ))}
          </div>
        </div>

        {children}
      </div>
    </>
  );
};

export default AcademicFailities;
