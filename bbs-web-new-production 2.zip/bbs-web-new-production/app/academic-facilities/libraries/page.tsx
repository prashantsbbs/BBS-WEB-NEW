"use client";
import Image from "next/image";
import "animate.css";
import ButtonCustom from "../../common/button";
import { international_sec, stateOfArt } from "../../constant/constant";

const library = [
  {
    title: "lecture",
    image: "/campusLife/library/1.webp",
  },
  {
    title: "lecture",
    image: "/campusLife/library/8.webp",
  },
  {
    title: "lecture",
    image: "/campusLife/library/2.webp",
  },
  {
    title: "lecture",
    image: "/campusLife/library/3.webp",
  },
  {
    title: "lecture",
    image: "/campusLife/library/4.webp",
  },
  {
    title: "lecture",
    image: "/campusLife/library/5.webp",
  },
  {
    title: "lecture",
    image: "/campusLife/library/6.webp",
  },
  {
    title: "lecture",
    image: "/campusLife/library/7.webp",
  },
];

const Libraries = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              src={"/campusLife/library/1.webp"}
              width={1000}
              height={1000}
              alt={"Library"}
              unoptimized={true}
              className=" bgImage_about "
            />
          </div>

          <h1 className="">Libraries</h1>
          <h4 className="text-justify">
            &emsp;&emsp;The Central Library is the hub of information services
            in the institutions. It serves as a creative and innovative partner
            in supporting the teaching, learning, and research activities. With
            a fast growing collection, both in digital and print format using
            state-of-the-art facilities, currently the Central Library has more
            than 25000 books and subscribes to various national and
            international journals/magazines in print besides a larger number of
            e-journals.
            <br />
            <br />
            &emsp;&emsp;The Central Library&#39;s operations and services are
            fully computerized. For this, we have specialized user-friendly open
            source software. In order to ease the track and circulation of the
            books/journals we also Bar-Code based computerized circulation
            system. This software facilitates automated circulation (issue &
            return) of the resources and speedy access to bibliographies,
            locations and availability information of the resources stocked in
            the library. We endeavor to further improve all our efforts to
            facilitate right information to the right user at the right time.
          </h4>
        </div>

        <div className="grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary w-[80%] m-auto">
          {library.map((game: any, index) => (
            <>
              <div key={index}>
                <Image
                  src={game.image}
                  width={800}
                  height={400}
                  alt={"Library"}
                  unoptimized={true}
                  className="  bgImageIndoor rounded-lg "
                />
              </div>
            </>
          ))}
        </div>
      </div>
    </>
  );
};

export default Libraries;
