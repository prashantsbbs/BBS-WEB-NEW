'use client';
import Image from 'next/image';
import 'animate.css';
const lectureTheaters = [
  {
    title: 'lecture',
    image: '/campusLife/lecture3.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/lecture6.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/lecture7.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/lecture4.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/lecture1.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/lecture2.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/secondlast.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/last.webp',
  },
];

const ConferenceHall = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        {/* why BBS */}

        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              unoptimized={true}
              src={'/campusLife/conferencehallbanner.webp'}
              width={1000}
              height={1000}
              alt={'Conference Hall Banner'}
              className=" bgImage_about "
            />
          </div>

          <h1 className="">Conference Halls</h1>
          <h4 className="text-justify">
            &emsp;&emsp;With State-of-the-art auditoriums, BBS group f
            institutions has a capacity to host 500+ people in its Conference
            hall. Students, faculty and guests can easily organise events,
            workshops and guest lectures. The conference halls are equipped with
            sound system, projector and green rooms and are air conditioned to
            cater to the need of audiences. This hall is aesthetically designed
            to not only meet the specific requirements but also to add to the
            overall pleasure of listening to and talking with some of the very
            sharp minds around, on work.
          </h4>

          <div className="grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary">
            {lectureTheaters.map((game: any, index) => (
              <>
                <div key={index}>
                  <Image
                    unoptimized={true}
                    src={game.image}
                    width={400}
                    height={400}
                    alt={'Conference Hall'}
                    className="  bgImageIndoor rounded-lg "
                  />
                </div>
              </>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default ConferenceHall;
