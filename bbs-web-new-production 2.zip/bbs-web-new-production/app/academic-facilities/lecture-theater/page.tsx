'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../../common/button';
import { international_sec, stateOfArt } from '../../constant/constant';
import { inDoorGames } from '../../constant/campusLife';

const lectureTheaters = [
  {
    title: 'lecture',
    image: '/campusLife/1.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/2.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/3.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/4.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/5.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/6.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/7.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/lectureTheatre.webp',
  },
];
const LectureTheatre = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        {/* why BBS */}

        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              src={'/campusLife/lectureTheatre.webp'}
              width={1000}
              height={1000}
              alt={'Lecture Theatre'}
              unoptimized={true}
              className=" bgImage_about "
            />
          </div>

          <h1 className="">Lecture Theaters</h1>
          <h4 className="text-justify">
            &emsp;&emsp;BBS Group of institutions has 73 classrooms which are
            built like amphitheater, so that the teacher can give equal
            attention to all the students. 24 out of these are tutorial rooms.
            All these classrooms are Air-Conditioned. There are Latest computer
            systems attached with projector as well as on demand sound system,
            Wi-Fi and all modern, hi-tech amenities to facilitate incubates to
            have demonstrative mode of learning. The Internet facility is
            available on the computers in all the institutions.
          </h4>

          <div className="grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary">
            {lectureTheaters.map((game: any, index) => (
              <>
                <div key={index}>
                  <Image
                    src={game.image}
                    width={800}
                    height={400}
                    alt={'Lecture Theatre'}
                    unoptimized={true}
                    className="  bgImageIndoor rounded-lg "
                  />
                </div>
              </>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default LectureTheatre;
