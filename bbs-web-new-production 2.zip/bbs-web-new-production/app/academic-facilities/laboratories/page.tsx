'use client';
import Image from 'next/image';
import 'animate.css';
import { bbsLabs } from '@/app/constant/bbsLabs';
import Arrow from '@/app/common/arrow';

const laboratories = [
  {
    title: 'lecture',
    image: '/campusLife/lab1.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/lab2.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/lab3.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/lab4.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/computerLab.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/lab5.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/lab6.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/lab7.webp',
  },
];

const Laboratories = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              unoptimized={true}
              src={'/campusLife/computerLab.webp'}
              width={1000}
              height={1000}
              alt={'Computer Lab'}
              className=" bgImage_about "
            />
          </div>

          <h1 className="">Laboratories</h1>
          <h4 className="text-justify">
            &emsp;&emsp;BBS Group of institutions has a total of 35 well
            equipped labs where the students get a hands-on experience on
            various emerging technologies through which they get an opportunity
            to expand their practical understanding of how a particular
            phenomenon works. This practical understanding comes really handy
            when they use those tools in practical situation, actually, in a
            corporate or on a project. Every department has its own laboratories
            where Students work with state-of-the-art machines under expert
            guidance from experienced and trained Faculty members.
          </h4>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary w-[80%] m-auto">
        {laboratories.map((game: any, index) => (
          <>
            <div key={index}>
              <Image
                unoptimized={true}
                src={game.image}
                width={800}
                height={400}
                alt={'Laboratories'}
                className="  bgImageIndoor rounded-lg "
              />
            </div>
          </>
        ))}
      </div>

      <div className="w-[80vw] p-4  m-auto ">
        <h2 className="text-5xl font-semibold">Labs at BBSCET</h2>
        <h4 className="text-justify">
          <div className="md:columns-2 columns-1">
            {bbsLabs.map((list: any, index: number) => (
              <div key={index} className="flex gap-4 ">
                <Arrow />
                {list.label}
              </div>
            ))}
          </div>
        </h4>
      </div>
    </>
  );
};

export default Laboratories;
