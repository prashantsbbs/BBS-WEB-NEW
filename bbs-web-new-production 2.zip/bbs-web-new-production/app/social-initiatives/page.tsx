'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../common/button';
import { international_sec, stateOfArt } from '../constant/constant';

const SocialInitiatives = () => {
  const gallery = [
    {
      image: '/about/social-initiative/5.webp',
    },
    {
      image: '/about/social-initiative/6.webp',
    },
    {
      image: '/about/social-initiative/7.webp',
    },
    {
      image: '/about/social-initiative/8.webp',
    },
    {
      image: '/about/social-initiative/9.webp',
    },
    {
      image: '/about/social-initiative/10.webp',
    },
    {
      image: '/about/social-initiative/11.webp',
    },
    {
      image: '/about/social-initiative/12.webp',
    },
  ];

  return (
    <>
      <div className="bg-gray pb-5 ">
        {/* why BBS */}
        <div className="m-auto w-3/4 lg:p-12 md:p-8 sm:p-4 mt-7 grid sm:grid-cols-2 grid grid-cols-1 gap-4 ">
          <Image
            unoptimized={true}
            src={'/about/social-initiative/1.webp'}
            width={700}
            height={150}
            alt={'Social Initiative'}
            className=" bgImage_1 w-10/12 rounded-l-2xl ml-auto mt-auto animate__animated animate__slideInLeft "
          />
          <Image
            unoptimized={true}
            src={'/about/social-initiative/2.webp'}
            width={700}
            height={150}
            alt={'Social Initiative'}
            className=" bgImage rounded-r-2xl m-auto  animate__animated animate__slideInRight "
          />
          <Image
            unoptimized={true}
            src={'/about/social-initiative/3.webp'}
            width={700}
            height={150}
            alt={'Social Initiative'}
            className=" bgImage rounded-l-2xl m-auto  animate__animated animate__slideInLeft"
          />
          <Image
            unoptimized={true}
            src={'/about/social-initiative/4.webp'}
            width={700}
            height={150}
            alt={'Social Initiative'}
            className="  rounded-r-2xl  bgImage_1 sm:order-4 order-3 mr-auto mb-auto animate__animated animate__slideInRight "
          />
        </div>

        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto  md:-mt-15 -mt-5 shadow-md bg-whiteCol">
          <h1 className="">Social Initiatives</h1>
          <h3 className="text-justify">
            &emsp;&emsp;At BBS Group of Institutions the culture of giving back
            originates from the deep desire of working for the betterment of the
            society. The thought to serve the society is a critical mission that
            is at the heart of everything that it does, how it meditates and
            what it is. Social initiatives of the institute aim to be relevant
            to local, national and global contexts. Key to this approach is the
            faculty members and students of the institute who generously give of
            their time, energy, experience and talent to serve society.
          </h3>

          <div className=" m-auto grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary">
            {gallery.map((game: any, index) => (
              <>
                <div key={index}>
                  <Image
                    unoptimized={true}
                    src={game.image}
                    width={400}
                    height={400}
                    alt={'Gallery Image'}
                    className=" socialImage  rounded-lg min-h-[200px] "
                  />
                </div>
              </>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default SocialInitiatives;
