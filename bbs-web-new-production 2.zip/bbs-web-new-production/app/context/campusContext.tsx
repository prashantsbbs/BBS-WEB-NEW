import React from 'react'

const CampusContext = React.createContext({})

export default CampusContext 