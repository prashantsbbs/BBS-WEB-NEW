import React, { useState } from "react";
import CampusContext from "./campusContext";


const CampusContextProvider = (children:any) =>{
    const [subComponent, setSubComponent] = useState(null)


    return(

        <CampusContext.Provider value={{subComponent, setSubComponent}}>
        {children}
        </CampusContext.Provider>


    )

}

export default CampusContextProvider