import responseFormatter from './response-formatter';
import http from './api-communicator';

const createContact = (payload: any = {}) => {
  const query = "?populate=*";
  return responseFormatter(
    http.post(`/contact-uses${query}`, payload)
  );
};

const createAdmissionEnquiry = (payload: any = {}) => {
  const query = "?populate=*";
  return responseFormatter(
    http.post(`/admission-enquiries${query}`, payload)
  );
};

const createAdmissionApply = (payload: any = {}) => {
  const query = "?populate=*";
  return responseFormatter(
    http.post(`/admission-applies${query}`, payload)
  );
};

// const getAdmissionApply = async (type: 'admin' | 'others',  page = 1,
//   pageSize = 100) => {
// const query = `?populate=*&sort=id:desc&pagination[page]=${page}&pagination[pageSize]=${pageSize}`;

//   const res = await responseFormatter(
//     http.get(`/admission-applies${query}`)
//   );

//   if (res?.data) {
//     let data = res.data;
//     console.log(data,"dataaaaa")

//     // 🔥 SOURCE FILTER
//     if (type === 'admin') {
//       data = data.filter(
//         (item: any) =>
//           item.attributes.source === 'meta' ||
//           item.attributes.source === 'google'
//       );
//     } else if (type === 'others') {
//       data = data.filter(
//         (item: any) => item.attributes.source === 'others'
//       );
//     }

//     // 🔥 LATEST FIRST (ID DESC)
//     data = data.sort((a: any, b: any) => b.id - a.id);

//     return data;
//   }

//   return [];
// };

const getAdmissionApply = async (
  type: 'admin' | 'others',
  page = 1,
  pageSize = 50
) => {
  let sourceFilter =
    type === 'admin'
      ? '&filters[source][$in][0]=meta&filters[source][$in][1]=google'
      : '&filters[source][$eq]=others';

  const res = await responseFormatter(
    http.get(
      `/admission-applies?populate=*&sort=id:desc&pagination[page]=${page}&pagination[pageSize]=${pageSize}${sourceFilter}`
    )
  );
 console.log(res?.data,"dataaaaa")
  return res?.data || [];
};

const createAdmissionApplyMeta = (payload: any = {}) => {
  const query = "?populate=*";
  return responseFormatter(
    http.post(`/admission-applies${query}`, payload)
  );
};
const createAdmissionApplyGoogle = (payload: any = {}) => {
  const query = "?populate=*";
  return responseFormatter(
    http.post(`/admission-applies${query}`, payload)
  );
};
const getCourseList = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/courses${query}`)
  );
};

const getCourseCategoryList = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/master-course-categories${query}`)
  );
};

const getBannerList = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/banners${query}`)
  );
};

const getPressReleaseList = () => {
  // const query = "?populate=*";
  const query = `?populate=*&pagination[page]=1&pagination[pageSize]=500`;

  return responseFormatter(
    http.get(`/press-releases${query}`)
  );
};


const getPressRelease = (id: any) => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/press-releases/${id}/${query}`)
  );
};

const getVideoGalleryList = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/video-galleries/${query}`)
  );
};

const getNewsList = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/new-lists/${query}`)
  );
};

const getNews = (id: any) => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/new-lists/${id}/${query}`)
  );
};

const getEventList = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/event-lists/${query}`)
  );
};

const getEvent = (id: any) => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/event-lists/${id}/${query}`)
  );
};

const getFlyerList = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/flyer-galleries/${query}`)
  );
};

const getHomePageData = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/home-page/${query}`)
  );
};

const getFacultyList = () => {
  const query = "?populate=*&pagination[limit]=-1";
  return responseFormatter(
    http.get(`/faculties/${query}`)
  );
};

const getTestimonialList = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/testimonials/${query}`)
  );
};

const getTestimonialCategoryList = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/testimonial-categories/${query}`)
  );
};

const getPictureGallery = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/picture-galleries/${query}`)
  );
};

const createAlumini = (payload: any = {}) => {
  const query = "?populate=*";
  return responseFormatter(
    http.post(`/alumini-lists${query}`, payload)
  );
};

const createAluminiJobProfile = (payload: any = {}) => {
  const query = "?populate=*";
  return responseFormatter(
    http.post(`/alumini-job-profiles${query}`, payload)
  );
};

const uploadImage = (formData: any = {}) => {
  const query = "?populate=*";
  return responseFormatter(
    http.post(`/upload${query}`, formData)
  );
};

const getBulletNewsList = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/bullet-news-lists/${query}`)
  );
};

const getNewsLetterList = (queryData = "") => {
  let query = "?populate=*";
  if (queryData) {
    query += queryData;
  }
  return responseFormatter(
    http.get(`/news-letters/${query}`)
  );
};
const getBlogsList = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/blog-lists${query}`)
  );
};
const getBlogsCategoryList = () => {
  const query = "?populate=*";
  return responseFormatter(
    http.get(`/blog-categories${query}`)
  );
};

const AppService: any = {
  createContact,
  createAdmissionEnquiry,
  createAdmissionApply,
  getAdmissionApply,
  createAdmissionApplyMeta,
  createAdmissionApplyGoogle,
  getCourseList,
  getBannerList,
  getPressReleaseList,
  getPressRelease,
  getVideoGalleryList,
  getCourseCategoryList,
  getNewsList,
  getNews,
  getEventList,
  getEvent,
  getFlyerList,
  getHomePageData,
  getFacultyList,
  getTestimonialList,
  getTestimonialCategoryList,
  getPictureGallery,
  createAlumini,
  createAluminiJobProfile,
  uploadImage,
  getBulletNewsList,
  getNewsLetterList,
  getBlogsList,
  getBlogsCategoryList
};

export default AppService;