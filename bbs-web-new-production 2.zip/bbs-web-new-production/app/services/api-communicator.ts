import axios from "axios";

const apiInstance = axios.create({
    baseURL: process.env.NEXT_PUBLIC_API_BASE_URL,
    timeout: 4 * 60000,
    headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
});

apiInstance.interceptors.request.use((config: any) => {
    if (config.setTimeout) {
        config.timeout = config.setTimeout
    }
    return config;
});

const http: any = {
    ...apiInstance
};

export default http;