import { error } from "console";

const responseFormatter = async (api: any) => {
    try {
        const { data: response, status } = await api;
        if (status === 202 && response.error) {
            throw response;
        }

        return {
            data: response && response.data,
            message: response.message,
            status,
            error: null
        }
    } catch(err: any) {
        if (!err.response) {
            return {
                data: null,
                status: null,
                error:
                    err.message &&
                    err.message.toLowerCase().indexOf("network error") === -1
                        ? err.message || err.error || "Something went wrong"
                        : [{ message: "" }]

            }
        }

        const { status = null, data: response = {}} = err.response || {}

        return {
            data: null,
            status,
            error: response.error || "Something went wrong"
        }
    }
};

export default responseFormatter;