'use client';
import { useEffect } from "react";
import { trackConversion } from "@/lib/gtag";

const ThankYou = () => {
     useEffect(() => {
    trackConversion({
      send_to: "AW-18076117043/93BJCOv5gZocELPQrqtD",
      value: 1,
      currency: "INR",
    });
  }, []);

  return (
    <>
      <div className="pt-28 pb-36 flex items-center justify-center w-[80%] m-auto text-center">
        <div>
        <h1>Thank You for Your Enquiry</h1>
        <h3>We have received your details.
</h3>
        <p>
         Our team will get in touch with you shortly to provide more information and answer your questions.
        </p>
         {/* <Link href={`/apply-online`} className="pt-16">
                    <ButtonCustom btnText="Submit Another Enquiry"/>
                  </Link> */}
      </div></div>
    </>
  );
};

export default ThankYou;
