'use client';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
// import {
//   blogsData1,blogsMarkdownData
// } from '@/app/constant/constant';
import {
  blogsMarkdownData
} from '@/app/constant/constant';
import { notFound } from 'next/navigation';
import { useParams } from 'next/navigation';
import Image from 'next/image';
import 'animate.css';
import Link from 'next/link';
import SeoWrapper from '@/app/common/SeoWrapper';
import Arrow from '@/app/common/arrow';
type MarkdownContentProps = {
  content: string;
};
const MarkdownContent = ({ content }: { content: string }) => {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      components={{
        
        img: ({ src, alt }) => (

    <img
      src={src || "" }
      alt={alt ?? "Blog image"}
      
      className="bgImage_blog"
      data-aos="fade-up" data-aos-duration="1500"
    />

),
         table: ({ children }) => (
      <div className="relative overflow-x-auto rounded-2xl border border-gray-dark bg-whiteCol shadow-xl mb-4" data-aos="fade-up" data-aos-duration="1500">
        <table className="w-full border-collapse text-sm">
          {children}
        </table>
      </div>
    ),

    thead: ({ children }) => (
      <thead className="bg-primary text-whiteCol">{children}</thead>
    ),
    
 tbody: ({ children }) => (
    <tbody className="[&>tr]:transition-all [&>tr]:duration-200 [&>tr:hover]:bg-gray">
      {children}
    </tbody>
  ),

  tr: ({ children }) => <tr>{children}</tr>,
    // tr: ({ children }) => (
    //   <tr className="group relative transition-all duration-200 hover:bg-gray">
    //     {children}
    //   </tr>
    // ),

    th: ({ children }) => (
      <th className="px-6 py-4 text-left font-semibold tracking-wide">
        {children}
      </th>
    ),

    td: ({ children }) => (
      <td className="relative px-6 py-5 font-semibold text-dark-blue">
        {children}
      </td>
    ),
         h1: ({ children }) => (
          <h1 
          style={{
          display: 'block',
          fontSize: '3rem',
          marginTop: '0.67rem',
          marginBottom: '0.67rem',
          marginLeft: '0',
          marginRight: '0',
          fontFamily: "'Asap Condensed', sans-serif",
          fontStyle: 'normal',
          fontWeight: 600,
          lineHeight: 1.2,
           }} data-aos="fade-up" data-aos-duration="1500">
            {children}
          </h1>
        ),
            h2: ({ children }) => (
          <h2 className=" md:text-3xl text-2xl text-dark-blue pt-6" data-aos="fade-up" data-aos-duration="1500">
            {children}
          </h2>
        ),
        h3: ({ children }) => (
          <h3 className="text-lg font-semibold" data-aos="fade-up" data-aos-duration="1500">
            {children}
          </h3>
        ),
        h4: ({ children }) => (
          <h4 className="text-base text-seaGreen font-semibold -mb-3 mt-4" data-aos="fade-up" data-aos-duration="1500">
            {children}
          </h4>
        ),

        ul: ({ children }) => (
  <ul className="space-y-1 mt-4 list-none p-0" data-aos="fade-up" data-aos-duration="1500">
    {children}
  </ul>
),

// li: ({ children }) => (
//   <li className="flex  gap-3 items-center">
//     <span className="shrink-0">
//       <Arrow />
//     </span>
//       <div className="text-gray-700  [&_*]:!text-sm ">
//       {children}
//     </div>
//   </li>
// ),
li: ({ children }) => (
  <li className="flex gap-3 items-center pb-1">
    <span className="shrink-0">
      <Arrow />
    </span>

    <div className="text-gray-700 text-base">
      {children}
    </div>
  </li>
),
 strong: ({ children }) => (
          <strong className="text-base font-medium">
            {children}
          </strong>
        ),
        p: ({ children }) => <h4 className="text-justify" data-aos="fade-up" data-aos-duration="1500">{children}</h4>,
        a: ({ href, children }) => {
          const isExternal = href?.startsWith('http');

          return (
            <Link
              href={href || '#'}
              target={isExternal ? '_blank' : undefined}
              rel={isExternal ? 'noopener noreferrer' : undefined}
              className="underline mx-1 text-link-blue"
            >
              {children}
            </Link>
          );
        },
      }}
    >
      {content}
    </ReactMarkdown>
  );
};

export default function BlogDetailPage() {
  const { id } = useParams();

  const blogData = blogsMarkdownData.find((blog) => blog.slug === id);
  console.log(blogData, 'blogsDataaaaaaaaaaaa');
  if (!blogData) {
    notFound();
  }

  return (
    <>
      <SeoWrapper
        title={blogData?.seoTitle}
        description={blogData?.seoDescription}
        keywords={blogData?.seoKeywords}
      >
        <section>
          <div className="bg-gray pb-6">
            <div
                    className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 shadow-md bg-whiteCol "
                  >
                    <div data-aos="fade-up" data-aos-duration="1500">
                      <h1 className="">{blogData.title}</h1>

                      <div className="text-justify">
                        <MarkdownContent content={blogData.description} />
                      </div>
                    </div>
                    <div className='pb-8'>
                        <MarkdownContent content={blogData.content} />
                    </div>
                   
                  </div>
                  
          </div>
          
        </section>
      </SeoWrapper>
    </>
  );
}


////////////////////////////////////////////////////////////////// BLOG DETAIL PAGE //////////////////////////////////////////////////////////

// 'use client';
// import ReactMarkdown from 'react-markdown';
// import remarkGfm from 'remark-gfm';
// import {
//   blogsData1,
// } from '@/app/constant/constant';
// import { notFound } from 'next/navigation';
// import { useParams } from 'next/navigation';
// import Image from 'next/image';
// import 'animate.css';
// import Link from 'next/link';
// import SeoWrapper from '@/app/common/SeoWrapper';
// import Arrow from '@/app/common/arrow';
// type MarkdownContentProps = {
//   content: string;
// };
// const MarkdownContent = ({ content }: { content: string }) => {
//   return (
//     <ReactMarkdown
//       remarkPlugins={[remarkGfm]}
//       components={{
//         p: ({ children }) => <h4 className="text-justify ">{children}</h4>,
//         a: ({ href, children }) => {
//           const isExternal = href?.startsWith('http');

//           return (
//             <Link
//               href={href || '#'}
//               target={isExternal ? '_blank' : undefined}
//               rel={isExternal ? 'noopener noreferrer' : undefined}
//               className="underline mx-1 text-link-blue"
//             >
//               {children}
//             </Link>
//           );
//         },
//       }}
//     >
//       {content}
//     </ReactMarkdown>
//   );
// };

// export default function BlogDetailPage() {
//   const { id } = useParams();

//   const blogData = blogsData1.find((blog) => blog.slug === id);
//   console.log(blogData, 'blogsData');
//   if (!blogData) {
//     notFound();
//   }

//   return (
//     <>
//       <SeoWrapper
//         title={blogData?.seo.title}
//         description={blogData?.seo.description}
//         keywords={blogData?.seo.keywords}
//       >
//         <section>
//           <div className="bg-gray pb-6">
//             {blogData?.sections.map((item: any) => (
//               <>
//                 {item.hero ? (
//                   <div
//                     className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 shadow-md bg-whiteCol "
//                     key={item.id}
//                   >
//                     <div data-aos="fade-up" data-aos-duration="1500">
//                       <h1 className="">{item.heading}</h1>

//                       <div className="text-justify">
//                         <MarkdownContent content={item.content} />
//                       </div>
//                     </div>
//                   </div>
//                 ):(
//                    <div
//                     className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol "
//                     key={item.id}
//                   >
//                     <div data-aos="fade-up" data-aos-duration="1500">
//                      {item.heading && <h2 className=" md:text-3xl text-2xl text-dark-blue mb-2 mt-2">
//                         {item.heading}
//                       </h2>}
//                       {item.image && (
//                         <div className="m-auto   animate__animated animate__slideInLeft">
//                           <img
//                             src={item.image}
//                             alt={item.image}
//                             className="bgImage_blog"
//                           />
//                         </div>
//                       )}

//                       {item.contentStart && (
//                         <h4 className={`text-justify -mb-6"}`}>
//                          <MarkdownContent content={item.contentStart} />
                       
//                         </h4>
//                       )}

//                       {item.content && (
//                         <h4 className="text-justify">
//                           <div className="text-justify">
//                             <MarkdownContent content={item.content} />
//                           </div>
//                           <br />
//                           <br />
//                         </h4>
//                       )}
//                       {item.contentSections && (
//                         <h4 className="text-justify">
//                           {item.contentSections.map((item: any) => (
//                             <div className="flex gap-6 my-2" key={item.id}>
//                               <Arrow />
//                               <h4 className="m-0 font-semibold">
//                                 {item.title}:{' '}
//                                 <span className="font-normal mx-2">
//                                   {item.description}
//                                 </span>
//                               </h4>
//                             </div>
//                           ))}
//                         </h4>
//                       )}
//                       {item.points  && (
//                       <h4 className="text-justify mb-10 mt-0">
//                         {item.points.map((point: any) => (
//                           <div className="flex gap-6" key={point.id}>
//                             <Arrow />
//                             <h3 className="m-0">{point.text}</h3>
//                             <br />
//                           </div>
//                         )
//                         )}
//                         </h4>
//                         )}

//                       {item.table &&  <div className="relative overflow-x-auto rounded-2xl border border-gray-dark bg-whiteCol shadow-xl mb-10">
//                         <table
//                           className={`w-full border-collapse text-sm ${
//                             item.table.headers.length > 2 ? '' : 'table-fixed'
//                           }`}
//                         >
//                           <thead>
//                             <tr className="bg-primary text-whiteCol">
//                               {item.table.headers.map(
//                                 (head: any, index: any) => (
//                                   <th
//                                     className="px-6 py-4 text-left font-semibold tracking-wide"
//                                     key={index}
//                                   >
//                                     {head}
//                                   </th>
//                                 )
//                               )}
//                             </tr>
//                           </thead>

//                           <tbody>
//                             {item.table.rows.map((row: any, index: any) => (
//                               <tr
//                                 key={index + 'row'}
//                                 className="group relative transition-all duration-200
//                                      hover:bg-gray"
//                               >
//                                 {row.cols.map((rowItem: any, index: any) => (
//                                   <>
//                                     {row.link && index == 0 ? (
//                                       <td
//                                         className="relative px-6 py-5 font-semibold text-dark-blue"
//                                         key={index + row.link}
//                                       >
//                                         <span className="absolute left-0 top-0 h-full w-[3px] bg-secondary opacity-0 group-hover:opacity-100 transition" />
//                                         <Link
//                                           href={row.link}
//                                           className="underline  mx-1 text-link-blue"
//                                         >
//                                           {rowItem}
//                                         </Link>
//                                       </td>
//                                     ) : (
//                                       <td
//                                         className="relative px-6 py-5 font-semibold text-dark-blue"
//                                         key={index + row.link}
//                                       >
//                                         {rowItem}
//                                       </td>
//                                     )}
//                                   </>
//                                 ))}
//                               </tr>
//                             ))}
//                           </tbody>
//                         </table>
//                       </div>}  
// {item.tableSteps &&
//                       item.tableSteps.map((step: any, index: number) => (
//                         <div
//                           className="p-4"
//                           data-aos="fade-up"
//                           data-aos-duration="1000"
//                           key={step.id}
//                         >
//                           <h3 className="text-lg font-semibold">
//                             {step.title}
//                           </h3>
//                           <p className="text-sm text-gray-700 mt-2 mb-2 line-clamp-3">
//                             {step.subTitle}
//                           </p>
//                         </div>
//                       ))}

//                        {item.steps && item.steps.map((innerItem: any, index: number) => (
//                         <div
//                           className=""
//                           data-aos="fade-up"
//                           data-aos-duration="1000"
//                           key={innerItem.id}
//                         >
//                           <h3 className="text-lg font-semibold">
//                             {item.showSerial && (
//                               <span className="mr-2">{innerItem.id} . </span>
//                             )}
//                             {innerItem.title}
//                           </h3>
//                           <div className="whitespace-pre-line text-gray-700 mt-2 mb-2  [&_*]:!text-sm">
//                             <MarkdownContent content={innerItem.subTitle} />
//                           </div>
//                           {innerItem.documentsHeading && (
//                             <h3 className="text-base text-seaGreen font-semibold">
//                               {item.showSerial && (
//                                 <span className="mr-2">{innerItem.id} . </span>
//                               )}
//                               {innerItem.documentsHeading}
//                             </h3>
                            
//                           )}
//                            {innerItem.table &&  <div className="relative overflow-x-auto rounded-2xl border border-gray-dark bg-whiteCol shadow-xl mb-10">
//                         <table
//                           className={`w-full border-collapse text-sm ${
//                             innerItem.table.headers.length > 2 ? '' : 'table-fixed'
//                           }`}
//                         >
//                           <thead>
//                             <tr className="bg-primary text-whiteCol">
//                               {innerItem.table.headers.map(
//                                 (head: any, index: any) => (
//                                   <th
//                                     className="px-6 py-4 text-left font-semibold tracking-wide"
//                                     key={index}
//                                   >
//                                     {head}
//                                   </th>
//                                 )
//                               )}
//                             </tr>
//                           </thead>

//                           <tbody>
//                             {innerItem.table.rows.map((row: any, index: any) => (
//                               <tr
//                                 key={index + 'row'}
//                                 className="group relative transition-all duration-200
//                                      hover:bg-gray"
//                               >
//                                 {row.cols.map((rowItem: any, index: any) => (
//                                   <>
//                                     {row.link && index == 0 ? (
//                                       <td
//                                         className="relative px-6 py-5 font-semibold text-dark-blue"
//                                         key={index + row.link}
//                                       >
//                                         <span className="absolute left-0 top-0 h-full w-[3px] bg-secondary opacity-0 group-hover:opacity-100 transition" />
//                                         <Link
//                                           href={row.link}
//                                           className="underline  mx-1 text-link-blue"
//                                         >
//                                           {rowItem}
//                                         </Link>
//                                       </td>
//                                     ) : (
//                                       <td
//                                         className="relative px-6 py-5 font-semibold text-dark-blue"
//                                         key={index + row.link}
//                                       >
//                                         {rowItem}
//                                       </td>
//                                     )}
//                                   </>
//                                 ))}
//                               </tr>
//                             ))}
//                           </tbody>
//                         </table>
//                       </div>} 
//                           {innerItem.documents && innerItem.documents.length > 0 &&
//                             innerItem.documents.map(
//                               (doc: string, index: number) => {
//                                 const hasColon = doc.includes(':');

//                                 if (hasColon) {
//                                   const [label, value] = doc.split(':');

//                                   return (
//                                     <div key={index} className="flex gap-6">
//                                       <Arrow />
//                                       <p className="text-sm text-gray-700 mt-2 mb-1 line-clamp-3">
//                                         <span className="font-semibold">
//                                           {label}:
//                                         </span>{' '}
//                                         {value.trim()}
//                                       </p>
//                                     </div>
//                                   );
//                                 }

//                                 return (
//                                   <div key={index} className="flex gap-6">
//                                     <Arrow />
//                                     <p className="text-sm text-gray-700 mt-2 mb-1 line-clamp-3">
//                                       {doc}
//                                     </p>
//                                   </div>
//                                 );
//                               }
//                             )}

//                           <div className="whitespace-pre-line text-gray-700 mt-3 mb-2  [&_*]:!text-sm">
//                             <MarkdownContent content={innerItem.subTitleLast} />
//                           </div>
//                          {/* {innerItem.subTitleLastHighlights &&  <div className="whitespace-pre-line text-gray-700 mt-3 mb-6  [&_*]:!text-sm font-medium">
//                             <MarkdownContent content={innerItem.subTitleLastHighlights} />
//                           </div>} */}
//                           {innerItem.subTitleLastHighlights && (
//   innerItem.subTitleLastHighlights.includes(":") ? (
//     (() => {
//       const [label, value] = innerItem.subTitleLastHighlights.split(":");
//       return (
//         <div className="whitespace-pre-line text-gray-700 mt-3 mb-6 [&_*]:!text-sm ">
//           <p>
//             <span className="font-semibold">{label}:</span> {value.trim()}
//           </p>
//         </div>
//       );
//     })()
//   ) : (
//     <div className="whitespace-pre-line text-gray-700 mt-3 mb-6 [&_*]:!text-sm font-medium">
//       <MarkdownContent content={innerItem.subTitleLastHighlights} />
//     </div>
//   )
// )}
//                         </div>
//                       ))}
                       
//                       {item.contentLast && (
//                         <h4 className="text-justify">
//                           <MarkdownContent content={item.contentLast} />
//                           <br />
//                         </h4>
//                       )}
//                       {item.faqs && item.faqs.map((item: any, index: number) => (
//                       <div
//                         className="p-4"
//                         data-aos="fade-up"
//                         data-aos-duration="1000"
//                         key={item.id}
//                       >
//                         <h3 className="text-lg font-semibold">
//                           <span className="mr-2">Q. </span> {item.question}
//                           <span className="ml-2">? </span>
//                         </h3>
//                         <p className="text-sm text-gray-700 mt-2 mb-2 line-clamp-3">
//                           {item.answer}
//                         </p>
//                       </div>
//                     ))}
//                     </div>
//                   </div>
//                 )}
//               </>
//             ))}
//           </div>
//         </section>
//       </SeoWrapper>
//     </>
//   );
// }
