'use client';
import Image from 'next/image';
import ButtonCustom from '../common/button';
// import { BlogsData, BlogsDataCategory,blogsMarkdownData } from '../constant/constant';
import { BlogsDataCategory,blogsMarkdownData } from '../constant/constant';
import { useState } from 'react';
import 'animate.css';
import Link from 'next/link';
import { stripMarkdown } from "../utils/stripMarkdown";

const Blogs = () => {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const categories = [
    'all',
    ...BlogsDataCategory.reduce((acc: any[], cur: any) => {
      if (!acc.includes(cur.category)) acc.push(cur.category);
      return acc;
    }, []),
  ];

  const filteredBlogs = blogsMarkdownData.filter((b: any) => {
    const userInput = search.trim().toLowerCase();

    if (userInput.length > 0 && userInput.length < 3) {
      return category === 'all' || b.category === category;
    }

    const text = `${b.title} ${b.subTitle}`.toLowerCase();
    const matchSearch = userInput.length >= 3 ? text.includes(userInput) : true;
    const matchCategory = category === 'all' || b.category === category;

    return matchSearch && matchCategory;
  });

  return (
    <div className="bg-whiteCol p-6">
      <div className="grid grid-cols-4 gap-6">
        <div className="hidden md:block col-span-1">
          <div className="sticky top-20 bg-white p-4 rounded-xl shadow h-fit space-y-6">
            <h1 className="col-span-full text-5xl text-primary font-bold mb-4">
              Blogs
            </h1>
            <div>
              <label className="text-sm font-semibold">Search</label>
              <input
                type="text"
                placeholder="Type minimum 3 letters..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full mt-1 p-2 border rounded-lg"
              />
            </div>
            <div>
              <label className="text-sm font-semibold">Category</label>
              <select
                className="w-full mt-1 p-2 border rounded-lg"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              >
                {categories.map((cat, i) => (
                  <option key={i} value={cat}>
                    {cat.charAt(0).toUpperCase() + cat.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
        <div className="col-span-4 md:col-span-3 grid grid-cols-1 md:grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredBlogs.length === 0 && (
            <div className="col-span-full bg-white p-6 rounded-xl shadow text-center">
              <h3 className="text-xl font-semibold text-gray-800">
                No Blogs Found
              </h3>
              <p className="text-gray-600 mt-2">
                No results match your search or selected category.
              </p>
            </div>
          )}
          {filteredBlogs.length > 0 &&
            [...filteredBlogs].reverse().map((item: any, index: number) => (
              <div
                key={index}
                className="bg-white rounded-xl shadow-md hover:shadow-lg transition"
                data-aos="fade-up"
                data-aos-duration="1000"
              >
                <Image
                  src={item.bannerImg}
                  width={1000}
                  height={600}
                  alt={item.bannerImg}
                  className="rounded-t-xl w-full h-72 object-contain md:h-60 md:object-cover"
                />

                <div
                  className="p-4"
                  data-aos="fade-up"
                  data-aos-duration="1000"
                >
                  <h3 className="text-lg font-semibold">{item.title}</h3>
                  <p className="text-sm text-gray-700 mt-2 mb-2 line-clamp-3">
                    {stripMarkdown(item?.description)}
                 
                  </p>
                  <Link href={`/blogs/${item.slug}`}>
                    <ButtonCustom />
                  </Link>
                </div>
              </div>
            ))}
        </div>
      </div>

      <div className="md:hidden mt-8 bg-white p-4 rounded-xl shadow space-y-4">
        <h2 className="text-xl font-semibold">Filters</h2>
        <div>
          <label className="text-sm font-semibold">Search</label>
          <input
            type="text"
            placeholder="Type minimum 3 letters..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full mt-1 p-2 border rounded-lg"
          />
        </div>

        <div>
          <label className="text-sm font-semibold">Category</label>
          <select
            className="w-full mt-1 p-2 border rounded-lg"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            {categories.map((cat, i) => (
              <option key={i} value={cat}>
                {cat.charAt(0).toUpperCase() + cat.slice(1)}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};

export default Blogs;


//////////////////////////////////// pre code 

// 'use client';
// import Image from 'next/image';
// import ButtonCustom from '../common/button';
// import { BlogsData, BlogsDataCategory } from '../constant/constant';
// import { useState } from 'react';
// import 'animate.css';
// import Link from 'next/link';

// const Blogs = () => {
//   const [search, setSearch] = useState('');
//   const [category, setCategory] = useState('all');
//   const categories = [
//     'all',
//     ...BlogsDataCategory.reduce((acc: any[], cur: any) => {
//       if (!acc.includes(cur.category)) acc.push(cur.category);
//       return acc;
//     }, []),
//   ];

//   const filteredBlogs = BlogsData.filter((b: any) => {
//     const userInput = search.trim().toLowerCase();

//     if (userInput.length > 0 && userInput.length < 3) {
//       return category === 'all' || b.category === category;
//     }

//     const text = `${b.title} ${b.subTitle}`.toLowerCase();
//     const matchSearch = userInput.length >= 3 ? text.includes(userInput) : true;
//     const matchCategory = category === 'all' || b.category === category;

//     return matchSearch && matchCategory;
//   });

//   return (
//     <div className="bg-whiteCol p-6">
//       <div className="grid grid-cols-4 gap-6">
//         <div className="hidden md:block col-span-1">
//           <div className="sticky top-20 bg-white p-4 rounded-xl shadow h-fit space-y-6">
//             <h1 className="col-span-full text-5xl text-primary font-bold mb-4">
//               Blogs
//             </h1>
//             <div>
//               <label className="text-sm font-semibold">Search</label>
//               <input
//                 type="text"
//                 placeholder="Type minimum 3 letters..."
//                 value={search}
//                 onChange={(e) => setSearch(e.target.value)}
//                 className="w-full mt-1 p-2 border rounded-lg"
//               />
//             </div>
//             <div>
//               <label className="text-sm font-semibold">Category</label>
//               <select
//                 className="w-full mt-1 p-2 border rounded-lg"
//                 value={category}
//                 onChange={(e) => setCategory(e.target.value)}
//               >
//                 {categories.map((cat, i) => (
//                   <option key={i} value={cat}>
//                     {cat.charAt(0).toUpperCase() + cat.slice(1)}
//                   </option>
//                 ))}
//               </select>
//             </div>
//           </div>
//         </div>
//         <div className="col-span-4 md:col-span-3 grid grid-cols-1 md:grid-cols-1 lg:grid-cols-2 gap-6">
//           {filteredBlogs.length === 0 && (
//             <div className="col-span-full bg-white p-6 rounded-xl shadow text-center">
//               <h3 className="text-xl font-semibold text-gray-800">
//                 No Blogs Found
//               </h3>
//               <p className="text-gray-600 mt-2">
//                 No results match your search or selected category.
//               </p>
//             </div>
//           )}
//           {filteredBlogs.length > 0 &&
//             [...filteredBlogs].reverse().map((item: any, index: number) => (
//               <div
//                 key={index}
//                 className="bg-white rounded-xl shadow-md hover:shadow-lg transition"
//                 data-aos="fade-up"
//                 data-aos-duration="1000"
//               >
//                 <Image
//                   src={item.image}
//                   width={1000}
//                   height={600}
//                   alt={item.alt}
//                   className="rounded-t-xl w-full h-72 object-contain md:h-60 md:object-cover"
//                 />

//                 <div
//                   className="p-4"
//                   data-aos="fade-up"
//                   data-aos-duration="1000"
//                 >
//                   <h3 className="text-lg font-semibold">{item.title}</h3>
//                   <p className="text-sm text-gray-700 mt-2 mb-2 line-clamp-3">
//                     {item.subTitle}
//                   </p>
//                   <Link href={item.link}>
//                     <ButtonCustom />
//                   </Link>
//                 </div>
//               </div>
//             ))}
//         </div>
//       </div>

//       <div className="md:hidden mt-8 bg-white p-4 rounded-xl shadow space-y-4">
//         <h2 className="text-xl font-semibold">Filters</h2>
//         <div>
//           <label className="text-sm font-semibold">Search</label>
//           <input
//             type="text"
//             placeholder="Type minimum 3 letters..."
//             value={search}
//             onChange={(e) => setSearch(e.target.value)}
//             className="w-full mt-1 p-2 border rounded-lg"
//           />
//         </div>

//         <div>
//           <label className="text-sm font-semibold">Category</label>
//           <select
//             className="w-full mt-1 p-2 border rounded-lg"
//             value={category}
//             onChange={(e) => setCategory(e.target.value)}
//           >
//             {categories.map((cat, i) => (
//               <option key={i} value={cat}>
//                 {cat.charAt(0).toUpperCase() + cat.slice(1)}
//               </option>
//             ))}
//           </select>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Blogs;
