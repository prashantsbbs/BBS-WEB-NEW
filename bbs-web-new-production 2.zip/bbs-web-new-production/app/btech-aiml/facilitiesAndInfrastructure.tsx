const AIMLFacilities =()=>{
    return (
        <div className="bg-secondary py-8">
            <div className="w-[80%] m-auto">
            <h2 className="font-semibold">Facilities & Infrastructure</h2>
            <h4>
            •	High-end computing labs with AI & ML tools like Python, TensorFlow, PyTorch, and R.
            </h4>
            <h4>
            •	Smart classrooms with interactive learning environments.
            </h4>
            <h4>
            •	AI research center for innovative projects and industry collaborations.
            </h4>
                

            

            </div>
        </div>
    )
};

export default AIMLFacilities