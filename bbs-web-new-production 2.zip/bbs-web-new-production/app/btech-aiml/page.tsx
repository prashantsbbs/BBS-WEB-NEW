'use client';
import Image from 'next/image';
import 'animate.css';
import Arrow from '../common/arrow';
import ScrollTrigger from 'react-scroll-trigger';
import { useEffect, useState } from 'react';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import MasterCourse from '../eligibility-criteria/masterCourse';
import SwiperComponent from '../home/congracts-section/swiper';
import CourseSlider from '../common/courseSlider';
import FutureReadyEng from '../common/futureReadyEng';
import AppService from '../services';
import AIMLFacilities from './facilitiesAndInfrastructure';
import Head from 'next/head';
import SeoWrapper from '../common/SeoWrapper';

const programHighlights = [
  {
    highlight: 'Core Subjects:',
    body: 'Data Structures & Algorithms, Operating Systems, Database Management Systems, Computer Networks.',
  },
  {
    highlight: 'AI & ML Specialization:',
    body: 'Machine Learning, Deep Learning, Natural Language Processing, Computer Vision, AI Ethics & Governance.',
  },
  {
    highlight: 'Advanced Technologies:',
    body: 'Big Data Analytics, Cloud Computing, Internet of Things (IoT), Robotics & Automation.',
  },
  {
    highlight: 'Capstone Projects:',
    body: 'Work on live AI projects, hackathons, and real-world problem-solving scenarios.',
  },
];

const careerProspectus = [
  'Machine Learning Engineer',
  'Data Scientist',
  'AI Research Scientist',
  'Robotics Engineer',
  'NLP Engineer',
  'Business Intelligence Developer',
];

const majorTrack = [
  {
    head: 'Industry-Relevant Curriculum:',
    body: 'Designed in collaboration with AI & ML experts and industry leaders.',
  },
  {
    head: 'State-of-the-Art Labs:',
    body: 'Access to high-performance computing resources, AI labs, and cloud-based platforms.',
  },
  {
    head: 'Expert Faculty:',
    body: 'Learn from experienced professors and industry professionals.',
  },
  {
    head: 'Practical Exposure:',
    body: 'Hands-on training through industry projects, internships, and research opportunities.',
  },
  {
    head: 'Placement Support:',
    body: 'Strong industry tie-ups ensuring excellent placement opportunities in top AI-driven companies.',
  },
];

const faculty = [
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
];

const defaultState = {
  isLoading: false,
  facultyList: [],
};

const departmentId = 6;
const BTecAIML = () => {
  const defaultAnimation = {
    courseOverview: false,
    highlights: false,
  };

  const [animationStart, setAnimationStart] = useState(defaultAnimation);
  const [state, setState] = useState(defaultState);
  const fetchFacultyList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getFacultyList();
    if (!error) {
      // Rehan Code for Category Filtering
      const facultyList = data.filter(
        (item: any) => item?.attributes?.department?.data?.id === departmentId
      );
      setState((prevState) => ({
        ...prevState,
        facultyList,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchFacultyList();
  }, []);

  return (
    <>
      <SeoWrapper
        title="Best Private B.Tech College in UP | BTech AIML"
        description="Explore BBS’s BTech AIML program, the best private B.Tech college in UP. Get top AI/ML education, modern labs & strong placements."
        keywords="best btech college in up"
      >
        {/* Hero Sectino */}
        <section>
          <div className="handleoverlflow w-[80%] m-auto grid md:grid-cols-2 grid-cols-1 justify-center items-center md:px-6 px-3 py-12">
            <div>
              <Image
                unoptimized={true}
                src={'/courses/bca-icon.webp'}
                width={90}
                height={20}
                alt="BCA Icon"
                className="animate__animated animate__fadeInLeftBig my-4 rotateAnimate"
              />
              <div>
                <h2 className="">UG Degree</h2>
                <div className="bg-secondary h-2 w-full"></div>
              </div>
              <h1 className="m-0">
                B.Tech CSE <br /> Artificial Intelligence & Machine Learning (AI
                & ML){' '}
              </h1>
              <h4 className="m-0">Affiliated to AKTU Lucknow </h4>
            </div>

            <div className="md:p-8 py-4">
              <Image
                unoptimized={true}
                src={'/courses/aiml.webp'}
                width={600}
                height={20}
                alt="B Tech AIML"
                className="animate__animated animate__fadeInRight rounded-lg"
              />
            </div>
          </div>
        </section>

        {/* Course Overveiw */}

        <section className="bg-gray handleoverlflow">
          <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-24 px-6">
            <div data-aos="fade-right" className={`p-6 `}>
              <div>
                <h2>COURSE OVERVIEW</h2>
                <h4 className="text-justify">
                  The B.Tech in Computer Science & Engineering (AI & ML) at BBS
                  College of Engineering & Technology is a cutting-edge program
                  designed to equip students with in-depth knowledge of
                  artificial intelligence, machine learning, and data science.
                  This program blends theoretical concepts with practical
                  applications, enabling students to develop intelligent systems
                  and innovative solutions for real-world challenges.
                </h4>
              </div>

              <div className="">
                <h2 className="uppercase">Why Choose This Program?</h2>
                <div className="">
                  {majorTrack.map((item, index) => (
                    <div key={index}>
                      <div className="flex gap-3">
                        <h3 className="m-0 font-semibold uppercase text-pink">
                          {item.head}
                        </h3>
                      </div>
                      <h4 className="m-2">{item.body}</h4>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className={`m-auto `} data-aos="fade-left">
              <div className="bg-secondary p-4 m-4 md:mr-12">
                <div className="p-4">
                  <h3 className="m-0">Duration</h3>
                  <h2 className="m-0">4 Years</h2>
                </div>
                <div className="p-4">
                  <h3 className="m-0">Programme Name</h3>
                  <h2 className="m-0">B.Tech CSE (AI & ML)</h2>
                </div>
              </div>
              <div className="bg-primary text-whiteCol p-4 m-4 md:ml-12">
                <div className="p-4">
                  <h2 className="m-0">Eligibility</h2>
                  <h5 className="text-justify mt-0">
                    Passed 10+2 examination with at least 50% marks in any
                    stream with maths as subject of study
                  </h5>
                </div>
                <div className="p-4">
                  <Link href={'apply-online'} target="blank">
                    <ButtonCustom
                      btnColor={'secondary'}
                      btnText={'Apply Online'}
                      textCol={'primary'}
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Program Highliths */}

        <section className="md:p-12 py-6 " data-aos="zoom-in-up">
          <div className="w-[80%] m-auto bg-primary p-6 text-whiteCol">
            <div>
              <h2 className="text-secondary">Curriculum Highlights</h2>
              <h4 className="text-white">
                The program covers core concepts of Computer Science along with
                specialized AI & ML subjects:
              </h4>
              <div
                className={`md:columns-2 columns-1 
                            ${
                              animationStart.highlights
                                ? 'animate__animated animate__fadeInRight animate__slower'
                                : ''
                            }`}
              >
                {programHighlights.map((list: any, index) => (
                  <>
                    <div key={index}>
                      <div className="flex gap-3">
                        <Arrow />
                        <h4 className="m-2 uppercase text-secondary">
                          {list.highlight}
                        </h4>
                      </div>
                      <h4 className="m-2">{list.body}</h4>
                    </div>
                  </>
                ))}
              </div>
            </div>
          </div>
        </section>

        <AIMLFacilities />

        {/* Future Ready */}
        <FutureReadyEng
          department={
            <>
              Department of <br />
              B.Tech CSE - Artificial Intelligence & Machine Learning (AI & ML)
            </>
          }
          image={'/futureReady/aiml.webp'}
          format="jpg"
        />

        {/* Advanced Options of Study */}
        <section data-aos="fade-up-right" className="md:p-12 py-6  bg-gray">
          <div className="w-[80%] m-auto bg-secondary rounded-xl p-6 text-whiteCol">
            <div>
              <h2 className="text-primary  text-center">Career Prospects</h2>
              <h4 className="text-center text-bg-black">
                Graduates of this program have vast career opportunities in
                various AI-driven sectors, including:
              </h4>
              <div className=" grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3   m-auto ">
                {careerProspectus.map((career: any, index) => (
                  <h3
                    key={index}
                    className="bg-whiteCol rounded-md drop-shadow-md px-6 py-2
                    text-primary m-0"
                  >
                    {career}
                  </h3>
                ))}
              </div>
            </div>
          </div>
        </section>
        {/* </ScrollTrigger> */}

        {/* Top Recruiters */}
        <div className="mt-12">
          <RecruitersComapnies />
        </div>

        {/* Eligibility  */}
        {/* <div className="md:p-12 p-8 ">
        <Eligibility EligibilityTable={EligibilityTable} />
      </div> */}

        {/* Faculty  */}
        {!!state.facultyList.length && (
          <div className="  bg-primary flex">
            <div className="lg:w-[85%] w-[90%] m-auto md:p-16 p-4  ">
              <h2 className="m-auto text-secondary text-center p-4">
                Our Faculty
              </h2>
              <CourseSlider elements={state.facultyList} />
            </div>
          </div>
        )}
      </SeoWrapper>
    </>
  );
};
export default BTecAIML;
