'use client';

import Image from 'next/image';
import Arrow from '../common/arrow';
import { useState } from 'react';
import GraducateCourse from './graducateCourse';
import MasterCourse from './masterCourse';
import 'animate.css';
import DiplomaCourses from './diplomaCourse';

const EligibilityCriteria = () => {
  const defaultState = {
    accordian: false,
    activeAccordian: 0,
  };

  const renderPanel = (step: number) => {
    let panel = <></>;
    switch (step) {
      case 1:
        panel = <GraducateCourse />;
        break;
      case 2:
        panel = <MasterCourse />;
        break;
      case 3:
        panel = <DiplomaCourses />;
        break;
    }
    return panel;
  };

  const courses = [
    { name: 'Graduate Course' },
    { name: 'Master Course' },
    { name: 'Diploma Course' },
  ];

  const [state, setSate] = useState(defaultState);

  const handleAccordian = (active: number) => {
    console.log(active);
    setSate((prev: any) => ({ ...prev, activeAccordian: active }));

    if (active === 0) {
      setSate((prev: any) => ({ ...prev, accordian: true }));
    } else {
      setSate((prev: any) => ({ ...prev, accordian: false }));
    }
  };

  return (
    <>
      <div className="md:w-[80vw] w-[100vw] p-5  pt-10 relative z-10 rounded-xl m-auto md:-mt-15 -mt-5  my-8">
        <div>
          <h2 className="text-3xl text-center">
            Eligibility Criteria (Session 2026-2027)
          </h2>
        </div>

        <div className="  m-auto  py-2 mb-2  items-center">
          {courses.map((course: any, index) => (
            <div key={index} className="">
              <div className="flex bg-primary justify-between m-2 p-2">
                <h4 className="m-0 text-whiteCol">{course.name}</h4>
                <div className=" cursor-pointer bg-primary p-2  ">
                  {state.activeAccordian !== index + 1 ? (
                    <Image
                      unoptimized={true}
                      className="z-40 relative min-w-5 m-auto	"
                      onClick={() => handleAccordian(index + 1)}
                      src={'/svg/plusIcon.svg'}
                      width={15}
                      height={15}
                      alt="Plus Icon"
                    />
                  ) : (
                    <Image
                      unoptimized={true}
                      className="z-40 relative min-w-5 m-auto  	"
                      onClick={() => handleAccordian(0)}
                      src={'/svg/crossIcon.svg'}
                      width={15}
                      height={15}
                      alt="Cross Icon"
                    />
                  )}
                </div>
              </div>
              {state.activeAccordian === index + 1 && (
                <div className="w-full animate__animated animate__slideInUp">
                  {renderPanel(state.activeAccordian)}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default EligibilityCriteria;
