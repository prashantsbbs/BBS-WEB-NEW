'use client';

import Image from 'next/image';

const GraducateCourse = () => {
  const webTable = [
    {
      name: 'B. Tech.',
      duration: '4 yrs.',
      specialization:
        'Computer Science & Engineering, AI & ML, I.T., Electronics and Communication Engineering, Civil Engineering, Mechanical Engineering, Electrical and Electronics Engineering',
      eligibility:
        'Passed 10+2 examination with Physics and Mathematics as compulsory subjects along with Chemistry / Computer Science. With at least 50% marks in the above subjects, taken together and 50% marks overall',
      relaxation:
        'Five percent relaxation in the minimum eligibility is provided to SC/ST Category Students',
    },
    {
      name: 'B. Tech.(Lateral Entry).',
      duration: '3 yrs.',
      specialization:
        'Computer Science & Engineering, AI & ML, I.T., Electronics and Communication Engineering, Civil Engineering, Mechanical Engineering, Electrical and Electronics Engineering',
      eligibility:
        'With at least 50% in 3 years Diploma recognized by Board of Technical Education / University or B Sc (PCM) ',
      relaxation:
        'Five percent relaxation in the minimum eligibility is provided to SC/ST Category Students',
    },

    {
      name: 'B.Pharm',
      duration: '4 Yrs.',
      specialization: '',
      eligibility:
        'Passed 10+2 examination with Physics and Mathematics/ Biology as compulsory subjects along with Chemistry / Computer Science. With at least 50% marks in the above subjects, taken together and 50% marks overall',
      relaxation:
        'Five percent relaxation in the minimum eligibility is provided to SC/ST Category Students',
    },
    {
      name: 'BCA',
      duration: '3 Yrs.',
      specialization: '',
      eligibility:
        'Passed 10+2 examination with at least 50% marks in any stream with maths as subject of study',
      relaxation:
        'Five percent relaxation in the minimum eligibility is provided to SC/ST Category Students',
    },
    {
      name: 'BBA',
      duration: '3 Yrs.',
      specialization: '',
      eligibility:
        'Passed 10+2 examination with at least 50% marks in any stream',
      relaxation:
        'Five percent relaxation in the minimum eligibility is provided to SC/ST Category Students',
    },
    {
      name: 'BA. LL.B.',
      duration: '5 Yrs.',
      specialization: '',
      eligibility:
        'Passed 10+2 examination with at least 50% marks in any stream',
      relaxation:
        'Five percent relaxation in the minimum eligibility is provided to SC/ST Category Students',
    },
    {
      name: 'LL.B.',
      duration: '3 Yrs.',
      specialization: '',
      eligibility: 'Passed 10+2 examination',
      relaxation:
        'Five percent relaxation in the minimum eligibility is provided to SC/ST Category Students',
    },
  ];

  return (
    <>
      {/* Admission Procedure */}
      <div className=" md:p-2 p-0   ">
        <div className=" w-[100%] m-auto">
          <div className="overflow-x-auto ">
            <table className="table-auto   rounded-xl ">
              <thead>
                <tr className="bg-primary text-whiteCol p-4">
                  <th className="p-4">Name of Course</th>
                  <th className="p-4">Duration</th>
                  <th className="p-4">Branch/ specialization</th>
                  <th className="p-4">Eligibility</th>
                  <th className="p-4">Relaxation</th>
                </tr>
              </thead>
              <tbody>
                {webTable.map((data: any, index: any) => (
                  <tr
                    key={index}
                    className="p-2 border border-gray-dark odd:bg-gray"
                  >
                    <td className="p-2 border-2 border-gray-dark">
                      {data.name}
                    </td>
                    <td className="p-2 border-2 border-gray-dark">
                      {data.duration}
                    </td>
                    <td className="p-2 border-2 border-gray-dark">
                      {data.specialization}
                    </td>
                    <td className="p-2 border-2 border-gray-dark">
                      {data.eligibility}
                    </td>
                    <td className="p-2 border-2 border-gray-dark">
                      {data.relaxation}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
};

export default GraducateCourse;
