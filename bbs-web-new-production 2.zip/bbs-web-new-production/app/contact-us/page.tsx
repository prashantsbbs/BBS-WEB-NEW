'use client';
import Head from 'next/head';
import { NextResponse } from 'next/server';
import React, { useState } from 'react';
import { text } from 'stream/consumers';
import ButtonCustom from '../common/button';
import { SubmitHandler, useForm } from 'react-hook-form';
import { ERROR_MESSAGES, REGEX } from '../constant/constant';
import Modal from '../apply-online/modal';
import Image from 'next/image';
import AppService from '../services';

type Inputs = {
  name: string;
  email: string;
  subject: string;
  message: string;
  exampleRequired: string;
};

const contactNumbers = [
  '1800-1200-407',
  '7607000961',
  '7607000962',
  '7607000963',
];

const Contact = () => {
  const [alertMessage, setAlertMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm<Inputs>();

  const sendEmail = async (data: any) => {
    const response = await fetch('/api/email', {
      method: 'POST',
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json',
      },
    });
    const res = await response.json();
    console.log(res);
  };

  const onSubmit: SubmitHandler<Inputs> = async (formData: any) => {
    setIsLoading(true);
    const payload = {
      data: {
        name: formData.name,
        email: formData.email,
        message: formData.message,
        subject: formData.subject,
      },
    };

    const { data, error } = await AppService.createContact(payload);

    if (error) {
      setAlertMessage(error?.message);
    } else {
      setAlertMessage('Submitted Successfully.');
      sendEmail({
        from: process.env.NEXT_PUBLIC_ADMIN_EMAIL,
        to: formData.email,
        dynamicTemplateData: payload.data,
        templateId: process.env.NEXT_PUBLIC_CONTACT_US_USER_TEMPLATE,
      });
      reset();
    }
    setIsLoading(false);
  };

  return (
    <>
      <div className="grid md:grid-cols-2 grid-cols-1 gap-2 place-items-center  bg-white ">
        <div className="bg-white flex flex  md:h-screen h-auto py-5">
          <form
            onSubmit={handleSubmit(onSubmit)}
            className="box-border mt-14 h-[35rem] sm:w-[29rem] w-11/12 rounded-lg px-10 pt-14 text-xl  tracking-wide shadow-2xl text-black bg-secondary mx-auto"
          >
            <h1 className="text-3xl">Get in touch </h1>
            <input
              {...register('name', { required: true })}
              type="text"
              className={`text-lg mb-4 bg-gray-50  border-gray-300  rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5   dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                errors.name ? 'border-red-500' : ''
              }`}
              placeholder="Name *"
            />
            {errors.name && (
              <div className="text-left text-sm text-danger">
                {ERROR_MESSAGES[errors.name.type] || errors.name.message}
              </div>
            )}
            <input
              {...register('email', {
                required: true,
                pattern: {
                  value: REGEX.EMAIL,
                  message: 'Email is not valid',
                },
              })}
              className={`text-lg mb-4 bg-gray-50  border-gray-300  rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5   dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                errors.name ? 'border-red-500' : ''
              }`}
              placeholder="Email *"
            />
            {errors.name && (
              <div className="text-left text-sm text-danger">
                {ERROR_MESSAGES[errors.name.type] || errors.name.message}
              </div>
            )}
            <input
              {...register('subject', { required: true })}
              type="text"
              className={`text-lg mb-4 bg-gray-50  border-gray-300  rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5   dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                errors.name ? 'border-red-500' : ''
              }`}
              placeholder="Subject *"
            />
            {errors.name && (
              <div className="text-left text-sm text-danger">
                {ERROR_MESSAGES[errors.name.type] || errors.name.message}
              </div>
            )}
            <textarea
              {...register('message', { required: true, maxLength: 46 })}
              className={`text-lg mb-4 bg-gray-50  border-gray-300  rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5   dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                errors.name ? 'border-red-500' : ''
              }`}
              cols={30}
              placeholder="Message"
              rows={4}
            />
            <button
              disabled={isLoading}
              type="submit"
              className={` sign-btn bg-primary text-whiteCol border 	py-2  cursor-pointer hover:bg-blue-600  w-full rounded-3xl`}
            >
              Submit
            </button>
          </form>
        </div>

        <div className=" flex bg-primary w-full md:h-screen h-auto py-5">
          <div className="m-auto ">
            <div className="box-border h-[35rem] sm:w-[29rem] w-11/12 rounded-lg px-10 pt-14 text-xl  tracking-wide shadow-2xl text-black bg-whiteCol mx-auto">
              <span className="pl-11 text-2xl tracking-tight font-semibold text-start text-gray-800 custom-family">
                Corporate Details
              </span>

              <div className="flex items-center mt-9 custom-family">
                <Image
                  unoptimized={true}
                  src="svg/message.svg"
                  alt="Message"
                  className="mr-5 h-5"
                  height={200}
                  width={25}
                />
                <span>
                  <a href="mailto:sabbas.85@gmail.com">
                    <b>Mail us at:</b>mail@bbs.ac.in
                  </a>
                </span>
              </div>

              <div className="flex items-center mt-5 custom-family">
                <Image
                  unoptimized={true}
                  src="svg/phone.svg"
                  alt="Phone"
                  className="mr-6  h-6"
                  height={200}
                  width={25}
                />
                <p className="font-bold">Contacts:</p>
              </div>
              <div className="flex items-center ml-[48px] custom-family">
                <ul className="list-disc list-inside">
                  {contactNumbers.map((number) => (
                    <li key={number}>
                      <a href={`tel:${number}`}>{number}</a>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex  mt-5 items-start pb-4 sm: sm:  custom-family">
                <Image
                  unoptimized={true}
                  src="svg/location.svg"
                  alt="Location"
                  className="mr-7  h-6"
                  height={200}
                  width={25}
                />
                <span className="text-justify">
                  <b>Our location:</b>
                  <p>BBS GROUP OF INSTITUTIONS. Phaphamau, Prayagraj-211013</p>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="  width-full md:block">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3600.3719861303816!2d81.84527657466654!3d25.525983218306568!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x398534756bf3572d%3A0x74542bb85458b295!2sBBS%20College%20of%20Engineering%20%26%20Technology!5e0!3m2!1sen!2sin!4v1711713771497!5m2!1sen!2sin"
          width="100%"
          height="500px"
          loading="lazy"
          referrerPolicy=""
          title="BBS College of Engineering"
        ></iframe>
      </div>
      <Modal
        message={alertMessage}
        isOpen={!!alertMessage}
        onClose={() => setAlertMessage('')}
      />
    </>
  );
};

export default Contact;
