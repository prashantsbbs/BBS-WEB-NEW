"use client";
import React, { useEffect, useState } from "react";
import Cards from "./cards/index";
import GridView from "./grid-view/index.jsx";
import SwiperComponent from "./slider/index.jsx";
import Image from "next/image";
import BreadcrumbSports from "../common/breadcrumbSports";
import Breadcrumb from "../common/breadcurb";
import BreadcrumbGallery from "../common/galleryBreadcrumb";
import AppService from "../services";

const apiData = [
  {
    title: "Academic Excellence Award-2023-24",
    images: [
      "/gallery/2024/AcademicExcellenceAward/IMG-20240111-WA0017.webp",
      "/gallery/2024/AcademicExcellenceAward/IMG-20240111-WA0028.webp",
      "/gallery/2024/AcademicExcellenceAward/IMG-20240111-WA0034.webp",
      "/gallery/2024/AcademicExcellenceAward/IMG-20240111-WA0029.webp",
      "/gallery/2024/AcademicExcellenceAward/IMG-20240111-WA0019.webp",
      "/gallery/2024/AcademicExcellenceAward/IMG-20240111-WA0021.webp",
      "/gallery/2024/AcademicExcellenceAward/IMG-20240111-WA0015.webp",
      "/gallery/2024/AcademicExcellenceAward/IMG-20240111-WA0008.webp",
      "/gallery/2024/AcademicExcellenceAward/IMG-20240111-WA0029.webp",
    ],
  },
  {
    title: "ACTU Zonal Sports",
    images: [
      "/gallery/2024/AKTUZonalSports/IMG-20231104-WA0014.webp",
      "/gallery/2024/AKTUZonalSports/IMG-20231104-WA0018.webp",
      "/gallery/2024/AKTUZonalSports/IMG-20231106-WA0004.webp",
    ],
  },
  {
    title: "Community Health Center - Holagarh Visit",
    images: [
      "/gallery/2024/HolagarhVisit/IMG-20231212-WA0011.webp",
      "/gallery/2024/HolagarhVisit/IMG-20231212-WA0040.webp",
      "/gallery/2024/HolagarhVisit/IMG-20231212-WA0041.webp",
      "/gallery/2024/HolagarhVisit/IMG-20231212-WA0051.webp",
      "/gallery/2024/HolagarhVisit/IMG-20231212-WA0053.webp",
      "/gallery/2024/HolagarhVisit/IMG-20231212-WA0054.webp",
      "/gallery/2024/HolagarhVisit/IMG-20231212-WA0056.webp",
    ],
  },
  {
    title: "CPRT Training at BBS",
    images: [
      "/gallery/2024/CPRTraining/IMG-20240316-WA0024.webp",
      "/gallery/2024/CPRTraining/IMG-20240316-WA0035.webp",
      "/gallery/2024/CPRTraining/IMG-20240316-WA0045.webp",
      "/gallery/2024/CPRTraining/IMG-20240316-WA0145.webp",
      "/gallery/2024/CPRTraining/IMG-20240316-WA0188.webp",
    ],
  },
  {
    title: "HDFC Cluster Branch Visit",
    images: [
      "/gallery/2024/HDFCCluster/IMG-20231213-WA0022.webp",
      "/gallery/2024/HDFCCluster/IMG-20231213-WA0038.webp",
      "/gallery/2024/HDFCCluster/IMG-20231213-WA0040.webp",
      "/gallery/2024/HDFCCluster/IMG-20231213-WA0041.webp",
      "/gallery/2024/HDFCCluster/IMG-20231213-WA0043.webp",
      "/gallery/2024/HDFCCluster/IMG-20231213-WA0044.webp",
      "/gallery/2024/HDFCCluster/IMG-20231213-WA0046.webp",
    ],
  },
  {
    title: "ISRO Scientist Guest Lecture",
    images: [
      "/gallery/2024/ISROScientist/IMG-20231125-WA0031.webp",
      "/gallery/2024/ISROScientist/IMG-20231125-WA0036.webp",
      "/gallery/2024/ISROScientist/IMG-20231125-WA0043.webp",
      "/gallery/2024/ISROScientist/IMG-20231125-WA0057.webp",
      "/gallery/2024/ISROScientist/IMG-20231125-WA0059.webp",
    ],
  },
  {
    title: "National Pharmacy Education Day 2024",
    images: [
      "/gallery/2024/NationalPharmacy/IMG-20240306-WA0056.webp",
      "/gallery/2024/NationalPharmacy/IMG-20240306-WA0058.webp",
      "/gallery/2024/NationalPharmacy/IMG-20240306-WA0061.webp",
      "/gallery/2024/NationalPharmacy/IMG-20240306-WA0066.webp",
      "/gallery/2024/NationalPharmacy/IMG-20240306-WA0067.webp",
      "/gallery/2024/NationalPharmacy/IMG-20240306-WA0071.webp",
      "/gallery/2024/NationalPharmacy/IMG-20240306-WA0106.webp",
    ],
  },
  {
    title: " Republic Day 2024",
    images: [
      "/gallery/2024/RepublicDay/DSC_0029.webp",
      "/gallery/2024/RepublicDay/DSC_0040.webp",
      "/gallery/2024/RepublicDay/DSC_0045.webp",
      "/gallery/2024/RepublicDay/DSC_0055.webp",
      "/gallery/2024/RepublicDay/DSC_0058.webp",
      "/gallery/2024/RepublicDay/DSC_0065.webp",
      "/gallery/2024/RepublicDay/DSC_0068.webp",
      "/gallery/2024/RepublicDay/DSC_0098.webp",
      "/gallery/2024/RepublicDay/IMG-20240126-WA0056.webp",
      "/gallery/2024/RepublicDay/IMG-20240126-WA0060.webp",
      "/gallery/2024/RepublicDay/IMG-20240126-WA0061.webp",
      "/gallery/2024/RepublicDay/IMG-20240126-WA0073.webp",
      "/gallery/2024/RepublicDay/IMG-20240126-WA0074.webp",
      "/gallery/2024/RepublicDay/IMG-20240126-WA0091.webp",
    ],
  },
  {
    title: "Swachhata Abhiyan 2024",
    images: [
      "/gallery/2024/Swachhata/IMG-20231002-WA0008.webp",
      "/gallery/2024/Swachhata/IMG-20231002-WA0009.webp",
      "/gallery/2024/Swachhata/IMG-20231002-WA0010.webp",
      "/gallery/2024/Swachhata/IMG-20231002-WA0019.webp",
      "/gallery/2024/Swachhata/IMG-20231002-WA0020.webp",
      "/gallery/2024/Swachhata/IMG-20231002-WA0030.webp",
    ],
  },
  {
    title: "Technical Conference at IIIT Prayagraj",
    images: [
      "/gallery/2024/TechnicalConferce/IMG-20231027-WA0001.webp",
      "/gallery/2024/TechnicalConferce/IMG-20231027-WA0003.webp",
      "/gallery/2024/TechnicalConferce/IMG-20231027-WA0004.webp",
      "/gallery/2024/TechnicalConferce/IMG-20231027-WA0005.webp",
    ],
  },
  {
    title: " Triveni Hospital Magh Mela Visit",
    images: [
      "/gallery/2024/TriveniHospital/IMG-20240223-WA0019.webp",
      "/gallery/2024/TriveniHospital/IMG-20240223-WA0061.webp",
      "/gallery/2024/TriveniHospital/IMG-20240223-WA0067.webp",
      "/gallery/2024/TriveniHospital/IMG-20240223-WA0069.webp",
      "/gallery/2024/TriveniHospital/IMG-20240223-WA0075.webp",
      "/gallery/2024/TriveniHospital/IMG-20240223-WA0077.webp",
      "/gallery/2024/TriveniHospital/IMG-20240223-WA0081.webp",
      "/gallery/2024/TriveniHospital/IMG-20240223-WA0109.webp",
    ],
  },
  {
    title: "International Women's Day 2024",
    images: [
      "/gallery/2024/womens-day/1.webp",
      "/gallery/2024/womens-day/2.webp",
      "/gallery/2024/womens-day/3.webp",
      "/gallery/2024/womens-day/4.webp",
      "/gallery/2024/womens-day/5.webp",
      "/gallery/2024/womens-day/6.webp",
      "/gallery/2024/womens-day/7.webp",
      "/gallery/2024/womens-day/8.webp",
      "/gallery/2024/womens-day/9.webp",
      "/gallery/2024/womens-day/10.webp",
      "/gallery/2024/womens-day/11.webp",
      "/gallery/2024/womens-day/12.webp",
      "/gallery/2024/womens-day/13.webp",
      "/gallery/2024/womens-day/14.webp",
      "/gallery/2024/womens-day/15.webp",
      "/gallery/2024/womens-day/16.webp",
      "/gallery/2024/womens-day/17.webp",
      "/gallery/2024/womens-day/18.webp",
      "/gallery/2024/womens-day/19.webp",
      "/gallery/2024/womens-day/20.webp",
    ],
  },
];

const defaultState = {
  activeId: 2,
  isButtonOpen: false,
  imageActiveId: null,
  overlayType: "ideal",
  overlayId: null,
  viewType: null,
  cardActiveId: null,
  pictureGallery: [],
  isLoading: false,
};
const PhotoGallery = () => {
  const [state, setState] = useState(defaultState);

  const viewTypeHandler = (
    viewType: any,
    imageActiveId: number,
    cardActiveId: number
  ) => {
    setState((prevState: any) => ({
      ...prevState,
      viewType: viewType,
      imageActiveId: imageActiveId,
      cardActiveId: cardActiveId,
    }));
  };

  const fetchPictureGallery = async () => {
    setState(prevState => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getPictureGallery();
    if (!error) {
      const pictureGallery = data.map((item: any) => {
        return {
          title: item?.attributes?.title,
          images: item?.attributes?.pictures?.data.map((item: any) => {
            return item?.attributes?.url
          })
        }
      })
      setState(prevState => ({ ...prevState, pictureGallery }));
    }
    setState(prevState => ({ ...prevState, isLoading: false }));
  };


  useEffect(() => {
    fetchPictureGallery();
  }, []);

  return (
    <div>
      <h1 className="sr-only">Photo Gallery</h1>
      <BreadcrumbGallery componentName={"Gallery"} />
      <div className="pt-12 pb-12 bg-gray-dark ">
        <div className="">
          <Cards
            apiData={state.pictureGallery}
            state={state}
            setState={setState}
            viewTypeHandler={viewTypeHandler}
          />
        </div>
        {(state.viewType === "grid" || state.viewType === "grid-back") && (
          <div className="fixed top-0  h-full w-full z-50 bg-black bg-main-gal">
            <img
              width={800}
              height={50}
              loading="lazy"
              src="/cross.webp"
              alt="BBS Image"
              className="w-9 shadow-2xl cursor-pointer m-3 bg-whiteCol rounded-full float-right relative z-50"
              onClick={() => viewTypeHandler("close-grid", 0, 0)}
            />
            <div
              className="absolute h-[90vh] w-[90vw] shadow-md rounded-xl overflow-x-auto bg-scrollbar bg-primary"
              style={{
                left: "50%",
                top: "50%",
                transform: "translate(-50%, -50%)",
                boxShadow: "0 0 7px rgba(0 0 0 / 32%)",
              }}
            >
              <GridView
                apiData={state.pictureGallery}
                state={state}
                viewTypeHandler={viewTypeHandler}
              />
            </div>
          </div>
        )}

        {(state.viewType === "carousel" ||
          state.viewType === "carousel-for-grid") && (
          <SwiperComponent
            state={state}
            apiData={state.pictureGallery}
            viewTypeHandler={viewTypeHandler}
          />
        )}
      </div>
    </div>
  );
};

export default PhotoGallery;
