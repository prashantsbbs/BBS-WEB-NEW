import { Swiper, SwiperSlide } from "swiper/react";
import Image from "next/image";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import { Pagination, Navigation } from "swiper/modules";

const SwiperComponent = ({ state, apiData, viewTypeHandler }) => {
  const getCaraouselImages = (index) => {
    const images = apiData[state.imageActiveId].images.filter(
      (_, ind) => ind !== index
    );
    return [apiData[state.imageActiveId].images[state.cardActiveId], ...images];
  };
  return (
    <div className="w-[90%] slider-box">
      <img
        width={300}
        height={50}
        loading="lazy"
        src="/cross.webp"
        alt="bbs"
        className="w-9 shadow-2xl cursor-pointer m-3 fixed top-0 right-0 z-50  rounded-full bg-whiteCol"
        onClick={() =>
          viewTypeHandler(
            state.viewType === "carousel" ? "close-carousel" : "grid-back",
            state.imageActiveId,
            state.cardActiveId
          )
        }
      />
      <Swiper
        slidesPerView={1}
        loop={true}
        navigation={true}
        modules={[Pagination, Navigation]}
        className="mySwiper"
        spaceBetween={0}
      >
        {getCaraouselImages(state.cardActiveId).map((item, index) => (
          <SwiperSlide key={index}>
            <img
              width={800}
              height={50}
              loading="lazy"
              src={item}
              alt="Magician Image"
              className="swiper-image  relative rounded-md animate__animated  animate__fadeIn gall-slide-img"
            />
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
};

export default SwiperComponent;
