import Image from 'next/image';

const GridView = ({ apiData, state, viewTypeHandler }) => {
  let filteredData = apiData.filter((_, id) => state.imageActiveId === id);
  filteredData = filteredData[0].images;

  return (
    <div className="md:p-14 p-6  grid grid-cols-3 lg:gap-10 gap-1 justify-center items-center  mx-auto my-auto image-grid-container">
      {/* images card */}
      {filteredData.map((src, imageId) => (
        <div
          key={imageId}
          className={`h-5/6 flex justify-center items-center relative img-card`}
          style={{
            boxShadow: '0 0 7px rgba(0 0 0 / 32%)',
          }}
        >
          <img
            width={500}
            height={50}
            loading="lazy"
            src={src}
            alt={filteredData[0].title || 'Photo Image'}
            className=" w-full h-full object-cover rounded-md card-shadow animate__animated  animate__zoomIn cursor-pointer"
            onClick={() =>
              viewTypeHandler('carousel-for-grid', state.overlayId, imageId)
            }
          />
        </div>
      ))}
    </div>
  );
};

export default GridView;
