import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/effect-cards';
import { EffectCards } from 'swiper/modules';
import Image from 'next/image';

const Cards = ({ apiData, state, setState, viewTypeHandler }) => {
  return (
    <>
      <div className="lg:max-w-[90%] grid grid-cols-3 lg:gap-14 gap-10 justify-center items-center image-grid-container mx-auto my-auto">
        {apiData.map((data, overlayId) => (
          <Swiper
            key={overlayId}
            effect={'cards'}
            grabCursor={true}
            modules={[EffectCards]}
            className="mySwiper lg:mb-0 mb-10"
          >
            {data.images.map((src, imageId) => (
              <SwiperSlide className="lg:mb-0" key={imageId}>
                <div
                  onMouseLeave={() =>
                    setState((prevState) => ({
                      ...prevState,
                      overlayType: 'ideal',
                      overlayId,
                    }))
                  }
                  onMouseEnter={() =>
                    setState((prevState) => ({
                      ...prevState,
                      overlayType: 'hover',
                      overlayId,
                    }))
                  }
                  className={`overlay-box h-[40%]  ${
                    state.overlayId === overlayId &&
                    state.overlayType !== 'ideal' &&
                    ' h-full top-0'
                  } `}
                >
                  <div
                    className={`h-full flex  items-center justify-evenly flex-col ${
                      state.overlayId === overlayId &&
                      state.overlayType === 'hover' &&
                      ' h-full  w-full'
                    }`}
                  >
                    {state.overlayId === overlayId &&
                    state.overlayType === 'hover' ? (
                      <div className="flex md:flex-row flex-col justify-evenly items-center h-full w-full ">
                        <div
                          className="bg-[#1f15574a] w-full h-full flex items-center justify-center paragraph-hover"
                          onClick={() =>
                            viewTypeHandler('carousel', overlayId, imageId)
                          }
                        >
                          <p className=" animate__animated animate__bounceIn  text-whiteCol ">
                            Carousel
                          </p>
                        </div>
                        <div
                          className="bg-[#1f15574a] w-full h-full flex items-center justify-center paragraph-hover"
                          onClick={() =>
                            viewTypeHandler('grid', overlayId, imageId)
                          }
                        >
                          <p className="animate__animated animate__bounceIn text-whiteCol  ">
                            Grid
                          </p>
                        </div>
                      </div>
                    ) : (
                      <>
                        <p className="font-medium lg:text-xl text-xl mb-2 font-family">
                          {data.title}
                        </p>
                      </>
                    )}
                  </div>
                </div>
                <img
                  width={800}
                  height={400}
                  loading="lazy"
                  src={src}
                  alt={data.title || 'Galary Image'}
                  className=" w-full h-[220px] object-cover galleryLayout rounded-md card-shadow"
                  onMouseEnter={() =>
                    setState((prevState) => ({
                      ...prevState,
                      overlayType: (prevState.overlayType = 'hover'),
                      overlayId,
                    }))
                  }
                />
              </SwiperSlide>
            ))}
          </Swiper>
        ))}
      </div>
    </>
  );
};

export default Cards;
