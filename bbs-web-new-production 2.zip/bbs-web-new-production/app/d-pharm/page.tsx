'use client';
import Image from 'next/image';
import 'animate.css';
import Arrow from '../common/arrow';
import ScrollTrigger from 'react-scroll-trigger';
import { useEffect, useState } from 'react';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import MasterCourse from '../eligibility-criteria/masterCourse';
import SwiperComponent from '../home/congracts-section/swiper';
import CourseSlider from '../common/courseSlider';
import FutureReadyEng from '../common/futureReadyEng';
import AppService from '../services';
import Head from 'next/head';
import SeoWrapper from '../common/SeoWrapper';

const programHighlights = [
  {
    highlight:
      'Practical Learning: Emphasis on case studies and hands-on training in modern laboratories.',
  },
  {
    highlight:
      'Industry Partnerships: Access to internship opportunities and collaboration with leading pharmaceutical companies.',
  },
  {
    highlight:
      'Skill Enhancement: Offering courses to improve business communication and presentation skills.',
  },
  {
    highlight:
      'Entrepreneurship: Encouraging entrepreneurial spirit and providing support for innovative ventures.',
  },
  {
    highlight:
      'Industry Insights: Guest lectures by industry experts to keep students updated with current trends and practices.',
  },
  {
    highlight:
      "Global Exposure: Opportunities for national and international immersion programs to broaden students' perspectives.",
  },
  {
    highlight:
      'Cutting-edge Technology: Access to the latest tools and technologies in pharmaceutical research and development, preparing students for the forefront of the industry.',
  },
];

const employmentRules = [
  'Hospital Pharmacist',
  'Community Pharmacist',
  'Production Chemist',
  'Production Technician',
  'Medical Representative',
  'Pharmaceutical Wholesaler',
];

const placementOpportunies = [
  { point: 'Govt. Hospitals: AIIMS, PGI, ESIC, Etc.' },
  { point: 'Private Hospitals: Max, Fortis, Apollo, Etc.' },
  {
    point:
      'Pharmaceutical Industries: Alkem, Cipla, Abbott, Dr.Reddy’s, Mankind, Unichem, Etc',
  },
  { point: 'Private Clinics & Nursing Homes' },
  { point: 'Wholesale Drug Distribution' },
];

const faculty = [
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
];

const defaultState = {
  isLoading: false,
  facultyList: [],
};

const departmentId = 2;
const DPharm = () => {
  const defaultAnimation = {
    courseOverview: false,
    highlights: false,
  };

  const [animationStart, setAnimationStart] = useState(defaultAnimation);

  const [state, setState] = useState(defaultState);
  const fetchFacultyList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getFacultyList();
    if (!error) {
      // Rehan Code for Category Filtering
      const facultyList = data.filter(
        (item: any) => item?.attributes?.department?.data?.id === departmentId
      );
      console.log(facultyList, 'facultyList');
      setState((prevState) => ({
        ...prevState,
        facultyList,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchFacultyList();
  }, []);

  return (
    <>
      <SeoWrapper
        title="Top Choice for Students | Best Pharmacy College in UP"
        description="Build your career at the best pharmacy college in UP. D. Pharm gives strong basics in medicine and healthcare with expert teaching and modern facilities."
        keywords="best pharmacy college in up"
      >
        <div className="">
          {/* Hero Sectino */}
          <section>
            <div className="w-[80%] overlflow-hidden m-auto grid md:grid-cols-2 grid-cols-1 justify-center items-center md:px-6 px-3 py-12">
              <div>
                <Image
                  unoptimized={true}
                  src={'/courses/d-pharma-icon.webp'}
                  width={90}
                  height={20}
                  alt="D Pharma Icon"
                  className="animate__animated animate__fadeInLeftBig my-4 rotateAnimate"
                />
                <div>
                  <h2 className="">UG Degree</h2>
                  <div className="bg-secondary h-2 w-full"></div>
                </div>
                <h1 className="m-0">
                  D.Pharm. <br /> Diploma in Pharmacy{' '}
                </h1>
              </div>

              <div className="md:p-8 p-4">
                <Image
                  src={'/courses/d-pharma.webp'}
                  unoptimized={true}
                  width={600}
                  height={20}
                  alt="D Pharma"
                  className="animate__animated animate__fadeInRight rounded-lg"
                />
              </div>
            </div>
          </section>

          {/* Course Overveiw */}

          <section className="bg-gray handleoverlflow">
            <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-24 px-6">
              <div data-aos="fade-right" className={`p-6 `}>
                <div>
                  <h2>COURSE OVERVIEW</h2>
                  <h4 className="text-justify">
                    The Diploma in Pharmacy (D. Pharm) is a short course for
                    students who want to begin a career in pharmacy quickly. Our
                    private institute is known as the best pharmacy college in
                    UP and offers modern labs and experienced faculty. The
                    course teaches the basics of medicine, healthcare, and
                    pharmacy practice. Completing D. Pharm gives students a
                    strong foundation to start work as a pharmacist or continue
                    to advanced programs like B. Pharm. It is a top choice for
                    career-focused students.
                  </h4>
                </div>

                <div className="">
                  <h2 className="uppercase">Placement Opportunities</h2>
                  <div className="grid  grid-cols-1">
                    {placementOpportunies.map((item, index) => (
                      <div key={index} className="flex gap-3">
                        <Arrow />
                        <h3 className="m-2">{item.point}</h3>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="">
                  <h2 className="uppercase">Advanced Options of Study</h2>
                  <div className="grid md:grid-cols-2 grid-cols-1">
                    <div className="flex gap-3">
                      <Arrow />
                      <h3 className="m-2">B.Pharm</h3>
                    </div>
                    <div className="flex gap-3">
                      <Arrow />
                      <h3 className="m-2">M.Pharm</h3>
                    </div>
                    <div className="flex gap-3">
                      <Arrow />
                      <h3 className="m-2">Pharm.D</h3>
                    </div>
                  </div>
                </div>
              </div>

              <div className={`m-auto `} data-aos="fade-left">
                <div className="bg-secondary p-4 m-4 md:mr-12">
                  <div className="p-4">
                    <h3 className="m-0">Duration</h3>
                    <h2 className="m-0">2 Years</h2>
                  </div>
                  <div className="p-4">
                    <h3 className="m-0">Programme Name</h3>
                    <h2 className="m-0">D.Pharm.</h2>
                  </div>
                </div>
                <div className="bg-primary text-whiteCol p-4 m-4 md:ml-12">
                  <div className="p-4">
                    <h2 className="m-0">Eligibility</h2>
                    <h5 className="text-justify mt-0">
                      Passed 10+2 examination with PCB / PCM with at least 50%
                      marks. (Candidate must have attained the age of 17 years
                      on 31.12.2025).
                    </h5>
                    <h5 className="text-justify mt-0">
                      Five percent relaxation in the minimum eligibility is
                      provided to SC/ST Category Students
                    </h5>
                  </div>
                  <div className="p-4">
                    <Link href={'apply-online'} target="blank">
                      <ButtonCustom
                        btnColor={'secondary'}
                        btnText={'Apply Online'}
                        textCol={'primary'}
                      />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Program Highliths */}

          <section
            className="md:p-12 py-6 overlflow-hidden "
            data-aos="zoom-in-up"
          >
            <div className="w-[80%] m-auto bg-primary p-6 text-whiteCol">
              <div>
                <h2 className="text-secondary">Programme Highlights</h2>
                <div
                  className={`md:columns-2 columns-1 
                            ${
                              animationStart.highlights
                                ? 'animate__animated animate__fadeInRight animate__slower'
                                : ''
                            }`}
                >
                  {programHighlights.map((list: any, index) => (
                    <>
                      <div key={index} className="flex gap-3">
                        <Arrow />
                        <h4 className="m-2">{list.highlight}</h4>
                      </div>
                    </>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* Future Ready */}
          <FutureReadyEng
            department={
              <>
                Department of <br />
                Diploma in Pharmacy
              </>
            }
            image={'/futureReady/dpharmCenter.webp'}
            format={'jpg'}
          />

          {/* Advanced Options of Study */}

          <section
            data-aos="fade-up-right"
            className="overlflow-hidden md:p-12 py-6  bg-gray"
          >
            <div className="w-[80%] m-auto bg-secondary rounded-xl p-6 text-whiteCol">
              <div>
                <h2 className="text-primary  text-center">Employment Roles</h2>
                <div className=" grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3   m-auto ">
                  {employmentRules.map((career: any, index) => (
                    <h3
                      key={index}
                      className="bg-whiteCol rounded-md drop-shadow-md px-6 py-2
                    text-primary m-0"
                    >
                      {career}
                    </h3>
                  ))}
                </div>
              </div>
            </div>
          </section>
          {/* </ScrollTrigger> */}

          {/* Top Recruiters */}
          <div className="mt-12">
            <RecruitersComapnies />
          </div>

          {/* Eligibility  */}
          {/* <div className="md:p-12 p-8 ">
        <Eligibility EligibilityTable={EligibilityTable} />
      </div> */}

          {/* Faculty  */}
          {!!state.facultyList.length && (
            <div className="  bg-primary flex">
              <div className="lg:w-[85%] w-[90%] m-auto md:p-16 p-4  ">
                <h2 className="m-auto text-secondary text-center p-4">
                  Our Faculty
                </h2>
                <CourseSlider elements={state.facultyList} />
              </div>
            </div>
          )}
        </div>
      </SeoWrapper>
    </>
  );
};
export default DPharm;
