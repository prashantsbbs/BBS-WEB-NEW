'use client';

import {
  GoogleReCaptcha,
  GoogleReCaptchaProvider,
} from 'react-google-recaptcha-v3';
import Modal from '@/app/apply-online/modal';
import { ERROR_MESSAGES, REGEX } from '@/app/constant/constant';
import AppService from '@/app/services';
import { Dialog, Transition } from '@headlessui/react';
import Image from 'next/image';
import React, { Fragment, useEffect, useMemo, useState } from 'react';
import { Controller, useFieldArray, useForm, useWatch } from 'react-hook-form';
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import { STATE_CITY_LIST } from '@/app/constant/state-city';
import axios from 'axios';
import Link from 'next/link';

type JobProfile = {
  organisationName: string;
  organisationAddress: string;
  designation: string;
  currentCtc: string;
};

type FormData = {
  name: string;
  fatherName: string;
  motherName: string;
  pssingSession: string;
  collegeRollNumber: string;
  whatsAppNumber: string;
  facebookId: string;
  personalContact: string;
  officialContact: string;
  gender: string;
  date: string;
  aboutMe: string;
  aluminiPhoto: string;
  jobProfile: JobProfile[];
  email: string;
  phone: string;
  course: string;
  branch: string;
  state: string;
  city: string;
};

const jobDetails = {
  organisationName: 'organisationName',
  organisationAddress: 'organisationAddress',
  designation: 'designation',
  remarks: 'remarks',
};

const passingSession = [
  '2024-2025',
  '2023-2024',
  '2022-2023',
  '2021-2022',
  '2020-2021',
  '2019-2020',
  '2018-2019',
  '2017-2018',
  '2016-2017',
  '2015-2016',
  '2014-2015',
  '2013-2014',
  '2012-2013',
  '2011-2012',
  '2010-2011',
  '2009-2010',
  '2008-2009',
  '2007-2008',
  '2006-2007',
  '2005-2006',
];

const gender = ['Male', 'Female', 'Transgender'];

// google Recaptcha-------------------------------

const AluminiForm = () => {
  const [recaptchaToken, setRecaptchaToken] = useState<string>('');

  const handleRecaptchaChange = (token: string | null) => {
    if (token) {
      setRecaptchaToken(token);
    }
  };

  const [courseList, setCourseList] = useState([]);
  const [alertMessage, setAlertMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [newCourseAppend, setNewCourseAppend] = useState<any>('');

  const handleFileChange = (event: any) => {
    const file = event.target.files[0];
    const fileType = file.type.split('/');
    const fileFormat = fileType[1];

    if (file.size > 1048576) {
      setErrorMessage('File is greater than 1mb');
    } else if (!['jpeg', 'jpg'].includes(fileFormat)) {
      setErrorMessage('Please upload jpg or jpeg');
    } else {
      setSelectedFile(file);
      setErrorMessage('');
    }
  };

  const fetchCourseList = async () => {
    setIsLoading(true);
    const { data, error } = await AppService.getCourseList();
    if (!error) {
      const newArray = [
        {
          id: 4,
          attributes: {
            name: 'B.Tech',
            description:
              'B.Tech is a four-year undergraduate degree focused on engineering and technology.',
            department: {
              data: {
                id: 6,
                attributes: {
                  name: 'Electronics & Communications Engineering',
                  alias: 'CSE',
                  description: 'Electronics & Communications Engineering',
                },
              },
            },

            course_category: {
              data: {
                id: 1,
                attributes: {
                  name: 'Bachelor Courses',
                  createdAt: '2024-04-17T17:50:29.851Z',
                  updatedAt: '2024-04-17T17:50:32.698Z',
                  publishedAt: '2024-04-17T17:50:32.570Z',
                },
              },
            },
          },
        },
        {
          id: 4,
          attributes: {
            name: 'B.Tech',
            description:
              'B.Tech is a four-year undergraduate degree focused on engineering and technology.',
            department: {
              data: {
                id: 20,
                attributes: {
                  name: 'Information Technology',
                  alias: 'IT',
                  description: 'Information Technology',
                },
              },
            },

            course_category: {
              data: {
                id: 1,
                attributes: {
                  name: 'Bachelor Courses',
                  createdAt: '2024-04-17T17:50:29.851Z',
                  updatedAt: '2024-04-17T17:50:32.698Z',
                  publishedAt: '2024-04-17T17:50:32.570Z',
                },
              },
            },
          },
        },
        {
          id: 4,
          attributes: {
            name: 'B.Tech',
            description:
              'B.Tech is a four-year undergraduate degree focused on engineering and technology.',
            department: {
              data: {
                id: 21,
                attributes: {
                  name: 'Applied Electronics and Instrumentation Engineering',
                  alias: 'EIE',
                  description:
                    'Applied Electronics and Instrumentation Engineering',
                },
              },
            },

            course_category: {
              data: {
                id: 1,
                attributes: {
                  name: 'Bachelor Courses',
                  createdAt: '2024-04-17T17:50:29.851Z',
                  updatedAt: '2024-04-17T17:50:32.698Z',
                  publishedAt: '2024-04-17T17:50:32.570Z',
                },
              },
            },
          },
        },
      ];
      data.push(...newArray);

      setCourseList(data);
    }
    setIsLoading(false);
  };

  const {
    register,
    handleSubmit,
    getValues,
    control,
    watch,
    resetField,
    reset,
    formState: { errors },
  } = useForm<FormData>();
  const [moIsOpen, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const handleClose = () => setShow(false);

  const sendEmail = async (data: any) => {
    const response = await fetch('/api/email', {
      method: 'POST',
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json',
      },
    });
    const res = await response.json();
    console.log(res);
  };

  const createJobProfiles = async (payloads: any = []) => {
    const promises = payloads.map((payload: any) => {
      return AppService.createAluminiJobProfile({ data: payload });
    });

    const result = await Promise.all(promises);
    return result
      .filter((item) => item.data)
      .map((item: any) => item?.data?.id);
  };

  const uploadAluminiImage = async (file: any = {}) => {
    const formData = new FormData();
    formData.set('files', file);
    try {
      const { data } = await axios.post(
        `${process.env.NEXT_PUBLIC_API_BASE_URL}upload`,
        formData,
        { headers: { 'Content-Type': 'multipart/form-data' } }
      );
      return data;
    } catch (error) {
      console.log(`ERROR while upload image: ${error}`);
      return false;
    }
  };

  const onSubmit = async (formData: FormData) => {
    setIsLoading(true);
    let jobProfiles: any = [];
    let aluminiImage: any;
    if (selectedFile) {
      const uploadResponse = await uploadAluminiImage(selectedFile);
      console.log(uploadResponse, 'uploadResponse');
      aluminiImage = uploadResponse?.[0]?.id || '';
    }

    const jobProfileData = formData.jobProfile.map((row) => ({
      organisation_name: row.organisationName,
      organisation_address: row.organisationAddress,
      designation: row.designation,
      current_ctc: row.currentCtc,
    }));

    if (jobProfileData.length) {
      jobProfiles = await createJobProfiles(jobProfileData);
    }

    const payload = {
      data: {
        name: formData.name,
        father_name: formData.fatherName,
        mother_name: formData.motherName,
        session: formData.pssingSession,
        college_roll_number: formData.collegeRollNumber,
        whatsapp_number: formData.whatsAppNumber,
        facebook_id: formData.facebookId,
        personal_contact_number: formData.personalContact,
        official_contact_number: formData.officialContact,
        gender: formData.gender,
        date_of_birth: formData.date,
        about: formData.aboutMe,
        media: aluminiImage,
        email: formData.email,
        phone: formData.phone,
        state: formData.state,
        city: formData.city,
        course: formData.course,
        branch: formData.branch,
        alumini_job_profiles: {
          connect: jobProfiles,
        },
      },
    };

    const { error } = await AppService.createAlumini(payload);

    if (error) {
      setAlertMessage(error?.message);
    } else {
      setAlertMessage('Submitted Successfully.');
      console.log(payload.data, 'payload.data');
      reset();
    }
    setIsLoading(false);
  };

  const [selectedCourse, selectedState] = useWatch({
    control,
    name: ['course', 'state'],
  });

  useEffect(() => {
    fetchCourseList();
    // let  newCourse =  {...courseList}
  }, []);

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'jobProfile', // Name of the field array in the form data
  });

  const courseAndBranchList = useMemo(() => {
    return courseList.reduce((acc: any, course: any) => {
      const courseIndex = acc.findIndex(
        (item: any) => item.name === course?.attributes?.name
      );
      if (courseIndex > -1) {
        acc[courseIndex].branch.push(
          course?.attributes?.department?.data?.attributes?.name
        );
      } else {
        acc.push({
          name: course?.attributes?.name,
          branch: [course?.attributes?.department?.data?.attributes?.name],
        });
      }
      return acc;
    }, []);
  }, [courseList]);

  const branchList =
    courseAndBranchList.find(({ name }: any) => name === selectedCourse)
      ?.branch || [];
  const cityList = STATE_CITY_LIST[selectedState] || [];

  return (
    <>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="relative flex flex-col px-8 pb-8 md:px-6 md:pb-6 md:pt-6 pt-2 gap-1 text-center 
                md:w-[80%] sm:w-[90%] w-[100%] m-auto "
      >
        <h1 className="text-3xl uppercase bg-primary text-whiteCol p-2 rounded-xl">
          Alumini Registration Form{' '}
        </h1>
        <div className="p-4">
          {/* course Details--------------------------------------------- */}

          <div>
            <h4 className="text-left mb-0 font-medium">Select Course</h4>

            <div className="grid md:grid-cols-2 grid-cols-1 gap-4 my-4">
              <div className="mb-2">
                <Controller
                  name="course"
                  control={control}
                  rules={{
                    required: true,
                  }}
                  render={({ field: { value, onChange } }) => (
                    <select
                      name="course"
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      onChange={onChange}
                    >
                      <option key={'index'} disabled selected>
                        Select Course *
                      </option>
                      {courseAndBranchList.map((course: any, index: any) => (
                        <option key={index}>{course.name}</option>
                      ))}
                    </select>
                  )}
                />
                {errors.course && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.course.type] ||
                      errors.course.message}
                  </div>
                )}
              </div>

              <div className="mb-2">
                <Controller
                  name="branch"
                  control={control}
                  rules={{
                    required: branchList.length > 1,
                  }}
                  render={({ field: { value, onChange } }) => (
                    <select
                      disabled={branchList.length < 2}
                      name="course"
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      onChange={onChange}
                    >
                      <option key={'index'} disabled selected>
                        Select Branch {branchList.length > 1 ? '*' : ''}
                      </option>
                      {branchList.map((branch: any, index: any) => (
                        <option key={index}>{branch}</option>
                      ))}
                    </select>
                  )}
                />
                {errors.branch && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.branch.type] ||
                      errors.branch.message}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* personal Details---------------------------------------------------- */}

          <div>
            <h4 className="text-left mb-0 font-medium">Personal Details</h4>

            {/* name------------------------------------------------------- */}
            <div className="mb-2">
              <input
                {...register('name', { required: true, maxLength: 55 })}
                type="text"
                className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                  errors.name ? 'border-red-500' : ''
                }`}
                placeholder="Name *"
              />
              {errors.name && (
                <div className="text-left text-sm text-danger">
                  {ERROR_MESSAGES[errors.name.type] || errors.name.message}
                </div>
              )}
            </div>

            {/* Father-mother name gender DOB--------------------------------------------------- */}
            <div className="grid md:grid-cols-2 grid-cols-1 gap-4 my-4">
              <div className="mb-2">
                <input
                  {...register('fatherName', { required: true, maxLength: 55 })}
                  type="text"
                  className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                    errors.fatherName ? 'border-red-500' : ''
                  }`}
                  placeholder="Father's Name *"
                />
                {errors.fatherName && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.fatherName.type] ||
                      errors.fatherName.message}
                  </div>
                )}
              </div>

              <div className="mb-2">
                <input
                  {...register('motherName', { maxLength: 55 })}
                  type="text"
                  className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                    errors.motherName ? 'border-red-500' : ''
                  }`}
                  placeholder="Mother's Name "
                />
                {errors.motherName && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.motherName.type] ||
                      errors.motherName.message}
                  </div>
                )}
              </div>

              <div className="mb-2">
                <h5 className="m-0 text-left font-medium">Select Gender</h5>
                <Controller
                  name="gender"
                  control={control}
                  rules={{
                    required: true,
                  }}
                  render={({ field: { value, onChange } }) => (
                    <select
                      name="gender"
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      onChange={onChange}
                    >
                      <option disabled selected className="">
                        Gender *
                      </option>
                      {gender.map((year, key) => (
                        <option key={key}>{year}</option>
                      ))}
                    </select>
                  )}
                />
                {errors.gender && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.gender.type] ||
                      errors.gender.message}
                  </div>
                )}
              </div>

              <div className="mb-2">
                <h5 className="m-0 text-left font-medium">Date of Birth</h5>
                <input
                  {...register('date', { required: true, maxLength: 55 })}
                  type="date"
                  className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                    errors.date ? 'border-red-500' : ''
                  }`}
                  placeholder="Date of Birth *"
                />
                {errors.date && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.date.type] || errors.date.message}
                  </div>
                )}
              </div>
            </div>

            {/* Email Phone State City--------------------------------------------------- */}

            <div className="grid md:grid-cols-2 grid-cols-1 gap-4 my-4">
              <div className="mb-2">
                <input
                  {...register('email', {
                    required: true,
                    pattern: {
                      value: REGEX.EMAIL,
                      message: 'Email is not valid',
                    },
                  })}
                  className="mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  placeholder="Email *"
                />
                {errors.email && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.email.type] || errors.email.message}
                  </div>
                )}
              </div>

              <div className="mb-2">
                <Controller
                  name="phone"
                  control={control}
                  rules={{
                    required: true,
                    pattern: {
                      value: REGEX.PHONE,
                      message: 'Invalid phone number',
                    },
                  }}
                  render={({ field: { value, onChange } }) => (
                    <PhoneInput
                      defaultCountry="IN"
                      countries={['IN']}
                      placeholder="Enter Phone Number *"
                      value={value}
                      onChange={onChange}
                      className="[&>input]:outline-none p-2.5 flex justify-stretch bg-whiteCol border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-1.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    />
                  )}
                />
                {errors.phone && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.phone.type] || errors.phone.message}
                  </div>
                )}
              </div>

              <div className="mb-2">
                <Controller
                  name="state"
                  control={control}
                  rules={{
                    required: true,
                  }}
                  render={({ field: { value, onChange } }) => (
                    <select
                      name="state"
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      onChange={onChange}
                    >
                      <option disabled selected className="">
                        Select State *
                      </option>
                      {Object.entries(STATE_CITY_LIST).map(([key]) => (
                        <option key={key}>{key}</option>
                      ))}
                    </select>
                  )}
                />
                {errors.state && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.state.type] || errors.state.message}
                  </div>
                )}
              </div>

              <div className="mb-2">
                <Controller
                  name="city"
                  control={control}
                  rules={{
                    required: !!cityList.length,
                  }}
                  render={({ field: { value, onChange } }) => (
                    <select
                      name="course"
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      onChange={onChange}
                    >
                      <option disabled selected>
                        Select City {cityList.length ? '*' : ''}
                      </option>
                      {cityList.map((item: any) => (
                        <option key={item.id}>{item.city}</option>
                      ))}
                    </select>
                  )}
                />
                {errors.city && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.city.type] || errors.city.message}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Passing Year and University Details--------------------------------------------------- */}
          <div>
            <h4 className="text-left mb-0 font-medium">College Details</h4>
            <div className="grid md:grid-cols-2 grid-cols-1 gap-4 my-4">
              <div className="mb-2">
                <Controller
                  name="pssingSession"
                  control={control}
                  rules={{
                    required: true,
                  }}
                  render={({ field: { value, onChange } }) => (
                    <select
                      name="pssingSession"
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      onChange={onChange}
                    >
                      <option disabled selected className="">
                        Passing Session *
                      </option>
                      {passingSession.map((year, key) => (
                        <option key={key}>{year}</option>
                      ))}
                    </select>
                  )}
                />
                {errors.pssingSession && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.pssingSession.type] ||
                      errors.pssingSession.message}
                  </div>
                )}
              </div>

              <div className="mb-2">
                <input
                  {...register('collegeRollNumber', {
                    required: true,
                    maxLength: 55,
                  })}
                  type="text"
                  className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                    errors.collegeRollNumber ? 'border-red-500' : ''
                  }`}
                  placeholder="College Roll Number *"
                />
                {errors.collegeRollNumber && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.collegeRollNumber.type] ||
                      errors.collegeRollNumber.message}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Job Profile--------------------------------------------------- */}
          <div className="bg-primary p-2">
            <h4 className="text-left mb-0 font-medium text-secondary">
              Job Profile
            </h4>
            <div className="">
              <div className="">
                {fields.length === 0 && (
                  <div className="flex gap-4 w-full">
                    <div className="text-whiteCol my-auto w-3">1</div>
                    <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-4 w-full">
                      <div className="mb-2">
                        <input
                          {...register(`jobProfile.0.organisationName`, {
                            maxLength: 55,
                          })}
                          type="text"
                          defaultValue=""
                          className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500`}
                          placeholder="Organisation Name"
                        />
                      </div>
                      {/* Add input fields for organisationAddress, designation, and remarks similarly */}
                      <div className="mb-2">
                        <input
                          {...register(`jobProfile.0.organisationAddress`, {
                            maxLength: 55,
                          })}
                          defaultValue=""
                          type="text"
                          className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500`}
                          placeholder="Organisation Address"
                        />
                      </div>

                      <div className="mb-2">
                        <input
                          {...register(`jobProfile.0.designation`, {
                            maxLength: 55,
                          })}
                          defaultValue=""
                          type="text"
                          className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500`}
                          placeholder="Designation"
                        />
                      </div>

                      <div className="mb-2">
                        <input
                          {...register(`jobProfile.0.currentCtc`, {
                            maxLength: 55,
                          })}
                          defaultValue=""
                          type="text"
                          className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500`}
                          placeholder="Current CTC"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {fields.map((row, index) => (
                  <div key={row.id} className="flex gap-4 w-full">
                    <div className="text-whiteCol md:my-auto w-[30px]">
                      {index + 1}
                    </div>
                    <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-4 w-full">
                      <div className="mb-2">
                        <input
                          {...register(`jobProfile.${index}.organisationName`, {
                            maxLength: 55,
                          })}
                          type="text"
                          defaultValue={row.organisationName}
                          className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500`}
                          placeholder="Organisation Name"
                        />
                      </div>

                      <div className="mb-2">
                        <input
                          {...register(
                            `jobProfile.${index}.organisationAddress`,
                            {
                              maxLength: 55,
                            }
                          )}
                          type="text"
                          defaultValue={row.organisationAddress}
                          className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500`}
                          placeholder="Organisation Address"
                        />
                      </div>

                      <div className="mb-2">
                        <input
                          {...register(`jobProfile.${index}.designation`, {
                            maxLength: 55,
                          })}
                          type="text"
                          defaultValue={row.designation} // Set default value if needed
                          className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500`}
                          placeholder="Designation"
                        />
                      </div>

                      <div className="mb-2">
                        <input
                          {...register(`jobProfile.${index}.currentCtc`, {
                            maxLength: 55,
                          })}
                          defaultValue={row.currentCtc} // Set default value if needed
                          type="text"
                          className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500`}
                          placeholder="Current CTC"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <button
            className="bg-secondary p-2 text-black flex justify-end "
            type="button"
            onClick={() =>
              append({
                organisationName: '',
                organisationAddress: '',
                designation: '',
                currentCtc: '',
              })
            }
          >
            Add Row
          </button>

          {/* Other Contact Details--------------------------------------------------- */}

          <div className="my-4">
            <h4 className="text-left mb-0 font-medium">
              Other Contact Details
            </h4>

            <div className="grid md:grid-cols-2 grid-cols-1 gap-4 ">
              <div className="mb-2">
                <input
                  {...register('whatsAppNumber', {
                    required: true,
                    maxLength: 55,
                  })}
                  type="text"
                  className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                    errors.whatsAppNumber ? 'border-red-500' : ''
                  }`}
                  placeholder="WhatsApp Number *"
                />
                {errors.whatsAppNumber && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.whatsAppNumber.type] ||
                      errors.whatsAppNumber.message}
                  </div>
                )}
              </div>

              <div className="mb-2">
                <input
                  {...register('facebookId', { maxLength: 55 })}
                  type="text"
                  className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                    errors.facebookId ? 'border-red-500' : ''
                  }`}
                  placeholder="Facebook Id "
                />
                {errors.facebookId && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.facebookId.type] ||
                      errors.facebookId.message}
                  </div>
                )}
              </div>

              <div className="mb-2">
                <input
                  {...register('personalContact', {
                    maxLength: 55,
                  })}
                  type="number"
                  className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                    errors.personalContact ? 'border-red-500' : ''
                  }`}
                  placeholder="Personal Contact Number "
                />
                {errors.personalContact && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.personalContact.type] ||
                      errors.personalContact.message}
                  </div>
                )}
              </div>

              <div className="mb-2">
                <input
                  {...register('officialContact', {
                    maxLength: 55,
                  })}
                  type="number"
                  className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                    errors.officialContact ? 'border-red-500' : ''
                  }`}
                  placeholder="Official Contact Number "
                />
                {errors.officialContact && (
                  <div className="text-left text-sm text-danger">
                    {ERROR_MESSAGES[errors.officialContact.type] ||
                      errors.officialContact.message}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* about Me------------------------------------------------- */}
          <div className="mb-2">
            <h4 className="text-left mb-0 font-medium">About Me</h4>
            <textarea
              {...register('aboutMe', { maxLength: 255 })}
              className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                errors.aboutMe ? 'border-red-500' : ''
              }`}
              placeholder="Describe Yourself here... "
            />
            {errors.aboutMe && (
              <div className="text-left text-sm text-danger">
                {ERROR_MESSAGES[errors.aboutMe.type] || errors.aboutMe.message}
              </div>
            )}
          </div>

          {/* UploadPhoto----------------------------------------------- */}
          <div className="mb-2">
            <h4 className="text-left mb-0 font-medium">Upload Photograph</h4>
            <input
              {...register('aluminiPhoto', {})}
              type="file"
              onChange={handleFileChange}
              className={`mb-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 ${
                errors.aluminiPhoto ? 'border-red-500' : ''
              }`}
              placeholder="Upload Photograph *"
            />
            {!errorMessage ? (
              <h5 className="text-left">
                Please upload only one file in jpg format and file size should
                be less than 1mb
              </h5>
            ) : (
              <h5 className="text-left text-danger">{errorMessage}</h5>
            )}
          </div>
        </div>
        <button
          type="submit"
          className={`sign-btn bg-primary text-whiteCol border rounded-lg	py-2 font-semibold cursor-pointer hover:bg-blue-600`}
        >
          Submit
        </button>
        <GoogleReCaptchaProvider reCaptchaKey="6LeUDMcpAAAAAMLebnVfJ3q1kKeOYyjOUUDOPUcA">
          <GoogleReCaptcha onVerify={handleRecaptchaChange} />
        </GoogleReCaptchaProvider>
        <Modal
          message={alertMessage}
          isOpen={!!alertMessage}
          onClose={() => setAlertMessage('')}
        />
      </form>
    </>
  );
};

export default AluminiForm;
