import { NextRequest } from "next/server";
import cache from "@/config/node-cache";
import axios from "axios";

const otpGenerator = require('otp-generator');

const FAST_SMS_API_URL = process.env.FAST_SMS_API_URL || "";
const FAST_SMS_API_KEY = process.env.FAST_SMS_API_KEY || "";


export async function POST(request: NextRequest) {
  try {
    const reqPayload = await request.json();
    const phoneNumber = reqPayload.phone_number;
    const otp = otpGenerator.generate(4, { digits: true, upperCaseAlphabets: false, lowerCaseAlphabets: false, specialChars: false });
    cache.set(phoneNumber, otp, 600);
    const payload = {
      variables_values: otp,
      route: "otp",
      numbers: phoneNumber,
    };
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': FAST_SMS_API_KEY
    };
    console.log(payload, headers, 'payload')
    const response = await axios.post(FAST_SMS_API_URL, payload, { headers });
    console.log(response, 'response')
    return new Response(JSON.stringify({ data: 'OTP sent successfully.' }), { status: 200 })
  } catch (error) {
    console.log(error, 'error')
    return new Response(JSON.stringify({ error }), { status: 400 });
  }
};
