import { NextRequest } from "next/server";
const sendGridMail = require('@sendgrid/mail');
sendGridMail.setApiKey(process.env.SEND_GRID_API_KEY);

export async function POST(request: NextRequest) {
  try {
    const payload = await request.json();
    await sendGridMail.send(payload);
    return new Response(JSON.stringify({ data: 'Email sent successfully.' }), { status: 200 })
  } catch (error) {
    return new Response(JSON.stringify({ error }), { status: 400 });
  }
};