import { NextRequest } from 'next/server';
import cache from '@/config/node-cache';

export async function POST(request: NextRequest) {
  try {
    const payload = await request.json();
    const phoneNumber = payload.phone_number;
    const otp = payload.otp;
    // Retrieve OTP from cache
    const storedOTP = cache.get(phoneNumber);
    console.log(storedOTP, phoneNumber, otp);

    if (!storedOTP) {
      return new Response(
        JSON.stringify({ error: 'OTP not found or expired' }),
        { status: 400 }
      );
    }

    if (otp === storedOTP) {
      cache.del(phoneNumber); // Remove OTP from cache after successful verification
      return new Response(
        JSON.stringify({ data: 'OTP verified successfully' }),
        { status: 200 }
      );
    } else {
      return new Response(JSON.stringify({ error: 'Invalid OTP' }), {
        status: 400,
      });
    }
  } catch (error) {
    return new Response(JSON.stringify({ error }), { status: 400 });
  }
}
