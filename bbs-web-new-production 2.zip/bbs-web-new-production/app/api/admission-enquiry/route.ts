import axios from "axios";
const sgMail = require('@sendgrid/mail');

sgMail.setApiKey(process.env.SEND_GRID_API_KEY);

const sendEmail = ({
    toEmail = "",
    dynamicTemplateData = {},
    templateId = ""
}) => {
    const payload = {
        from: process.env.SEND_GRID_FROM_EMAIL,
        to: toEmail,
        dynamicTemplateData,
        templateId
    };

    sgMail
        .send(payload)
        .then(() => {
            console.log('Email sent')
        })
        .catch((error: any) => {
            console.error(error)
        });
};

export async function POST(request: Request) {
    try {
        const {
            Name,
            Email,
            Phone,
            Course,
            Branch,
            State,
            City,
        } = await request.json();

        if (!Name || !Email || !Phone || !Course || !State) {
            return new Response(JSON.stringify({ error: 'Required field missing.' }), { status: 400, headers: { 'Content-Type': 'application/json' } });
        }

        const endpoint = `${process.env.API_BASE_URL}/admission-enquiries`;
        const payload = {
            data: {
                Name,
                Email,
                Phone,
                Course,
                Branch,
                State,
                City,
            }
        };

        const response = await axios.post(endpoint, payload);
        sendEmail({
            toEmail: Email,
            dynamicTemplateData: payload.data,
            templateId: process.env.SEND_GRID_ADMISSION_ENQUIRY_USER_TEMPLATE_ID
        });
        sendEmail({
            toEmail: process.env.SEND_GRID_FROM_EMAIL,
            dynamicTemplateData: payload.data,
            templateId: process.env.SEND_GRID_ADMISSION_ENQUIRY_ADMIN_TEMPLATE_ID
        });

        const responseData = response.data;

        return new Response(JSON.stringify(responseData), { status: 200, headers: { 'Content-Type': 'application/json' } });
    } catch (error: any) {
        console.log(error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { 'Content-Type': 'application/json' } });
    }
}