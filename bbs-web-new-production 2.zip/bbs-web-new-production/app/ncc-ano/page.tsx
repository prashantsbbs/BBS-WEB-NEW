'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../common/button';
import { international_sec, stateOfArt } from '../constant/constant';

const NccAno = () => {
  
  return (
    <>
      <section>
        <div className="bg-gray pb-5 ">
          <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 shadow-md bg-whiteCol">
               <Image
              unoptimized={true}
              src={'/ncc/nccAno10.webp'}
              width={700}
              height={150}
              alt={'NCC'}
              className=" bgImage rounded-r-2xl m-auto "
              data-aos="fade-up"
            />
            <div className='pt-4'>
              <h1 className="text-" data-aos="fade-up"
               >
                Approval of NCC Unit at BBSCET, Phaphamau, Prayagraj
              </h1>
              <h4 className="text-justify" data-aos="fade-up">
                &emsp;&emsp;BBS College of Engineering & Technology (BBSCET),
                Phaphamau, Prayagraj has received formal approval for{' '}
                <strong> 80 SD/SW (FSFS) </strong> under{' '}
                <strong>1 UP CTR NCC, Prayagraj,</strong> marking a significant
                milestone in the institution’s commitment to discipline and
                nation-building. The approval was granted after the successful
                inspection and visits of{' '}
                <strong>Colonel Ravindra Khatri,</strong> Commanding Officer,{' '}
                <strong>1 UP CTR NCC,</strong> and{' '}
                <strong>Brigadier U. S. Kandil,</strong> Group Commander,
                Prayagraj Group Headquarters. Following the approval, a rigorous{' '}
                <strong>
                  physical test, medical examination, and written examination
                </strong>{' '}
                were conducted, after which a total of{' '}
                <strong>34 cadets</strong> from the{' '}
                <strong>B.Tech. course</strong> were enrolled in NCC, including
                24{' '}
                <strong>
                  Senior Division (SD) cadets and 10 Senior Wing (SW) cadets.
                </strong>{' '}
                The establishment of this NCC unit at BBSCET is expected to play
                a vital role in fostering leadership, discipline, patriotism,
                and overall personality development among students.
              </h4>
            </div>
            <div>
              <br />
<div data-aos="fade-up">
              <h2 className="" >ANO PROFILE</h2>
              <h4 className="text-justify" >
                &emsp;&emsp;BBS College of Engineering & Technology (BBSCET),
                Phaphamau, Prayagraj has received formal approval for{' '}
                <strong> 80 SD/SW (FSFS) </strong> under{' '}
                <strong>1 UP CTR NCC, Prayagraj,</strong> marking a significant
                milestone in the institution’s commitment to discipline and
                nation-building. The approval was granted after the successful
                inspection and visits of{' '}
                <strong>Colonel Ravindra Khatri,</strong> Commanding Officer,{' '}
                <strong>1 UP CTR NCC,</strong> and{' '}
                <strong>Brigadier U. S. Kandil,</strong> Group Commander,
                Prayagraj Group Headquarters. Following the approval, a rigorous{' '}
                <strong>
                  physical test, medical examination, and written examination
                </strong>{' '}
                were conducted, after which a total of{' '}
                <strong>34 cadets</strong> from the{' '}
                <strong>B.Tech. course</strong> were enrolled in NCC, including
                24{' '}
                <strong>
                  Senior Division (SD) cadets and 10 Senior Wing (SW) cadets.
                </strong>{' '}
                The establishment of this NCC unit at BBSCET is expected to play
                a vital role in fostering leadership, discipline, patriotism,
                and overall personality development among students.
              </h4>
              </div>
            
            </div>
            <br />
             <br />
                 <br />
      
              <div className="grid" data-aos="fade-up">
                <div className="grid grid-cols-2 gap-4">
                  <Image
                    unoptimized={true}
                    src={'/ncc/ncc1.webp'}
                    width={800}
                    height={800}
                    alt={'NCC'}
                    className=" socialImage  rounded-lg min-h-[200px] max-h-[280px]"
                    data-aos="fade-right"
                  />
                  <Image
                    unoptimized={true}
                    src={'/ncc/nccAno1.webp'}
                    width={800}
                    height={800}
                    alt={'NCC'}
                    className=" socialImage  rounded-lg min-h-[200px] max-h-[280px] "
                    data-aos="fade-left"
                  />
                </div>
                <h4>
                  Visit of <strong>Colonel Ravindra Khatri,</strong> Commanding
                  Officer, <strong>1 UP CTR NCC</strong>
                </h4>
              </div>
              <br />
              <br />
                  <br />
              <div className="grid" data-aos="fade-up">
                <div className="grid grid-cols-2 gap-4">
                  <Image
                    unoptimized={true}
                    src={'/ncc/nccAno2.webp'}
                    width={800}
                    height={800}
                    alt={'NCC'}
                    className=" socialImage  rounded-lg min-h-[200px] max-h-[380px] "
                    data-aos="fade-right"
                  />
                  <Image
                    unoptimized={true}
                    src={'/ncc/nccAno3.webp'}
                    width={800}
                    height={800}
                    alt={'NCC'}
                    className=" socialImage  rounded-lg min-h-[200px] max-h-[380px]"
                    data-aos="fade-left"
                  />
                </div>
                <h4>
                  Visit of <strong>Brigadier U. S. Kandil,</strong> Group Commander, Prayagraj Group Headquarters
                </h4>
              </div>
              <br />
              <br />
                  <br />
              <div className="grid" data-aos="fade-up">
                <div className='grid gap-4' data-aos="fade-up">
                     <Image
                    unoptimized={true}
                    src={'/ncc/nccAno4.webp'}
                    width={1000}
                    height={1000}
                    alt={'NCC'}
                    className=" socialImage  rounded-lg min-h-[200px] max-h-[400px]"
                  />
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Image
                    unoptimized={true}
                    src={'/ncc/nccAno5.webp'}
                    width={800}
                    height={800}
                    alt={'NCC'}
                    className=" socialImage  md:col-span-1  rounded-lg min-h-[200px] max-h-[280px] "
                    data-aos="fade-right"
                  />
                  <Image
                    unoptimized={true}
                    src={'/ncc/ncc6.webp'}
                    width={800}
                    height={800}
                    alt={'NCC'}
                    className=" socialImage md:col-span-2  rounded-lg min-h-[200px] max-h-[280px] "
                    data-aos="fade-left"
                  />
                </div></div>
                <h4>
                 Plantation by  <strong>Brigadier U. S. Kandil,</strong> Group Commander, Prayagraj Group Headquarters and <strong>Colonel Ravindra Khatri,</strong> Commanding Officer, <strong>1 UP CTR NCC.</strong>
                </h4>
              </div>
              <br />
              <br />
                  <br />
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">

  {[
    {
      img: '/ncc/nccAno6.webp',
      text: 'First NCC PI class in BBSCET by hawaldar Monu Singh and Surjeet Singh.',
    },
    {
      img: '/ncc/nccAno7.webp',
      text: 'First NCC Class by CTO Dr. Vandana Yadav',
    },
    {
      img: '/ncc/nccAno8.webp',
      text: 'First Drill of NCC by cadets of BBSCET.',
    },
  ].map((item, i) => (
    
    <div
      key={i}
      data-aos="fade-up"
      className="group bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition duration-300"
    >

      {/* Image */}
      <div className="w-full h-[180px]">
        <Image
          src={item.img}
          alt="NCC"
          width={500}
          height={400}
          unoptimized
          className="w-full h-full object-fill group-hover:scale-105 transition duration-300"
        />
      </div>

      {/* Text */}
      <div className="px-3 py-2">
        <h4 className=" text-sm leading-snug">
          {item.text}
        </h4>
      </div>

    </div>

  ))}

</div>
              {/* <div className="grid" data-aos="fade-up">
                     <Image
                    unoptimized={true}
                    src={'/ncc/nccAno6.webp'}
                    width={1000}
                    height={1000}
                    alt={'Gallery Image'}
                    className=" socialImage  rounded-lg min-h-[200px] "
                  />
                <h4>
                First NCC PI class in BBSCET by hawaldar Monu Singh and Surjeet Singh.
                </h4>
              </div>
              <br />
                  <br />
                      <br />
               <div className="grid" data-aos="fade-up">
                     <Image
                    unoptimized={true}
                    src={'/ncc/nccAno7.webp'}
                    width={1000}
                    height={1000}
                    alt={'Gallery Image'}
                    className=" socialImage  rounded-lg min-h-[200px] "
                  />
                <h4>
                First NCC Class by CTO Dr. Vandana Yadav
                </h4>
              </div>
              <br />
                  <br />
                      <br />
               <div className="grid" data-aos="fade-up">
                     <Image
                    unoptimized={true}
                    src={'/ncc/nccAno8.webp'}
                    width={1000}
                    height={1000}
                    alt={'Gallery Image'}
                    className=" socialImage  rounded-lg min-h-[200px] "
                  />
                <h4>
                First Drill of NCC by cadets of BBSCET.
                </h4>
              </div> */}

            {/* <div className=" m-auto grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary">
              {gallery.map((game: any, index) => (
                <>
                  <div key={index}>
                    <Image
                      unoptimized={true}
                      src={game.image}
                      width={400}
                      height={400}
                      alt={'Gallery Image'}
                      className=" socialImage  rounded-lg min-h-[200px] "
                    />
                  </div>
                </>
              ))}
            </div> */}
          </div>
       
          <div className="w-[80vw] mx-auto py-12 space-y-12">

  {/* 🔥 SECTION 1 (HIGHLIGHT) */}
  <div className="grid md:grid-cols-2 gap-6 items-center">
    
    {/* Image 13 (Big Left) */}
    <div className="bg-gray-100 rounded-3xl overflow-hidden p-4 shadow-lg hover:shadow-xl transition duration-300">
      <Image
        src="/ncc/nccAno13.webp"
        alt="NCC"
        width={800}
        height={500}
        className="w-full h-[350px] object-contain"
      />
    </div>

    {/* Image 12 (Right) */}
    <div className="bg-gray-100 rounded-3xl overflow-hidden p-4 shadow-lg hover:shadow-xl transition duration-300">
      <Image
        src="/ncc/nccAno12.webp"
        alt="NCC"
        width={800}
        height={500}
        className="w-full h-[350px] object-contain"
      />
    </div>

  </div>

 {/* 🔥 SECTION 2 (DIFFERENT STYLE) */}
<div className="space-y-6">
  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">

    {[
      '/ncc/nccAno14.webp',
      '/ncc/nccAno11.webp',
      '/ncc/ncc8.webp',
      '/ncc/nccAno9.webp',
    ].map((src, i) => (
      <div
        key={i}
        className="group rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition duration-300"
      >
        
        <Image
          src={src}
          alt="NCC"
          width={600}
          height={400}
          unoptimized
          className="w-full h-[260px] object-cover group-hover:scale-105 transition duration-300"
        />

      </div>
    ))}

  </div>
</div>

</div>
          {/* <div className="m-auto w-3/4 lg:p-12 md:p-8 sm:p-4 mt-7 grid sm:grid-cols-2 grid grid-cols-1 gap-4 ">
            <Image
              unoptimized={true}
              src={'/ncc/nccAno13.webp'}
              width={700}
              height={400}
              alt={'Social Initiative'}
              className=" bgImage_1 w-10/12 rounded-l-2xl ml-auto mt-auto "
              data-aos="fade-right"
            />
            <Image
              unoptimized={true}
              src={'/ncc/ncc2.webp'}
              width={700}
              height={150}
              alt={'Social Initiative'}
              className=" bgImage rounded-r-2xl m-auto   "
              data-aos="fade-left"
            />
            <Image
              unoptimized={true}
              src={'/ncc/ncc4.webp'}
              width={700}
              height={150}
              alt={'Social Initiative'}
              className=" bgImage rounded-l-2xl m-auto  "
              data-aos="fade-up"
            />
            <Image
              unoptimized={true}
              src={'/about/social-initiative/4.webp'}
              width={700}
              height={150}
              alt={'Social Initiative'}
              className="  rounded-r-2xl  bgImage_1 sm:order-4 order-3 mr-auto mb-auto  "
              data-aos="fade-down"
            />
            <Image
              unoptimized={true}
              src={'/ncc/nccAno12.webp'}
              width={700}
              height={150}
              alt={'Social Initiative'}
              className=" bgImage_1 w-10/12 rounded-l-2xl ml-auto mt-auto "
              data-aos="fade-right"
            />
            <Image
              unoptimized={true}
              src={'/ncc/nccAno9.webp'}
              width={700}
              height={150}
              alt={'Social Initiative'}
              className=" bgImage rounded-r-2xl m-auto   "
              data-aos="fade-left"
            />
          </div> */}
        </div>
      </section>
    </>
  );
};

export default NccAno;
