'use client';

import Image from 'next/image';

const Eligibility = ({ EligibilityTable = [{}] }) => {
  return (
    <>
      {/* Admission Procedure */}
      <div className=" md:p-2 p-0   ">
        <h2 className="text-center">Eligibility Criteria</h2>

        <div className="md:w-[80%] w-[100%] m-auto">
          <div className="overflow-x-auto ">
            <table className="table-auto   rounded-xl ">
              <thead>
                <tr className="bg-primary text-whiteCol p-4">
                  <th className="p-4">Name of Course</th>
                  <th className="p-4">Duration</th>
                  <th className="p-4">Branch/ specialization</th>
                  <th className="p-4">Eligibility</th>
                  <th className="p-4">Relaxation</th>
                </tr>
              </thead>
              <tbody>
                {EligibilityTable.map((data: any, index: any) => (
                  <tr
                    key={index}
                    className="p-2 border border-gray-dark odd:bg-gray"
                  >
                    <td className="p-2 border-2 border-gray-dark">
                      {data.name}
                    </td>
                    <td className="p-2 border-2 border-gray-dark">
                      {data.duration}
                    </td>
                    <td className="p-2 border-2 border-gray-dark">
                      {data.specialization}
                    </td>
                    <td className="p-2 border-2 border-gray-dark">
                      {data.eligibility}
                    </td>
                    <td className="p-2 border-2 border-gray-dark">
                      {data.relaxation}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
};

export default Eligibility;
