'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../../common/button';
import { international_sec, stateOfArt } from '../../constant/constant';
import { inDoorGames } from '../../constant/campusLife';
const gymPhotos = [
  {
    title: 'Gym ',
    image: '/campusLife/gym.webp',
  },
  {
    title: 'Gym ',
    image: '/campusLife/gym2.webp',
  },
  {
    title: 'Gym ',
    image: '/campusLife/gym2.webp',
  },
  {
    title: 'Gym ',
    image: '/campusLife/gym3.webp',
  },
  {
    title: 'Gym ',
    image: '/campusLife/gym4.webp',
  },
  {
    title: 'Gym ',
    image: '/campusLife/gym5.webp',
  },
  {
    title: 'Gym ',
    image: '/campusLife/gym6.webp',
  },
  {
    title: 'Gym ',
    image: '/campusLife/gym7.webp',
  },
];

const Gym = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        {/* why BBS */}

        <div className="w-[80vw] p-5   relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              src={'/campusLife/gym.webp'}
              width={1400}
              height={400}
              alt={'BBS Gym'}
              unoptimized={true}
              className=" bgImage_about mb-4 "
            />
          </div>

          <div className="grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary">
            {gymPhotos.map((game: any, index) => (
              <>
                <div key={index}>
                  <Image
                    src={game.image}
                    unoptimized={true}
                    width={400}
                    height={400}
                    alt={'Gym'}
                    className="  bgImageIndoor rounded-lg "
                  />
                </div>
              </>
            ))}
          </div>
          <h1 className="">Gym</h1>
          <h4 className="text-justify">
            &emsp;&emsp; For a proper study we should have a healthy body. If
            you want to protect your brain, you might as well protect the rest
            of your body as well, right. BBS college has a Gym which has all the
            required equipment. The students do exercise under the supervision
            of an expert coach.
          </h4>
        </div>
      </div>
    </>
  );
};

export default Gym;
