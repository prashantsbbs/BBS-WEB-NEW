'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../../common/button';
import { international_sec, stateOfArt } from '../../constant/constant';
import { inDoorGames } from '../../constant/campusLife';
const medicalFacilities = [
  {
    title: 'medicalFacilities',
    image: '/campusLife/medical8.webp',
  },

  {
    title: 'medicalFacilities',
    image: '/campusLife/medical9.webp',
  },
  {
    title: 'medicalFacilities',
    image: '/campusLife/medical5.webp',
  },
  {
    title: 'medicalFacilities',
    image: '/campusLife/medical6.webp',
  },
  {
    title: 'medicalFacilities',
    image: '/campusLife/medical2.webp',
  },
  {
    title: 'medicalFacilities',
    image: '/campusLife/medical4.webp',
  },
  {
    title: 'medicalFacilities',
    image: '/campusLife/medical7.webp',
  },
  {
    title: 'medicalFacilities',
    image: '/campusLife/medical9.webp',
  },
];

const MedicalFacilities = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        <div className="w-[80vw] p-5   relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              src={'/campusLife/medicalFacility.webp'}
              width={1400}
              unoptimized={true}
              height={400}
              alt={'Campus medical Facilities'}
              className=" bgImage_about mb-4 "
            />
          </div>

          <h1 className="">Medical Facilities</h1>
          <h4 className="text-justify">
            &emsp;&emsp; The future of India, of any country for that matter,
            lies with its youth. BBS Group of Institutions has taken on the
            onerous responsibility of imparting comprehensive and high quality
            education, which is both vocational-based, as well as professional
            in nature to the young minds who desire to be part of the booming
            world economy in general and Indian economy in particular.
            <br />
            <br />
            &emsp;&emsp; A sound mind and creative intellect can only flourish
            in a healthy body. Just as important a good teacher is for
            stimulating the mind of a student or a sports instructor for
            physical fitness, there is a crucial role of a physician to keep the
            body healthy and disease-free.
            <br />
            <br />
            &emsp;&emsp; The essential objective of this medical facilities is
            to maintain a holistic approach to the physical well-being of our
            students, faculty and support staff. We aim to offer 24x7 prompt and
            effective medical, surgical and psychosocial support to all workers
            and residents.
            <br />
            <br />
            &emsp;&emsp; Routine complaints like coughs, colds, seasonal fevers,
            rashes, cuts, bruises, sprains, asthmatic attacks, and fainting fits
            are attended within the ambit of our existing facilities. Anything
            of a more serious nature is referred to a higher centre in
            Prayagraj. Serious patients are invariably accompanied by a Nurse
            (in the case of females), Nursing Aide or Doctor. A fully equipped
            ambulance is always on stand-by to take students for referral or
            even ferry them to or from the Dispensary within the extensive
            college campus. Students are also sent for routine investigations to
            Prayagraj in case of unrelenting fevers or suspected fractures.
          </h4>

          <div className="grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary">
            {medicalFacilities.map((game: any, index) => (
              <>
                <div key={index}>
                  <Image
                    src={game.image}
                    unoptimized={true}
                    width={400}
                    height={400}
                    alt={'Medical Facilities'}
                    className="  bgImageIndoor rounded-lg "
                  />
                </div>
              </>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default MedicalFacilities;
