'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../../common/button';
import { international_sec, stateOfArt } from '../../constant/constant';
import { inDoorGames } from '../../constant/campusLife';
const hostel = [
  {
    title: 'lecture',
    image: '/campusLife/hostel/1.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/hostel/2.webp',
  },

  {
    title: 'lecture',
    image: '/campusLife/hostel/3.webp',
  },

  {
    title: 'lecture',
    image: '/campusLife/hostel/4.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/hostel/5.webp',
  },
  {
    title: 'lecture',
    image: '/campusLife/hostel_3.webp',
  },

  {
    title: 'lecture',
    image: '/campusLife/hostel/7.webp',
  },

  {
    title: 'lecture',
    image: '/campusLife/hostel/8.webp',
  },
];

const Hostel = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        <div className="w-[80vw] p-5   relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              src={'/campusLife/hostel_3.webp'}
              width={1400}
              height={400}
              alt={'BBS Hostel'}
              unoptimized={true}
              className=" bgImage_about mb-4 "
            />
          </div>

          <div className="grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary ">
            {hostel.map((game: any, index) => (
              <>
                <div key={index}>
                  <Image
                    src={game.image}
                    width={400}
                    height={400}
                    alt={'Hostel'}
                    unoptimized={true}
                    className="  bgImageIndoor rounded-lg "
                  />
                </div>
              </>
            ))}
          </div>
          <h1 className="">Our Hostel</h1>
          <h4 className="text-justify">
            &emsp;&emsp; &emsp;&emsp; Hundreds of students from all across the
            country live in the hostels, which comes closest to being &#39;a
            home away from home&#39;. Institutions provides well-furnished
            hostel facility to its outstation candidates. The campus hostels are
            surrounded by lush green lawns and playing fields. The separate
            facilities for boys and girls, caring wardens and a tight security
            ensures a pleasant stay allowing you to focus on your academics. The
            hostels have complete power backup. Facilities for indoor games like
            TT, carom, chess, Television etc. are also available.
            <br />
            <br />
            &emsp;&emsp; A warden / hostel in-charge looks after the
            administration of the hostel. Students enjoy a homely and
            comfortable stay with a sense of camaraderie and fraternity.
            Hygienic, quality food prepared by professionally-qualified cooks is
            provided to the students in the hostel canteen. Meals provided in
            the hostel mess are wholesome and nourishing. The mess caters to the
            tastes of the students with varied culinary preferences from
            different regions. The mess menu is planned and managed by the
            students in consultation with the caterer and the management.
            <br />
            <br />
            &emsp;&emsp; Students also get a highly professional on-campus
            laundry service. Whilst internet access and STD facilities ensure
            close contact with family and friends outside, the fully equipped
            common rooms allow for that relaxed time with friends on Campus.
            <br />
            <br />
            &emsp;&emsp; The campus has strict security through CCTV cameras,
            fire warning systems, 24-hour guards. For total care for in any
            emergencies, we have our own dispensaries with best doctors and
            nurses.
            <br />
            <br />
            &emsp;&emsp; Students are provided TV, Newspapers etc. all the
            hostels have in-door games like, Carom, Badminton, TT
            <br />
            <br />
            &emsp;&emsp; Each room has a wedge-shaped bay window that provides
            protection from the sun and lets in natural light at the same time.
          </h4>
        </div>
      </div>
    </>
  );
};

export default Hostel;
