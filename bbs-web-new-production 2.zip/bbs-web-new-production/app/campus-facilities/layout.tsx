'use client';
import Image from 'next/image';
import 'animate.css';
import Breadcrumb from '../common/breadcurb';
import { useContext, useEffect, useState } from 'react';
import MedicalFacilities from './medical-facilities/page';
import Hostel from './hostel/page';
import Gym from './gym/page';
import Cafeteria from './cafeteria/page';
import TransportFacility from './transport-facility/page';
import { usePathname } from 'next/navigation';
import Link from 'next/link';

const CampusFailities = ({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) => {
  const defaultState: any = {
    activeHead: 0,
  };

  const [state, setState] = useState(defaultState);

  const heads = [
    {
      title: 'Medical Facilities',
      active: 0,
      url: '/campus-facilities/medical-facilities',
    },
    { title: 'Hostel', active: 1, url: '/campus-facilities/hostel' },
    { title: 'Gym', active: 2, url: '/campus-facilities/gym' },
    { title: 'Cafeteria', active: 3, url: '/campus-facilities/cafeteria' },
    {
      title: 'Transport Facility',
      active: 4,
      url: '/campus-facilities/transport-facility',
    },
  ];

  let pathname = usePathname();

  useEffect(() => {
    heads.map((page: any) => {
      if (pathname === page.url) {
        setState((prev: any) => ({ ...prev, activeHead: page.active }));
      }
    });
  }, [pathname]);

  const handleActiveMenu = (activeMenu: any, url: any) => {
    setState((prev: any) => ({ ...prev, activeHead: activeMenu }));
  };

  return (
    <>
      <div className="bg-gray ">
        <Breadcrumb componentName={'Campus Facility'} />

        <div className="bg-primary text-whiteCol py-5 ">
          <div className="flex md:flex-row flex-col text-center justify-between items-center	 w-3/4 m-auto   cursor-pointer ">
            {heads.map((head, index) => (
              <div key={index}>
                <Link href={head.url}>
                  <h3
                    className="px-4 my-2"
                    onClick={() => handleActiveMenu(index, head.url)}
                  >
                    {head.active !== state.activeHead ? (
                      head.title
                    ) : (
                      <div className="bg-secondary animate__animated animate__fadeInLeft rounded-md m-0 px-2 py-1 m-auto w-max	 text-primary">
                        {head.title}
                      </div>
                    )}
                  </h3>
                </Link>
              </div>
            ))}
          </div>
        </div>

        {children}
      </div>
    </>
  );
};

export default CampusFailities;
