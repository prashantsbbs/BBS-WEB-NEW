'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../../common/button';
import { international_sec, stateOfArt } from '../../constant/constant';
import { inDoorGames } from '../../constant/campusLife';

const TransportFacility = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        <div className="w-[80vw] p-5   relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              src={'/campusLife/transportFacility.webp'}
              width={1400}
              unoptimized={true}
              height={400}
              alt={'Transport Facility'}
              className=" bgImage_about mb-4 "
            />
          </div>

          <h1 className="">Transport Facility</h1>
          <h4 className="text-justify">
            &emsp;&emsp; The Institutions has a fleet of luxury AC Buses and
            Non-AC Deluxe buses providing transport facility to the students of
            Prayagraj region. BBS owns the fleet of buses along with 16 contract
            buses. College buses are equipped with all safety devices i.e. GPS,
            to track the bus location, Route, Speed etc. and speed governor to
            restrict the speed of the buses as per the Supreme Court guidelines,
            Fire Extinguisher and First Aid Kit. From the safety point of view,
            Buses of BBS Institutions board (at the time of departure from
            Campus) and de-board (after arrival at campus) the students inside
            the campus premises only. Students are allowed to board or de-board
            the bus at the scheduled stops only. We also allot seat numbers to
            every transport-facility user on the basis of first-come-first-serve
            (the student deposit the transport fee first, gets the seat first).
            Transport ID Card is valid for one Academic Session of the
            respective Institute. Transport fee is collected one time in advance
            for the whole academic session at the time of availing transport
            facility.
          </h4>
        </div>
      </div>
    </>
  );
};

export default TransportFacility;
