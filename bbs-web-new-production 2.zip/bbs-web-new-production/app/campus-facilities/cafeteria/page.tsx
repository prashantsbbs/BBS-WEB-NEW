'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../../common/button';
import { international_sec, stateOfArt } from '../../constant/constant';
import { inDoorGames } from '../../constant/campusLife';
const cafeteria = [
  {
    title: 'Cafeteria ',
    image: '/campusLife/caffe/1.webp',
  },
  {
    title: 'Cafeteria ',
    image: '/campusLife/caffe/2.webp',
  },

  {
    title: 'Cafeteria ',
    image: '/campusLife/caffe/3.webp',
  },
  {
    title: 'Cafeteria ',
    image: '/campusLife/cafe5.webp',
  },
  {
    title: 'Cafeteria ',
    image: '/campusLife/cafe6.webp',
  },
  {
    title: 'Cafeteria ',
    image: '/campusLife/cafe7.webp',
  },
  {
    title: 'Cafeteria ',
    image: '/campusLife/cafe8.webp',
  },
  {
    title: 'Cafeteria ',
    image: '/campusLife/cafe9.webp',
  },
];

const Cafeteria = () => {
  return (
    <>
      <div className="bg-gray pb-6">
        {/* why BBS */}

        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <div className="m-auto   animate__animated animate__slideInLeft">
            <Image
              src={'/campusLife/caffe/banner.webp'}
              width={1400}
              height={400}
              alt={'Cafeteria'}
              unoptimized={true}
              className=" bgImage_about "
            />
          </div>

          <h1 className="">Cafeteria</h1>
          <h4 className="text-justify">
            &emsp;&emsp; For students to grow mentally, physical growth is
            mandatory. They need proper nourishment which is only possible
            through Balanced Diet. Keeping that in mind all the cafeterias have
            menu that are planned by a group of expert dieticians which provide
            them healthy and nutritious food. We understand that students have
            cravings for snacks every now and then but we ensure that they
            don&#39;t eat junk. The food provided in cafeteria is hygienic and
            vegetarian. We have cafeterias in campus that helps the students to
            fulfil their cravings as and when they want. The cafeteria offers a
            good menu of multi-cuisine delights, amidst a lively, jolly
            atmosphere.
          </h4>

          <div className="grid lg:grid-cols-4 sm:grid-cols-2 gap-12 h-bg-primary">
            {cafeteria.map((game: any, index) => (
              <>
                <div key={index}>
                  <Image
                    src={game.image}
                    width={400}
                    height={400}
                    unoptimized={true}
                    alt={'BBS Cafeteria'}
                    className="  bgImageIndoor rounded-lg "
                  />
                </div>
              </>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Cafeteria;
