'use client';
import Image from 'next/image';
import 'animate.css';
import ButtonCustom from '../common/button';
import { international_sec, stateOfArt } from '../constant/constant';
import { useEffect } from 'react';
import { useState } from 'react';
import Arrow from '../common/arrow';

const BeniMadhav = () => {
  const colleges = [
    { name: 'BBS College of Engineering and Technology (BBSCET) code: 138' },
    { name: 'BBS College of Pharmacy and Polytechnic (BBSCPP) code: 4528 ' },
    { name: 'BBS Institute of Professional Studies (BBSIPS)' },
    { name: 'BBS Institute of Law (BBSIL)' },
    { name: 'Smt. Janki Devi Girls Inter College' },
    { name: 'Beni Madhav Singh Degree College' },
  ];

  const defaultState = {
    mobileBanner: false,
  };

  const [state, setState] = useState(defaultState);

  const getBodyWidth = (evt: any) => {
    if (evt.target.innerWidth < 768) {
      setState((prev: any) => ({ mobileBanner: true }));
    } else setState((prev: any) => ({ mobileBanner: false }));
  };

  useEffect(() => {
    if (window) {
      window.addEventListener('resize', getBodyWidth);
      const screenWidth = window.screen.width;

      if (screenWidth < 768) {
        setState((prev: any) => ({ mobileBanner: true }));
      } else setState((prev: any) => ({ mobileBanner: false }));
    }
    return () => window && window.removeEventListener('resize', getBodyWidth);
  }, []);

  return (
    <>
      <div className="bg-gray ">
        {/* why BBS */}
        <div className="m-auto   animate__animated animate__slideInLeft">
          {state.mobileBanner ? (
            <Image
              unoptimized={true}
              src={'/banner/bannerAboutM.webp'}
              width={1000}
              height={1000}
              alt={'Banner About'}
              className=" bgImage_aboutM   "
            />
          ) : (
            <Image
              unoptimized={true}
              src={'/banner/bannerAbout.webp'}
              width={1400}
              height={1000}
              alt={'Banner About'}
              className=" bgImage_aboutD   "
            />
          )}
        </div>

        <div className="w-[80vw] p-5  relative z-10 rounded-xl m-auto md:-mt-15 -mt-5 shadow-md bg-whiteCol ">
          <h1 className="text-pink">BENI MADHAV SHIKSHA SAMITI</h1>
          <h4 className="text-justify">
            &emsp;&emsp;Beni Madhav Shiksha Samiti has been diligently committed
            to the noble cause of fostering educational institutions since its
            inception in 1983, under the visionary leadership of the Late Bhola
            Singh ji, a stalwart in the realm of social reform. Guided by his
            unwavering dedication, the samiti has strived to create avenues for
            quality education, empowering countless individuals to realize their
            potential and contribute to society.
            <br />
            <br />
            &emsp;&emsp;Today, continuing the illustrious legacy of her esteemed
            father, Mrs. Madhuri Singh gracefully shoulders the responsibility
            of chairmanship. Her steadfast leadership and commitment to
            excellence uphold the values and vision of the samiti, ensuring its
            continued success in shaping the future of education. Under her
            guidance, the samiti remains steadfast in its mission to provide
            accessible and high-quality education, thereby enriching lives and
            fostering societal progress. <br />
            <br />
          </h4>
          <h2>
            Institutions established under the auspices of the samiti include:
          </h2>

          {colleges.map((list: any, index) => (
            <div key={index} className="flex gap-4">
              <Arrow />
              <h3>{list.name}</h3>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default BeniMadhav;
