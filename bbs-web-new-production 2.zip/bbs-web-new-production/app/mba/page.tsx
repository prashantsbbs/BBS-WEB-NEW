'use client';
import Image from 'next/image';
import 'animate.css';
import Arrow from '../common/arrow';
import ScrollTrigger from 'react-scroll-trigger';
import { useEffect, useState } from 'react';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import MasterCourse from '../eligibility-criteria/masterCourse';
import SwiperComponent from '../home/congracts-section/swiper';
import CourseSlider from '../common/courseSlider';
import FutureReadyEng from '../common/futureReadyEng';
import AppService from '../services';
import Head from 'next/head';
import SeoWrapper from '../common/SeoWrapper';

const careerProspectus = [
  'Finance Manager',
  'Market Research Analyst',
  'Product Manager',
  'Media Planner',
  'Financial Manager/Analyst',
  'Credit Analyst',
  'HR Generalist',
  'HR Analyst',
  'Operations Manager',
  'Accounting Officer',
  'Business Analyst',
  'Project Manager',
];

const programHighlights = [
  {
    point:
      'Advisory board made up of high court judges, senior advocates in the Supreme Court, and in-house counsels for business corporations Court, and In-house counsels of business corporations.',
  },
  {
    point:
      'A dedicated library of School of Law, in addition to the main university library.',
  },
  {
    point:
      'A dedicated Employability, Placement, and Career Advancement Cell to help students develop a high employability index (HEI).',
  },
  {
    point: 'The curriculum is contemporary and emphasizes hands-on experience.',
  },
  { point: 'Dedicated center for training in Corporate and Business Laws.' },
  {
    point:
      'Literary and Debate Committee to develop elocution and oratory skills.',
  },
  {
    point:
      'Moot court session, MUN, and Parliamentary debates for hands-on experience.',
  },
];

const faculty = [
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
];

const defaultState = {
  isLoading: false,
  facultyList: [],
};

const departmentId = 10;

const Mba = () => {
  const defaultAnimation = {
    courseOverview: false,
    highlights: false,
  };

  const [animationStart, setAnimationStart] = useState(defaultAnimation);

  const [state, setState] = useState(defaultState);
  const fetchFacultyList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getFacultyList();
    if (!error) {
      // Rehan Code for Category Filtering
      const facultyList = data.filter(
        (item: any) => item?.attributes?.department?.data?.id === departmentId
      );

      setState((prevState) => ({
        ...prevState,
        facultyList,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchFacultyList();
  }, []);

  return (
    <>
      <SeoWrapper
        title="Top Choice for Students | Best MBA College in UP"
        description="BBS College is listed among the best MBA colleges in UP. Gain hands-on learning, electives, and career guidance to succeed in business and management."
      >
        {/* Hero Sectino */}
        <section>
          <div className="handleoverlflow w-[80%] m-auto grid md:grid-cols-2 grid-cols-1 justify-center items-center md:px-6 px-3 py-12">
            <div>
              <Image
                unoptimized={true}
                src={'/courses/mba-icon.webp'}
                width={90}
                height={20}
                alt="Mba Icon"
                className="animate__animated animate__fadeInLeftBig my-4 rotateAnimate"
              />
              <div>
                <h2 className="">PG Degree</h2>
                <div className="bg-secondary h-2 w-full"></div>
              </div>
              <h1 className="m-0">
                MBA <br /> Master of Business Administration{' '}
              </h1>
            </div>

            <div className="md:p-8 p-4">
              <Image
                unoptimized={true}
                src={'/courses/mba.webp'}
                width={600}
                height={20}
                alt="MBA"
                className="animate__animated animate__fadeInRight rounded-lg"
              />
            </div>
          </div>
        </section>

        {/* Course Overveiw */}

        <section className="bg-gray handleoverlflow">
          <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-24 px-6">
            <div data-aos="fade-right" className={`p-6 `}>
              <div>
                <h2>COURSE OVERVIEW</h2>
                <h4 className="text-justify">
                  At BBS College, we run an MBA program that teaches simple,
                  useful business skills. We are listed among the top 10 best
                  MBA colleges in UP for our teaching and practical training. As
                  a private college, we keep our fee structure clear so students
                  can plan their money and choices without surprise.
                </h4>
                <h4 className="text-justify">
                  Our course covers all the main areas of business. Students
                  learn finance, marketing, operations, human resources, and
                  strategy. We also offer a long list of electives so each
                  student can pick subjects that match their career goals.
                </h4>
                <h4 className="text-justify">
                  We mix classroom learning with real work. Students do
                  internships, company visits, live projects, and attend guest
                  lectures from industry leaders. This hands-on work builds real
                  skills and industry knowledge.
                </h4>
                <h4 className="text-justify">
                  Our career services help with placement and guidance.
                  Graduates take roles in pharma, banking, IT, and many other
                  fields. We focus on making students ready for leadership. Join
                  our MBA to grow your business skills, expand your professional
                  network, and improve job opportunities.
                </h4>
              </div>

              <div className=""></div>
            </div>

            <div className={`m-auto `} data-aos="fade-left">
              <div className="bg-secondary p-4 m-4 md:mr-12">
                <div className="p-4">
                  <h3 className="m-0">Duration</h3>
                  <h2 className="m-0">2 Years</h2>
                </div>
                <div className="p-4">
                  <h3 className="m-0">Programme Name</h3>
                  <h2 className="m-0">MBA</h2>
                </div>
              </div>
              <div className="bg-primary text-whiteCol p-4 m-4 md:ml-12">
                <div className="p-4">
                  <h2 className="m-0">Eligibility</h2>

                  <h5 className="text-justify mt-0">
                    Passed 10+2 examination with at least 50% marks in any
                    stream.
                  </h5>
                </div>
                <div className="p-4">
                  <Link href={'apply-online'} target="blank">
                    <ButtonCustom
                      btnColor={'secondary'}
                      btnText={'Apply Online'}
                      textCol={'primary'}
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Program Highliths */}

        <section className="md:p-12 py-6 " data-aos="zoom-in-up">
          <div className="w-[80%] m-auto bg-primary p-6 text-whiteCol">
            <div>
              <h2 className="text-secondary">Programme Highlights</h2>
              <div
                className={` columns-1 
                            ${
                              animationStart.highlights
                                ? 'animate__animated animate__fadeInRight animate__slower'
                                : ''
                            }`}
              >
                <h4 className="text-justify">
                  MBA curriculum is carefully designed to ensure a balance
                  between theoretical knowledge and practical application.
                  Students engage in rigorous coursework that combines lectures,
                  case studies, group projects, and interactive discussions to
                  ensure they develop critical thinking, problem-solving, and
                  decision-making skills. The program also focuses on ethical
                  leadership, effective communication, and a global perspective,
                  preparing students to lead with integrity in a diverse and
                  interconnected business environment. One of the great features
                  of the MBA program is that it has a faculty comprised of
                  renowned academics and experienced industry professionals.
                  These acclaimed instructors bring a wealth of real-world
                  expertise to the classroom, bridging the gap between theory
                  and practice. Additionally,BBS group of institutions fosters a
                  collaborative and inclusive learning environment, encouraging
                  students to actively participate and learn from their peers.
                  Core areas of expertise include:{' '}
                </h4>
                <div className="flex gap-4">
                  <Arrow />
                  <h4>Marketing</h4>
                </div>
                <div className="flex gap-4">
                  <Arrow />
                  <h4>Human Resource Management </h4>
                </div>
                <div className="flex gap-4">
                  <Arrow />
                  <h4>Information Technology </h4>
                </div>
                <div className="flex gap-4">
                  <Arrow />
                  <h4>International Business etc. </h4>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Future Ready */}
        <FutureReadyEng
          department={
            <>
              Department of <br />
              Master of Business Administration
            </>
          }
          image={'/futureReady/mbaCenter.webp'}
          format={'jpg'}
        />

        {/* Advanced Options of Study */}
        {/* <ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}> */}
        <section data-aos="fade-up-right" className="md:p-12 py-6  bg-gray">
          <div className="w-[80%] m-auto bg-secondary rounded-xl p-6 text-whiteCol">
            <div>
              <h2 className="text-primary  text-center">Career Prospects</h2>
              <div className=" grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3   m-auto ">
                {careerProspectus.map((career: any, index) => (
                  <h3
                    key={index}
                    className="bg-whiteCol rounded-md drop-shadow-md px-6 py-2
                    text-primary m-0"
                  >
                    {career}
                  </h3>
                ))}
              </div>
            </div>
          </div>
        </section>
        {/* </ScrollTrigger> */}

        {/* Top Recruiters */}
        <div className="mt-12">
          <RecruitersComapnies />
        </div>

        {/* Eligibility  */}
        {/* <div className="md:p-12 p-8 ">
        <Eligibility EligibilityTable={EligibilityTable} />
      </div> */}

        {/* Faculty  */}
        {!!state.facultyList.length && (
          <div className="  bg-primary flex">
            <div className="lg:w-[85%] w-[90%] m-auto md:p-16 p-4  ">
              <h2 className="m-auto text-secondary text-center p-4">
                Our Faculty
              </h2>
              <CourseSlider elements={state.facultyList} />
            </div>
          </div>
        )}
      </SeoWrapper>
    </>
  );
};
export default Mba;
