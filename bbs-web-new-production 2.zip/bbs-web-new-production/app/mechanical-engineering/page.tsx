'use client';
import Image from 'next/image';
import 'animate.css';
import Arrow from '../common/arrow';
import ScrollTrigger from 'react-scroll-trigger';
import { useEffect, useState } from 'react';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import MasterCourse from '../eligibility-criteria/masterCourse';

import SwiperComponent from '../home/congracts-section/swiper';
import CourseSlider from '../common/courseSlider';
import FutureReadyEng from '../common/futureReadyEng';
import AppService from '../services';
import SeoWrapper from '../common/SeoWrapper';

const programHighlights = [
  {
    highlight:
      'Hands-on Learning: Emphasis on practical experience and application of mechanical engineering principles through laboratory experiments, workshops, and industry internships.',
  },
  {
    highlight:
      'Industry Integration: Collaboration with leading mechanical engineering companies for internships, industrial visits, and live projects, providing students with real-world exposure and experience.',
  },
  {
    highlight:
      'Skill Enhancement: Offering specialized courses and training in areas such as thermal engineering, fluid mechanics, and machine design to develop technical expertise and problem-solving skills.',
  },
  {
    highlight:
      'Innovation and Research: Encouraging innovation and research in mechanical engineering through project-based learning, seminars, and participation in national and international conferences and competitions.',
  },
  {
    highlight:
      'Global Outlook: Exposure to global trends and emerging technologies in mechanical engineering through guest lectures by industry experts, international exchange programs, and collaboration with foreign universities.',
  },
];

const careerProspectus = [
  'Automotive Engineer',
  'Maintenance Engineer',
  'Research And Development Supervisor',
  'Construction Engineer',
  'Manufacturing Engineer',
  'Control And Instrumentation Engineer',
  'Mechanical Engineer',
];

const majorTrack = [
  { track: 'Design and Simulation' },
  { track: 'Robotics and Automation' },
  { track: 'Energy' },
  { track: 'Manufacturing and Automation' },
  { track: 'Automotive Engineering' },
];

const faculty = [
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
];

const defaultState = {
  isLoading: false,
  facultyList: [],
};

const departmentId = 4;
const MechanicalEngineering = () => {
  const defaultAnimation = {
    courseOverview: false,
    highlights: false,
  };

  const [animationStart, setAnimationStart] = useState(defaultAnimation);

  const onEnterViewport = () => {
    setAnimationStart((prev) => ({
      ...prev,
      courseOverview: true,
      highlights: true,
    }));
  };

  const onExitViewport = () => {
    setAnimationStart((prev) => ({
      ...prev,
      courseOverview: true,
      highlights: true,
    }));
  };

  const [state, setState] = useState(defaultState);
  const fetchFacultyList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getFacultyList();
    if (!error) {
      // Rehan Code for Category Filtering
      const facultyList = data.filter(
        (item: any) => item?.attributes?.department?.data?.id === departmentId
      );

      setState((prevState) => ({
        ...prevState,
        facultyList,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchFacultyList();
  }, []);
  return (
    <>
      <SeoWrapper
        title="Best Mechanical Engineering College in UP | B.Tech Program"
        description="BBS College of Engineering offers B.Tech Mechanical Engineering at the best mechanical engineering college in UP with hands-on projects, industry training, and career support."
      >
        {/* Hero Sectino */}
        <section>
          <div className="handleoverlflow w-[80%] m-auto grid md:grid-cols-2 grid-cols-1 justify-center items-center md:px-6 px-3 py-12">
            <div>
              <Image
                unoptimized={true}
                src={'/courses/mechanical-icon.webp'}
                width={90}
                height={20}
                alt="Mechanical Icon"
                className="animate__animated animate__fadeInLeftBig my-4 rotateAnimate"
              />
              <div>
                <h2 className="">UG Degree</h2>
                <div className="bg-secondary h-2 w-full"></div>
              </div>
              <h1 className="m-0">
                B.Tech. <br /> Mechanical Engineering
              </h1>
            </div>

            <div className="md:p-8 p-4">
              <Image
                unoptimized={true}
                src={'/courses/mechnical.webp'}
                width={600}
                height={20}
                alt="Mechnical"
                className="animate__animated animate__fadeInRight rounded-lg"
              />
            </div>
          </div>
        </section>

        {/* Course Overveiw */}

        <section className="bg-gray handleoverlflow">
          <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-24 px-6">
            <div data-aos="fade-right" className={`p-6 `}>
              <div>
                <h2>COURSE OVERVIEW</h2>
                <h4 className="text-justify">
                  &emsp;&emsp;The B.Tech Mechanical Engineering program at the
                  best mechanical engineering college in UP equips students to
                  design and develop a wide range of equipment, from automobile
                  engines and air conditioning systems to medical devices and
                  e-mobility solutions.
                  <br />
                  <br />
                  &emsp;&emsp;Students gain practical experience through
                  industry projects, research initiatives, industry tours, and
                  rural exposure programs, preparing them to work with complex
                  mechanical systems in fields like biomedicine, aviation,
                  energy, manufacturing, automation, IoT, and artificial
                  intelligence.
                  <br />
                  <br />
                  &emsp;&emsp;This program is offered by a top mechanical
                  engineering college in UP, known for its experienced faculty
                  and strong focus on innovation and hands-on learning.
                </h4>
              </div>

              <div className="">
                <h2 className="uppercase">Major Tracks</h2>
                <div className="grid md:grid-cols-2 grid-cols-1">
                  {majorTrack.map((item, index) => (
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h3 className="m-2">{item.track}</h3>
                    </div>
                  ))}
                </div>
              </div>
              <div className="">
                <h2 className="uppercase">Advanced Options of Study</h2>
                <div className="grid md:grid-cols-2 grid-cols-1">
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">M.Tech.</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">MBA</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">Other PG Course</h3>
                  </div>
                </div>
              </div>
            </div>

            <div className={`m-auto `} data-aos="fade-left">
              <div className="bg-secondary p-4 m-4 md:mr-12">
                <div className="p-4">
                  <h3 className="m-0">Duration</h3>
                  <h2 className="m-0">4 Years</h2>
                </div>
                <div className="p-4">
                  <h3 className="m-0">Programme Name</h3>
                  <h2 className="m-0">B.Tech Mechanical Engineering</h2>
                </div>
              </div>
              <div className="bg-primary text-whiteCol p-4 m-4 md:ml-12">
                <div className="p-4">
                  <h2 className="m-0">Eligibility</h2>
                  <h3 className="mb-0 text-secondary uppercase">B. Tech.</h3>
                  <h5 className="text-justify mt-0">
                    Passed 10+2 examination with Physics and Mathematics as
                    compulsory subjects along with Chemistry / Computer Science.
                    With at least 50% marks in the above subjects, taken
                    together and 50% marks overall
                  </h5>
                  <h3 className="mb-0 text-secondary uppercase">
                    B. Tech. (Lateral Entry).
                  </h3>
                  <h5 className="text-justify m-0">
                    With at least 50% in 3 years Diploma recognized by Board of
                    Technical Education / University or B Sc (PCM)
                  </h5>
                </div>
                <div className="p-4">
                  <Link href={'apply-online'} target="blank">
                    <ButtonCustom
                      btnColor={'secondary'}
                      btnText={'Apply Online'}
                      textCol={'primary'}
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Program Highliths */}

        <section className="md:p-12 py-6 " data-aos="zoom-in-up">
          <div className="w-[80%] m-auto bg-primary p-6 text-whiteCol">
            <div>
              <h2 className="text-secondary">Programme Highlights</h2>
              <div
                className={`md:columns-2 columns-1 
                            ${
                              animationStart.highlights
                                ? 'animate__animated animate__fadeInRight animate__slower'
                                : ''
                            }`}
              >
                {programHighlights.map((list: any, index) => (
                  <>
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h4 className="m-2">{list.highlight}</h4>
                    </div>
                  </>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Future Ready */}
        <FutureReadyEng
          department={
            <>
              Department of <br />
              Mechanical Engineering
            </>
          }
          image={'/futureReady/meCenter.webp'}
          format={'jpg'}
        />

        {/* Advanced Options of Study */}
        <section data-aos="fade-up-right" className="md:p-12 py-6  bg-gray">
          <div className="w-[80%] m-auto bg-secondary rounded-xl p-6 text-whiteCol">
            <div>
              <h2 className="text-primary  text-center">Career Prospects</h2>
              <div className=" grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3   m-auto ">
                {careerProspectus.map((career: any, index) => (
                  <h3
                    key={index}
                    className="bg-whiteCol rounded-md drop-shadow-md px-6 py-2
                    text-primary m-0"
                  >
                    {career}
                  </h3>
                ))}
              </div>
            </div>
          </div>
        </section>
        {/* </ScrollTrigger> */}

        {/* Top Recruiters */}
        <div className="mt-12">
          <RecruitersComapnies />
        </div>

        {/* Eligibility  */}

        {/* Faculty  */}
        {!!state.facultyList.length && (
          <div className="  bg-primary flex">
            <div className="lg:w-[85%] w-[90%] m-auto md:p-16 p-4  ">
              <h2 className="m-auto text-secondary text-center p-4">
                Our Faculty
              </h2>
              <CourseSlider elements={state.facultyList} />
            </div>
          </div>
        )}
      </SeoWrapper>{' '}
    </>
  );
};
export default MechanicalEngineering;
