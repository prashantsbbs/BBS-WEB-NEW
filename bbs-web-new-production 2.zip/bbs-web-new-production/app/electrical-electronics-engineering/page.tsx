'use client';
import Image from 'next/image';
import 'animate.css';
import Arrow from '../common/arrow';
import ScrollTrigger from 'react-scroll-trigger';
import { useEffect, useState } from 'react';
import ButtonCustom from '../common/button';
import Link from 'next/link';
import RecruitersComapnies from '../apply-online/RecruitersCompanies';
import MasterCourse from '../eligibility-criteria/masterCourse';

import SwiperComponent from '../home/congracts-section/swiper';
import CourseSlider from '../common/courseSlider';
import FutureReadyEng from '../common/futureReadyEng';
import AppService from '../services';
import SeoWrapper from '../common/SeoWrapper';

const programHighlights = [
  {
    highlight:
      'Practical Learning: Our program emphasizes hands-on experience and practical application of electrical and electronics engineering concepts through laboratory experiments, projects, and industrial training.',
  },
  {
    highlight:
      'Industry Collaboration: We partner with leading electrical and electronics companies to offer internships, industrial visits, and collaborative projects, providing students with invaluable exposure to real-world challenges and solutions.',
  },
  {
    highlight:
      'Specialized Training: Students receive specialized training in areas such as power systems, control systems, and electronics design, enabling them to develop expertise in their chosen field of study.',
  },
  {
    highlight:
      'Research and Innovation: Our curriculum fosters a culture of innovation and research, with opportunities for students to engage in cutting-edge projects, seminars, and conferences, and contribute to advancements in the field.',
  },
  {
    highlight:
      'Global Perspective: We provide students with a global outlook by exposing them to international best practices, emerging technologies, and cross-cultural experiences through guest lectures, exchange programs, and collaboration with universities abroad.',
  },
];

const careerProspectus = [
  'Junior Engineer (JE)',
  'Scientist / Engineer',
  'Power Plant Engineer',
  'Telecommunications Engineer',
  'Electrical Design Engineer',
  'Instrumentation Engineer',
  'Micro Electrical Engineer',
  'Controls Engineer',
  'Test Engineer',
  'Electrical Project Manager',
];

const majorTrack = [
  { track: 'Design and Simulation' },
  { track: 'Robotics and Automation' },
  { track: 'Energy' },
  { track: 'Manufacturing and Automation' },
  { track: 'Automotive Engineering' },
];

const faculty = [
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
  {
    title: 'Mr. Rajat Singh',
    avatar: '/courses/dummyImage.webp',
    description: 'Lecturer',
    subDescription: 'Physics Department',
  },
];

const defaultState = {
  isLoading: false,
  facultyList: [],
};

const departmentId = 5;
const ElectricalEngineering = () => {
  const defaultAnimation = {
    courseOverview: false,
    highlights: false,
  };

  const [animationStart, setAnimationStart] = useState(defaultAnimation);

  const onEnterViewport = () => {
    setAnimationStart((prev) => ({
      ...prev,
      courseOverview: true,
      highlights: true,
    }));
  };

  const onExitViewport = () => {
    setAnimationStart((prev) => ({
      ...prev,
      courseOverview: true,
      highlights: true,
    }));
  };

  const [state, setState] = useState(defaultState);
  const fetchFacultyList = async () => {
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const { data, error } = await AppService.getFacultyList();
    if (!error) {
      // Rehan Code for Category Filtering
      const facultyList = data.filter(
        (item: any) => item?.attributes?.department?.data?.id === departmentId
      );

      setState((prevState) => ({
        ...prevState,
        facultyList,
      }));
    }
    setState((prevState) => ({ ...prevState, isLoading: false }));
  };

  useEffect(() => {
    fetchFacultyList();
  }, []);

  return (
    <>
      <SeoWrapper
        title="Best Electrical Engineering College in UP | B.Tech Program"
        description="Study B.Tech EEE at BBS College, a leading electrical engineering college in UP, with hands-on learning, projects, and skills for energy, automotive, and telecom careers."
      >
        {/* Hero Sectino */}
        <section>
          <div className="handleoverlflow w-[80%] m-auto grid md:grid-cols-2 grid-cols-1 justify-center items-center md:px-6 px-3 py-12">
            <div>
              <Image
                unoptimized={true}
                src={'/courses/electronic-icon.webp'}
                width={90}
                height={20}
                alt="Electronic Icon"
                className="animate__animated animate__fadeInLeftBig my-4 rotateAnimate"
              />
              <div>
                <h2 className="">UG Degree</h2>
                <div className="bg-secondary h-2 w-full"></div>
              </div>
              <h1 className="m-0">
                B.Tech. <br /> Electrical & Electronics Engineering
              </h1>
            </div>

            <div className="md:p-8 p-4">
              <Image
                unoptimized={true}
                src={'/courses/electronics.webp'}
                width={600}
                height={20}
                alt="Electronics"
                className="animate__animated animate__fadeInRight rounded-lg"
              />
            </div>
          </div>
        </section>

        {/* Course Overveiw */}

        <section className="bg-gray handleoverlflow">
          <div className="grid md:grid-cols-2 grid-cols-1 gap-6 md:px-24 px-6">
            <div data-aos="fade-right" className={`p-6 `}>
              <div>
                <h2>COURSE OVERVIEW</h2>
                <h4 className="text-justify">
                  &emsp;&emsp;The Bachelor of Technology in Electrical and
                  Electronic Engineering (B. Tech EEE) is his four-year
                  bachelor&apos;s degree program that combines electrical and
                  electronic engineering principles to design and develop
                  electrical systems, devices, and equipment. This program
                  provides students with the technical skills and knowledge
                  necessary to work in a variety of fields such as energy
                  systems, telecommunications, control systems, and automation.
                  <br />
                  <br />
                  &emsp;&emsp;The B. Tech EEE program curriculum is designed to
                  provide students with a solid foundation in the fundamentals
                  of electrical and electronic engineering. Coursework includes
                  topics such as circuit analysis, signals and systems,
                  electromagnetic fields, power electronics, and control
                  systems. Additionally, students gain practical experience
                  through laboratory sessions, internships, and projects,
                  allowing them to apply their theoretical knowledge to
                  real-world situations.
                  <br />
                  <br />
                  &emsp;&emsp;Graduates of the B. Tech EEE program can pursue
                  successful careers in a variety of industries, including
                  energy, telecommunications, automotive, and aerospace. They
                  can work as designers, project managers, research and
                  development engineers, and technical consultants. The demand
                  for electrical and electronic engineers is expected to
                  increase in the coming years as the use of technology
                  increases across industries.
                  <br />
                  <br />
                  &emsp;&emsp;In addition to technical skills, the program also
                  focuses on developing soft skills such as communication,
                  teamwork, leadership, and problem solving. These skills are
                  essential for success in the workplace and for furthering
                  higher education and research.
                  <br />
                  <br />
                  &emsp;&emsp;Overall, B.Tech EEE is an excellent course for
                  students interested in a career in electrical and electronic
                  engineering, and BBS is recognized as a leading electrical
                  engineering college in UP for students aiming to build a
                  strong career in this field.
                </h4>
              </div>

              <div className="">
                <h2 className="uppercase">Major Tracks</h2>
                <div className="grid md:grid-cols-2 grid-cols-1">
                  {majorTrack.map((item, index) => (
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h3 className="m-2">{item.track}</h3>
                    </div>
                  ))}
                </div>
              </div>
              <div className="">
                <h2 className="uppercase">Advanced Options of Study</h2>
                <div className="grid md:grid-cols-2 grid-cols-1">
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">M.Tech.</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">MBA</h3>
                  </div>
                  <div className="flex gap-3">
                    <Arrow />
                    <h3 className="m-2">Other PG Course</h3>
                  </div>
                </div>
              </div>
            </div>

            <div className={`m-auto `} data-aos="fade-left">
              <div className="bg-secondary p-4 m-4 md:mr-12">
                <div className="p-4">
                  <h3 className="m-0">Duration</h3>
                  <h2 className="m-0">4 Years</h2>
                </div>
                <div className="p-4">
                  <h3 className="m-0">Programme Name</h3>
                  <h2 className="m-0">
                    B.Tech. Electrical & Electronics Engineering
                  </h2>
                </div>
              </div>
              <div className="bg-primary text-whiteCol p-4 m-4 md:ml-12">
                <div className="p-4">
                  <h2 className="m-0">Eligibility</h2>
                  <h3 className="mb-0 text-secondary uppercase">B. Tech.</h3>
                  <h5 className="text-justify mt-0">
                    Passed 10+2 examination with Physics and Mathematics as
                    compulsory subjects along with Chemistry / Computer Science.
                    With at least 50% marks in the above subjects, taken
                    together and 50% marks overall
                  </h5>
                  <h3 className="mb-0 text-secondary uppercase">
                    B. Tech. (Lateral Entry).
                  </h3>
                  <h5 className="text-justify m-0">
                    With at least 50% in 3 years Diploma recognized by Board of
                    Technical Education / University or B Sc (PCM)
                  </h5>
                </div>
                <div className="p-4">
                  <Link href={'apply-online'} target="blank">
                    <ButtonCustom
                      btnColor={'secondary'}
                      btnText={'Apply Online'}
                      textCol={'primary'}
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Program Highliths */}

        <section className="md:p-12 py-6 " data-aos="zoom-in-up">
          <div className="w-[80%] m-auto bg-primary p-6 text-whiteCol">
            <div>
              <h2 className="text-secondary">Programme Highlights</h2>
              <div
                className={`md:columns-2 columns-1 
                            ${
                              animationStart.highlights
                                ? 'animate__animated animate__fadeInRight animate__slower'
                                : ''
                            }`}
              >
                {programHighlights.map((list: any, index) => (
                  <>
                    <div key={index} className="flex gap-3">
                      <Arrow />
                      <h4 className="m-2">{list.highlight}</h4>
                    </div>
                  </>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Future Ready */}
        <FutureReadyEng
          department={
            <>
              Department of <br />
              Electrical & Electronics Engineering
            </>
          }
          image={'/futureReady/eeeCenter.webp'}
          format={'jpg'}
        />

        {/* Advanced Options of Study */}
        {/* <ScrollTrigger onEnter={onEnterViewport} onExit={onExitViewport}> */}
        <section data-aos="fade-up-right" className="md:p-12 py-6  bg-gray">
          <div className="w-[80%] m-auto bg-secondary rounded-xl p-6 text-whiteCol">
            <div>
              <h2 className="text-primary  text-center">Career Prospects</h2>
              <div className=" grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-3   m-auto ">
                {careerProspectus.map((career: any, index) => (
                  <h3
                    key={index}
                    className="bg-whiteCol rounded-md drop-shadow-md px-6 py-2
                    text-primary m-0"
                  >
                    {career}
                  </h3>
                ))}
              </div>
            </div>
          </div>
        </section>
        {/* </ScrollTrigger> */}

        {/* Top Recruiters */}
        <div className="mt-12">
          <RecruitersComapnies />
        </div>

        {/* Eligibility  */}
        {/* <div className="md:p-12 p-8 ">
        <Eligibility EligibilityTable={EligibilityTable} />
      </div> */}

        {/* Faculty  */}
        {!!state.facultyList.length && (
          <div className="  bg-primary flex">
            <div className="lg:w-[85%] w-[90%] m-auto md:p-16 p-4  ">
              <h2 className="m-auto text-secondary text-center p-4">
                Our Faculty
              </h2>
              <CourseSlider elements={state.facultyList} />
            </div>
          </div>
        )}
      </SeoWrapper>
    </>
  );
};
export default ElectricalEngineering;
